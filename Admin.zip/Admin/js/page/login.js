var loginObj = {
    needCode: false,
    needAuth:false,
    secretKey:null
  };
  if(window.top !== window.self){ 
    window.top.location = window.location;
  }
  /**
   * 
   * @param {name} 用户名
   * @param {pwd} 密码
   * @param {code} 验证码
   * @param {authCode} 授权码
   */
  function check_login(name, pwd, code,authCode) {
    var obj = {};
    obj.account = name;
    obj.password = pwd;
    obj.captcha = code;
    obj.longinadds = location.host;
    obj.authCode = authCode;
    if(loginObj.secretKey)obj.secretKey = loginObj.secretKey;
    if(loginObj.needAuth && !authCode){
      layer.msg('授权码不能为空');
      $('#author').focus();
      return false;
    }
    var index=layer.msg('跳转中...',{icon:16,shade:0.01,time:200000});
    ajaxService.doPost("/login/login.mvc", obj, function(res) {
      layer.close(index);
      if (res && res.code == 200) {
        location.href = "./index.html";
      } else {
        $("#code").val();
        getConfig();
        if (res.code == 303) {
          layer.msg("验证码错误，请重新输入");
          getImgcode();
          $("#code").focus();
        } else if (res.code == 402) {
          layer.msg("登录失败，请检查密码和账号是否正确");
        } else if(res.code==401){
          layer.msg('授权码错误,请重新输入');
          $("#author").focus();
        }else if(res.code==409){
          layer.msg("登录失败(409),请联系管理员");
        }else{
          layer.msg(res.msg ? res.msg : '登录请求错误');
        }
      }
    });
    return false;
  }
  
  function getConfig() {
    ajaxService.doGet("/login/login-config.mvc", null, function(res) {
      if (res.httpCode == 200) {
        // $(".code-div").show();
        // getImgcode();
        loginObj.needCode = res.needValidateCode;
        loginObj.needAuth = res.needAuth;
      } else {
        loginObj.needCode = true;
        loginObj.needAuth = true;
      }
      if(!loginObj.needCode){
        $(".code-div").hide();
      }else{
        $(".code-div").show();
        getImgcode();
      }
      if(loginObj.needAuth){
        $('.author-div').show()
      }else{
        $('.author-div').hide()
      }
    });
  }
  // 获取验证码
  function getImgcode() {
    $("#imgCode").attr("src", "/captcha/code.mvc?" + Math.random());
  }
  //授权码获取
  function initAuthQrCode() {
    var userName=$("#user_name").val();
    ajaxService.doGet('/login/auth-data.mvc',{account:userName},function(res){
        var authData=res.authData;
        if(authData != null){
            loginObj.secretKey=authData.secretKey;
            $("#qrCode").show();
            $("#qrCodeContext").html("");
            $("#qrCodeContext").qrcode({
                width: 150, //宽度
                height:150, //高度
                text: authData.url
            });
        }else {
            $("#qrCode").hide();
            loginObj.secretKey=null;
        }
    });
  }
  $(function() {
    getConfig();
    //获取验证码
    $("#qrCodeContext").click(function () {
        initAuthQrCode();
    });
    $("#user_name").blur(function(){
      if(loginObj.needAuth ==false){
        return false;
      }
      var userName=$("#user_name").val();
      if(userName.trim()==""){
        $("#qrCode").hide();
        return;
      }
      initAuthQrCode();
    });
    //登录
    $("#login").click(function(e) {
      e.preventDefault();
      var name = $("#user_name").val();
      var pwd = $("#password").val();
      var code = $("#code").val();
      var authCode = $("#author").val();
      if (name && pwd) {
        check_login(name, pwd, code,authCode);
      } else {
        if (!name) {
          layer.msg("请输入用户名");
        } else if (!pwd) {
          layer.msg("请输入密码");
        }
        return false;
      }
    });
    $("#imgCode").click(function() {
      getImgcode();
    });
  });
  