var htmlTpl = {
  addHtml: `
    <form class="layui-form mask-box level" lay-filter="add">
      <div class="layui-form-item">
        <div class="layui-inline layui-username">
          <label class="layui-form-label">用户账号</label>
          <div class="layui-input-block">
            <input type="text" name="username" class="layui-input layui-username" lay-verify="required"/>
          </div>
        </div>
        <div class="layui-inline layui-enddate">
          <label class="layui-form-label">开始日期</label>
          <div class="layui-input-block">
            <input type="text" name="statisticsTime_begin" class="layui-input" lay-verify="required" id='layui-endDate'/>
          </div>
        </div>
        <div class="layui-inline layui-startdate">
          <label class="layui-form-label">修复日期</label>
          <div class="layui-input-block">
            <input type="text" name="updatetime" class="layui-input" lay-verify="required" id='layui-addDate'/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`
};
