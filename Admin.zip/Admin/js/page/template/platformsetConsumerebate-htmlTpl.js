var htmlTpl = {
  addHtml: `
    <form class="layui-form mask-box level" lay-filter="add">
      <div class="layui-form-item">
        <label class="layui-form-label">返利类型</label>
        <div class="layui-input-block">
          <select name="type" class="layui-type" lay-verify="required"></select>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">起始金额</label>
        <div class="layui-input-block">
          <input type="text" name="beginamt" class="layui-input" lay-verify="required|number" autocomplete='off' maxlength="30"/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">截止金额</label>
        <div class="layui-input-block">
          <input type="text" name="endamt" class="layui-input layui-date" lay-verify="required|number" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">级数</label>
        <div class="layui-input-block">
          <input type="text" name="rebatelevel" class="layui-input layui-date" lay-verify="required|number" autocomplete='off' />
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">返利金额</label>
        <div class="layui-input-block">
          <input type="text" name="rebateamt" class="layui-input layui-date" lay-verify="required" autocomplete='off' placeholder="例(级数是2级，则输入10,5)"/>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`
};
