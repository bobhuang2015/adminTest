var htmlTpl = {
  detailHtml: `
    <form class="layui-form mask-box bank-open" lay-filter="add">
      <div class="layui-form-item">
        <table class="layui-table first-table" lay-size="sm"></table>
        <div style="margin-top:10px;"></div>
        <table class="layui-table second-table" lay-size="sm"> </table>
        <div style="margin-top:10px;"></div>
        <table class="layui-table third-table" lay-size="sm"> </table>
      </div>
    </form>`,
    zhuiHtml: `
      <form class="layui-form mask-box bank-open" lay-filter="zhui">
        <div class="layui-form-item">
          <table class="layui-table zhui-table" lay-size="sm"></table>
        </div>
      </form>`,
};
