var htmlTpl = {
  stepFirstHtml:`
  <form class="layui-form mask-box level" lay-filter="first">  
    <div class="layui-input-inline select-box">
      <label class="layui-form-label" style="width:auto;">活动类型</label>
      <div class="layui-input-inline layui-type-box">
        <select name="type" class="layui-type" lay-verify="required" lay-filter="type"></select>
      </div>
    </div>
    <div class="layui-input-inline select-box">
      <label class="layui-form-label" style="width:auto;">活动模板</label>
      <div class="layui-input-inline">
        <select name="template" lay-verify="required" >
          <option value="1">模板1</option>
        </select>
      </div>
    </div>
    <div class="layui-preview-box" style="width:600px;height:400px;line-height:400px;text-align:center;margin:10px 0;overflow-y:scroll;cursor:zoom-in"><img /></div>
    <div class="layui-form-item">
      <div class="layui-input-block" style="margin-left:15px;">
        <div class="layui-block" style="float:left;">
          <input type="radio" name="client" title="PC预览" value="PC" lay-skin="primary" checked lay-filter="preview">
          <input type="radio" name="client" title="APP预览" value="APP" lay-skin="primary" lay-filter="preview">
        </div>
        <button class="layui-btn" lay-submit lay-filter="formFirst" style="float:right;margin-right:30px;display:none;">下一步</button>
      </div>
    </div>
  </form>`,
  stepSecondHtml: `
  <form class="layui-form mask-box layui-promotion-box" lay-filter="second" style="padding:20px 0 20px 20px;">
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">活动标题</label>
        <div class="layui-input-block">
          <input type="text" name="title" class="layui-input" lay-verify="required" maxlength="20"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">活动排序</label>
        <div class="layui-input-block">
          <input type="text" name="sort" class="layui-input" lay-verify="required|number" maxlength="3"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">展示端</label>
        <div class="layui-input-block">
          <input type="checkbox" name="isDisplayPc" class="layui-input" checked title="PC" lay-skin="primary" lay-filter="PC"/>
          <input type="checkbox" name="isDisplayH5" class="layui-input" checked title="H5" lay-skin="primary" lay-filter="H5"/>
          <input type="checkbox" name="isDisplayIos" class="layui-input" checked title="iOS" lay-skin="primary" lay-filter="iOS"/>
          <input type="checkbox" name="isDisplayAndroid" class="layui-input" checked title="Android" lay-skin="primary" lay-filter="Android"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">活动标签</label>
        <div class="layui-input-block layui-label-box">
          <div class="layui-inline">
            <input type="text" name="label1" placeholder="标签1" autocomplete="off" maxlength="3" class="layui-input layui-inline label-input">
            <div class="select-box">
              <select name="labelSelect1">
                <option value="1">样式一</option>
                <option value="2">样式二</option>
                <option value="3">样式三</option>
                <option value="4">样式四</option>
              </select>
            </div>
          </div>
          <div class="layui-inline">
            <input type="text" name="label2" placeholder="标签2" autocomplete="off" maxlength="3" class="layui-input layui-inline label-input">
            <div class="select-box">
              <select name="labelSelect2">
                <option value="1">样式一</option>
                <option value="2">样式二</option>
                <option value="3">样式三</option>
                <option value="4">样式四</option>
              </select>
            </div>
          </div>
          <div class="layui-inline">
            <input type="text" name="label3" placeholder="标签3" autocomplete="off" maxlength="3" class="layui-input layui-inline label-input">
            <div class="select-box">
              <select name="labelSelect3">
                <option value="1">样式一</option>
                <option value="2">样式二</option>
                <option value="3">样式三</option>
                <option value="4">样式四</option>
              </select>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">展示时间</label>
        <div class="layui-input-block">
          <input type="text" class="layui-input layui-date" id="layui-showTime" style="width:320px;" autocomplete="off" lay-verify="required" name="showTime">
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">活动时间</label>
        <div class="layui-input-inline">
          <input type="text" class="layui-input layui-date" id="layui-activeTime" style="width:320px;" autocomplete="off" lay-verify="required" name="activeTime">
        </div>
        <div class="layui-input-inline" style="margin-left:135px;">
          <input type="checkbox" name="isDoingDate" class="layui-input"  title="前台显示该项" lay-skin="primary">
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">活动对象</label>
        <div class="layui-input-inline" style="width:320px;">
          <select name="memberType" lay-verify="required">
            <option value="1">全体会员</option>
            <option value="2">其他</option>
          </select>
        </div>
        <div class="layui-input-inline" style="margin-left:5px;">
          <input type="checkbox" name="isMemberType" class="layui-input"  title="前台显示该项" lay-skin="primary">
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">派奖方式</label>
        <div class="layui-input-inline" style="width:320px;">
          <select name="receiveType" lay-verify="required">
            <option value>请选择</option>
            <option value="1">自动派奖</option>
            <option value="2">人工派奖</option>
          </select>
        </div>
      </div>
    </div>
    <div id="special-box">
      <div class="layui-form-item layui-fanwei">
        <label class="layui-form-label">活动范围</label>
        <div class="layui-input-block fanwei-list"></div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">活动内容</label>
          <div class="layui-input-block" style="width:520px;">
            <div class="layui-input-block" style="width:600px;height:180px;margin-left:0">
              <textarea class="layui-textarea" id="LAY_demo2" style="display: none"></textarea>
            </div>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">条件设置</label>
          <div class="layui-input-block" style="width:520px;">
            <div class="layui-input-block" style="margin-left:0;">
                <input type="checkbox" name="isDailyReset" class="layui-input"  title="每日重置" lay-skin="primary">
                <div class="layui-inline layui-first">
                  <input type="checkbox" name="isFirstRecharge" class="layui-input"  title="首次充值" lay-skin="primary" lay-filter="firstRecharge" checked >
                </div>
                <div class="layui-inline layui-ip">
                  <input type="checkbox" name="isIpCheck" class="layui-input"  title="IP限制" lay-skin="primary" lay-filter="firstRecharge">
                </div>
            </div>
            <div class="layui-input-block" style="margin-left:0">
              <div class="layui-other-box">
                <div class="layui-btn layui-btn-sm layui-add layui-btn-normal" data-id="0">添加</div>
                <table class="layui-table layui-other-table" lay-size="sm" style="width:600px;">
                  <thead class="layui-thead">
                    <tr>
                      <th style="width:40px;" class="layui-pos">档位</th>
                      <th class="layui-th-recharge">充值方式</th>
                      <th class="layui-th-amount">累充额度</th>
                      <th>可领次数</th>
                      <th>固定奖励</th>
                      <th class="layui-th-ratio">比例(充值额)</th>
                      <th>操作</th>
                    </tr> 
                  </thead>
                  <tbody class="layui-tbody"></tbody>
                </table>
              </div>
              
              <div class="layui-yinkui-box">
                盈利送
                <div class="layui-btn layui-btn-sm layui-add layui-btn-normal" data-id="1">添加</div>
                <table class="layui-table layui-yinkui-table" lay-size="sm" style="width:600px;">
                  <thead class="layui-thead">
                    <tr>
                      <th>满</th>
                      <th>送</th>
                      <th>领取次数</th>
                      <th>操作</th>
                    </tr> 
                  </thead>
                  <tbody class="layui-tbody" data-content="1"></tbody>
                </table>
              </div>
              <div class="layui-yinkui-box">
                亏损送
                <div class="layui-btn layui-btn-sm layui-add layui-btn-normal"  data-id="2">添加</div>
                <table class="layui-table layui-yinkui-table" lay-size="sm" style="width:600px;">
                  <thead class="layui-thead">
                    <tr>
                      <th>满</th>
                      <th>送</th>
                      <th>领取次数</th>
                      <th>操作</th>
                    </tr> 
                  </thead>
                  <tbody class="layui-tbody" data-content="2"></tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
       <div class="layui-form-item layui-withdrawal-amount">
      <div class="layui-inline">
        <label class="layui-form-label">提现金额</label>
        <div class="layui-input-block">
          <input type="text" name="bateTotal" class="layui-input" lay-verify="required" maxlength="20"/>
        </div>
      </div>
    </div>
      <div class="layui-form-item layui-other-set">
        <div class="layui-inline">
          <label class="layui-form-label">所需流水</label>
          <div class="layui-input-block layui-liushui">
            <div class="layui-input-inline layui-first-condition">
                <input type="checkbox"  class="layui-input layui-benjin"  title="本金" lay-skin="primary" checked lay-filter="benjin">
                <input type="text" name="principalRate" class="layui-input" maxlength="5" lay-verify="number" value="100"  style="width:100px;position:absolute;left:64px;top:0;">
                <div style="width:100px;position:absolute;left:170px;top:10px;">%</div>
            </div>
            <div class="layui-input-inline">
                <input type="checkbox"  class="layui-input layui-jiangli"  title="奖励" lay-skin="primary" checked lay-filter="jiangli">
                <input type="text" name="rewardRate" class="layui-input" lay-verify="number"  value="100" style="width:100px;position:absolute;left:64px;top:0;">
                <div style="width:100px;position:absolute;left:170px;top:10px;">%</div>
            </div>
          </div>
        </div>
      </div>
      <div class="layui-form-item layui-yinkui-set">
        <div class="layui-inline">
          <label class="layui-form-label">满足条件</label>
          <div class="layui-input-block layui-liushui">
            <div class="layui-input-inline">
                <input type="checkbox"  class="layui-input layui-benjin"  title="流水" lay-skin="primary" checked lay-filter="benjin">
                <input type="text" name="bateTotal" class="layui-input" maxlength="8" lay-verify="number" value="1000"  style="width:100px;position:absolute;left:64px;top:0;">
            </div>
            <div class="layui-input-inline" style="width:50px;width:10px;margin-left:-22px;line-height:34px;">或</div> 
            <div class="layui-input-inline">
                <input type="checkbox"  class="layui-input layui-jiangli"  title="存款" lay-skin="primary" checked lay-filter="jiangli">
                <input type="text" name="deposit" class="layui-input" lay-verify="number" maxlength="9" value="10000" style="width:100px;position:absolute;left:64px;top:0;">
            </div>
          </div>
        </div>
      </div>
      <div class="layui-form-item layui-yinkui-set">
        <div class="layui-inline">
          <label class="layui-form-label">所需流水</label>
          <div class="layui-input-block layui-liushui">
            <div class="layui-input-inline">
                <input type="checkbox"  class="layui-input layui-jiangli"  title="奖励" lay-skin="primary" checked lay-filter="jiangli">
                <input type="text" name="rewardRate" class="layui-input" lay-verify="number"  value="100" style="width:100px;position:absolute;left:64px;top:0;">
                <div style="width:100px;position:absolute;left:170px;top:10px;">%</div>
            </div>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">注意事项</label>
          <div class="layui-input-block" style="width:520px;">
            <div class="layui-input-block" style="width:600px;height:180px;margin-left:0">
              <textarea class="layui-textarea" id="LAY_demo1" style="display: none"></textarea>
            </div>
          </div>
        </div>
      </div>
    
    </div>
    <div class="layui-form-item layui-pc" style="margin-top:8px;">
      <label class="layui-form-label">PC图片路径</label>
      <div class="layui-input-block">
        <input type="text" name="headImgUrlPc" class="layui-input layui-imgurl" readonly autocomplete='off' style="width:482px;display:inline-block;" lay-verify="required"/>
        <button class='layui-btn layui-btn-operator layui-btn-normal' id="layui-upload-web" type="button">&nbsp;&nbsp;选择&nbsp;&nbsp;</button>
        <button class='layui-btn layui-btn-operator layui-btn-normal layui-preview'>预览图片</button>
      </div>
    </div>
    <div class="layui-form-item layui-app">
      <label class="layui-form-label" style="width:82px;">app图片路径</label>
      <div class="layui-input-block">
        <input type="text" name="headImgUrlApp" class="layui-input layui-imgurl" readonly autocomplete='off' style="width:482px;display:inline-block;margin-left:-2px;"/>
        <button class='layui-btn layui-btn-operator layui-btn-normal' id="layui-upload-app" type="button">&nbsp;&nbsp;选择&nbsp;&nbsp;</button>
        <button class='layui-btn layui-btn-operator layui-btn-normal layui-preview'>预览图片</button>
      </div>
    </div>
    <div class="layui-form-item layui-save-box" style="margin-top:20px;">
      <div class="layui-input-block">
        <button class="layui-btn" lay-submit lay-filter="formSecond">保存</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
      </div>
    </div>
  </form>`

};
