var htmlTpl = {
  addHtml: `
    <form class="layui-form mask-box bank" lay-filter="add">
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label bankname">出款银行</label>
          <div class="layui-input-block">
            <input type="text" name="bankname" class="layui-input" lay-verify="required" autocomplete="off"/>
          </div>
        </div>
        <div class="layui-inline">
          <label class="layui-form-label accountname">出款户名</label>
          <div class="layui-input-block">
            <input type="text" name="accountname" class="layui-input" lay-verify="required" autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label accountnumber">出款卡号</label>
          <div class="layui-input-block">
            <input type="text" name="accountnumber" class="layui-input" lay-verify="required|number" autocomplete="off"/>
          </div>
        </div>
        <div class="layui-inline">
          <label class="layui-form-label">余额</label>
          <div class="layui-input-block">
            <input type="text" name="balance" class="layui-input" lay-verify="required|number" autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`,
  transferHtml: `
    <form class="layui-form mask-box level" lay-filter="transfer">
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">银行名称</label>
          <div class="layui-input-block">
            <input type="text" name="tradingbank" class="layui-input" lay-verify="required"/>
          </div>
        </div>
        <div class="layui-inline">
          <label class="layui-form-label">开户名称</label>
          <div class="layui-input-block">
            <input type="text" name="tradingname" class="layui-input" lay-verify="required"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">银行卡号</label>
          <div class="layui-input-block">
            <input type="text" name="tradingnumber" class="layui-input" lay-verify="required|number"/>
          </div>
        </div>
        <div class="layui-inline transfer-box">
          <label class="layui-form-label">转入金额</label>
          <div class="layui-input-block">
            <input type="text" name="rukuan" class="layui-input" lay-verify="required|number"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">手续费</label>
        <div class="layui-input-block">
          <input type="text" name="handlingcharge" class="layui-input" lay-verify="required|number"/>
        </div>
      </div>
    </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formTransfer">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`
};
