var htmlTpl = {
  addHtml: `
    <form class="layui-form mask-box level" lay-filter="set">
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">是否启用</label>
          <div class="layui-input-block" style="margin-left:130px;">
            <select name="enabled"> 
              <option value="1">是</option>
              <option value="0">否</option>
            </select>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">赔率</label>
        <div class="layui-input-block">
          <input type="number" name="odds" class="layui-input" lay-verify="number" autocomplete='off' step='0.1'/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">返水</label>
        <div class="layui-input-block">
          <input type="number" name="water" class="layui-input" lay-verify="number" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">最小投注</label>
        <div class="layui-input-block">
          <input type="number" name="minbet" class="layui-input" lay-verify="number" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">最大投注</label>
        <div class="layui-input-block">
          <input type="number" name="maxbet" class="layui-input" lay-verify="number" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block" style="margin-left:130px;">
          <button class="layui-btn" lay-submit lay-filter="formSet">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`
};
