var htmlTpl = {
  lotteryHtml: `
    <form class="layui-form mask-box" lay-filter="lottery">
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">游戏类型</label>
          <div class="layui-input-block">
            <input type="text" name="gametypename" class="layui-input" disabled/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">期号</label>
          <div class="layui-input-block">
            <input type="text" name="issueno" class="layui-input" disabled/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">状态</label>
          <div class="layui-input-block">
            <input type="text" name="state" class="layui-input" disabled/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">开盘时间</label>
          <div class="layui-input-block">
            <input type="text" name="opentime" class="layui-input" disabled/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">封盘时间</label>
          <div class="layui-input-block">
            <input type="text" name="closetime" class="layui-input" disabled/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">开奖时间</label>
          <div class="layui-input-block">
            <input type="text" name="lotterydt" class="layui-input" disabled/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">开奖号码</label>
          <div class="layui-input-block">
            <input  type="text" class="layui-input layui-nums" lay-verify="required" style="font-size:20px;">
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formLottery">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`
};
