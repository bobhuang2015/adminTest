var htmlTpl = {
  addHtml: `
    <form class="layui-form mask-box level" lay-filter="add">
      <div class="layui-form-item">
          <label class="layui-form-label">平台名称</label>
          <div class="layui-input-inline">
            <select name="platform" lay-verify="required" class="layui-thirdPlat">
            </select>
          </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">是否开启</label>
        <div class="layui-input-inline">
          <select name="isOpen" lay-verify="required">
            <option value="1">是</option>
            <option value="0">否</option>
          </select>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">是否首页显示</label>
        <div class="layui-input-inline">
          <select name="isIndex" lay-verify="required">
            <option value="1">是</option>
            <option value="0">否</option>
          </select>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">玩法名称</label>
        <div class="layui-input-block">
          <input type="text" name="name" class="layui-input"  autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item layui-gameCode">
        <label class="layui-form-label">游戏编码</label>
        <div class="layui-input-block">
          <input type="text" name="gameCode" class="layui-input" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item layui-h5GameCode">
        <label class="layui-form-label">H5游戏编码</label>
        <div class="layui-input-block">
          <input type="text" name="h5GameCode" class="layui-input" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item layui-appGameCode">
        <label class="layui-form-label" style="font-size:12px;">app游戏编码</label>
        <div class="layui-input-block">
          <input type="text" name="appGameCode" class="layui-input" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">web图片路径</label>
        <div class="layui-input-block">
          <input type="text" name="webImgUrl" class="layui-input layui-imgurl" readonly autocomplete='off' style="width:300px;display:inline-block;"/>
          <button class='layui-btn layui-btn-operator layui-btn-normal' id="layui-upload-web" type="button">&nbsp;&nbsp;选择&nbsp;&nbsp;</button>
          <button class='layui-btn layui-btn-operator layui-btn-normal layui-preview'>预览图片</button>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">h5图片路径</label>
        <div class="layui-input-block">
          <input type="text" name="h5ImgUrl" class="layui-input layui-imgurl"  readonly autocomplete='off' style="width:300px;display:inline-block;"/>
          <button class='layui-btn layui-btn-operator layui-btn-normal' id="layui-upload-h5" type="button">&nbsp;&nbsp;选择&nbsp;&nbsp;</button>
          <button class='layui-btn layui-btn-operator layui-btn-normal layui-preview'>预览图片</button>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">app图片路径</label>
        <div class="layui-input-block">
          <input type="text" name="appImgUrl" class="layui-input layui-imgurl"  readonly autocomplete='off' style="width:300px;display:inline-block;"/>
          <button class='layui-btn layui-btn-operator layui-btn-normal' id="layui-upload-app" type="button">&nbsp;&nbsp;选择&nbsp;&nbsp;</button>
          <button class='layui-btn layui-btn-operator layui-btn-normal layui-preview'>预览图片</button>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">app方图片路径</label>
        <div class="layui-input-block">
          <input type="text" name="appImgUrlSquare" class="layui-input layui-imgurl" readonly autocomplete='off' style="width:300px;display:inline-block;"/>
          <button class='layui-btn layui-btn-operator layui-btn-normal' id="layui-upload-appSquare" type="button">&nbsp;&nbsp;选择&nbsp;&nbsp;</button>
          <button class='layui-btn layui-btn-operator layui-btn-normal layui-preview'>预览图片</button>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">是否支持web端</label>
        <div class="layui-input-inline">
          <select name="webSupport" lay-verify="required">
            <option value="1">是</option>
            <option value="0">否</option>
          </select>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">是否支持h5端</label>
        <div class="layui-input-inline">
          <select name="h5Support" lay-verify="required">
            <option value="1">是</option>
            <option value="0">否</option>
          </select>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">是否支持app端</label>
        <div class="layui-input-inline">
          <select name="appSupport" lay-verify="required">
            <option value="1">是</option>
            <option value="0">否</option>
          </select>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">是否热门</label>
        <div class="layui-input-inline">
          <select name="isHot" lay-verify="required">
            <option value="1">是</option>
            <option value="0">否</option>
          </select>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">app显示方式</label>
        <div class="layui-input-inline">
          <select name="appDisplayMode" lay-verify="required">
            <option value="0">竖屏</option>
            <option value="1">横屏</option>
          </select>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">备注类型</label>
        <div class="layui-input-inline">
          <select name="isIndex" lay-verify="required" lay-filter="isIndex">
            <option value="0">普通第三方玩法</option>
            <option value="1">首页第三方类别</option>
          </select>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">子玩法</label>
        <div class="layui-input-inline">
          <select name="subPlatform" lay-verify="required" id="layui-subPlatform"></select>
        </div>
      </div>
      <div class="layui-form-item" style="margin-left:20px;">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`
};
