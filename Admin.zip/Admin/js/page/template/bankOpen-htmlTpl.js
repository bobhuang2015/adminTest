var htmlTpl = {
  addHtml: `
    <form class="layui-form mask-box bank-open" lay-filter="add">
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">商户类型</label>
          <div class="layui-input-block">
            <select name="merchantType" lay-search="" class="merchantType"> 
              <option value="">选择商户</option>
            </select>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">银行名称</label>
          <div class="layui-input-block">
            <input type="text" name="name" class="layui-input" lay-verify="required"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">图标</label>
          <div class="layui-input-block">
            <input type="text" name="icon" class="layui-input" lay-verify="required"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">编码</label>
          <div class="layui-input-block">
            <input type="text" name="code" class="layui-input" lay-verify="required"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">银行登录地址</label>
          <div class="layui-input-block">
            <input type="text" name="url" class="layui-input" lay-verify="required"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">最低限额</label>
          <div class="layui-input-block">
            <input type="text" name="minlimit" class="layui-input" lay-verify="required"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">最高限额</label>
          <div class="layui-input-block">
            <input type="text" name="maxlimit" class="layui-input" lay-verify="required"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`
};
