var htmlTpl = {
  reviewHtml: `
    <form class="layui-form mask-box level" lay-filter="add">
      <div class="layui-form-item">
        <label class="layui-form-label">用户账号</label>
        <div class="layui-input-block">
          <input type="text" name="username" class="layui-input" lay-verify="required" disabled/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">派奖金额</label>
        <div class="layui-input-block">
          <input type="text" name="amount" class="layui-input" lay-verify="required" disabled/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">申请时间</label>
        <div class="layui-input-block">
          <input type="text" name="applyTime" class="layui-input layui-date" lay-verify="required" autocomplete='off' disabled/>
        </div>
      </div>
      <div class="layui-form-item layui-money">
        <label class="layui-form-label">账户余额</label>
        <div class="layui-input-block">
          <input type="text" name="balance" class="layui-input" lay-verify="required" disabled/>
        </div>
      </div>
      <div class="layui-form-item layui-remark">
        <label class="layui-form-label">备注</label>
        <div class="layui-input-block">
          <input type="text" name="remark" class="layui-input" lay-verify="required"/>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`
};
