var htmlTpl = {
  changeInfo: `
    <form class="layui-form mask-box layui-change" lay-filter="example">
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">用户账号</label>
          <div class="layui-input-block">
            <input type="text" name="username" class="layui-input" lay-verify="required" disabled/>
          </div>
        </div>
        <div class="layui-inline">
          <label class="layui-form-label">用户昵称</label>
          <div class="layui-input-block">
            <input type="text" name="nickname" class="layui-input"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">用户类型</label>
          <div class="layui-input-block">
            <select name="usertype">
              <option value="2">会员</option>
              <option value="1">代理</option>
            </select>
          </div>
        </div>
        <div class="layui-inline">
          <label class="layui-form-label">保留返点</label>
          <div class="layui-input-block">
            <input type="text" name="bonus" class="layui-input"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">是否关注</label>
          <div class="layui-input-block">
            <select name="isfollow">
              <option value="1">关注</option>
              <option value="0">不关注</option>
            </select>
          </div>
        </div>
        <div class="layui-inline">
          <label class="layui-form-label">是否继承</label>
          <div class="layui-input-block">
            <select name="isextends">
              <option value="1">是</option>
              <option value="0">否</option>
            </select>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">注册最低账户返点</label>
          <div class="layui-input-block">
            <input type="text" name="regMaxbonus" class="layui-input"/>
          </div>
        </div>
        <div class="layui-inline">
          <label class="layui-form-label">备注</label>
          <div class="layui-input-block">
            <input type="text" name="remark" class="layui-input"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">是否显示分享链接</label>
          <div class="layui-input-block">
            <select name="isshare">
              <option value="1">是</option>
              <option value="0">否</option>
            </select>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formLayer">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`,
  linkHtml: `<form class="layui-form mask-box" lay-filter="contact">
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">用户账号</label>
        <div class="layui-input-block">
          <input type="text" name="username" class="layui-input" lay-verify="required" disabled/>
        </div>
      </div>
      <div class="layui-inline">
        <label class="layui-form-label">用户昵称</label>
        <div class="layui-input-block">
          <input type="text" name="nickname" class="layui-input"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">邮箱</label>
        <div class="layui-input-block">
          <input type="text" name="email" class="layui-input" lay-verify="email"/>
        </div>
      </div>
      <div class="layui-inline">
        <label class="layui-form-label">QQ</label>
        <div class="layui-input-block">
          <input type="text" name="qq" class="layui-input" lay-verify="number"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">电话</label>
        <div class="layui-input-block">
          <input type="text" name="telephone" class="layui-input" lay-verify="number"/>
        </div>
      </div>
      <div class="layui-inline">
        <label class="layui-form-label">备注</label>
        <div class="layui-input-block">
          <input type="text" name="remark" class="layui-input"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-input-block">
        <button class="layui-btn" lay-submit lay-filter="formLayer">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
      </div>
    </div>
  </form>`,
  transferHtml: `<form class="layui-form mask-box" lay-filter="transfer">
    <div class="layui-form-item" pane="">
      <label class="layui-form-label">转账权限</label>
      <div class="layui-input-block">
        <input type="checkbox" name="like[1]" title="其他" value="1" lay-skin="primary"><input type="checkbox" name="like[2]" title="充值" value="2" lay-skin="primary"><input type="checkbox" name="like[3]" title="分红" value="3" lay-skin="primary"><input type="checkbox" name="like[4]" title="日工资" value="4" lay-skin="primary">
      </div>
      <div class="layui-form-item" style="margin-top:30px;">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formLayer">保存</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </div>
  </form>`,
  levelHtml: `<form class="layui-form mask-box level" lay-filter="level">
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">用户类型</label>
        <div class="layui-input-block">
          <input type="text" name="usertype" class="layui-input" lay-verify="required" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">层级</label>
        <div class="layui-input-block">
          <select name="userlevel" class="userLevel">
          </select>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">是否团队转移</label>
        <div class="layui-input-block">
          <select name="isteam">
            <option value="0">否</option>
            <option value="1">是</option>
          </select>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-input-block">
        <button class="layui-btn" lay-submit lay-filter="level">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
      </div>
    </div>
  </form>`,
  roleHtml: `<form class="layui-form mask-box" lay-filter="role">
    <div class="layui-form-item" pane="">
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">用户名称</label>
          <div class="layui-input-block">
            <input type="text" name="username" class="layui-input" lay-verify="required" disabled/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">关联账户</label>
          <div class="layui-input-block">
            <select name="usernameQuery">
              <option value="0">用户自己</option>
              <option value="1">下级代理</option>
              <option value="2">下级用户</option>
              <option value="4">用户所有下级</option>
            </select>
          </div>
        </div>
      </div>
      <label class="layui-form-label">转账权限</label>
      <div class="layui-input-block role-list"></div>
      <div class="layui-form-item" style="margin-top:30px;">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="role">保存</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </div>
  </form>`,
  thirdStatusHtml: `<p style="padding:10px 0 0 20px;font-size:12px;">仅用在用户开通第三方账户失败时使用</p><form class="layui-form mask-box" lay-filter="thirdStatus">
	<div class="layui-form-item">
		<div class="layui-inline">
			<label class="layui-form-label">用户账号</label>
			<div class="layui-input-block">
				<input type="text" name="username" class="layui-input" lay-verify="required" disabled/>
			</div>
		</div>
		<div class="layui-inline">
			<label class="layui-form-label">AG状态</label>
			<div class="layui-input-block">
				<select name="isAGState">
					<option value="0">未开通</option>
					<option value="1">已开通</option>
				</select>
			</div>
		</div>
	</div>
	<div class="layui-form-item">
		<div class="layui-inline">
			<label class="layui-form-label">BBIN状态</label>
			<div class="layui-input-block">
				<select name="isBBINState">
					<option value="0">未开通</option>
					<option value="1">开通</option>
				</select>
			</div>
		</div>
		<div class="layui-inline">
			<label class="layui-form-label">PT状态</label>
			<div class="layui-input-block">
				<select name="isPTState">
					<option value="0">未开通</option>
					<option value="1">已开通</option>
				</select>
			</div>
		</div>
	</div>
	<div class="layui-form-item">
		<div class="layui-inline">
			<label class="layui-form-label">MG状态</label>
			<div class="layui-input-block">
				<select name="isMGState">
					<option value="0">未开通</option>
					<option value="1">已开通</option>
				</select>
			</div>
		</div>
		<div class="layui-inline">
			<label class="layui-form-label">好利状态</label>
			<div class="layui-input-block">
				<select name="isLKState">
					<option value="0">未开通</option>
					<option value="1">已开通</option>
				</select>
			</div>
		</div>
	</div>
	<div class="layui-form-item">
		<div class="layui-inline">
			<label class="layui-form-label">VR状态</label>
			<div class="layui-input-block">
				<select name="isVRState">
					<option value="0">未开通</option>
					<option value="1">已开通</option>
				</select>
			</div>
		</div>
		<div class="layui-inline">
			<label class="layui-form-label">KY状态</label>
			<div class="layui-input-block">
				<select name="isKYState">
					<option value="0">未开通</option>
					<option value="1">已开通</option>
				</select>
			</div>
		</div>
	</div>
	<div class="layui-form-item">
		<div class="layui-inline">
			<label class="layui-form-label" style="font-size:13px;">BDB体育状态</label>
			<div class="layui-input-block">
				<select name="isXJState">
					<option value="0">未开通</option>
					<option value="1">已开通</option>
				</select>
			</div>
		</div>
		<div class="layui-inline">
			<label class="layui-form-label">SB状态</label>
			<div class="layui-input-block">
				<select name="isSBState">
					<option value="0">未开通</option>
					<option value="1">已开通</option>
				</select>
			</div>
		</div>
		<div class="layui-inline">
			<label class="layui-form-label">KX状态</label>
			<div class="layui-input-block">
				<select name="isKXState">
					<option value="0">未开通</option>
					<option value="1">已开通</option>
				</select>
			</div>
		</div>
		<div class="layui-inline">
			<label class="layui-form-label">BG状态</label>
			<div class="layui-input-block">
				<select name="isBGState">
					<option value="0">未开通</option>
					<option value="1">已开通</option>
				</select>
			</div>
		</div>
	</div>
	<div class="layui-form-item">
		<div class="layui-input-block">
			<button class="layui-btn" lay-submit lay-filter="thirdStatus">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
		</div>
	</div>
</form>`,
passwordHtml:`<form class="layui-form mask-box" lay-filter="password">
<div class="layui-form-item">
  <div class="layui-inline">
    <label class="layui-form-label">用户账号</label>
    <div class="layui-input-block">
      <input type="text" name="username" class="layui-input" lay-verify="required" disabled/>
    </div>
  </div>
  <div class="layui-inline">
    <label class="layui-form-label">用户类型</label>
    <div class="layui-input-block">
      <input type="text" name="usertype" class="layui-input" lay-verify="required" disabled/>
    </div>
  </div>
</div>
<div class="layui-form-item">
  <div class="layui-inline">
    <label class="layui-form-label">登录密码</label>
    <div class="layui-input-block">
      <input type="password" name="password" class="layui-input"/>
    </div>
  </div>
  <div class="layui-inline">
    <label class="layui-form-label">资金密码</label>
    <div class="layui-input-block">
      <input type="password" name="moneyPwd" class="layui-input"/>
    </div>
  </div>
</div>
<div class="layui-form-item">
  <div class="layui-input-block">
    <button class="layui-btn" lay-submit lay-filter="password">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
  </div>
</div>
</form>`,
makeLevelHtml:`<form class="layui-form mask-box" lay-filter="makeLevel">
<div class="layui-form-item">
  <div class="layui-inline">
    <label class="layui-form-label">转移用户</label>
    <div class="layui-input-block">
      <input type="text" name="username" class="layui-input" lay-verify="required" disabled style="width:475px;"/>
    </div>
  </div>
</div>
<div class="layui-form-item">
  <div class="layui-inline">
    <label class="layui-form-label">转移至层级</label>
    <div class="layui-input-block">
      <select name="userlevel" class="userLevel"></select>
    </div>
  </div>
</div>
<div class="layui-form-item">
  <div class="layui-input-block">
    <button class="layui-btn" lay-submit lay-filter="makeLevel">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
  </div>
</div>
</form>`,
setRole:`<div id="test12" class="demo-tree-more"></div>`,
walletHtml: `
<form class="layui-form mask-box bank-open" lay-filter="wallet" style="padding:0 20px 20px;">
  <div class="layui-form-item">
    <table class="layui-table wallet-table" lay-size="sm"></table>
  </div>
</form>`,
thirdChangeHtml:`
<form class="layui-form mask-box layui-third-change" lay-filter="third" style="padding:0 20px 20px;">
  <div class="layui-form-item">
    <div class="layui-inline">
      <label class="layui-form-label">用户名称</label>
      <div class="layui-input-block">
        <input type="text" name="username" class="layui-input" lay-verify="required" disabled/>
      </div>
    </div>
    <div class="layui-inline">
      <div class="layui-btn layui-btn-danger layui-btn-refreshBalance">刷新余额</div>
    </div>
  </div>
  
  <div class="layui-form-item layui-third-cancle" style="margin-left:585px;">
    <div class="layui-input-block">
      <a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">关闭</a>
    </div>
  </div>
</form>`
};
