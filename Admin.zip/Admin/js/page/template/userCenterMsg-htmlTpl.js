var htmlTpl = {
  addHtml: `
    <form class="layui-form mask-box level" lay-filter="add">
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">消息类型</label>
          <div class="layui-input-block">
          <select name="messagetype">
            <option value="1">用户消息</option>
          </select>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">消息标题</label>
        <div class="layui-input-block">
          <input type="text" name="messagetitle" class="layui-input" lay-verify="required" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">消息内容</label>
        <div class="layui-input-block">
          <textarea placeholder="请输入内容" class="layui-textarea" lay-verify="required" name="messagecontent" autocomplete='off'  style="resize:none;"/></textarea>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">收信人</label>
        <div class="layui-input-block">
          <input type="text" name="receivername" class="layui-input" lay-verify="required" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">收信人下级</label>
          <div class="layui-input-block">
            <input type="checkbox" name="receivernames"  lay-skin="primary" checked="checked" />
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`
};
