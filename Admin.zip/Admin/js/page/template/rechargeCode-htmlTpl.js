var htmlTpl = {
  addHtml: 
  `<form class="layui-form mask-box" lay-filter="add">
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">已完成打码额</label>
        <div class="layui-input-block">
          <input type="text" name="currentordersamount" class="layui-input layui-username" lay-verify="required" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">未完成打码额</label>
        <div class="layui-input-block">
          <input type="text" name="currentordersamount2" class="layui-input layui-userid" lay-verify="required" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">要求打码额</label>
        <div class="layui-input-block">
          <input type="text" name="demandordersamount" class="layui-input layui-balance" lay-verify="required" onkeyup="this.value=this.value.replace(/[^0-9.]/g,'')"  onblur="this.value=this.value.replace(/[^0-9.]/g,'')"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-input-block">
        <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
      </div>
    </div>
  </form>`
};
