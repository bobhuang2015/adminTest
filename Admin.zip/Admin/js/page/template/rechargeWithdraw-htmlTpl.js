var htmlTpl = {
  checkHtml: `
  <form class="layui-form layui-widthdraw" lay-filter="check">
    <div class="title">钱包金额</div>
    <div class="layui-category">
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">账户余额 :</label>
          <div class="layui-input-block">
            <input type="text" name="accountbalance" class="layui-input" readonly/>
          </div>
        </div>
        <div class="layui-inline">
          <label class="layui-form-label">系统充值总额 :</label>
          <div class="layui-input-block">
            <input type="text" name="systemmoneyin" class="layui-input" readonly/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">用户充值总额 :</label>
          <div class="layui-input-block">
            <input type="text" name="moneyinamount" class="layui-input" readonly/>
          </div>
        </div>
        <div class="layui-inline">
          <label class="layui-form-label">用户充值次数 :</label>
          <div class="layui-input-block">
            <input type="text" name="moneyincount" class="layui-input" readonly/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">上级转入总额 :</label>
          <div class="layui-input-block">
            <input type="text" name="transfermoneyintotal" class="layui-input" readonly/>
          </div>
        </div>
        <div class="layui-inline">
          <label class="layui-form-label">转给下级总额 :</label>
          <div class="layui-input-block">
            <input type="text" name="transfermoneyouttotal" class="layui-input" readonly/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">提现次数 :</label>
          <div class="layui-input-block">
            <input type="text" name="moneyoutcount" class="layui-input" readonly/>
          </div>
        </div>
        <div class="layui-inline">
          <label class="layui-form-label">提现累计金额 :</label>
          <div class="layui-input-block">
            <input type="text" name="withdrawdayamount" class="layui-input" readonly/>
          </div>
        </div>
      </div>
    </div>
    <div class="title">额度转换金额</div>
    <div class="layui-category">
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">游戏转入总额 :</label>
          <div class="layui-input-block">
            <input type="text" name="transferInTotal" class="layui-input" readonly/>
          </div>
        </div>
        <div class="layui-inline">
          <label class="layui-form-label">游戏转出总额 :</label>
          <div class="layui-input-block">
            <input type="text" name="transferOutTotal" class="layui-input" readonly/>
          </div>
        </div>
      </div>
    </div>
    <div class="title">平台游戏</div>
    <div class="layui-category layui-third">
      
    </div>
    <div class="layui-form-item" style='float:right;margin:15px 77px 20px 0;'>
      <div class="layui-input-block">
        <a class="layui-btn layui-layer-close" href="javascript:;" style="line-height:38px;">关闭</a>
      </div>
    </div>
  </form>`,
  refuseHtml: `
    <form class="layui-form mask-box" lay-filter="refuse">
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">用户账号</label>
          <div class="layui-input-block">
            <input type="text" name="username" class="layui-input" readonly >
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">提现前余额</label>
          <div class="layui-input-block">
            <input type="text" name="balance" class="layui-input" readonly>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">提现金额</label>
          <div class="layui-input-block">
            <input type="text" name="amount" class="layui-input" readonly>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">申请时间</label>
          <div class="layui-input-block">
            <input type="text" name="applydt" class="layui-input" readonly>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">拒绝原因</label>
          <div class="layui-input-block">
            <input type="text" name="remark" class="layui-input" lay-verify="required"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formRefuse">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`,
  throughHtml: `
    <form class="layui-form mask-box" lay-filter="through">
      <div class="info">
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">用户账户</label>
          <div class="layui-input-block">
            <input type="text" name="username" class="layui-input layui-username" lay-verify="required" readonly/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline layui-copy-div">
          <label class="layui-form-label">银行名称</label>
          <div class="layui-input-block">
            <input type="text" name="bankname" class="layui-input layui-userid" lay-verify="required" readonly id="bankname"/>
          </div>
          <div class="layui-btn layui-btn-copy" data-clipboard-target="#bankname">复制</div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline  layui-copy-div">
          <label class="layui-form-label">支行名称</label>
          <div class="layui-input-block">
            <input type="text" name="branchname" class="layui-input layui-balance" lay-verify="required" readonly id="branchname"/>
          </div>
          <div class="layui-btn layui-btn-copy" data-clipboard-target="#branchname">复制</div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline layui-copy-div">
          <label class="layui-form-label">卡号</label>
          <div class="layui-input-block">
            <input type="text" name="accountno" class="layui-input" lay-verify="required" readonly id="accountno"/>
          </div>
          <div class="layui-btn layui-btn-copy" data-clipboard-target="#accountno">复制</div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline layui-copy-div">
          <label class="layui-form-label">银行户名</label>
          <div class="layui-input-block">
            <input type="text" name="accountname" class="layui-input" lay-verify="required"  id="accountname"/>
          </div>
          <div class="layui-btn layui-btn-copy" data-clipboard-target="#accountname">复制</div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline layui-copy-div">
          <label class="layui-form-label">提现金额</label>
          <div class="layui-input-block">
            <input type="text" name="amount" class="layui-input" lay-verify="required" readonly id="amount"/>
          </div>
          <div class="layui-btn layui-btn-copy" data-clipboard-target="#amount">复制</div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">手续费</label>
          <div class="layui-input-block">
            <input type="text" name="handlingcharge" class="layui-input" lay-verify="required|number" />
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">出款银行</label>
          <div class="layui-input-block">
            <select name="chuKuanBankId" class="chukuanBank" lay-verify="required"> 
              <option value="">请选择</option>
            </select>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formThrough">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`

};
