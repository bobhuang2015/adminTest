var htmlTpl = {
  transferHtml: `
  <form class="layui-form mask-box bank-open" lay-filter="transfer">
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">源商户id</label>
        <div class="layui-input-block">
          <input type="text" name="sourcemerchantid" class="layui-input" lay-verify="required" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">目标银行名称</label>
        <div class="layui-input-block">
          <input type="text" name="targetbankname" class="layui-input" lay-verify="required" autocomplete="off"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">目标支行名称</label>
        <div class="layui-input-block">
          <input type="text" name="targetbranchname" class="layui-input" lay-verify="required" autocomplete="off"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">目标开户名称</label>
        <div class="layui-input-block">
          <input type="text" name="targetaccountname" class="layui-input" lay-verify="required" autocomplete="off"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">目标银行卡号</label>
        <div class="layui-input-block">
          <input type="text" name="targetaccountno" class="layui-input" lay-verify="required|number" maxlength="19" autocomplete="off"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">金额</label>
        <div class="layui-input-block">
          <input type="text" name="money" class="layui-input" lay-verify="required|number" autocomplete="off"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">手续费</label>
        <div class="layui-input-block">
          <input type="text" name="fee" class="layui-input" lay-verify="required" autocomplete="off"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-input-block">
        <button class="layui-btn" lay-submit lay-filter="formTrsansfer">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
      </div>
    </div>
  </form>`,
  addHtml: `
    <form class="layui-form mask-box bank-open" lay-filter="add">
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">支付名称</label>
          <div class="layui-input-block">
            <input type="text" name="descript" class="layui-input" lay-verify="required" autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">支付类别</label>
          <div class="layui-input-block">
            <select name="rechargtype" lay-search="" class="rechargtype" lay-verify="required"> 
              <option value="">支付类别</option>
            </select>
          </div>
        </div>
      </div>
      <div class="layui-form-item layui-add-merchantBox">
        <div class="layui-inline">
          <label class="layui-form-label">商户类型</label>
          <div class="layui-input-block">
            <select name="merchantType" lay-search="" class="merchantType" lay-verify="required" lay-filter="merchantType"> 
              <option value="">选择商户</option>
            </select>
          </div>
        </div>
      </div>
      <div class="layui-form-item layui-edit-merchantBox">
        <div class="layui-inline">
          <label class="layui-form-label">商户类型</label>
          <div class="layui-input-block">
            <select name="merchantType" lay-search="" class="merchantType" lay-verify="required" lay-filter="merchantType" disabled> 
              <option value="">选择商户</option>
            </select>
          </div>
        </div>
      </div>
      <div class="layui-form-item bank-list-box">
        <div class="layui-inline">
          <label class="layui-form-label" style="opacity:0;">商户类型</label>
          <div class="layui-input-block bank-list" style="overflow-y:scroll;height:100px;"></div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">自动添加小数</label>
          <div class="layui-input-block">
            <select name="ispoint" lay-verify="required"> 
              <option value="">请选择</option>
              <option value="1">是</option>
              <option value="0">否</option>
            </select>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">充值备注</label>
          <div class="layui-input-block">
            <input type="text" name="rechargeremark" class="layui-input" autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">手续费</label>
          <div class="layui-input-block">
            <input type="text" name="fee" class="layui-input" lay-verify="required|number" autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">显示终端</label>
          <div class="layui-input-block">
            <select name="viewtype" lay-search="" class="viewtype" lay-verify="required">
              <option value="">请选择</option> 
              <option value="0">全部</option>
              <option value="1">网页端</option>
              <option value="2">APP</option>
            </select>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">排序</label>
          <div class="layui-input-block">
            <input type="text" name="sort" class="layui-input" lay-verify="required" autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">收款卡号</label>
          <div class="layui-input-block">
            <input type="text" name="merchantid" class="layui-input" lay-verify="required" autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">第三方商户ID</label>
          <div class="layui-input-block">
            <input type="text" name="thirdMerchantID" class="layui-input"  autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">秘钥</label>
          <div class="layui-input-block">
            <input type="text" name="md5key" class="layui-input" lay-verify="required" maxlength="3000" autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">公钥</label>
          <div class="layui-input-block">
            <input type="text" name="publicKey" class="layui-input" maxlength="3000" autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">充值地址</label>
          <div class="layui-input-block">
            <input type="text" name="payUrl" class="layui-input" lay-verify="required" autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">最小充值金额</label>
          <div class="layui-input-block">
            <input type="text" name="minlimit" class="layui-input" lay-verify="required|number" autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">最大充值金额</label>
          <div class="layui-input-block">
            <input type="text" name="maxlimit" class="layui-input" lay-verify="required|number" autocomplete="off" maxlength="8"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">金额配置</label>
          <div class="layui-input-block">
            <input type="text" name="amountConfig" class="layui-input" lay-verify="" autocomplete="off" placeholder="逗号分隔(例如100,500,1000)"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`
};
