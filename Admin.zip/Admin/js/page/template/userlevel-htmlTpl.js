var htmlTpl = {
  addHtml: `
    <form class="layui-form mask-box level" lay-filter="add">
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">层级名称</label>
          <div class="layui-input-block">
            <input type="text" name="name" class="layui-input" lay-verify="required"/>
          </div>
        </div>
        <div class="layui-inline">
          <label class="layui-form-label">最大充值金额</label>
          <div class="layui-input-block">
            <input type="text" name="moneyinmax" class="layui-input" lay-verify="required|number" maxlength="10"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">注册开始时间</label>
          <div class="layui-input-block">
            <input type="text" name="beginregdt" class="layui-input" lay-verify="required" id="begin"/>
          </div>
        </div>
        <div class="layui-inline">
          <label class="layui-form-label">注册结束时间</label>
          <div class="layui-input-block">
            <input type="text" name="endregdt" class="layui-input" lay-verify="required" id="end"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">充值次数</label>
          <div class="layui-input-block">
            <input type="text" name="moneyincount" class="layui-input" lay-verify="required"/>
          </div>
        </div>
        <div class="layui-inline">
          <label class="layui-form-label">充值总额</label>
          <div class="layui-input-block">
          <input type="text" name="moneyintotal" class="layui-input" lay-verify="required"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">提现次数</label>
          <div class="layui-input-block">
            <input type="text" name="moneyoutcount" class="layui-input" lay-verify="required"/>
          </div>
        </div>
        <div class="layui-inline">
          <label class="layui-form-label">提现总额</label>
          <div class="layui-input-block">
            <input type="text" name="moneyouttotal" class="layui-input" lay-verify="required"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">单笔最小提现金额</label>
          <div class="layui-input-block">
            <input type="text" name="SingleMinTxAmount" class="layui-input" lay-verify="required" maxlength="10"/>
          </div>
        </div>
        <div class="layui-inline">
          <label class="layui-form-label">单笔最大提现金额</label>
          <div class="layui-input-block">
            <input type="text" name="SingleMaxTxAmount" class="layui-input" lay-verify="required" maxlength="10"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">每天最大提现次数</label>
          <div class="layui-input-block">
            <input type="text" name="everyDayMaxTxNum" class="layui-input" lay-verify="required"/>
          </div>
        </div>
        <div class="layui-inline">
          <label class="layui-form-label">每天最大提现金额</label>
          <div class="layui-input-block">
            <input type="text" name="everyDayMaxTxAmount" class="layui-input" lay-verify="required"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">备注</label>
          <div class="layui-input-block">
            <input type="text" name="remark" class="layui-input"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`,
  rechargePFHtml: `<form class="layui-form mask-box recharge" lay-filter="rechargePF">
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">层级名称</label>
        <div class="layui-input-block">
          <input type="text" name="name" class="layui-input name" lay-verify="required" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <label class="layui-form-label">充值宝付</label>
      <div class="layui-input-block recharge-list"></div>
    </div>
    <div class="layui-form-item">
      <div class="layui-input-block">
        <button class="layui-btn" lay-submit lay-filter="rechargePF">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
      </div>
    </div>
  </form>`,
  limitHtml: `<form class="layui-form mask-box recharge" lay-filter="limit">
    <div class="layui-form-item">
      <label class="layui-form-label">选择宝付</label>
      <div class="layui-input-block">
        <select name="selectId" class="limit-list" lay-filter="limit"></select>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">单笔最小充值金额</label>
        <div class="layui-input-block">
          <input type="text" name="moneyinoncemin" class="layui-input money-min" lay-verify="required|number" maxlength="7"/>
        </div>
      </div>
      <div class="layui-inline" style="margin-left:36px;">
        <label class="layui-form-label">单笔最大充值金额</label>
        <div class="layui-input-block">
          <input type="text" name="moneyinoncemax" class="layui-input money-max" lay-verify="required|number" maxlength="7"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-input-block">
        <button class="layui-btn" lay-submit lay-filter="limit">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
      </div>
    </div>
  </form>`,
  levelHtml: `<form class="layui-form mask-box level" lay-filter="level">
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">用户类型</label>
        <div class="layui-input-block">
          <input type="text" name="usertype" class="layui-input" lay-verify="required" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">层级</label>
        <div class="layui-input-block">
          <select name="userlevel" class="userLevel">
          </select>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">是否团队转移</label>
        <div class="layui-input-block">
          <select name="isteam">
            <option value="0">否</option>
            <option value="1">是</option>
          </select>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-input-block">
        <button class="layui-btn" lay-submit lay-filter="level">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
      </div>
    </div>
  </form>`,
  txBankHtml: `<form class="layui-form mask-box bank" lay-filter="txBank">
    <div class="layui-form-item" pane="">
      <div class="layui-form-item bank-box">
        <div class="layui-inline">
          <label class="layui-form-label">层级名称</label>
          <div class="layui-input-block">
            <input type="text" name="name" class="layui-input" lay-verify="required" disabled style="border:none;"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">平台银行账户</label>
        <div class="layui-input-block bank-list"></div>
      </div>
      <div class="layui-form-item" style="margin-top:20px;">
        <div class="layui-input-block">
          <button class="layui-btn layui-all layui-btn-normal">全选</button>
          <button class="layui-btn" lay-submit lay-filter="txBank">保存</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </div>
  </form>`,
  thirdStatusHtml: `<form class="layui-form mask-box" lay-filter="thirdStatus">
	<div class="layui-form-item">
		<div class="layui-inline">
			<label class="layui-form-label">用户账号</label>
			<div class="layui-input-block">
				<input type="text" name="username" class="layui-input" lay-verify="required" disabled/>
			</div>
		</div>
		<div class="layui-inline">
			<label class="layui-form-label">AG状态</label>
			<div class="layui-input-block">
				<select name="isAGState">
					<option value="0">未开通</option>
					<option value="1">已开通</option>
				</select>
			</div>
		</div>
	</div>
	<div class="layui-form-item">
		<div class="layui-inline">
			<label class="layui-form-label">BBIN状态</label>
			<div class="layui-input-block">
				<select name="isBBINState">
					<option value="0">未开通</option>
					<option value="1">开通</option>
				</select>
			</div>
		</div>
		<div class="layui-inline">
			<label class="layui-form-label">PT状态</label>
			<div class="layui-input-block">
				<select name="isPTState">
					<option value="0">未开通</option>
					<option value="1">已开通</option>
				</select>
			</div>
		</div>
	</div>
	<div class="layui-form-item">
		<div class="layui-inline">
			<label class="layui-form-label">MG状态</label>
			<div class="layui-input-block">
				<select name="isMGState">
					<option value="0">未开通</option>
					<option value="1">开通</option>
				</select>
			</div>
		</div>
		<div class="layui-inline">
			<label class="layui-form-label">好利状态</label>
			<div class="layui-input-block">
				<select name="isLKState">
					<option value="0">未开通</option>
					<option value="1">已开通</option>
				</select>
			</div>
		</div>
	</div>
	<div class="layui-form-item">
		<div class="layui-inline">
			<label class="layui-form-label">VR状态</label>
			<div class="layui-input-block">
				<select name="isVRState">
					<option value="0">未开通</option>
					<option value="1">开通</option>
				</select>
			</div>
		</div>
		<div class="layui-inline">
			<label class="layui-form-label">KY状态</label>
			<div class="layui-input-block">
				<select name="isKYState">
					<option value="0">未开通</option>
					<option value="1">已开通</option>
				</select>
			</div>
		</div>
	</div>
	<div class="layui-form-item">
		<div class="layui-inline">
			<label class="layui-form-label">BDB体育状态</label>
			<div class="layui-input-block">
				<select name="isXJState">
					<option value="0">未开通</option>
					<option value="1">开通</option>
				</select>
			</div>
		</div>
		<div class="layui-inline">
			<label class="layui-form-label">SB状态</label>
			<div class="layui-input-block">
				<select name="isSBState">
					<option value="0">未开通</option>
					<option value="1">已开通</option>
				</select>
			</div>
		</div>
	</div>
	<div class="layui-form-item">
		<div class="layui-input-block">
			<button class="layui-btn" lay-submit lay-filter="thirdStatus">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
		</div>
	</div>
</form>`,
passwordHtml:`<form class="layui-form mask-box" lay-filter="password">
<div class="layui-form-item">
  <div class="layui-inline">
    <label class="layui-form-label">用户账号</label>
    <div class="layui-input-block">
      <input type="text" name="username" class="layui-input" lay-verify="required" disabled/>
    </div>
  </div>
  <div class="layui-inline">
    <label class="layui-form-label">用户类型</label>
    <div class="layui-input-block">
      <input type="text" name="usertype" class="layui-input" lay-verify="required" disabled/>
    </div>
  </div>
</div>
<div class="layui-form-item">
  <div class="layui-inline">
    <label class="layui-form-label">登录密码</label>
    <div class="layui-input-block">
      <input type="password" name="password" class="layui-input"/>
    </div>
  </div>
  <div class="layui-inline">
    <label class="layui-form-label">资金密码</label>
    <div class="layui-input-block">
      <input type="password" name="moneyPwd" class="layui-input"/>
    </div>
  </div>
</div>
<div class="layui-form-item">
  <div class="layui-input-block">
    <button class="layui-btn" lay-submit lay-filter="password">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
  </div>
</div>
</form>`,
};
