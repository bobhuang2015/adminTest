var htmlTpl = {
  addHtml: `
  <form class="layui-form mask-box" lay-filter="add">
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">用户账户</label>
        <div class="layui-input-block">
          <input type="text" name="username" class="layui-input layui-username" lay-verify="required" autocomplete="off"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">用户id</label>
        <div class="layui-input-block">
          <input type="text" name="userid" class="layui-input layui-userid" lay-verify="required" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">钱包余额</label>
        <div class="layui-input-block">
          <input type="text" name="accountbalance" class="layui-input layui-balance" lay-verify="required" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">充值类型</label>
        <div class="layui-input-block">
          <select name="changeitem" class="rechargeType" lay-verify="required"> 
            <option value="">请选择</option>
          </select>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">活动归类</label>
        <div class="layui-input-block">
          <select name="gametype" class="activeType" lay-verify="required"> 
          </select>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">充值金额</label>
        <div class="layui-input-block">
          <input type="text" name="changemoney" class="layui-input" lay-verify="required|number"  autocomplete="off" maxlength="8"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">打码额(%)</label>
        <div class="layui-input-block">
          <input type="text" name="demandorderamount" class="layui-input" lay-verify="required|dme" maxlength="7"  autocomplete="off"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">备注</label>
        <div class="layui-input-block">
          <input type="text" name="remark" class="layui-input" lay-verify="required"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-input-block">
        <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
      </div>
    </div>
  </form>`,
  makeupHtml: `
  <form class="layui-form mask-box" lay-filter="makeup">
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">用户账户</label>
        <div class="layui-input-block">
          <input type="text" name="username" class="layui-input layui-username" lay-verify="required"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">用户id</label>
        <div class="layui-input-block">
          <input type="text" name="userid" class="layui-input layui-userid" lay-verify="required" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">钱包余额</label>
        <div class="layui-input-block">
          <input type="text" name="accountbalance" class="layui-input layui-balance" lay-verify="required" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">充值方式</label>
        <div class="layui-input-block">
          <select name="changeitem" lay-verify="required"> 
            <option value="5">线下充值补单</option>
            <option value="4">在线充值补单</option>
          </select>
        </div>
      </div>
    </div>
    <div class="layui-form-item layui-bank">
      <div class="layui-inline layui-platform">
        <label class="layui-form-label">平台银行</label>
        <div class="layui-input-block">
          <select name="bankaccountid" class="platform" lay-verify="required"> 
            <option value="">请选择</option>
          </select>
        </div>
      </div>
      <div class="layui-inline layui-baofoo">
        <label class="layui-form-label">宝付银行</label>
        <div class="layui-input-block">
          <select name="baofooaccount" class="baofoo" lay-verify="required"> 
            <option value="">请选择</option>
          </select>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">充值金额</label>
        <div class="layui-input-block">
          <input type="text" name="changemoney" class="layui-input" lay-verify="required"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">打码额(%)</label>
        <div class="layui-input-block">
          <input type="text" name="demandorderamount" class="layui-input" lay-verify="required"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">备注</label>
        <div class="layui-input-block">
          <input type="text" name="remark" class="layui-input" lay-verify="required"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-input-block">
        <button class="layui-btn" lay-submit lay-filter="formMakeup">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
      </div>
    </div>
  </form>`,
};
