var htmlTpl = {
  addHtml: `
    <form class="layui-form mask-box level" lay-filter="add">
      <div class="layui-form-item">
        <label class="layui-form-label">期号</label>
        <div class="layui-input-block">
          <input type="text" name="issueno" class="layui-input" lay-verify="required|number" autocomplete='off' maxlength="30"/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">开盘时间</label>
        <div class="layui-input-block">
          <input type="text" name="opentime" class="layui-input layui-date" lay-verify="required" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">封盘时间</label>
        <div class="layui-input-block">
          <input type="text" name="closetime" class="layui-input layui-date" lay-verify="required" autocomplete='off' />
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">开奖时间</label>
        <div class="layui-input-block">
          <input type="text" name="lotterydt" class="layui-input layui-date" lay-verify="required" autocomplete='off' />
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">状态</label>
        <div class="layui-input-block">
          <select name="state" class="layui-state" lay-verify="required">
            <option>请选择</option>
          </select>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`
};
