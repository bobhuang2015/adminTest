var htmlTpl = {
  transferHtml: `
  <form class="layui-form mask-box bank-open" lay-filter="transfer">
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">源银行名称</label>
        <div class="layui-input-block">
          <input type="text" name="sourcebankname" class="layui-input" lay-verify="required" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">源支行名称</label>
        <div class="layui-input-block">
          <input type="text" name="sourcebranchname" class="layui-input" lay-verify="required" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">源开户名称</label>
        <div class="layui-input-block">
          <input type="text" name="sourceaccountname" class="layui-input" lay-verify="required" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">源银行卡号</label>
        <div class="layui-input-block">
          <input type="text" name="sourceaccountno" class="layui-input" lay-verify="required" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">目标银行名称</label>
        <div class="layui-input-block">
          <select name="targetbankname" lay-search="" class="targetbankname" lay-verify="required"> 
            <option value="">选择银行</option>
          </select>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">目标支行名称</label>
        <div class="layui-input-block">
          <input type="text" name="targetbranchname" class="layui-input" lay-verify="required"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">目标开户名称</label>
        <div class="layui-input-block">
          <input type="text" name="targetaccountname" class="layui-input" lay-verify="required"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">目标银行卡号</label>
        <div class="layui-input-block">
          <input type="text" name="targetaccountno" class="layui-input" lay-verify="required|number" maxlength="19"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">金额</label>
        <div class="layui-input-block">
          <input type="text" name="money" class="layui-input" lay-verify="required|number"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">手续费</label>
        <div class="layui-input-block">
          <input type="text" name="fee" class="layui-input" lay-verify="required"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-input-block">
        <button class="layui-btn" lay-submit lay-filter="formTrsansfer">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
      </div>
    </div>
  </form>`,
  addHtml: `
    <form class="layui-form mask-box bank-open" lay-filter="add">
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">名称</label>
          <div class="layui-input-block">
            <input type="text" name="name" class="layui-input" lay-verify="required"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">图片路径</label>
          <div class="layui-input-block">
            <input type="text" name="imgurl" class="layui-input layui-imgurl" lay-verify="required" autocomplete='off' readonly style="width:260px;display:inline-block;"/>
            <button class='layui-btn layui-btn-operator layui-btn-normal' id="layui-upload" type="button">&nbsp;&nbsp;选择&nbsp;&nbsp;</button>
            <button class='layui-btn layui-btn-operator layui-btn-normal' id="layui-preview">预览图片</button>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">排序</label>
          <div class="layui-input-block">
            <input type="text" name="sort" class="layui-input" lay-verify="required|number" autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`
};
