var htmlTpl = {
  addHtml: `
    <form class="layui-form mask-box level" lay-filter="add">
      <div class="layui-form-item">
        <label class="layui-form-label">更新时间</label>
        <div class="layui-input-block">
          <input type="text" name="updateTime" class="layui-input" lay-verify="required" autocomplete='off' id="startFresh"/>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">更新内容</label>
          <div class="layui-input-block" style="width:630px;">
             <textarea class="layui-textarea" id="LAY_demo2" style="display: none"></textarea>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`
};
