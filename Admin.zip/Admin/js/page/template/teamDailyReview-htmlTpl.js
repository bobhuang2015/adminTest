var htmlTpl = {
  setHtml: `
  <form class="layui-form mask-box bank-open" lay-filter="set">
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">用户名</label>
        <div class="layui-input-block">
          <input type="text" name="username" class="layui-input" lay-verify="required" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">派发金额</label>
        <div class="layui-input-block">
          <input type="text" name="amout" class="layui-input" lay-verify="required"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-input-block">
        <button class="layui-btn" lay-submit lay-filter="formSet">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
      </div>
    </div>
  </form>`,
  addHtml: `
    <form class="layui-form mask-box bank-open" lay-filter="add">
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">商户类型</label>
          <div class="layui-input-block">
            <select name="merchantType" lay-search="" class="merchantType" lay-verify="required"> 
              <option value="">选择商户</option>
            </select>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">充值大类</label>
          <div class="layui-input-block">
            <select name="rechargtype" lay-search="" class="rechargtype" lay-verify="required"> 
              <option value="">充值大类</option>
            </select>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">显示终端</label>
          <div class="layui-input-block">
            <select name="viewtype" lay-search="" class="viewtype" lay-verify="required"> 
              <option value="0">全部</option>
              <option value="1">网页端</option>
              <option value="2">APP</option>
            </select>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">自动添加小数</label>
          <div class="layui-input-block">
            <select name="ispoint" lay-verify="required"> 
              <option value="1">是</option>
              <option value="0">否</option>
            </select>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">排序</label>
          <div class="layui-input-block">
            <input type="text" name="sort" class="layui-input" lay-verify="required"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">前端展示描述</label>
          <div class="layui-input-block">
            <input type="text" name="descript" class="layui-input" lay-verify="required"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">充值备注</label>
          <div class="layui-input-block">
            <input type="text" name="rechargeremark" class="layui-input" lay-verify="required"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">商户ID</label>
          <div class="layui-input-block">
            <input type="text" name="merchantid" class="layui-input" lay-verify="required"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">秘钥</label>
          <div class="layui-input-block">
            <input type="text" name="md5key" class="layui-input" lay-verify="required" maxlength="19"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">宝付终端</label>
          <div class="layui-input-block">
            <input type="text" name="url" class="layui-input" lay-verify="required"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">充值地址</label>
          <div class="layui-input-block">
            <input type="text" name="payUrl" class="layui-input" lay-verify="required"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">报警额度</label>
          <div class="layui-input-block">
            <input type="text" name="maxmoney" class="layui-input" lay-verify="required"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">手续费</label>
          <div class="layui-input-block">
            <input type="text" name="fee" class="layui-input" lay-verify="required|number"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">最小充值金额</label>
          <div class="layui-input-block">
            <input type="text" name="minlimit" class="layui-input" lay-verify="required|number"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">最大充值金额</label>
          <div class="layui-input-block">
            <input type="text" name="maxlimit" class="layui-input" lay-verify="required|number"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`
};
