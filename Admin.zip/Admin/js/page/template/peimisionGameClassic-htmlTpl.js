var htmlTpl = {
  addHtml: `
    <form class="layui-form mask-box" lay-filter="set">
      <div class="layui-form-item">
        <label class="layui-form-label">模式类型</label>
        <div class="layui-input-block layui-pattern">
          <input type="checkbox" value="1" lay-skin="primary" title="元" name="pattern[1]">
          <input type="checkbox" value="2" lay-skin="primary" title="角"  name="pattern[2]">
          <input type="checkbox" value="3" lay-skin="primary" title="分"  name="pattern[3]">
          <input type="checkbox" value="4" lay-skin="primary" title="厘"  name="pattern[4]">
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block" style="margin-left:130px;">
          <button class="layui-btn" lay-submit lay-filter="formSet">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`
};
