var htmlTpl = {
  addHtml: `
  <form class="layui-form mask-box layui-teamManage" lay-filter="add">
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">用户账号</label>
        <div class="layui-input-block">
          <input type="text" name="username" class="layui-input" lay-verify="required" id="username"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">用户id</label>
        <div class="layui-input-block">
          <input type="text" name="userid" class="layui-input layui-userid" lay-verify="required" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
      <label class="layui-form-label">选择</label>
      <div class="layui-input-block">
        <select name="type" lay-filter="type" class="type" lay-verify="required"> 
          <option value="0">分红</option>
          <option value="1">日工资</option>
        </select>
      </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
      <label class="layui-form-label">是否自动</label>
      <div class="layui-input-block">
        <select name="isauto" lay-search="" class="isauto" lay-verify="required"> 
          <option value="0">非自动</option>
          <option value="1">自动</option>
        </select>
      </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">游戏</label>
        <div class="layui-input-block">
          <select name="gametype" lay-search="" class="layui-gametype" lay-verify="required"> 
          </select>
        </div>
      </div>
    </div>
    <div class="layui-form-item layui-hong">
      <div class="layui-inline">
      <label class="layui-form-label">分红策略</label>
      <div class="layui-input-block">
        <select name="divdendplot" lay-search="" class="divdendplot"> 
          <option value="0">累积不盈亏</option>
          <option value="1">累积盈亏</option>
        </select>
      </div>
      </div>
    </div>
    <div class="layui-form-item layui-hong">
      <div class="layui-inline">
      <label class="layui-form-label">分红期数</label>
      <div class="layui-input-block">
        <select name="divendperiod" lay-search="" class="divendperiod"> 
          <option value="0">每日</option>
          <option value="1">半月</option>
          <option value="2">一月</option>
        </select>
      </div>
      </div>
    </div>
    <div class='details x-so'>
      <div class="layui-form-item layui-first">
        <h2 style="margin-bottom:10px;">详情</h2>
        <div class="layui-detail-item layui-detail-first">
          <input type="text" name="datequantity" placeholder="日量>=" autocomplete="off" class="layui-input layui-nums"  lay-verify="required" >
          <input type="text" name="vaildusers" placeholder="有效会员>=" autocomplete="off" class="layui-input layui-nums"  lay-verify="required">
          <div class="layui-inline" style="width:150px;">
            <div class="layui-input-inline"  style="width:150px;">
              <select name="rewardtype">
                <option value="0">固定</option>
                <option value="1">比率</option>
                </select>
            </div>
          </div>
          <input type="text" name="rewardamout" placeholder="金额/比率" autocomplete="off" class="layui-input layui-nums"  lay-verify="required" >
          <div class="layui-btn layui-new">新增</div>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-input-block" style="margin-left:45px;">
        <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;" ondragstart="return false;">取消</a>
      </div>
    </div>
  </form>`,
  editHtml:`
  <form class="layui-form mask-box layui-teamManage" lay-filter="edit">
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">用户账号</label>
        <div class="layui-input-block">
          <input type="text" name="username" class="layui-input" lay-verify="required" id="username" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">用户id</label>
        <div class="layui-input-block">
          <input type="text" name="userid" class="layui-input layui-userid" lay-verify="required" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">选择</label>
        <div class="layui-input-block">
          <input type="text" name="type" class="layui-input layui-userid" lay-verify="required" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
      <label class="layui-form-label">是否自动</label>
      <div class="layui-input-block">
        <select name="isauto" lay-search="" class="isauto" lay-verify="required"> 
          <option value="0">非自动</option>
          <option value="1">自动</option>
        </select>
      </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">游戏</label>
        <div class="layui-input-block">
          <input type="text" name="gametype" class="layui-input layui-userid" lay-verify="required" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item layui-hong">
      <div class="layui-inline">
      <label class="layui-form-label">分红策略</label>
      <div class="layui-input-block">
        <select name="divdendplot" lay-search="" class="divdendplot"> 
          <option value="0">累积不盈亏</option>
          <option value="1">累积盈亏</option>
        </select>
      </div>
      </div>
    </div>
    <div class="layui-form-item layui-hong">
      <div class="layui-inline">
      <label class="layui-form-label">分红期数</label>
      <div class="layui-input-block">
        <select name="divendperiod" lay-search="" class="divendperiod"> 
          <option value="0">每日</option>
          <option value="1">半月</option>
          <option value="2">一月</option>
        </select>
      </div>
      </div>
    </div>
    <div class='details x-so'>
      <div class="layui-form-item layui-first">
        <h2 style="margin-bottom:10px;">详情</h2>
        <div id="layui-detail-list"></div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-input-block" style="margin-left:45px;">
        <button class="layui-btn" lay-submit lay-filter="formEdit">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
      </div>
    </div>
  </form>`
};
