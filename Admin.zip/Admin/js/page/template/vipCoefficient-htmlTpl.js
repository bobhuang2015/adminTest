var htmlTpl = {
  addHtml: `
    <form class="layui-form mask-box level" lay-filter="add">
      <div class="layui-form-item">
        <label class="layui-form-label">平台名称</label>
        <div class="layui-inline">
          <select class="layui-platformId" name="platformId" lay-verify="required" lay-filter="platformId">
            <option value="">请选择</option>
          </select>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">类型名称</label>
        <div class="layui-inline">
          <select class="layui-subPlatformId" name="subPlatformId" lay-verify="required" lay-filter="subPlatformId">
          </select>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">系数</label>
        <div class="layui-input-block">
          <input type="text" name="expRatio" class="layui-input" lay-verify="required|number" style="width:196px;" maxlength="3"/>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`,
  knighthoodHtml: `
    <form class="layui-form mask-box level" lay-filter="add">
      <div class="layui-form-item">
        <label class="layui-form-label">礼金</label>
        <div class="layui-input-block">
          <input type="text" name="cashGift" class="layui-input layui-special" lay-verify="required|number"/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">俸禄</label>
        <div class="layui-input-block">
          <input type="text" name="salary" class="layui-input layui-special" lay-verify="required|number"/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">提现次数</label>
        <div class="layui-input-block">
          <input type="text" name="withdrawalsNum" class="layui-input" lay-verify="required|number"/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">提现金额</label>
        <div class="layui-input-block">
          <input type="text" name="withdrawalsLimit" class="layui-input" lay-verify="required|number"/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">衰减经验</label>
        <div class="layui-input-block">
          <input type="text" name="subExperience" class="layui-input layui-special" lay-verify="required|number"/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">返点类型</label>
        <div class="layui-input-block fanwei-list">
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">返水比例</label>
        <div class="layui-input-block">
          <input type="text" name="bouns" class="layui-input" lay-verify="required|number"/>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`,
};
