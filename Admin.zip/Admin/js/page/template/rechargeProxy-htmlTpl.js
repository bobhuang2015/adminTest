var htmlTpl = {
  refuseHtml: 
  `<form class="layui-form mask-box" lay-filter="add">
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">拒绝原因</label>
        <div class="layui-input-block">
          <input type="text" name="remark" class="layui-input" lay-verify="required"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-input-block">
        <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
      </div>
    </div>
  </form>`,
  throughHtml: 
  `<form class="layui-form mask-box" lay-filter="through">
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">打码额度</label>
        <div class="layui-input-block">
          <input type="text" name="dme" class="layui-input"  placeholder='没有输入则默认系统打码值' lay-verify="money" onkeyup="this.value=this.value.replace(/[^0-9]/g,'')" maxlength="3"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">备注</label>
        <div class="layui-input-block">
          <input type="text" name="remark" class="layui-input"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-input-block">
        <button class="layui-btn" lay-submit lay-filter="formThrough">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
      </div>
    </div>
  </form>`
};
