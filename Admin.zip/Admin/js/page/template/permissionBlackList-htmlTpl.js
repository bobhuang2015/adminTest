var htmlTpl = {
  addHtml: `
    <form class="layui-form mask-box level" lay-filter="add">
      <div class="layui-form-item layui-select-type">
        <label class="layui-form-label">类型</label>
        <div class="layui-inline" style="width:77%;margin-right:0;">
          <select id="layui-type" name="type" lay-verify="required" lay-filter="type" >
            <option value="">请选择</option>
            <option value="1">活动</option>
            <option value="2">银行卡</option>
          </select>
        </div>
      </div>
      <div id="layui-content-box"></div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`
};
