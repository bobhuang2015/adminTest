var htmlTpl = {
  addHtml: `
    <form class="layui-form mask-box level" lay-filter="add">
      <div class="layui-form-item">
        <label class="layui-form-label">类型</label>
        <div class="layui-input-block" style="margin-left:130px;width:430px;">
          <select name="type" id="layui-type">
          </select>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">IP地址</label>
        <div class="layui-input-block">
          <input type="text" name="address" class="layui-input" lay-verify="required|ip" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">备注</label>
        <div class="layui-input-block">
          <input type="text" name="remarks" class="layui-input" lay-verify="required" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block" style="margin-left:130px;">
          <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`
};
