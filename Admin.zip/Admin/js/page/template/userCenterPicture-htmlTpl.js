var htmlTpl = {
  addHtml: `
    <form class="layui-form mask-box level" lay-filter="add">
      <div class="layui-form-item">
        <label class="layui-form-label">图片名称</label>
        <div class="layui-input-block">
          <input type="text" name="name" class="layui-input" lay-verify="required" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">图片类型</label>
        <div class="layui-inline">
          <select name="type" lay-verify="required" lay-search lay-filter="type" id="layui-type">
            <option value="1">PC首页轮播图</option>
            <option value="2">支付二维码</option>
            <option value="3">app下载二维码</option>
            <option value="4">移动端首页轮播图</option>
            <option value="5">其它图片</option>
            <option value="6">PC购彩大厅轮播图</option>
          </select>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">图片路径</label>
        <div class="layui-input-block">
          <input type="text" name="imgurl" class="layui-input layui-imgurl" lay-verify="required" autocomplete='off' readonly style="width:300px;display:inline-block;"/>
          <button class='layui-btn layui-btn-operator layui-btn-normal' id="layui-upload" type="button">&nbsp;&nbsp;选择&nbsp;&nbsp;</button>
          <button class='layui-btn layui-btn-operator layui-btn-normal' id="layui-preview">预览图片</button>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">开始时间</label>
        <div class="layui-input-block">
          <input type="text" name="timebegin" class="layui-input layui-date" lay-verify="required" autocomplete='off' />
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">结束时间</label>
        <div class="layui-input-block">
          <input type="text" name="timeend" class="layui-input layui-date" lay-verify="required" autocomplete='off' />
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">排序</label>
        <div class="layui-input-block">
          <input type="text" name="sort" class="layui-input" lay-verify="required|number" autocomplete='off' />
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">备注</label>
        <div class="layui-input-block">
          <input type="text" name="remarks" class="layui-input" lay-verify="required" autocomplete='off' />
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`
};
