var htmlTpl = {
  addBigHtml: `
    <form class="layui-form mask-box level" lay-filter="add">
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">名称</label>
          <div class="layui-input-block">
            <input type="text" name="title" class="layui-input" lay-verify="required"/>
          </div>
        </div>
        <div class="layui-inline">
          <label class="layui-form-label">排序</label>
          <div class="layui-input-block">
            <input type="text" name="ranking" class="layui-input" lay-verify="required|number"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`,
    addMiddleHtml: `
      <form class="layui-form mask-box level" lay-filter="add">
        <div class="layui-form-item">
          <div class="layui-inline">
            <label class="layui-form-label">父级</label>
            <div class="layui-input-block">
              <select name="parentId" class="layui-parent" lay-verify="required">
                <option value>请选择</option>
              </select>
            </div>
          </div>
        </div>
        <div class="layui-form-item">
          <div class="layui-inline">
            <label class="layui-form-label">名称</label>
            <div class="layui-input-block">
              <input type="text" name="title" class="layui-input" lay-verify="required"/>
            </div>
          </div>
          <div class="layui-inline">
            <label class="layui-form-label">排序</label>
            <div class="layui-input-block">
              <input type="text" name="ranking" class="layui-input" lay-verify="required|number"/>
            </div>
          </div>
        </div>
        <div class="layui-form-item">
          <div class="layui-input-block">
            <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
          </div>
        </div>
      </form>`,
    addSmallHtml: `
      <form class="layui-form mask-box level" lay-filter="add">
        <div class="layui-form-item">
          <div class="layui-inline">
            <label class="layui-form-label">父级</label>
            <div class="layui-input-block">
              <select name="parentId" class="layui-parent" lay-verify="required">
                <option value>请选择</option>
              </select>
            </div>
          </div>
        </div>
        <div class="layui-form-item">
          <div class="layui-inline">
            <label class="layui-form-label">名称</label>
            <div class="layui-input-block">
              <input type="text" name="title" class="layui-input" lay-verify="required"/>
            </div>
          </div>
          <div class="layui-inline">
            <label class="layui-form-label">排序</label>
            <div class="layui-input-block">
              <input type="text" name="ranking" class="layui-input" lay-verify="required|number"/>
            </div>
          </div>
        </div>
        <div class="layui-form-item">
          <div class="layui-input-block">
            <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
          </div>
        </div>
      </form>`
};
