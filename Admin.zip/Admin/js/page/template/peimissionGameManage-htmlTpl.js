var htmlTpl = {
  redHtml: `
    <form class="layui-form mask-box" lay-filter="red">
      <div class="layui-form-item dn">
        <div class="layui-inline">
          <label class="layui-form-label">id</label>
          <div class="layui-input-block">
            <input type="text" name="id" class="layui-input" lay-verify='required'/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">限红金额</label>
          <div class="layui-input-block">
            <input type="text" name="maxwinmoney" class="layui-input" lay-verify='required|number' autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">传统限红金额</label>
          <div class="layui-input-block">
            <input type="text" name="kjmaxwinmoney" class="layui-input" lay-verify='required|number' autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formRed">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`,
  sortHtml: `
    <form class="layui-form mask-box" lay-filter="sort">
      <div class="layui-form-item dn">
        <div class="layui-inline">
          <label class="layui-form-label">id</label>
          <div class="layui-input-block">
            <input type="text" name="id" class="layui-input" lay-verify='required'/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">首页顺序</label>
          <div class="layui-input-block">
            <input type="text" name="recommendSort" class="layui-input" lay-verify='number' autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">热门排序</label>
          <div class="layui-input-block">
            <input type="text" name="hotSort" class="layui-input" lay-verify='number' autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">彩种推荐</label>
        <div class="layui-input-block" style="width:165px;">
          <select name="recommendType">
            <option value="">请选择</option>
            <option value="H">H</option>
            <option value="N">N</option>
             <option value="S">S</option>
          </select>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formSort">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`,
  limitHtml: `<form class="layui-form mask-box recharge" lay-filter="limit">
  <div class="layui-form-item">
    <label class="layui-form-label">选择玩法</label>
    <div class="layui-input-block" style="width:560px;">
      <select name="selectId" class="limit-list" lay-filter="limit" ></select>
    </div>
  </div>
  <div class="layui-form-item layui-subType">
    <label class="layui-form-label">子玩法</label>
    <div class="layui-input-block" id="layui-subType">
    </div>
  </div>
  <div class="layui-form-item">
    <div class="layui-inline">
      <label class="layui-form-label">限制注数</label>
      <div class="layui-input-block">
        <input type="text" name="limitlist" class="layui-input money-min" lay-verify="required|number"/>
      </div>
    </div>
    <div class="layui-inline" style="margin-left:36px;">
      <label class="layui-form-label">限号个数</label>
      <div class="layui-input-block">
        <input type="text" name="limitnum" class="layui-input money-max" lay-verify="required|number"/>
      </div>
    </div>
  </div>
  <div class="layui-form-item">
    <div class="layui-input-block">
      <button class="layui-btn" lay-submit lay-filter="limit">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
    </div>
  </div>
</form>`,
  permissonHtml: `<form class="layui-form mask-box" lay-filter="role">
    <div class="layui-form-item" pane="">
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">管理员名称</label>
          <div class="layui-input-block">
            <input type="text" name="username" class="layui-input" lay-verify="required" disabled/>
          </div>
        </div>
      </div>
      <label class="layui-form-label">用户角色</label>
      <div class="layui-input-block role-list"></div>
      <div class="layui-form-item" style="margin-top:30px;">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="role">保存</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </div>
  </form>`,
};
