var htmlTpl = {
  verifyHtml: `
  <form class="layui-form mask-box bank-open" lay-filter="verify">
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">用户账号</label>
        <div class="layui-input-block">
          <input type="text" name="username" class="layui-input" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">充值金额</label>
        <div class="layui-input-block">
          <input type="text" name="amount" class="layui-input" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">收款信息</label>
        <div class="layui-input-block">
          <input type="text" name="platformbankaccountname" class="layui-input" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">申请时间</label>
        <div class="layui-input-block">
          <input type="text" name="applydt" class="layui-input" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item layui-balance">
      <div class="layui-inline">
        <label class="layui-form-label">收款账户余额</label>
        <div class="layui-input-block">
          <input type="text" name="balance" class="layui-input" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline layui-switch">
        <label class="layui-form-label">手续费</label>
        <div class="layui-input-block">
          <input type="text" name="fee" class="layui-input" lay-verify="required"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item layui-remark">
      <div class="layui-inline">
        <label class="layui-form-label">备注</label>
        <div class="layui-input-block">
          <input type="text" name="remark" class="layui-input"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-input-block">
        <button class="layui-btn" lay-submit lay-filter="formVerify">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
      </div>
    </div>
  </form>`
};
