var htmlTpl = {
  addHtml: `
    <form class="layui-form mask-box level" lay-filter="add">
      <div class="layui-form-item">
        <label class="layui-form-label">参数类型</label>
        <div class="layui-input-block">
          <select class="layui-type" name="type" lay-verify="required" lay-filter="paramType">
            <option value="">请选择</option>
          </select>
        </div>
      </div>
      <div class="layui-form-item" id="layui-paramType-box">
        <label class="layui-form-label">分类</label>
        <div class="layui-input-block">
        <select class="layui-paramtype" name="paramtype" lay-verify="required" >
          <option value="">请选择</option>
        </select>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">参数名</label>
        <div class="layui-input-block">
          <input type="text" name="markcode" class="layui-input" lay-verify="required" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">参数</label>
        <div class="layui-input-block">
          <input type="text" name="paramname" class="layui-input" lay-verify="required" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">参数值</label>
        <div class="layui-input-block">
          <input type="text" name="paramvalue" class="layui-input" lay-verify="required" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">参数描述</label>
        <div class="layui-input-block">
          <input type="text" name="paramdes" class="layui-input" lay-verify="required" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block" style="margin-left:130px;">
          <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`
};
