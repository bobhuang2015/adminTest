var htmlTpl = {
  transferHtml: `
  <form class="layui-form mask-box bank-open" lay-filter="transfer">
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">源银行名称</label>
        <div class="layui-input-block">
          <input type="text" name="sourcebankname" class="layui-input" lay-verify="required" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">源支行名称</label>
        <div class="layui-input-block">
          <input type="text" name="sourcebranchname" class="layui-input" lay-verify="required" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">源开户名称</label>
        <div class="layui-input-block">
          <input type="text" name="sourceaccountname" class="layui-input" lay-verify="required" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">源银行卡号</label>
        <div class="layui-input-block">
          <input type="text" name="sourceaccountno" class="layui-input" lay-verify="required" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">目标银行名称</label>
        <div class="layui-input-block">
          <select name="targetbankname" lay-search="" class="targetbankname" lay-verify="required"> 
            <option value="">选择银行</option>
          </select>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">目标支行名称</label>
        <div class="layui-input-block">
          <input type="text" name="targetbranchname" class="layui-input" lay-verify="required" autocomplete="off"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">目标开户名称</label>
        <div class="layui-input-block">
          <input type="text" name="targetaccountname" class="layui-input" lay-verify="required" autocomplete="off"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">目标银行卡号</label>
        <div class="layui-input-block">
          <input type="text" name="targetaccountno" class="layui-input" lay-verify="required|number" maxlength="19" autocomplete="off"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">金额</label>
        <div class="layui-input-block">
          <input type="text" name="money" class="layui-input" lay-verify="required|number" autocomplete="off"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">手续费</label>
        <div class="layui-input-block">
          <input type="text" name="fee" class="layui-input" lay-verify="required" autocomplete="off"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-input-block">
        <button class="layui-btn" lay-submit lay-filter="formTrsansfer">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
      </div>
    </div>
  </form>`,
  addHtml: `
    <form class="layui-form mask-box bank-open" lay-filter="add">
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">支付名称</label>
          <div class="layui-input-block">
            <input type="text" name="payName" class="layui-input" lay-verify="required" autocomplete="off" maxlength="18"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item layui-add-merchantBox">
        <div class="layui-inline">
          <label class="layui-form-label">商户类型</label>
          <div class="layui-input-block">
            <select name="merchantType" lay-search="" class="merchantType" lay-verify="required" lay-filter="merchantType"> 
              <option value="">选择商户</option>
            </select>
          </div>
        </div>
      </div>
      <div class="layui-form-item layui-edit-merchantBox">
        <div class="layui-inline">
          <label class="layui-form-label">商户类型</label>
          <div class="layui-input-block">
            <select name="merchantType" lay-search="" class="merchantType" lay-verify="required" lay-filter="merchantType" disabled> 
              <option value="">选择商户</option>
            </select>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">充值大类</label>
          <div class="layui-input-block">
            <select name="rechargtype" lay-search="" class="rechargtype" lay-verify="required" autocomplete="off"> 
              <option value="">充值大类</option>
            </select>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">自动添加小数</label>
          <div class="layui-input-block">
            <select name="ispoint" lay-verify="required"> 
              <option value="">请选择</option>
              <option value="1">是</option>
              <option value="0">否</option>
            </select>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">备注类型</label>
          <div class="layui-input-block">
            <select name="REMARK_TYPE" lay-search="" class="REMARK_TYPE" lay-verify="required"  autocomplete="off"> 
              <option value="">请选择</option>
              <option value="NAME">名称</option>
              <option value="NO">订单号</option>
            </select>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">排序</label>
          <div class="layui-input-block">
            <input type="text" name="sort" class="layui-input" lay-verify="required"  autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">充值备注</label>
          <div class="layui-input-block">
            <input type="text" name="rechargeremark" class="layui-input" autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">显示终端</label>
          <div class="layui-input-block">
            <select name="viewtype" lay-search="" class="viewtype" lay-verify="required"> 
              <option value="">请选择</option>
              <option value="0">全部</option>
              <option value="1">网页端</option>
              <option value="2">APP</option>
            </select>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">户名</label>
          <div class="layui-input-block">
            <input type="text" name="accountname" class="layui-input" lay-verify="required" autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item layui-card-no">
        <div class="layui-inline">
          <label class="layui-form-label">卡号</label>
          <div class="layui-input-block">
            <input type="text" name="accountno" class="layui-input" lay-verify="required|number" maxlength="25"  autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item layui-card">
        <div class="layui-inline">
          <label class="layui-form-label">卡号名称</label>
          <div class="layui-input-block">
            <input type="text" name="accountnoname" class="layui-input" lay-verify="required"  autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">充值赠送点</label>
          <div class="layui-input-block">
            <input type="text" name="rate" class="layui-input" lay-verify="required|number"  autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">金额配置</label>
          <div class="layui-input-block">
            <input type="text" name="amountConfig" class="layui-input" lay-verify="" autocomplete="off" placeholder="逗号分隔(例如100,500,1000)"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">每天赠送最大金额</label>
          <div class="layui-input-block">
            <input type="text" name="todayGiveMaxMoney" class="layui-input" lay-verify="number" autocomplete="off" id="layui-tips"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">赠送打码额(%)</label>
          <div class="layui-input-block">
            <input type="text" name="giveDemanRate" class="layui-input" lay-verify="number" autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item layui-code-box" style="display:none;">
        <div class="layui-inline">
          <label class="layui-form-label">二维码路径</label>
          <div class="layui-input-block">
            <input type="text" name="icon" class="layui-input layui-imgurl" autocomplete='off' readonly style="width:260px;display:inline-block;"/>
            <button class='layui-btn layui-btn-operator layui-btn-normal' id="layui-upload" type="button">&nbsp;&nbsp;选择&nbsp;&nbsp;</button>
            <button class='layui-btn layui-btn-operator layui-btn-normal' id="layui-preview">预览图片</button>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`
};
