var htmlTpl = {
  addHtml: `
    <form class="layui-form mask-box level" lay-filter="add">
      <div class="layui-form-item">
        <label class="layui-form-label">总金额</label>
        <div class="layui-input-block">
          <input type="text" name="totalmoney" class="layui-input" lay-verify="required" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">投注金额</label>
        <div class="layui-input-block">
          <input type="text" name="betmoney" class="layui-input" lay-verify="required" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">数量</label>
        <div class="layui-input-block">
          <input type="text" name="quantity" class="layui-input" lay-verify="required" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">限制领取次数</label>
        <div class="layui-input-block">
          <input type="text" name="limitnum" class="layui-input" lay-verify="required" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">达标充值金额</label>
        <div class="layui-input-block">
          <input type="text" name="notlimitnumamount" class="layui-input" lay-verify="required|number" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">平均值最大百分比</label>
        <div class="layui-input-block">
          <input type="text" name="avgmaxratio" class="layui-input" lay-verify="required" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">平均值最小百分比</label>
        <div class="layui-input-block">
          <input type="text" name="avgmixratio" class="layui-input" lay-verify="required" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">开始时间</label>
        <div class="layui-input-block">
          <input type="text" name="begintime" class="layui-input layui-date" lay-verify="required" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">结束时间</label>
        <div class="layui-input-block">
          <input type="text" name="endtime" class="layui-input layui-date" lay-verify="required" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">间隔时间(分钟)</label>
        <div class="layui-input-block">
          <input type="text" name="intervaltime" class="layui-input" lay-verify="required" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">是否启用</label>
          <div class="layui-input-block" style="margin-left:170px;">
            <select name="enabled">
              <option value="1">是</option>
              <option value="0">否</option>
            </select>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label" style="font-size:13px;">红包领取允许时间(分钟)</label>
        <div class="layui-input-block">
          <input type="text" name="allowtime" class="layui-input" lay-verify="required" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">打码额(%)</label>
        <div class="layui-input-block">
          <input type="text" name="demandorderamount" class="layui-input" lay-verify="required" autocomplete='off'/>
        </div>
      </div>
      <div class="layui-form-item">
          <label class="layui-form-label">备注</label>
          <div class="layui-input-block">
            <input type="text" name="remark" class="layui-input" lay-verify="required" autocomplete='off'/>
          </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block" style="margin-left:170px;">
          <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`
};
