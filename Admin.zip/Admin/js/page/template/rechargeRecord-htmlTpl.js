var htmlTpl = {
  detailHtml: `
    <form class="layui-form mask-box" lay-filter="add">
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">用户账号:</label>
          <div class="layui-input-block">
            <input type="text" name="username" class="layui-input layui-username"/>
          </div>
        </div>
        <div class="layui-inline">
          <label class="layui-form-label">订单号:</label>
          <div class="layui-input-block">
            <input type="text" name="ordernumber" class="layui-input"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">充值方式:</label>
          <div class="layui-input-block">
            <input type="text" name="way" class="layui-input"/>
          </div>
        </div>
        <div class="layui-inline">
          <label class="layui-form-label">充值时间:</label>
          <div class="layui-input-block">
            <input type="text" name="rechargedt" class="layui-input"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">充值户名:</label>
          <div class="layui-input-block">
            <input type="text" name="userbankaccountname" class="layui-input"/>
          </div>
        </div>
        <div class="layui-inline">
          <label class="layui-form-label">充值银行卡:</label>
          <div class="layui-input-block">
            <input type="text" name="userbankaccountno" class="layui-input"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">收款户名:</label>
          <div class="layui-input-block">
            <input type="text" name="platformbankaccountname" class="layui-input"/>
          </div>
        </div>
        <div class="layui-inline">
          <label class="layui-form-label">收款银行卡:</label>
          <div class="layui-input-block">
            <input type="text" name="platformbankaccountnov" class="layui-input"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">充值金额:</label>
          <div class="layui-input-block">
            <input type="text" name="amount" class="layui-input"/>
          </div>
        </div>
        <div class="layui-inline">
          <label class="layui-form-label">手续费:</label>
          <div class="layui-input-block">
            <input type="text" name="fee" class="layui-input"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">操作者:</label>
          <div class="layui-input-block">
            <input type="text" name="operator" class="layui-input"/>
          </div>
        </div>
      </div>
    </form>`
};
