var htmlTpl = {
  transferHtml: `
  <form class="layui-form mask-box bank-open" lay-filter="transfer">
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">源商户id</label>
        <div class="layui-input-block">
          <input type="text" name="sourcemerchantid" class="layui-input" lay-verify="required" disabled/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">目标银行名称</label>
        <div class="layui-input-block">
          <input type="text" name="targetbankname" class="layui-input" lay-verify="required" autocomplete="off"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">目标支行名称</label>
        <div class="layui-input-block">
          <input type="text" name="targetbranchname" class="layui-input" lay-verify="required" autocomplete="off"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">目标开户名称</label>
        <div class="layui-input-block">
          <input type="text" name="targetaccountname" class="layui-input" lay-verify="required" autocomplete="off"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">目标银行卡号</label>
        <div class="layui-input-block">
          <input type="text" name="targetaccountno" class="layui-input" lay-verify="required|number" maxlength="19" autocomplete="off"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">金额</label>
        <div class="layui-input-block">
          <input type="text" name="money" class="layui-input" lay-verify="required|number" autocomplete="off"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">手续费</label>
        <div class="layui-input-block">
          <input type="text" name="fee" class="layui-input" lay-verify="required" autocomplete="off"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-input-block">
        <button class="layui-btn" lay-submit lay-filter="formTrsansfer">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
      </div>
    </div>
  </form>`,
  addHtml: `
    <form class="layui-form mask-box bank-open" lay-filter="add">
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">商户名</label>
          <div class="layui-input-block">
            <input type="text" name="merchantName" class="layui-input" lay-verify="required" autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">代理编码</label>
          <div class="layui-input-block">
            <input type="text" name="agentCode" class="layui-input" autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">商户号</label>
          <div class="layui-input-block">
            <input type="text" name="merchantNo" class="layui-input" lay-verify="required" autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">交易编码</label>
          <div class="layui-input-block">
            <input type="text" name="tranCode" class="layui-input" autocomplete="off"/>
          </div>
        </div>
      </div>
       <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">启用/禁用</label>
          <div class="layui-input-block">
            <select name="enabled" lay-verify="required">
              <option value="">请选择</option>
              <option value="1">启用</option>
              <option value="0">禁用</option>
            </select>
          </div>
        </div>
      </div>
       <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">商户私钥</label>
          <div class="layui-input-block">
            <input type="text" name="privateKey" class="layui-input" lay-verify="required" autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">平台公钥</label>
          <div class="layui-input-block">
            <input type="text" name="publicKey" class="layui-input" autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">其他秘钥</label>
          <div class="layui-input-block">
            <input type="text" name="otherKey" class="layui-input" autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">第三方网关</label>
          <div class="layui-input-block">
            <input type="text" name="thirdGateway" class="layui-input" lay-verify="required" autocomplete="off"/>
          </div>
        </div>
      </div>
       <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">代付网关</label>
          <div class="layui-input-block">
            <input type="text" name="payGateway" class="layui-input" autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">出款类型</label>
          <div class="layui-input-block">
            <select name="withdrawType" lay-verify="required">
              <option value="">请选择</option>
              <option value="1">手动</option>
              <option value="2">自动</option>
            </select>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">最小金额</label>
          <div class="layui-input-block">
            <input type="text" name="minLimit" class="layui-input" lay-verify="required" autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">最大金额</label>
          <div class="layui-input-block">
            <input type="text" name="maxLimit" class="layui-input" lay-verify="required" autocomplete="off"/>
          </div>
        </div>
      </div>
       <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">手续费</label>
          <div class="layui-input-block">
            <input type="text" name="fee" class="layui-input" lay-verify="required" autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">手续费比例</label>
          <div class="layui-input-block">
            <input type="text" name="feeRate" class="layui-input" autocomplete="off"/>
          </div>
        </div>
      </div>
     
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">排序</label>
          <div class="layui-input-block">
            <input type="text" name="sort" class="layui-input" autocomplete="off"/>
          </div>
        </div>
      </div>
     <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label" style="width: 100px">第三方查询网关</label>
          <div class="layui-input-block">
            <input type="text" name="thirdQuery" class="layui-input" autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label" style="width: 100px">第三方白名单</label>
          <div class="layui-input-block">
            <input type="text" name="thirdIp" class="layui-input" autocomplete="off" placeholder="逗号分隔(例如100,500,1000)"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">备注</label>
          <div class="layui-input-block">
            <input type="text" name="remark" class="layui-input" autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`
};
