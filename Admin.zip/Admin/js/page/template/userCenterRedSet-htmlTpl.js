var htmlTpl = {
  addHtml: `
    <form class="layui-form mask-box level" lay-filter="add">
      <div class="layui-form-item">
          <label class="layui-form-label">红包标题</label>
          <div class="layui-input-block">
            <input type="text" name="title" class="layui-input layui-username" lay-verify="required" maxLength="12"/>
          </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">会员范围</label>
        <div class="layui-input-block fanwei-list">
          
          <span class="checkbox-list"></span>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">参与条件</label>
        <div class="layui-input-block layui-requirements">
          <input type="checkbox" value="1" lay-skin="primary" title="已绑定银行卡" checked name="requirements[1]">
          <input type="checkbox" value="2" lay-skin="primary" title="已绑定手机"  name="requirements[2]">
          <input type="checkbox" value="3" lay-skin="primary" title="已验证邮箱"  name="requirements[3]">
          <input type="checkbox" value="4" lay-skin="primary" title="已绑定QQ"  name="requirements[4]">
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">是否启用ip限制</label>
        <div class="layui-input-block">
          <input type="radio" name="limitIp" value="1" title="是" checked>
          <input type="radio" name="limitIp" value="0" title="否">
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">发放总额</label>
        <div class="layui-input-block">
          <input type="text" name="amount" class="layui-input layui-username" lay-verify="required|number" maxLength="7"/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">发放个数</label>
        <div class="layui-input-block">
          <input type="number" name="total" class="layui-input layui-username" lay-verify="required|dme" maxLength="3"/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">失效时间/分钟</label>
        <div class="layui-input-block">
          <input type="text" name="failureTime" class="layui-input layui-username" lay-verify="required|dme" maxLength="6"/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">打码额(%)</label>
        <div class="layui-input-block">
          <input type="text" name="multiple" class="layui-input layui-username" lay-verify="required|dme" maxLength="3"/>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">备注</label>
        <div class="layui-input-block">
          <textarea class="layui-textarea" name="note" lay-verify="required" maxLength="50"></textarea>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`
};
