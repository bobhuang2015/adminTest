var htmlTpl = {
  addHtml: `
    <form class="layui-form mask-box" lay-filter="add">
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">角色类型</label>
          <div class="layui-input-block">
            <select name="roletype">
              <option value="1">用户角色</option>
              <option value="2">管理员角色</option>
            </select>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">角色名称</label>
          <div class="layui-input-block">
            <input type="text" name="rolename" class="layui-input" lay-verify='required' autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`,
  setHtml:`
  <form class="layui-form mask-box" lay-filter="set">
    <div class="layui-form-item dn">
      <div class="layui-inline">
        <label class="layui-form-label">id</label>
        <div class="layui-input-block">
          <input type="text" name="id" class="layui-input" lay-verify='required'/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">角色类型</label>
        <div class="layui-input-block">
          <select name="roletype">
            <option value="1">用户角色</option>
            <option value="2">管理员角色</option>
          </select>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-inline">
        <label class="layui-form-label">角色名称</label>
        <div class="layui-input-block">
          <input type="text" name="rolename" class="layui-input" lay-verify='required' maxLength='16' autocomplete="off"/>
        </div>
      </div>
    </div>
    <div class="layui-form-item">
      <div class="layui-input-block">
        <button class="layui-btn" lay-submit lay-filter="formSet">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
      </div>
    </div>
  </form>`,
  permissonHtml: `<form class="layui-form mask-box" lay-filter="role">
    <div class="layui-form-item" pane="">
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">管理员名称</label>
          <div class="layui-input-block">
            <input type="text" name="username" class="layui-input" lay-verify="required" disabled/>
          </div>
        </div>
      </div>
      <label class="layui-form-label">用户角色</label>
      <div class="layui-input-block role-list"></div>
      <div class="layui-form-item" style="margin-top:30px;">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="role">保存</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </div>
  </form>`,
};
