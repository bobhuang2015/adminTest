var htmlTpl = {
  addHtml: `
    <form class="layui-form mask-box" lay-filter="add">
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">平台类型</label>
          <div class="layui-input-block">
            <select name="thridtype" class="platform" lay-verify='required'>
            </select>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">启用状态</label>
          <div class="layui-input-block">
            <select name="start" class="userLevel" lay-verify='required'>
              <option value="0">禁用</option>
              <option value="1">启用</option>
            </select>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">维护时间(始)</label>
          <div class="layui-input-block">
            <input type="text" name="ser_whdtbegin" class="layui-input"  lay-verify='required' id="layui-start" autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">维护时间(末)</label>
          <div class="layui-input-block">
            <input type="text" name="ser_whdtend" class="layui-input"  lay-verify='required' id="layui-end" autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">日转出金额</label>
          <div class="layui-input-block">
            <input type="text" name="dayTransferOutTotal" class="layui-input"  lay-verify='required|number' autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">月转出金额</label>
          <div class="layui-input-block">
            <input type="text" name="monTransferOutTotal" class="layui-input"  lay-verify='required' autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-inline">
          <label class="layui-form-label">备注</label>
          <div class="layui-input-block">
            <input type="text" name="remark" class="layui-input"  lay-verify='required' autocomplete="off"/>
          </div>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="formAdd">确定</button><a class="layui-btn layui-btn-primary layui-layer-close" href="javascript:;">取消</a>
        </div>
      </div>
    </form>`
};
