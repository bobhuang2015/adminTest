
var peimissionUserBetLog = {
  table:null,
  toolbarHtml:'',
  getToolbarHtml(){ 
  },
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getName(str){
    var obj={
      '投注内容':'投注内容(传统注单)',
      '用户操作日志':'用户操作日志(经典注单)'
    }
    return str=='投注内容' || str=='用户操作日志' ? obj[str] : str ? str : ''
  },
  getContent(data){
    var targetStr = '';
    var txt1 = '投注号码';
    var otherStr = '';
    if(data.content.includes(txt1)){
      let tempArr=data.content.split(' |');
      let userStr = tempArr[0].split('|<')[0];
      let touzhuInfoArr= JSON.parse(tempArr[0].split('|<')[1].match(/【(.*?)】/)[1]); 
      touzhuInfoArr.forEach((v,k)=>{
        targetStr +=`投注号码:${v.touZhuHaoMa} ; 投注类型/玩法:${v.playtypename} ;  `
      })
      tempArr.forEach((v,k)=>{
        k !=0 && (otherStr +=v+'; ')
      })
      targetStr+=`&nbsp;&nbsp;${userStr}; ${otherStr}`
    }else{
      targetStr = data.content ? data.content : '';
    }
    return targetStr;
  },
  getOptions:function(util){
    var _this = this;
    var arr=[
       { field: 'account', title: '用户账号',sort: true,width:120}
      , { field: 'host', title: 'IP地址', width: 120, sort: true}
      , { field:'timestamp',title: '操作时间',sort: true,width:180}
      , { field: 'content', title: '日志内容', sort: true,templet:function(d){return _this.getContent(d)}}
    ]
    return arr
  },
}

layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  peimissionUserBetLog.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  parent.globalAdmin.renderIntDate(laydate,util)
  
  var topHeight = ~~($(".layui-row").height()+40);
  
  var today =  util.toDateString(new Date().getTime(),'yyyy-MM-dd');
  var tomorrow =  util.toDateString(new Date().getTime() + 1000 * 60 * 60 * 24,'yyyy-MM-dd');
  peimissionUserBetLog.table.render({
    elem: '#demo'
    , height: `full-${topHeight}`
    , url: '/logger/search.mvc'
    , page: true
    ,request: {
      pageName: 'pageNum' 
      ,limitName: 'pageSize'
    }
    , method: 'get'
    , cols: [ peimissionUserBetLog.getOptions(util)],
    where: {
      timestampBegin:today,
      timestampEnd:tomorrow,
      content:'投注号码',
      contentSearchType:1
    }
    , parseData: function (res) {
      var result = {
        "code": res.responseCode, 
        "msg": res.responseMessage,
        "count":res.responseData ?  res.responseData.total : 0,
        "data": res.responseData ? res.responseData.list :[]
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
    }
  });
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    peimissionUserBetLog.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



