var profitLossTeamDaily = {
  table:null,
  thirdData:[],
  thirdTotal:[],
  platform:{},
  lotteryTotal:{},
  reqUrl:'/termsProfitStatistics/dailyStatis.mvc',
  reloadTable:function(){
    this.table.reload('demoDaily',{
      // where:data.field,
      page:{
        curr:1  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  showLayer: function(title, url, w, h) {
    layer.open({
      type: 2,
      area: [w + "px", h + "px"],
      fix: false, 
      shadeClose: false,
      shade: 0.4,
      title: title,
      content: url
    });
  },
  getOptions:function(util){
    var arr=[
      {width:52,templet:function(d){return `<i class="iconfont icon-jiahao" data-id="${d.reportdate}"></i>`},rowspan: 2}
      , { width: 120, title:'报表日期',rowspan: 2,templet:function(d){return util.toDateString(d.reportdate, "yyyy-MM-dd")}}
      , { field: 'allProfitloss', width: 120, title:'盈亏',rowspan: 2,templet:function(d){return `<span class='${parent.globalAdmin.getColor((d.allProfitloss+d.allSelfbonusmoney+d.allAgentBonusMoney+d.hdzs))}'>${globalAdmin.commafy((d.allProfitloss+d.allSelfbonusmoney+d.allAgentBonusMoney+d.hdzs).toFixed(3))}</span>`}}
      , { align: 'center',  title:'钱包中心',colspan: 4}
      , { align: 'center',  title:'游戏盈亏',colspan: 6}
    ]
    return arr
  },
  getSmallOption(){
    var arr=[
      { field: 'inmoneytotal', width: 140, title:'充值',templet:function(d){return globalAdmin.commafy(d.inmoneytotal.toFixed(3))}}
      , { field: 'outmoneytotal', width: 140, title:'提现',templet:function(d){return globalAdmin.commafy(d.outmoneytotal.toFixed(3))}}
      , { field: 'hdzs', width: 140, title:'活动赠送',templet:function(d){return globalAdmin.commafy(d.hdzs.toFixed(3))}}
      , { field: 'transfermoneyintotal', width: 140, title:'代理充值',templet:function(d){return globalAdmin.commafy(d.transfermoneyintotal.toFixed(3))}}
      , { field: 'allOrderNumber', width: 120, title:'注单'}
      , { field: 'allOrderMoneyTotal', width: 120, title:'投注额',templet:function(d){return globalAdmin.commafy(d.allOrderMoneyTotal.toFixed(3))}}
      , { width: 140, title:'自身返点总额',templet:function(d){return globalAdmin.commafy(d.allSelfbonusmoney.toFixed(3))}}
      , { width: 140, title:'代理返点总额',templet:function(d){return globalAdmin.commafy(d.allAgentBonusMoney.toFixed(3))}}
      , { field: 'outmoneytotal', width: 120, title:'中奖额',templet:function(d){return globalAdmin.commafy((d.allProfitloss + d.allOrderMoneyTotal).toFixed(3))}}
      , { field: 'allProfitloss', title:'投注盈亏',templet:function(d){return `<span class='${parent.globalAdmin.getColor(d.allProfitloss)}'>${globalAdmin.commafy(d.allProfitloss.toFixed(3))}</span>`}}
    ]
    return arr
  },
  toggleClick(){
    var _this = this;
    $('.layui-table-main table tr').on('click','.iconfont',function(){
      var targetId = $(this).attr('data-id');
      var iconJia = 'icon-jiahao',iconJian = 'icon-jianhao'
      if($(this).hasClass(iconJia)){
        $(this).addClass(iconJian).removeClass(iconJia);
        var targetArr = _this.tableData.filter(v=>{return v.reportdate == targetId})
        _this.thirdData = targetArr[0].thirdGameReportList || [];
        var len = _this.thirdData.length > 0 && _this.thirdData.length || 2;
        $(this).parents('tr').after('<tr class="detail'+targetId+'"><td colspan="13"><iframe src="./profitloss-third-user.html?time='+new Date().getTime()+'" frameborder="0" style="width:95%;padding-left:10px;height:'+(len * 32 + 44)+'px;"></iframe></td></tr>')
      }else{
        $(this).addClass(iconJia).removeClass(iconJian);
        $(`tr.detail${targetId}`).remove();
      }
    })
  },
  tableData:[]
}

layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  profitLossTeamDaily.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;

  var arr1 = profitLossTeamDaily.getOptions(util);
  var arr2 = profitLossTeamDaily.getSmallOption();
  parent.globalAdmin.renderIntDate(laydate,util);

  var topHeight = ~~($(".layui-row").height()+40);

  profitLossTeamDaily.table.render({
    elem: '#demoDaily'
    , height: `full-${topHeight}`
    , url: `${profitLossTeamDaily.reqUrl}`
    , page: false
    // , limit:  10000
    , method: 'get'
    , cols: [arr1,arr2],
    where: {
    }
    , parseData: function (res) {
      var resData = res.responseData;
      profitLossTeamDaily.lotteryTotal = resData.allStatistics;
      profitLossTeamDaily.thirdTotal =resData.allStatistics.thirdGameReportList;
      profitLossTeamDaily.tableData =resData.userDailyReportList.list;
      var result = {
        "code": res.responseCode, 
        "msg": res.responseMessage,
        "count": resData.userDailyReportList.totalRecord,
        "data": resData.userDailyReportList.list
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      if(count>=1){
        profitLossTeamDaily.toggleClick();
        if($('.layui-done-table'))$('.layui-done-table').remove();
        var thirdHtml = '';
        var totalMoney=0;
        if(profitLossTeamDaily.thirdTotal && profitLossTeamDaily.thirdTotal.length>0){
          profitLossTeamDaily.thirdTotal.forEach((v,k)=>{
            var platform =  top.globalAdmin.thirdPlatform[v.platform];
            thirdHtml +=`<tr>
                            <td>  ${platform}投注:${globalAdmin.commafy(v.orderMoneyTotal.toFixed(3))} </td>                                       									
                            <td>  ${platform}中奖:${globalAdmin.commafy((v.orderMoneyTotal + v.profitlossMoneyTotal).toFixed(3))}</td>
                            <td>  ${platform}盈亏:<span class='layui-yinkui ${parent.globalAdmin.getColor(v.profitlossMoneyTotal)}'>${globalAdmin.commafy(v.profitlossMoneyTotal.toFixed(3))}</span></td>                                       									
                            <td>  ${platform}返点:${(v.selfBonusMoney + v.agentBonusMoney).toFixed(3)}</td>                                       									
                            <td>  ${platform}总盈亏:<span class='layui-yinkui ${parent.globalAdmin.getColor(v.agentBonusMoney + v.profitlossMoneyTotal + v.selfBonusMoney)}'>${globalAdmin.commafy((v.agentBonusMoney + v.profitlossMoneyTotal + v.selfBonusMoney).toFixed(3))}</span> </td>                                       									
                        </tr> `
            totalMoney +=v.agentBonusMoney + v.profitlossMoneyTotal + v.selfBonusMoney;
          })
        }
        
        var totalCount = `<tr>
                            <td>  活动赠送:${globalAdmin.commafy(profitLossTeamDaily.lotteryTotal.hdzs)} </td>                                       									
                            <td>  汇总盈亏:<span class='layui-yinkui ${parent.globalAdmin.getColor(totalMoney + profitLossTeamDaily.lotteryTotal.hdzs)}'>${globalAdmin.commafy((totalMoney + profitLossTeamDaily.lotteryTotal.hdzs).toFixed(3))}</span></td>
                            <td>  充值总额:${globalAdmin.commafy(profitLossTeamDaily.lotteryTotal.inmoneytotal.toFixed(3))}</span></td>                                       									
                            <td>  提现总额:${globalAdmin.commafy(profitLossTeamDaily.lotteryTotal.outmoneytotal.toFixed(3))}</td>                                       									
                        </tr> `
        var table = `<table  style="border: 0px solid #d0cdcd;background: #d0cdcd;width:1306px;margin:10px 0 10px 10px;" lay-skin="line" lay-size="sm" class="layui-table layui-done-table">
                      <tbody>
                        <tr>                                                           									
                          <td rowspan="13" width="15%" style="text-align: center;"> 总合计</td>                                                      							    
                        </tr>
                        ${thirdHtml}${totalCount}                                                       								
                      </tbody>
                    </table>`
        $('.layui-table-main table').after(table);
      }
    }
  });
  
  //监听行工具条
  profitLossTeamDaily.table.on('tool(demoDaily)', function(obj){
    var data = obj.data;
    profitLossTeamDaily.thirdData = data.thirdGameReportList;
    if(profitLossTeamDaily.thirdData && profitLossTeamDaily.thirdData.length > 0 ){
      profitLossTeamDaily.thirdData.forEach((v,k,arr)=>{
        arr[k].allSelfbonusmoney = data.allSelfbonusmoney.toFixed(3);
        arr[k].allAgentBonusMoney = data.allAgentBonusMoney.toFixed(3);
      })
    }
    if(obj.event === 'detail'){
      profitLossTeamDaily.showLayer(`第三方日结数据-${util.toDateString(data.reportdate, "yyyy-MM-dd")}`,'./profitloss-third-user.html','1300','800')
    } 
  });
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    profitLossTeamDaily.table.reload('demoDaily',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
  
});



