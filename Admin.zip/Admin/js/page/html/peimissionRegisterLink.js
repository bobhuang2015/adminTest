
var peimissionRegisterLink = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  hasDel:false,
  hasSet:false,
  pageNumber:1,
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var obj={
      '禁用/启用':'hasLock',
      '删除':'hasDel',
      '修改':'hasSet'
    }
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        this[obj[i]]=true;
      })
    }
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var arr=[
      { field: 'username', title: '用户名', width: 140, sort: true}
      , { title: '用户类型', width: 140, sort: true,templet:function(d){return d.usertype == 1  ?  '代理': '会员'}}
      , { field: 'bonus', title: '返点', width: 100, sort: true}
      , { field: 'realRegCode', title: '注册链接', width: 180, sort: true}
      , { field: 'agenturl', title: '代理URL', width: 240, sort: true}
      , { field: 'remark', title: '备注', width: 120, sort: true}
      , { title: '生成时间', width: 180, sort: true,templet:function(d){return util.toDateString(d.createdt, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'lastoperator', title: '操作者', width: 180, sort: true}
      , { field: 'lastoperationtime', title: '操作时间', width: 180, sort: true,templet:function(d){return util.toDateString(d.lastoperationtime, "yyyy-MM-dd HH:mm:ss")}}
      , { title: '操作',toolbar:'#barDemo'}
    ]
    return arr
  },
}

peimissionRegisterLink.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  peimissionRegisterLink.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  
  var topHeight = ~~($(".layui-row").height()+40);
  peimissionRegisterLink.table.render({
    elem: '#demo'
    , height: `full-${topHeight}`
    , url: '/registercode/list.mvc'
    , page: true
    , method: 'get'
    , cols: [ peimissionRegisterLink.getOptions(util)],
    where: {
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results
      };
      peimissionRegisterLink.tableData=res.results;
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      peimissionRegisterLink.pageNumber = cur;
    }
  });
  
  //监听行工具事件
  peimissionRegisterLink.table.on('tool(demo)', function(obj){
    var data = obj.data;
    if(obj.event === 'lock'){
      var text = data.enabled==1 ? '禁用' : '启用'; 
      layer.confirm(`是否${text}注册链接 ${data.realRegCode}?`, function(index){
        var reqData={
          userid:data.userid,
          id:data.id
        }
        parent.ajaxService.doPost("/registercode/updateEnabled.mvc",reqData,function(res){
          var msg = res.resultMessage;
          if(res.resultCode ==0){
            peimissionRegisterLink.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(obj.event =='del'){
      layer.confirm(`是否删除注册链接 ${data.realRegCode}?`, function(index){
        var reqData={
          userid:data.userid,
          id:data.id
        }
        parent.ajaxService.doPost("/registercode/delete.mvc",reqData,function(res){
          var msg = res.resultMessage;
          if(res.resultCode ==0){
            peimissionRegisterLink.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(obj.event ==='set'){
      layer.open({
        title:'修改',
        type: 1,
        skin: 'layui-layer-test',
        area: ['400px', '240px'],
        content: htmlTpl.setHtml,
        success:function(){
          var obj={
            "agenturl": data.agenturl,
            "remark":data.remark
          }
          form.val('set', obj);
          form.on('submit(formSet)',function(submitData){
            var reqData = submitData.field;
            reqData.id = data.id;
            parent.ajaxService.doPost('/registercode/updateAgentUrl.mvc',reqData,function(res){
              var msg = res.resultMessage;
              if(res.resultCode==0){
                peimissionRegisterLink.layerCallback(msg);
              }else{
                layer.msg(msg)
              }
            })
            return false;
          })
        }
      })
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    peimissionRegisterLink.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



