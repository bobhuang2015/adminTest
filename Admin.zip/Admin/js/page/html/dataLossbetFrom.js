var dataLossBetFrom = {
  getTable(data,id){
    var html = '';
    var tempArr=[];
    data.forEach(v=>{
      if(Object.keys(v).length !=0){
        tempArr.push(v)
      }
    })
    tempArr.forEach(v=>{
      html +=`<tr><td>${v.name}</td><td>${v.value}</td></tr>`;
    })
    return `<table class="layui-table" lay-size="sm" style="width:100%;"><thead><tr><th><div class="table_th">终端名称</div></th><th><div class="table_th">${id =='layui-bet-rate' ? '投注额' : '投注量'}</div></th></tr></thead><tbody class="tbody">${html}</tbody></table>`
  },
  getTable2(obj){
    var html = '';
    obj.date.forEach((v,k)=>{
      html +=`<tr><td>${v}</td><td>${obj.pcArr[k]}</td><td>${obj.andriodArr[k]}</td><td>${obj.iphoneArr[k]}</td><td>${obj.h5Arr[k]}</td><td>${obj.h5AndriodArr[k]}</td><td>${obj.h5IphoneArr[k]}</td></tr>`;
    })
    var headHtml=``;
    var headArr=['日期','电脑投注','安卓投注','苹果投注','H5投注','安卓H5投注','苹果H5投注'];
    for(var i=0;i<headArr.length;i++){
      headHtml +=`<th><div class="table_th2">${headArr[i]}</div></th>`
    }
    return `<table class="layui-table" lay-size="sm" style="width:100%;"><thead><tr>${headHtml}</tr></thead><tbody class="tbody">${html}</tbody></table>`
  },
  renderPie(legendData,seriesData,id) {
    var _this = this;
    if(seriesData.length ==0){
      $(`#${id}`).html('<div class="layui-nodata">暂无数据!</div>')
      return
    }
    var option = {
        title : {},
        tooltip : {
          trigger: 'item',
          formatter: "{b} : {c} [{d}%]"
        },
        toolbox: {
          show: true,
          feature:{
            dataView: {
              lang:['','关闭'],
              show: true, 
              title:'表格',
              readOnly: true,
              optionToContent:function(opt){
                var table = _this.getTable(seriesData,id);
                return table;
              },
            },
          }
        },
        legend: {
          orient: 'horizontal',
          left: 'center',
          top:'10%',
          data: legendData
        },
        series : [
            {
                name: '数据统计',
                type: 'pie',
                radius : '55%',
                center: ['50%', '60%'],
                data:seriesData,
                itemStyle: {
                    emphasis: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                }
            }
        ]
    };
    var myChart = echarts.init(document.getElementById(id));
    myChart.setOption(option,true);
  },
  renderLine(obj){
    if(obj.pcArr.length ==0){
      $(`#layui-bet-trend`).html('<div class="layui-nodata">暂无数据!</div>')
      return
    }
    var _this = this;
    option = {
      tooltip: {
          trigger: 'axis'
      },
      xAxis: [
          {
              type: 'category',
              data: obj.date,
              axisPointer: {
                  type: 'shadow'
              }
          }
      ],
      yAxis: [
          {
              type: 'value',
              name: '投注量',
              min: 0,
              axisLabel: {
                  formatter: '{value}'
              }
          }
      ],
      toolbox: {
        show: true,
        feature:{
          dataView: {
            lang:['','关闭'],
            show: true, 
            title:'表格',
            readOnly: true,
            optionToContent:function(opt){
              var table = _this.getTable2(obj);
              return table;
            },
          },
        }
      },
      series: [
          {
              name:'电脑投注',
              type:'bar',
              data:obj.pcArr
          },
          {
              name:'安卓投注',
              type:'bar',
              data:obj.andriodArr
          },
          {
              name:'苹果投注',
              type:'bar',
              data:obj.iphoneArr
          },
          {
              name:'H5投注',
              type:'bar',
              data:obj.h5Arr
          },
          {
              name:'安卓H5投注',
              type:'bar',
              data:obj.h5AndriodArr
          },
          {
              name:'苹果H5投注',
              type:'bar',
              data:obj.h5IphoneArr
          }
      ]
    };
    var ele = document.getElementById('layui-bet-trend')
    var myChart = echarts.init(ele);
    myChart.setOption(option,true);
  },
  getData(reqData) {
    var _this = this;
    top.ajaxService.doGet("/gameGatherDaily/statisByBetType.mvc",reqData,function(res) {
        if (res.resultCode == 0) {
          // if($('.layui-nodata'))$('.layui-nodata').remove();
          var data = res.results[0];
          var deviceData = data.deviceScaleList; //投注额/注单占比
          var trendData = data.deviceBetCountTrendList;//注单走势
          var seriesDataArr = [];
          var legendDataArr = [];
          var betCountArr = [];
          // 投注额走势数据
          var betObj = {
            date:[],
            pcArr:[],
            andriodArr:[],
            iphoneArr:[],
            h5Arr:[],
            h5AndriodArr:[],
            h5IphoneArr:[]
          }
          var betFromObj={
            0:'pcArr',
            1:'andriodArr',
            2:'iphoneArr',
            3:'h5Arr',
            4:'h5AndriodArr',
            5:'h5IphoneArr'
          }
          getUsefulData();

          function getUsefulData(){
            deviceData.length > 0 && deviceData.forEach((v,k)=>{
              var tempObj = {};
              var tempObj2 = {};
              v.betCount > 0 && (tempObj.value = +v.betMoneyTotal.toFixed(2));
              v.betCount > 0 && (tempObj2.value =  v.betCount);
              v.betCount > 0 && (tempObj.name = v.mobileBetName);
              v.betCount > 0 && (tempObj2.name = v.mobileBetName);
              legendDataArr.push(v.betCount > 0 && v.mobileBetName);
              seriesDataArr.push(tempObj);
              betCountArr.push(tempObj2);
            })
          }
          trendData.length > 0 && trendData.forEach(v=>{
            if(v.mobileBet==0)betObj.date.push(v.reportDate.substr(5).replace(/-/g,'\/'))
            betObj[betFromObj[v.mobileBet]].push(v.betCount)
          })
          _this.renderPie(legendDataArr,seriesDataArr,'layui-bet-rate');

          _this.renderPie(legendDataArr,betCountArr,'layui-bet-moshi');
          _this.renderLine(betObj);
        }else{
          layer.msg(res.resultMessage)
        }
      }
    );
  }
};

layui.use(["laydate", "form","util"], function() {
  var laydate = layui.laydate;
  var form = layui.form;
  var util = layui.util;
  parent.globalAdmin.isYesterday = !0;
  parent.globalAdmin.renderIntDate(laydate,util);
  var reqData = {
    reportdate_begin:$('#start').val(),
    reportdate_end:$('#end').val(),
  }
  dataLossBetFrom.getData(reqData);

  // 表单提交demo
  form.on("submit(formDemo)", function(data) {
    var reqData = {
      reportdate_begin:data.field.reportdate_begin,
      reportdate_end:data.field.reportdate_end
    }
    dataLossBetFrom.getData(reqData);
    return false;
  });
});
