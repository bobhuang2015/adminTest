
var rechargeDeduction = {
  table:null,
  toolbarHtml:'',
  deductionTypeObj:{},
  is:!0,
  token:'',
  renderUserlevel:function(data){
    var html='';
    data.forEach(function(v,k){
      html+=`<option value="${v.id}">${v.name}</option>`
    })
    $(".userLevel").append(html);
  },
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
          editHtml +='<button id="'+i+'" class="layui-btn" lay-event="'+i+'">'+i+'</button>'
      })
    }
    this.toolbarHtml =`<div>${editHtml}</div>`;
  },
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1  
      }
	  })
  },
  rechargeTypeObj:{},
  getRechargeType(form){
    var _this = this;
    this.renderUserlevel(parent.globalAdmin.userLevelArr);
    parent.ajaxService.doGet("/rechargType/getRechageType.mvc",null,function(res){
      if(res.resultCode==0){
        var html="";
        _this.rechargeTypeObj=res.results[0];
        for(var i in res.results[0]){
          html+=`<option value='${i}'>${res.results[0][i]}</option>`
        }
        $("#rechargeMethod").append(html);
        form.render('select')
      }
    })
  },
  getDeductionType(form){
    var _this = this;
    parent.ajaxService.doGet("/getEnumByName.mvc",{enumName:'Deduction_Type'},function (res) { 
      if(res.resultCode == 0){
        var data = res.results[0];
        _this.deductionTypeObj=data;
        _this.renderData('rechargeType',data);
        form.render("select",'add');
      }
    })  
  },
  formatState(state){
    var obj={
      "1":"处理中",
      "2":"成功",
      "3":"失败",
    }
    return obj[state];
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var arr=[
      { field: 'ordernumber', title: '订单号', width: 180, sort: true}
      , { field: 'username', title: '用户账号', width: 120,sort: true}
      , { field: 'changeitem', title: '扣款方式', width: 120,sort: true,templet:function(d){return rechargeDeduction.rechargeTypeObj[d.changeitem]}}
      , { field: 'changemoney', title: '扣款金额', width: 120,sort: true,templet:function(d){return d.changemoney.toFixed(3)}}
      , { field: 'demandorderamount', title: '要求打码额(%)', width: 160,sort: true}
      , { field: 'changetime', title: '充提时间', width: 180, sort: true,templet:function(d){return util.toDateString(d.changetime, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'state', title: '状态', width: 120,templet:function(d){return rechargeDeduction.formatState(d.state)}}
      , { field: 'operator', title: '操作者', width: 120}
      , { field: 'remark', title: '备注'}
    ]
    return arr
  },
  getUserId(name){
    parent.ajaxService.doGet("/systemDepositAndWithdraw/findUser.mvc",{userName:name},function(res){
      if(res.resultCode==0){
        var data = res.results[0].capitalCenter;
        $(".layui-balance").val(data.accountbalance);
        $(".layui-userid").val(data.userid);
        parent.ajaxService.doGet('/systemDepositAndWithdraw/getToken.mvc',{userId:data.userid},function(res){
          if(res.resultCode == 0 ){
            rechargeDeduction.token = res.results[0];
          }
        })
      }else{
        layer.msg('没有该用户请重新输入!')
      }
    })
  },
  renderData(id,data){
    var html='';
    for(var i in data){
      html+=`<option value="${i}">${data[i]}</option>`
    }
    $(`.${id}`).append(html);
  },
  renderTotal(res){
    if (res.data && res.data.length > 0 && res.total){
      var str='<tr class="table-total"><td colspan="50">总量合计:';
      res.total.forEach((v,k)=>{
          str+= `<span>${v.changename}：${v.sumChangemoney}</span>`
      })
      str +='</td></tr>';
      $('.layui-table-body table').append(str)
    }
  },
  walletAlert(title,form,data){
    var _this = this;
    layer.open({
      title:title,
      type: 1,
      skin: 'layui-layer-test',
      area: ['600px', '420px'],
      content: htmlTpl.walletHtml,
      success:function(){
        if(JSON.stringify(_this.deductionTypeObj) =='{}'){
          _this.getDeductionType(form)
        }else{
          _this.renderData('rechargeType',_this.deductionTypeObj);
          form.render("select",'add');
        }
        var obj={
          "username": '',
          "userid": '',
          "accountbalance":'',
          "changeitem":'',
          "changemoney":'',
          "remark":''
        }
        form.val('add', obj);
        $(".layui-username").on('change',function(){
          var name = $(this).val();
          _this.getUserId(name);
        })
        form.on('submit(formAdd)',function(submitData){
          var reqUrl = '/systemDepositAndWithdraw/withdraw.mvc';
          var reqData = Object.assign(submitData.field,{changetype:3,token:rechargeDeduction.token});
          if(+reqData.changemoney <= 0){
            layer.msg('请输入比0大的数值！');
            return false;
          }
          $('button[lay-filter="formAdd"]').addClass('layui-btn-disabled').html('提交中');
          if(rechargeDeduction.is){
            rechargeDeduction.is=0;
            rechargeDeduction.token && parent.ajaxService.doPost(reqUrl,reqData,function(res){
              var msg = res.resultMessage;
              rechargeDeduction.is=!0;
              if(res.resultCode==0){
                rechargeDeduction.token='';
                _this.layerCallback(msg);
              }else{
                layer.msg(msg)
              }
            })
            return false;
          }
        })
      }
    })
  },
}

rechargeDeduction.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  rechargeDeduction.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  globalAdmin.renderRechargeDate(laydate,util)
  rechargeDeduction.table.render({
    elem: '#demo'
    , height: 'full-80'
    , url: '/systemDepositAndWithdraw/search.mvc'
    , toolbar: rechargeDeduction.toolbarHtml
    , defaultToolbar:[]
    , page: true
    , method: 'get'
    , cols: [ rechargeDeduction.getOptions(util)],
    where: {
      'changetype':3
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results[0],
        "total": res.results[0] && res.results[1]
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      rechargeDeduction.renderTotal(res);
    }
  });
  
rechargeDeduction.getRechargeType(form);
  // 金额验证;
  form.verify({
    money:function(value,item){
      var patrn = /^\d+(\.\d+)?$/;
      if(!patrn.exec(value)){
        return '只能输入数字或者带小数点的数字'
      }
    }
  })
  
  // 工具栏操作
  rechargeDeduction.table.on("toolbar(demo)",function(res){
    var checkStatus = rechargeDeduction.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    var event = res.event;
    switch (event) {
      case '钱包中心扣款':
        rechargeDeduction.walletAlert(event,form,data)
      break;
      default:
        break;
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    rechargeDeduction.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        },
        done:function(res){
          rechargeDeduction.renderTotal(res);
        }
    })
    return false;
  });
});



