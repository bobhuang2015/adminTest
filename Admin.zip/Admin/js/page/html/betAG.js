
var betAG = {
  table:null,
  toolbarHtml:'',
  stateObj:{},
  playTypeArr:[],
  tableData:[],
  pageNumber:1,
  tableIns:30,
  hasDaochu:false,
  name:'thirdGame',
  currentPlatform:1,
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){
    var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    permision && permision.forEach(v=>{
      if(v.menuName.includes('导出数据')){
        this.hasDaochu=!0;
        $('button[lay-filter="formDaochu"]').show();
      }
    })
  },
  renderHtml(data,ele,is){
    var html='';
    data.forEach((v,k)=>{
      html+=`<option value="${v.code}">${v.name}</option>`
    })
    $(`.${ele}`).append(html);
  },
  getGameplatform(form,util){
    var _this = this;
    parent.ajaxService.doGet("/thirdPartyBetRecordsWeb/getThirdPartyPlatform.mvc",null,function(res){
      if(res.resultCode == 0){
        var html='';
        var data = res.results[0];
        _this.platformObj = data;
        for(var i in data){
          html+=`<option value="${i}">${data[i]}</option>`;
        }
        $(".platform").html(html);
        form.render('select');
        var tempArr=Object.keys(data);
        _this.currentPlatform = tempArr[0]
        betAG.getSettleStatus(util,_this.currentPlatform);
      }
    })
  },
  getSettleStatus(util,platformId){
    var _this = this;
    top.ajaxService.doGet("/thirdPartyBetRecordsWeb/getEnumSettleStatus.mvc",null,function(res){
      if(res.resultCode==0){
        var html='';
        var data = res.results[0];
        top.globalAdmin.thirdStateObj = data;
       _this.tableIns=_this.table.render({
          elem: '#demo'
          , height: 'full-100'
          , url: '/thirdPartyBetRecordsWeb/search.mvc'
          , page: true
          , method: 'get'
          , cols: [ _this.getOptions(util)],
          where: {
            platform:platformId
          }
          , parseData: function (res) {
            var result = {
              "code": res.resultCode, 
              "msg": res.resultMessage,
              "count": res.meta.totalRecord,
              "data": res.results[0],
              "total":res.results[0].length > 0 && res.results[1]
            };
            return result
          },
          response: {
            statusCode: '0'
          },
          done: function (res, cur, count) {
            _this.renderTotal(res);
            _this.pageNumber = cur;
            betAG.tableData = res.data;
          }
        });
      }
    })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var arr=[
      { field: 'billNo', title: '投注单号', width: 180, sort: true}
      , { field: 'userName', title: '用户账号', width: 160, sort: true}
      , { field: 'gameTypeName', title: '游戏类型', width: 140, sort: true}
      , { field: 'playTypeName', title: '玩法类型', width: 140, sort: true}
      , { title: '投注时间', width:180,templet:function(d){return util.toDateString(d.betTime, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'betMoney', title: '投注金额', width: 140, sort: true,templet:function(d){return d.betMoney.toFixed(3)}}
      , { field: 'validBetMoney', title: '有效投注额', width: 140, sort: true,templet:function(d){return d.validBetMoney.toFixed(3)}}
      , { title: '结算状态', width: 140,templet:function(d){return top.globalAdmin.thirdStateObj[d.settleStatus]}}
      , { title: '结算时间', width:180,templet:function(d){return util.toDateString(d.settleTime, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'profitMoney', title: '投注盈亏',templet:function(d){return `<span class='${parent.globalAdmin.getColor(d.profitMoney)}'>${d.profitMoney.toFixed(3)}</span>`}}
    ]
    return arr
  },
  renderTotal(res){
    if (res.data && res.data.length > 0 && res.total){
      var tr = '<tr class="table-total"><td colspan="50">总量合计：<span>投注总额： '+res.total.betMoney+'</span>'+
            '<span>有效投注额度： '+res.total.validBetMoney +'</span>'+'<span>投注盈亏：<a class="'+parent.globalAdmin.getColor(res.total.profitMoney)+'">'+res.total.profitMoney+'</a></span></td></tr>'
      $('.layui-table-body table').append(tr)
    }
  }
}

betAG.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  betAG.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  betAG.getGameplatform(form,util);
  top.globalAdmin.renderRechargeDate(laydate,util);
  
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    delete data.field.isAll
    betAG.tableIns = betAG.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        },
        done:function(res){
          betAG.tableData = res.data;
          betAG.renderTotal(res);
        }
    })
    return false;
  });
  
  form.on('submit(formDaochu)', function (data) {
    betAG.hasDaochu && parent.globalAdmin.exportData(form,data,betAG);
    return false;
  });
  

  //平台选择
  form.on('select(platform)',function(data){
    betAG.currentPlatform = data.value;
  })
  $(document).on('click',".layui-btn-normal",function(){
    var startVal = $('#start').val(),endVal=$('#end').val();
    var timeStamp = new Date(endVal).getTime() - new Date(startVal).getTime();
    var dayTime = 24 * 60 * 60 *1000;
    if(startVal && endVal){
      var reqData = {
        platform:betAG.currentPlatform,
        startTime:startVal,
        endTime:endVal
      }
      if(timeStamp > dayTime){
        layer.alert('时间间隔不能超过一天哦!');
        return
      }
      var index = layer.load(2);
      parent.ajaxService.doPost('/thirdPartyManualSync/manualSync.mvc',reqData,function(res){
        layer.close(index);
        setTimeout(()=>{
          layer.alert(res.resultMessage);
        },300)
      })
    }else{
      layer.alert('请选择日期范围。')
    }
  })
  // tips事件处理
  var index=0;
  $(".layui-btn-normal").mouseover(function() {
    index=layer.tips('同步数据时间范围请选择在7天内，且间隔不能超过一天', this, {
      tips: [2, "#FF5722"],
      time: 10e3
    });
  }).mouseout(function(){
      layer.close(index);
  })
});



