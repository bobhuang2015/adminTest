var profitLossBetplay = {
  table:null,
  renderGametype(data){
    var html='';
    data.forEach((v,k)=>{
      html+=`<li data-id="${v.id}"  class="${ k >7 ? `hide layui-toggle` :''}" ${ k >7 ? `data-num=${k}` :''}>${v.name}</li>`
    })
    $(".layui-lottery-box").append(html);
  },
  getOptions:function(){
    var arr=[
      { field: 'playTypeName', width: 180, title:'玩法大类',sort: true}
      , { field: 'betTypeName',title:'玩法小类',width:180,sort: true}
      , { field: 'betNum',title:'投注数量',sort: true}
    ]
    return arr
  },
}

profitLossBetplay.renderGametype(top != parent ? top.globalAdmin.gameListArr : JSON.parse(localStorage.getItem('globalAdmin')).gameListArr);
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  profitLossBetplay.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  
  parent.globalAdmin.isYesterday = !0;
  parent.globalAdmin.renderIntDate(laydate,util);
  
  profitLossBetplay.table.render({
    elem: '#demo'
    , height: 700
    , url: '/betrecord/getGameTypeBetTypeCount.mvc'
    , method: 'get'
    , page:false
    , cols: [ profitLossBetplay.getOptions()],
    where: {
      betdt_begin:$("#start").val(),
      betdt_end:$('#end').val()
    }
    , parseData: function (res) {
      var total = 0;
      res.results[0].length > 0 && res.results[0].forEach(v=>{
        total += v.betNum
      })
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results[0],
        "total":total
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      
    if (res.data && res.data.length > 0 && res.total){
      var tr = '<tr class="table-total"><td colspan="20">总量合计：<span>投注数量 : '+res.total+'</span></td></tr>'
      $('.layui-table-body table').append(tr)
    }
    }
  });
  
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
   var obj = data.field;
   var gametype = $('.layui-lottery-box li.active').attr('data-id');
   Object.assign(obj,{gametype:gametype})
    profitLossBetplay.table.reload('demo',{
        where:obj,
        page:{
            curr:1  
        }
    })
    return false;
  });

  
  $('.layui-lottery-box li').on('click',function(){
    $(this).addClass('active').siblings().removeClass('active');
  })
  $(document).on('click','.layui-btn-more',function(){
    if($(this).hasClass('r180')){
      $('.layui-lottery-box li.layui-toggle').addClass('hide');
      parent.$('iframe[tab-id=5]').css('height',"760px")
    }else{
      $('.layui-lottery-box li').removeClass('hide');
      parent.$('iframe[tab-id=5]').css('height',"870px")
    }
    $(this).toggleClass('r180');
    return false;
  })
  parent.$('iframe[tab-id=5]').css('height',"760px")
});



