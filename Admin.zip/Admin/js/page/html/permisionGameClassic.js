
var permisionGameClassic = {
  table:null,
  hasSet:true,
  pageNumber:1,
  currentPlayId:1,
  currentTabIndex:0,
  isOnce:!0,
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action ='permision-game-classic';
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i =='设置模式'){
         this.hasSet=true;
        }
      })
    }
  },
  getGametype(form){
    var _this = this;
    var p = new Promise((resolve,reject)=>{
      parent.ajaxService.doGet("/lotteryOdds/getOddsGameByClassic.mvc",null,function(res){
        if(res.resultCode == 0){
          var html='';
          var data = res.results;
          parent.globalAdmin.classicGameList = data;
          _this.currentPlayId = data[0].gametype;
          resolve( _this.currentPlayId);
          data.forEach(function(v,k){
            html+=`<option value="${v.gametype}">${v.gamename}</option>`
          })
          $(".layui-game-type").append(html);
          form.render('select');
        }
      })
    })
    return p;
  },
  typeObj:{
    '1':'元',
    '2':'角',
    '3':'分',
    '4':'厘'
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1  
      }
	  })
  },
  getMoshi(str){ //转换提款信息
    var arr=[];
    var _this = this;
    var temp = str.split(",");
    temp.forEach(function(v,k){
      arr.push(_this.typeObj[v])
    })
    return arr.length > 0 ? arr.join() :''
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  renderPlayType(form,element,id){//玩法渲染
    var _this = this;
    var playHtml = '';
    var activePlayTypeName = '';
    this.table.render({
      elem: '#demo'
      , height: `full-120`
      , url: '/lotteryOdds/getClassicOddsByGameType.mvc'
      , method: 'get'
      , cols: [ _this.getOptions()],
      where: {
        gameType:id
      }
      , parseData: function (res) {
        // 渲染tab；
        if(_this.isOnce){
          res.results.forEach((v,k)=>{
            playHtml+=`<li>${v.name}</li>`
          })
          $(".layui-tab-playtype").html(playHtml);
          $(".layui-tab-playtype li:eq(0)").addClass('layui-this');
          element.render('tab','tab_box_playtype');
          _this.isOnce = 0;
        }

        var result = {
          "code": res.resultCode, 
          "msg": res.resultMessage,
          "count": res.results[_this.currentTabIndex].list.length,
          "data": res.results[_this.currentTabIndex].list
        };
        return result
      },
      response: {
        statusCode: '0'
      },
      done: function (res, cur, count) {
      }
    });
  },
  getOptions:function(){
    var _this = this;
    var arr=[
      { field: 'betName', title: '玩法算法名称', width: 140, sort: true}
      , { field: 'baseScale', title: '基础赔率', width: 140, sort: true}
      , { field: 'multiple', title: '倍率',sort: true,width:140}
      , { field: 'pattern', title: '投注模式',sort: true,width:160,templet:function(d){return _this.getMoshi(d.pattern)}}
      , { title: '操作',toolbar:'#barDemo'}
    ]
    return arr
  }
}

layui.use(['laydate', 'table', 'form', 'layer','element'], function () {
  var laydate = layui.laydate;
  permisionGameClassic.table = layui.table;
  var form = layui.form;
  var element = layui.element;
  var layer = layui.layer;
  // permisionGameClassic.getToolbarHtml();
  permisionGameClassic.getGametype(form).then((id)=>{
    permisionGameClassic.renderPlayType(form,element,id)
  })
  //玩法tab
  element.on('tab(tab_box_playtype)', function (data) {
    permisionGameClassic.currentTabIndex = data.index; 
    permisionGameClassic.renderPlayType(form,element,permisionGameClassic.currentPlayId)
  })
  //彩种切换
  form.on('select(gameType)', function(data){
    permisionGameClassic.currentPlayId = data.value;
    permisionGameClassic.isOnce=!0;
    permisionGameClassic.currentTabIndex=0;
    permisionGameClassic.renderPlayType(form,element,data.value)
  });
  //监听行工具事件
  permisionGameClassic.table.on('tool(demo)', function(obj){
    var data = obj.data;
    var event = obj.event;
    if(event ==='set'){
    layer.open({
      title:'设置模式',
      type: 1,
      skin: 'layui-layer-test',
      area: ['400px', '200px'],
      content: htmlTpl.addHtml,
      success:function(){
        var obj={};
        data.pattern.split(',').forEach(function(v,k){
          Object.assign(obj,{['pattern['+v+']']:true})
        })
        form.val('set',obj)
        form.render(null,'set');
        form.on('submit(formSet)',function(submitData){
          var fieldData = submitData.field;
          var pattersArr=[];
          for(var i in fieldData){
            if(i.indexOf("pattern")>-1){
              pattersArr.push(fieldData[i])
            }
          }
          var reqData={
            betLossId:data.betLossId,
            pattern:pattersArr.join()
          }
          if(pattersArr.length ==0){
            layer.msg('请至少选择一个投注模式!')
            return false
          }
          parent.ajaxService.doPost('/lotteryOdds/updateBetLossPattern.mvc',reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              permisionGameClassic.layerCallback(msg);
            }else{
              layer.msg(msg)
            }
          })
          return false;
        })
      }
    })
    }
  })
});



