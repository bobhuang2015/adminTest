
var profitLossLotteryDetail = {
  renderData(data){
    var html = '';
    parent.profitLossLottery.detailData.forEach((v,k)=>{
      html+=`<tr>
        <td>${v.platformName}</td>
        <td>${v.betNum}</td>
        <td>${top.globalAdmin.commafy(v.betAmount.toFixed(3))}</td>
        <td>${top.globalAdmin.commafy(v.winAmount.toFixed(3))}</td>
        <td class="${top.globalAdmin.getColor(v.profitAmount)}">${top.globalAdmin.commafy((v.profitAmount).toFixed(3))}</td>
        <td>${v.betNum ? (v.profitAmount / v.betAmount * 100).toFixed(3) : '0.000'}%</td>
        <td>${top.globalAdmin.commafy(v.selfBonusAmount.toFixed(3))}</td>
        <td>${top.globalAdmin.commafy(v.agentBonusAmount.toFixed(3))}</td>
        <td class="${top.globalAdmin.getColor(v.shijiProfit)}">${top.globalAdmin.commafy(v.shijiProfit.toFixed(3))}</td>
        <td>${v.betAmount ? top.globalAdmin.commafy((v.shijiProfit / v.betAmount * 100).toFixed(3)) :'0.000'}%</td>
      </tr>`
    })
    $(".tbody").append(html);
    // $('.yinkui-box').html(`盈亏总额:<span class="${top.globalAdmin.getColor(parent.profitLossLottery.yinKuiTotal)}">${top.globalAdmin.commafy(parent.profitLossLottery.yinKuiTotal)}</span>`)
  }
}
profitLossLotteryDetail.renderData(parent.profitLossLottery.detailData)

{/* <td class="${top.globalAdmin.getColor(v.profitAmount)}">${top.globalAdmin.commafy((v.betAmount ? ((v.profitAmount/v.betAmount) * 100).toFixed(3)+'%' : '0%'))}</td> */}


