var profitLossLotteryBetPercent = {
  renderPie(legendData,seriesData) {
    var myChart = echarts.init(document.getElementById("demo"));
    var option = {
        title : {},
        tooltip : {
          trigger: 'item',
          formatter: "{b} :{c} [{d}%]"
        },
        legend: {
          orient: 'horizontal',
          left: 'center',
          top:'10%',
          data: legendData
        },
        series : [
            {
                name: '投注占比统计',
                type: 'pie',
                radius : '55%',
                center: ['50%', '60%'],
                data:seriesData,
                itemStyle: {
                    emphasis: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                }
            }
        ]
    };
    myChart.setOption(option);
  },
  getData(reqData) {
    var _this = this;
    parent.parent.ajaxService.doGet("/gameGatherDaily/statisByBetType.mvc",reqData,function(res) {
        if($('.layui-nodata'))$('.layui-nodata').remove();
        if (res.resultCode == 0) {
          var data = res.results[0];
          var total = res.results[1].toFixed(2);
          var seriesDataArr = [];
          var legendDataArr = [];
          data.forEach((v,k)=>{
            if(v.betmoneytotal){
              legendDataArr.push(v.mobileBetName);
              var tempObj = {};
              tempObj.value = v.betmoneytotal.toFixed(2);
              tempObj.name = v.mobileBetName;
              seriesDataArr.push(tempObj);
            }
          })
          if(!(+total))$('#demo').before('<div class="layui-nodata">无数据!</div>')
          _this.renderPie(legendDataArr,seriesDataArr)
        }
      }
    );
  }
};

// profitLossLotteryBetPercent.getToolbarHtml();
profitLossLotteryBetPercent.getData(null);
layui.use(["laydate", "form", "layer","util"], function() {
  var laydate = layui.laydate;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  parent.globalAdmin.renderIntDate(laydate,util);

  // 表单提交demo
  form.on("submit(formDemo)", function(data) {
    var reqData = {
      reportdate_begin:data.field.reportdate_begin,
      reportdate_end:data.field.reportdate_end
    }
    profitLossLotteryBetPercent.getData(reqData);
    return false;
  });
  laydate.render({
    elem: "#start" //指定元素
  });
  laydate.render({
    elem: "#end" //指定元素
  });
});
