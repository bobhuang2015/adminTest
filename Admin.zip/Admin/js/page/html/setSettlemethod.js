
var setSettlemethod = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  getToolbarHtml(){ 
    var action = window.name;
    var permision = parent.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i !='解锁' && i!='增加'){
          editHtml +='<button id="'+i+'" class="layui-btn layui-btn-disabled" lay-event="'+i+'">'+i+'</button>'
        }
        if(i=='解锁'){
          this.hasLock=true;
        }
        if(i=='增加'){
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${editHtml}<div style="display:inline-block;margin-left:10px;">${otherHtml}</div></div>`;
  },
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1  
      }
	  })
  },
  balanceList:{},
  getBalanceList(){
    parent.ajaxService.doGet("/lotteryOdds/getKjBalancerList.mvc",null,function(res){
    })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var arr=[
      {type:'checkbox',width:80}
      , { field: 'name', title: '玩法', width: 140,sort: true}
      , { title: '类型', width: 180,sort: true,templet:function(d){return d.gametype == 2 ? '六合彩' : '普通彩票'}}
      , { field: 'gameGenres', title: '结算方式', width: 780,sort: true}
    ]
    return arr
  },
  editIdArr:[],
  tableData:[]
}

// setSettlemethod.getToolbarHtml();
setSettlemethod.getBalanceList();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  setSettlemethod.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  var requestUrl = '/lotteryOdds/listKjPalyAll.mvc';
  setSettlemethod.table.render({
    elem: '#demo'
    , height: 600
    , url: requestUrl
    ,toolbar: setSettlemethod.toolbarHtml
    , page: true
    , method: 'get'
    , cols: [ setSettlemethod.getOptions(util)],
    where: {
      gametype:66
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results
      };
      setSettlemethod.tableData=res.results;
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
    }
  });
  parent.globalAdmin.checkboxEdit(setSettlemethod,window.name)
  
  // 工具栏操作
  setSettlemethod.table.on("toolbar(demo)",function(res){
    var checkStatus = setSettlemethod.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    switch (res.event) {
      case '增加':
      case '修改':
        var isAdd = res.event == '增加' ? 1 : 0;
        layer.open({
          title:res.event,
          type: 1,
          skin: 'layui-layer-test',
          area: ['600px', '400px'],
          content: htmlTpl.addHtml,
          success:function(){
            var obj={
              "username": isAdd ? '' :data[0].username,
              "bankname": isAdd ? '' :data[0].bankname,
              "branchname":isAdd ? '' :data[0].branchname,
              "accountname":isAdd ? '' :data[0].accountname,
              "accountno":isAdd ? '' :data[0].accountno
            }
            form.val('add', obj)
            form.on('submit(formAdd)',function(submitData){
              var reqUrl = isAdd ? '/setSettlemethod/addsetSettlemethod.mvc' : '/setSettlemethod/updatesetSettlemethod.mvc';
              var reqData = isAdd ? submitData.field : Object.assign(submitData.field,{id:data[0].id,userid:data[0].userid});
              parent.ajaxService.doPost(reqUrl,reqData,function(res){
                var msg = res.resultMessage;
                if(res.resultCode==0){
                  setSettlemethod.layerCallback(msg);
                  setSettlemethod.editIdArr=[];
                }else{
                  layer.msg(msg)
                }
              })
              return false;
            })
          }
        })
      break;
      case '删除':
        layer.confirm("是否删除选中的银行?",{
            btn:['确定','取消']
          },function(){
          var reqData = {
            id:setSettlemethod.editIdArr.join()
          }
          parent.ajaxService.doPost("/setSettlemethod/deletesetSettlemethod.mvc",reqData,function(res){
            if(res.resultCode ==0){
              setSettlemethod.layerCallback(res.resultMessage);
              setSettlemethod.editIdArr=[];
            }else{
              layer.msg(res.resultMessage);
            }
          })
          },function(index){
            layer.close(index)
          }
        )
      break;
      default:
        // layer.msg("接口文档未完善，需要相应人员支持!")
        break;
    }
  })
  //监听行工具事件
  setSettlemethod.table.on('tool(demo)', function(obj){
    var data = obj.data;
    if(obj.event === 'lock'){
      var text = data.locked==0 ? '锁定' : '解锁'; 
      layer.confirm(`是否${text}账号 ${data.username}?`, function(index){
        var reqData={
          userid:data.userid,
          locked:data.locked
        }
        parent.ajaxService.doPost("/setSettlemethod/updatesetSettlemethodState.mvc",reqData,function(res){
          if(res.resultCode ==0){
            setSettlemethod.layerCallback(res.resultMessage);
          }else{
            layer.msg(res.resultMessage);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    setSettlemethod.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
  laydate.render({
    elem: '#start' 
  });
  laydate.render({
    elem: '#end' 
  });
});



