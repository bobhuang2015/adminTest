
var peimissionBlackList = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  hasSet:false,
  hasDel:false,
  typeObj:{},
  pageNumber:1,
  layeditIndex:0,
  limitArr:[],
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action ='permission-black-list';
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    var obj={
      '修改':'hasSet',
      '删除':'hasDel'
    }
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i!='新增'){
          this[obj[i]]=true;
        }else{
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${otherHtml}</div>`;//toolbar 跟表格联动
    this.getStates();
  },
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1  
      }
	  })
  },
  getStates(){//注单状态
    var _this = this;
    parent.ajaxService.doGet("/getEnumByName.mvc",{enumName:'Blacklist_Type'},function(res){
      if(res.resultCode == 0){
        var data = res.results[0];
        _this.typeObj = data;
        _this.renderHtml(data,'layui-type');
      }
    })
  },
  renderHtml(data,ele){
    var html='';
    for(var i  in  data){
      html+=`<option value="${i}">${data[i]}</option>`
    }
    $(`.${ele}`).append(html);
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var _this = this;
    var arr=[
      { field: 'type', title: '类型', width: 100, sort: true,templet:function(d){return _this.typeObj[d.type]}}
      , { field: 'checkKey', title: '黑名单', width: 260, sort: true}
      , { field: 'checkName', title: '说明', width: 140, sort: true}
      , { field: 'operator', title: '操作者', width: 120, sort: true}
      , { field: 'operateTime', title: '操作时间', width: 160, sort: true,templet:function(d){return util.toDateString(d.operateTime, "yyyy-MM-dd HH:mm:ss")}}
      , {title:'操作',toolbar:'#barDemo'}
    ]
    return arr
  },
  showIframe: function(title, url, w, h) {
    var _this = this;
    var index=layer.open({
      type: 2,
      area: [w + "px", h + "px"],
      fix: false, 
      shadeClose: true,
      shade: 0.4,
      title: title,
      content: url,
      btn:['保存','取消'],
      yes: function(index, layero){
        layer.close(index);
        var w = $(layero).find("iframe")[0].contentWindow;
        _this.limitArr= w.usercenterPromotios.editIdArr;
        $('.layui-promotion-chekcId').val(_this.limitArr[0].title)
      }
    });
  },
  editAlert(title,data,form,laydate){
    var isAdd = title == '新增' ? 1 : 0;
    var _this = this;
    layer.open({
      title:title,
      type: 1,
      skin: 'layui-layer-test',
      area: ['500px', '320px'],
      content: htmlTpl.addHtml,
      success:function(){
        var obj = {
          'checkId':isAdd ? '' : data.checkId,
          'type':isAdd ? '1' : data.type,
          'checkName':isAdd ? '' : data.checkName,
          'checkKey':isAdd ? '' : data.checkKey
        }
        var bankHtml=`<div id="layui-bank-box">
                <div class="layui-form-item">
                  <label class="layui-form-label">银行卡号</label>
                  <div class="layui-input-block">
                    <input type="text" name="checkId" class="layui-input" lay-verify="required|number" autocomplete='off' maxlength="19"/>
                  </div>
                </div>
                <div class="layui-form-item">
                  <label class="layui-form-label">银行卡说明</label>
                  <div class="layui-input-block">
                    <input type="text" name="checkName" class="layui-input" lay-verify="required" autocomplete='off' id="layui-checkedId"/>
                  </div>
                </div>
              </div>`
        var promotionHtml =`<div class="layui-form-item" id="layui-promotion-box">
                        <label class="layui-form-label">活动标题</label>
                        <div class="layui-input-block">
                          <input type="text" name="checkName" class="layui-input layui-promotion-chekcId" lay-verify="required" autocomplete='off' readonly style="width:83%;display:inline-block;"/>
                          <div class="layui-btn layui-btn-normal layui-choose">选择</div>
                        </div>
                      </div>
                      <div class="layui-form-item">
                        <label class="layui-form-label">用户账号</label>
                        <div class="layui-input-block">
                          <input type="text" name="checkKey" class="layui-input" lay-verify="required" autocomplete='off' id="layui-user" placeholder="多个用逗号隔开"/>
                        </div>
                      </div>`

        $('#layui-content-box').html(!isAdd ? data.type ==1 ? promotionHtml : bankHtml : promotionHtml);
        form.val('add',obj);
        !isAdd && ($('#layui-type').attr('disabled',true),form.render('select'))

        form.on('select(type)',function(data){
          $('#layui-content-box').html(data.value == 2 ? bankHtml : promotionHtml)
        })
        var reqUrl = isAdd ? '/blacklist/insert.mvc' : '/blacklist/update.mvc';
        form.on('submit(formAdd)',function(submitData){
          var reqData = submitData.field;
          if(reqData.type ==1){
            reqData.checkId = _this.limitArr[0].id;
          }else if(reqData.type ==2){
            reqData.checkKey=reqData.checkId
          }
          !isAdd && Object.assign(reqData,{id:data.id})
          parent.ajaxService.doPost(reqUrl,reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              _this.layerCallback(msg);
            }else{
              layer.msg(msg)
            }
          })
          return false;
        })
      }
    })
  }
}

peimissionBlackList.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  peimissionBlackList.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  var laydate = layui.laydate;
  
  var topHeight = ~~($(".layui-row").height()+40);
  peimissionBlackList.table.render({
    elem: '#demo'
    , height: `full-${topHeight}`
    , url: '/blacklist/list.mvc'
    , toolbar: peimissionBlackList.toolbarHtml
    , defaultToolbar:[]
    , page: true
    , method: 'get'
    , cols: [ peimissionBlackList.getOptions(util)],
    where: {
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
    }
  });
  

    // 工具栏操作
    peimissionBlackList.table.on("toolbar(demo)",function(res){
      var checkStatus = peimissionBlackList.table.checkStatus(res.config.id);
      var data = checkStatus.data;
      switch (res.event) {
        case '新增':
          peimissionBlackList.editAlert(res.event,data,form,laydate)
        break;
        default:
          // layer.msg("接口文档未完善，需要相应人员支持!")
          break;
      }
    })
    //监听行工具事件
    peimissionBlackList.table.on('tool(demo)', function(obj){
      var data = obj.data;
      var event = obj.event;
      if(event ==='set'){
        peimissionBlackList.editAlert('修改',data,form,laydate)
      }else if(event ==='del'){
        layer.confirm("是否删除?",{
            btn:['确定','取消']
          },function(){
          var reqData = {
            id:data.id
          }
          parent.ajaxService.doPost("/blacklist/delete.mvc",reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode ==0){
              peimissionBlackList.layerCallback(msg);
            }else{
              layer.msg(msg);
            }
          })
          },function(index){
            layer.close(index)
          }
        )
      }
    })


  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    peimissionBlackList.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
  $(document).on('click',".layui-choose",function(){
    peimissionBlackList.showIframe('活动列表',`./usercenter-promotions.html?blackList=true&permision=iframe_59&time=${+new Date()}`,'1200','740');
  })
});



