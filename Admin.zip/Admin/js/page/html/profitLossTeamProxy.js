var profitLossTeamProxy = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  hasDaochu:false,
  playTypeArr:[],
  thirdData:[],
  thirdTotal:[],
  userTotal:[],
  upFloor:'',
  index:999999,
  name:'teamUser',
  tableIns:null,
  pageNumber:1,
  reqUrl:'/termsProfitStatistics/termsStatisLevelAgent.mvc',
  // platform:{},
  lotteryTotal:{},
  tableHtml:'',
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){
    var action =parent.window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = top.globalAdmin.menuObj[action].permision;
    var name = parent.$(".layui-this").attr("data-name");
    var editHtml = "";
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i=='导出数据'){
          this.hasDaochu = !0;
          name=='user' && $('button[lay-filter="formDaochu"]').show();
        }else{
          editHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${editHtml}</div>`;//toolbar 跟表格联动
  },
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1
      }
	  })
  },
  showLayer: function(title, url, w, h) {
    layer.open({
      type: 2,
      area: [w + "px", h + "px"],
      fix: false,
      shadeClose: false,
      shade: 0.4,
      title: title,
      content: url
    });
  },
  controlInput(){
    var name = parent.$(".layui-this").attr("data-name");
    var html = `
            <div class="layui-input-inline select-box">
              <select name="usernameQuery">
                <option value="1">用户自己</option>
                <option value="2">直属下级</option>
                <option value="3">所有下级</option>
              </select>
            </div>`
    if(name=='user'){
      $(".layui-username").after(html);
      $('#layui-back').remove();
      $('#layui-select').show();
      $(".layui-username").attr('lay-verify',"required");
      this.reqUrl = "/termsProfitStatistics/usersStatis.mvc"
    }
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  // getPlatform(){
  //   var _this = this;
  //   parent.ajaxService.doGet("/getEnumByName.mvc",{enumName:'ThirdParty_Platform'},function(res){
  //     if(res.resultCode == 0){
  //       _this.platform = data
  //     }
  //   })
  // },
  reloadByClick(name){
    $('.layui-username').val(name);
    profitLossTeamProxy.table.reload('demo',{
      where:{
        username:name,
        statisticsTime_begin:$('#start').val(),
        statisticsTime_end:$('#end').val()
      }
    })
  },
  getOptions:function(){
    var arr=[
      {width:52,templet:function(d){return `<i class="iconfont icon-jiahao" data-id="${d.userid}"></i>`},rowspan: 2}
      ,{ field: 'username', width: 120, title:'代理账号',sort:true,rowspan: 2,templet:function(d){return '<div class="layui-table-username" data-name='+d.username+'>'+d.username+'</div>'}}
      , { field: 'floor', width: 100, title:'级数',rowspan: 2,sort:true}
      , { field: 'totalAllProfitloss', width: 120, title:'盈亏',sort:true,rowspan: 2,templet:function(d){return `<span class='${parent.globalAdmin.getColor(d.totalAllProfitloss)}'>${globalAdmin.commafy((d.totalAllProfitloss).toFixed(2))}</span>`}}
      , { align: 'center',  title:'钱包中心',colspan: 4}
      , { align: 'center',  title:'游戏盈亏',colspan: 6}
      // , { align: 'center', title:'第三方',rowspan: 2, toolbar: '#barDemo'}
    ]
    return arr
  },
  formatData(data){
    return /.*\..*/.test(data) ? data.toFixed(2) : data
  },
  getSmallOption(){
    var _this = this;
    var arr=[
      { field: 'inmoneytotal', width: 120, title:'充值',sort: true,templet:function(d){return '<div class="layui-table-recharge" data-userid='+d.userid+' data-floor='+d.floor+' data-type="1">'+globalAdmin.commafy(_this.formatData(d.inmoneytotal))+'</div>'}}
      , { field: 'outmoneytotal', width: 120, title:'提现',sort: true,templet:function(d){return globalAdmin.commafy(_this.formatData(d.outmoneytotal))}}
      , { field: 'hdzs', width: 120, title:'活动赠送',sort: true,templet:function(d){return globalAdmin.commafy(_this.formatData(d.hdzs))}}
      , { field: 'transfermoneyintotal', width: 120, sort: true,title:'代理充值',templet:function(d){return globalAdmin.commafy(d.transfermoneyintotal)}}
      , { field: 'allOrderNumber', width: 120, sort: true,title:'注单'}
      , { field: 'allOrderMoneyTotal', width: 120, sort: true,title:'投注额',templet:function(d){return globalAdmin.commafy(_this.formatData(d.allOrderMoneyTotal))}}
      , { field: 'allSelfbonusmoney',width: 140, title:'自身返点总额',sort: true,templet:function(d){return globalAdmin.commafy(_this.formatData(d.allSelfbonusmoney))}}
      , { field: 'allAgentBonusMoney',width: 140, title:'代理返点总额',sort: true,templet:function(d){return globalAdmin.commafy(_this.formatData(d.allAgentBonusMoney))}}
      , { field: 'outmoneytotal', width: 120,sort: true, title:'中奖额',templet:function(d){return globalAdmin.commafy(_this.formatData((d.allProfitloss + d.allOrderMoneyTotal)))}}
      , { field: 'allProfitloss',sort: true, title:'投注盈亏',templet:function(d){return `<span class='${parent.globalAdmin.getColor(d.allProfitloss)}'>${globalAdmin.commafy(_this.formatData(d.allProfitloss))}</span>`}}
    ]
    return arr
  },
  editIdArr:[],
  tableData:[],
  toggleClick(){
    var _this = this;
    $('.layui-table-main table tr').on('click','.iconfont',function(){
      var targetId = $(this).attr('data-id');
      var iconJia = 'icon-jiahao',iconJian = 'icon-jianhao'
      if($(this).hasClass(iconJia)){
        $(this).addClass(iconJian).removeClass(iconJia);
        var targetArr = _this.userTotal.filter(v=>{return v.userid == targetId});

        profitLossTeamProxy.thirdData = targetArr[0].thirdGameReportList || [];
        var len = profitLossTeamProxy.thirdData.length > 0 && profitLossTeamProxy.thirdData.length || 2;
        $(this).parents('tr').after('<tr class="detail'+targetId+'"><td colspan="14"><iframe src="./profitloss-third-user.html?time='+new Date().getTime()+'" frameborder="0" style="width:86%;padding-left:10px;height:'+(len * 32 + 44)+'px;"></iframe></td></tr>')
      }else{
        $(this).addClass(iconJia).removeClass(iconJian);
        $(`tr.detail${targetId}`).remove();
      }
    })
  }
}

profitLossTeamProxy.controlInput();
profitLossTeamProxy.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  profitLossTeamProxy.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;

  var util = layui.util;
  var arr1 = profitLossTeamProxy.getOptions();
  var arr2 = profitLossTeamProxy.getSmallOption();
  var name = parent.$(".layui-this").attr("data-name");

  parent.globalAdmin.renderIntDate(laydate,util);

  var renderObj = {
    elem: '#demo'
    , height: 'full-30'
    , url: `${profitLossTeamProxy.reqUrl}`
    , method: 'get'
    , cols: [arr1,arr2],
    where: {
    }
    , parseData: function (res) {
      var data = res.results[0];
      data.forEach((v,k,arr)=>{
        arr[k].totalAllProfitloss=v.allProfitloss+v.allAgentBonusMoney+v.allSelfbonusmoney+v.hdzs
      })
      var userName = $('input[name="username"]').val();
      // if(name !='user'&& userName && data[0].username != userName){
      //   var index = data.findIndex(v=>{return v.username == userName});
      //   var targetData = data[index];
      //   data.splice(index,1);
      //   data.unshift(targetData);
      // }
      var result = {
        "code": res.resultCode,
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": data
      };
      profitLossTeamProxy.userTotal = data;
      profitLossTeamProxy.lotteryTotal = res.results[1];
      profitLossTeamProxy.thirdTotal = res.results[1] && res.results[1].thirdGameReportList;
      profitLossTeamProxy.upFloor = res.results[2];
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      profitLossTeamProxy.tableData = res.data;
      profitLossTeamProxy.pageNumber = cur;
      $('.layui-table-username').click(function(){
        var username = $(this).attr('data-name');
        profitLossTeamProxy.reloadByClick(username);
      })
      $('.layui-table-recharge').click(function(){
        var userid = $(this).attr('data-userid');
        var floor = $(this).attr('data-floor');
        var profitlosssubtypeid = $(this).attr('data-type');
        var profitlossdt_begin = $('#start').val();
        var profitlossdt_end = $('#end').val();
        // 数据是有的 用的不多 可以不做了 0710
        // top.tab.tabAdd('团队明细1024', `./html/profitloss-team-detail.html?userid=${userid}&floor=${floor}&profitlosssubtypeid=${profitlosssubtypeid}&profitlossdt_begin=${profitlossdt_begin}&profitlossdt_end=${profitlossdt_end}`, profitLossTeamProxy.index,new Date().getTime());
        // top.tab.tabChange( profitLossTeamProxy.index);
        // profitLossTeamProxy.index++;
      })
      $('.layui-table-page').hide();
      if(count>=1){
        profitLossTeamProxy.toggleClick();
        if($('.layui-done-table'))$('.layui-done-table').remove();
        var thirdHtml = '';
        var totalMoney=0;
        var userTotalMoney = 0;
        if(profitLossTeamProxy.thirdTotal && profitLossTeamProxy.thirdTotal.length>0){
          profitLossTeamProxy.thirdTotal.forEach((v,k)=>{
            var platform = profitLossTeamProxy.globalAdmin.thirdPlatform[v.platform];
            thirdHtml +=`<tr>
                          <td>  ${platform}投注:${globalAdmin.commafy(v.orderMoneyTotal.toFixed(3))} </td>                                       									
                          <td>  ${platform}中奖:${globalAdmin.commafy((v.orderMoneyTotal + v.profitlossMoneyTotal).toFixed(3))}</td>
                          <td>  ${platform}盈亏:<span class='layui-yinkui ${parent.globalAdmin.getColor(v.profitlossMoneyTotal)}'>${globalAdmin.commafy(v.profitlossMoneyTotal.toFixed(3))}</span></td>                                       									
                          <td>  ${platform}返点:${globalAdmin.commafy((v.selfBonusMoney + v.agentBonusMoney).toFixed(3))}</td>                                       									
                          <td>  ${platform}总盈亏:<span class='layui-yinkui ${parent.globalAdmin.getColor(v.agentBonusMoney + v.profitlossMoneyTotal + v.selfBonusMoney)}'>${globalAdmin.commafy((v.agentBonusMoney + v.profitlossMoneyTotal + v.selfBonusMoney).toFixed(3))}</span> </td>                                       									
                        </tr> `
          })
        }

        // 用户盈亏报表
        if(name=='user')profitLossTeamProxy.userTotal.forEach((v,k)=>{userTotalMoney +=v.allProfitloss+v.allAgentBonusMoney+v.allSelfbonusmoney+v.hdzs})
        totalMoney = profitLossTeamProxy.lotteryTotal.allProfitloss + profitLossTeamProxy.lotteryTotal.allAgentBonusMoney + profitLossTeamProxy.lotteryTotal.allSelfbonusmoney + profitLossTeamProxy.lotteryTotal.hdzs;
        var totalProxyHtml = `<tr>
                                <td>  彩票投注人数:${profitLossTeamProxy.lotteryTotal.betuser} </td>                                       									
                                <td>  传统彩票投注人数:${profitLossTeamProxy.lotteryTotal.kjbetuser}</td>
                                <td>  微投投注人数:${profitLossTeamProxy.lotteryTotal.wtbetuser}</span></td>                                       									
                                <td>  总计投注人数:${+profitLossTeamProxy.lotteryTotal.sumbetuser}</td>                                       									
                              </tr>
                              <tr>
                                <td>  活动赠送:${globalAdmin.commafy(profitLossTeamProxy.lotteryTotal.hdzs.toFixed(3))} </td>                                       									
                                <td>  汇总盈亏:<span class='layui-yinkui ${parent.globalAdmin.getColor(totalMoney)}'>${globalAdmin.commafy(totalMoney.toFixed(3))}</span></td>
                                <td>  充值总额:${globalAdmin.commafy(profitLossTeamProxy.lotteryTotal.inmoneytotal.toFixed(3))}</span></td>                                       									
                                <td>  提现总额:${globalAdmin.commafy(profitLossTeamProxy.lotteryTotal.outmoneytotal.toFixed(3))}</td>                                       									
                              </tr>`;
        var totalUserHtml = `<tr>
                              <td>  活动赠送:${globalAdmin.commafy(profitLossTeamProxy.lotteryTotal.hdzs.toFixed(3))} </td>                                       									
                              <td>  汇总盈亏:<span class='layui-yinkui ${parent.globalAdmin.getColor(userTotalMoney)}'>${globalAdmin.commafy(userTotalMoney.toFixed(3))}</span></td>
                            </tr>`;
        var totalCount = `${name=='user' ? totalUserHtml : totalProxyHtml }`;
         profitLossTeamProxy.tableHtml = `<div id="layui-table-div" style="padding-bottom:15px;"><table  style="border: 0px solid #d0cdcd;background: #d0cdcd;width:1306px;margin:10px 0 10px 10px;" lay-skin="line" lay-size="sm" class="layui-table layui-done-table">
                      <tbody>
                        <tr>                                                           									
                          <td rowspan="20" width="15%" style="text-align: center;"> 总合计</td>                                                      							    
                        </tr>
                        ${thirdHtml} ${totalCount}                                                         								
                      </tbody>
                    </table></div>`
        $('.layui-table-main table').after(profitLossTeamProxy.tableHtml);
      }
    }
  }
  if(name=='user'){
    renderObj.where={usernameQuery:1};
    renderObj.toolbar=profitLossTeamProxy.toolbarHtml;
    renderObj.defaultToolbar=[];
    // Object.assign(renderObj,{toolbar: profitLossTeamProxy.toolbarHtml,defaultToolbar:[]})
  }
  profitLossTeamProxy.tableIns=profitLossTeamProxy.table.render(renderObj);

  //监听工具条
  profitLossTeamProxy.table.on('toolbar(demo)', function(obj){
    var data = obj.data;
    var event = obj.event;
    var isAdd = event == '报表修复' ? !0 : 0;
    if(event === '报表修复' || event === '第三方修复'){
      layer.open({
        title:event,
        type: 1,
        skin: 'layui-layer-test',
        area: ['600px', '240px'],
        content: htmlTpl.addHtml,
        success:function(){
          if(isAdd){
            $('.layui-enddate').remove();
          }else{
            $('.layui-startdate  label').text('结束日期');
            $('#layui-addDate').attr('name','statisticsTime_end');
            $('.layui-username').remove();
            laydate.render({
              elem: '#layui-endDate' //指定元素
              ,type:'date'
              ,value: new Date(new Date() - 1000*24*60*60)
            });
          }

          laydate.render({
            elem: '#layui-addDate' //指定元素
            ,type:'date'
            ,value: new Date()
          });
          form.on('submit(formAdd)',function(submitData){
            var reqUrl = isAdd ? '/termsProfitStatistics/updateUserReport.mvc' : '/termsProfitStatistics/updateUserReport2.mvc';
            var reqData = submitData.field;
            parent.ajaxService.doPost(reqUrl,reqData,function(res){
              var msg = res.resultMessage;
              if(res.resultCode==0){
                profitLossTeamProxy.layerCallback(msg);
              }else{
                layer.msg(msg)
              }
            })
            return false;
          })
        }
      })
    }
  });
  //监听行工具条
  profitLossTeamProxy.table.on('tool(demo)', function(obj){
    var data = obj.data;
    profitLossTeamProxy.thirdData = data.thirdGameReportList;
    if(profitLossTeamProxy.thirdData && profitLossTeamProxy.thirdData.length > 0 ){
      profitLossTeamProxy.thirdData.forEach((v,k,arr)=>{
        arr[k].allSelfbonusmoney = data.allSelfbonusmoney.toFixed(3);
        arr[k].allAgentBonusMoney = data.allAgentBonusMoney.toFixed(3);
      })
    }
    if(obj.event === 'detail'){
      profitLossTeamProxy.showLayer(`第三方数据-${data.username}`,'./profitloss-third-user.html','1200','700')
    }
  });
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    delete data.field.isAll;
    profitLossTeamProxy.table.reload('demo',{
        where:data.field,
        page:{
            curr:1
        }
    })
    return false;
  });

  
  // 导出数据
  form.on('submit(formDaochu)', function (data) {
    parent.globalAdmin.exportData(form,data,profitLossTeamProxy)
    return false;
  });

  $('#layui-back').click(function(){
    profitLossTeamProxy.reloadByClick(profitLossTeamProxy.upFloor)
  })
  //排序处理
  profitLossTeamProxy.table.on('sort(demo)', function(obj){ 
    $('#layui-table-div').html(profitLossTeamProxy.tableHtml)
  });
});



