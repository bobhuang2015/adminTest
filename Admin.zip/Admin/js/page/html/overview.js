layui.use(['layer','table','laydate','util'],function(){
    var layer= layui.layer;
    var laydate= layui.laydate;
    var table = layui.table;
    var util = layui.util;
    var overView = {
        init(){
            this.weekDate = this.getSevenArr();
            this.getBaseInfo();
            this.get7Data();
            this.renderTable();
            this.initCanvasSize();
            parent.globalAdmin.getGametype();
        },
        width:0,
        height:0,
        initCanvasSize(){
            var width = ~~$('#layui-deposit-withdraw').width()+'px';
            var height = ~~$('#layui-deposit-withdraw').height()+'px';
            this.width = width;
            this.height= height;
        },
        getBaseInfo:function(){
            ajaxService.doGet('/kjmanager/getHomePageData.mvc',null,function(res){
                if(res.resultCode==0){
                    var data = res.results[1];
                    $('.new-user').text(data.newUserNumber);
                    $('.active-user').text(data.activeMember);
                    $('.login-user').text(data.loginUserNumber);
                    $('.total-deposit').text(globalAdmin.commafy(data.rechargeAmount.toFixed(2)));
                    $('.total-withdraw').text(globalAdmin.commafy(data.withdrawAmount.toFixed(2)));
                    $('.online-user').text(data.onlineUserNumber);
                }else{
                    layer.alert(res.resultMessage)
                }
            })
        },
        get7Data(){
            var _this = this;
            parent.ajaxService.doGet('/kjmanager/getHomePage7Data.mvc',null,function(res){
                if(res.resultCode ==0){
                    var data = res.results[0];
                    var dateArr =[];//日期
                    var depositAmountArr = [];//存款金额
                    var withdrawAmountArr= [];//取款金额
                    var newUserNumArr= [];//新增人数
                    var conversionUserNumArr= [];//转化人数
                    var betAmountArr= [];//投注金额
                    var winAmountArr= [];//中奖金额
                    var rechargeUserNumArr= [];//充值人数
                    var withdrawUserNumArr= [];//提款人数
                    var betUserNumArr= [];//投注人数
                    var activityUserNumArr= [];//活动参与人数

                    data && data.length>0 && data.forEach((v,k)=>{
                        dateArr.push(v.reportDate.substr(5).replace(/-/g,'\/'));
                        depositAmountArr.push(v.depositAmount.toFixed(2));
                        withdrawAmountArr.push(v.withdrawAmount.toFixed(2));
                        newUserNumArr.push(v.newUserNum);
                        conversionUserNumArr.push(v.conversionUserNum);
                        betAmountArr.push(v.betAmount.toFixed(2));
                        winAmountArr.push(v.winAmount.toFixed(2));
                        rechargeUserNumArr.push(v.rechargeUserNum);
                        withdrawUserNumArr.push(v.withdrawUserNum);
                        betUserNumArr.push(v.betUserNum);
                        activityUserNumArr.push(v.activityUserNum);
                    })
                    // 图表渲染;
                    _this.renderFirst(dateArr,depositAmountArr,withdrawAmountArr);
                    _this.renderSecond(dateArr,newUserNumArr,conversionUserNumArr);
                    _this.renderThird(dateArr,betAmountArr,winAmountArr);
                    _this.renderFour(dateArr,rechargeUserNumArr,withdrawUserNumArr,betUserNumArr,activityUserNumArr)

                    // 存取款图表渲染(数据结构变更)
                    // _this.renderWidthdraw(data.deposit,data.withdraw,!0);
                    // _this.renderWidthdraw(data.newUserNumberList,data.conversionList);
                    // _this.renderOrderAndWin(data.thirdGameReportList);
                    // _this.renderVip(data.activeMemberNumber7Day);
                }else{
                    layer.alert(res.resultMessage)
                }
            })
        },
        renderWidthdraw(depositData,withdrawData,is){
            var widthdrawObj = {};
            var widthdrawArr =[];
            var depositArr = [];
            var depositObj ={};
            var tempDate = [];
            this.weekDate.forEach((v,k)=>{
                widthdrawObj[v]=0;
                depositObj[v]=0;
                tempDate.push(v.substr(5).replace('-','/'));
            })
            for(var i in depositObj){
                if(depositData.length > 0){
                    depositData.forEach((iv,ik)=>{
                        if(i == iv.keyDate){
                            depositObj[i]=+iv.valueDate
                        }
                    })
                }
            }
            for(var i in depositObj){
                depositArr.push(depositObj[i])
            }
            for(var i in widthdrawObj){
                if(withdrawData.length > 0){
                    withdrawData.forEach((iv,ik)=>{
                        if(i == iv.keyDate){
                            widthdrawObj[i]=+iv.valueDate
                        }
                    })
                }
            }
            for(var i in widthdrawObj){
                widthdrawArr.push(widthdrawObj[i])
            }
            if(is){
                this.renderFirst(tempDate,depositArr,widthdrawArr);
            }else{
                this.renderSecond(tempDate,depositArr,widthdrawArr);
            }
        },
        renderOrderAndWin(data){
            // 中奖等于盈亏加投注
            var targetArr1 = [];
            var targetArr2 = [];
            var targetObj ={};
            var tempDate = [];
            this.weekDate.forEach((v,k)=>{
                targetObj[v]={};
                Object.assign(targetObj[v],{'orderMoneyTotal':0,'profitlossMoneyTotal':0})
                tempDate.push(v.substr(5).replace('-','/'));
            })
            for(var i in targetObj){
                if(data.length > 0){
                    data.forEach((iv,ik)=>{
                        if(i == iv.reportDate){
                            targetObj[i].orderMoneyTotal=(+iv.orderMoneyTotal).toFixed(2);
                            targetObj[i].profitlossMoneyTotal=(+iv.profitlossMoneyTotal + +iv.orderMoneyTotal).toFixed(2);
                        }
                    })
                }
            }
            for(var i in targetObj){
                targetArr1.push(targetObj[i].orderMoneyTotal);
                targetArr2.push(targetObj[i].profitlossMoneyTotal);
            }
            this.renderThird(tempDate,targetArr1,targetArr2)
        },
        renderVip(data){
            var targetArr1 = [];//充值人数
            var targetArr2 = [];//提款人数
            var targetArr3 = [];//投注人数
            var targetArr4 = [];//活动人数
            var targetObj ={};
            var tempDate = [];
            this.weekDate.forEach((v,k)=>{
                targetObj[v]={};
                Object.assign(targetObj[v],{'inMoneyTotal':0,'outMoneyTotal':0,'betRecodeNumber':0,'hdzs':0})
                tempDate.push(v.substr(5).replace('-','/'));
            })
            for(var i in targetObj){
                if(data.length > 0){
                    data.forEach((iv,ik)=>{
                        if(i == iv.reportDate){
                            targetObj[i].inMoneyTotal=iv.inMoneyTotal ? iv.inMoneyTotal : 0;
                            targetObj[i].outMoneyTotal=iv.outMoneyTotal ? iv.outMoneyTotal : 0;
                            targetObj[i].betRecodeNumber=iv.betRecodeNumber ? iv.betRecodeNumber : 0;
                            targetObj[i].hdzs=iv.hdzs ? iv.hdzs : 0;
                        }
                    })
                }
            }
            for(var i in targetObj){
                targetArr1.push(targetObj[i].inMoneyTotal);
                targetArr2.push(targetObj[i].outMoneyTotal);
                targetArr3.push(targetObj[i].betRecodeNumber);
                targetArr4.push(targetObj[i].hdzs);
            }
            this.renderFour(tempDate,targetArr1,targetArr2,targetArr3,targetArr4)
        },
        weekDate:[],
        monthDate:[],
        getDay(day){  
            var today = new Date();  
            var targetday_milliseconds=today.getTime() + 1000*60*60*24*day;
            today.setTime(targetday_milliseconds);
            var tYear = today.getFullYear();  
            var tMonth = today.getMonth();  
            var tDate = today.getDate();  
            tMonth = this.doHandleMonth(tMonth + 1);  
            tDate = this.doHandleMonth(tDate);  
            return tYear+"-"+tMonth+"-"+tDate; 
        },
        doHandleMonth(month){  
            var m = month;  
            if(month.toString().length == 1){  
               m = "0" + month;  
            }  
            return m;  
        },
        getSevenArr(){
            var j = -6;
            var arr = [];
            for(var i=0;i<7;i++){
                arr.push(this.getDay(j));
                j++;
            }
            return arr;
        },
        getMonthArr(){
            var myDate = new Date();
            var year = myDate.getFullYear();
            var Month = myDate.getMonth()+1;
            var day = myDate.getDate();
            var arr=[];
            // var initArr=[];
            var targetObj ={};
            for(var i=1;i<=day;i++){
                let formatDay = i >=10 ? i : '0'+i;
                arr.push(`${year}-${Month}-${formatDay}`)
            }
            arr.forEach((v,k)=>{
                targetObj[v]={};
                Object.assign(targetObj[v],{'reportDate':v,'inMoneyTotal':0,'outMoneyTotal':0,'betRecodeNumber':0,'newUserNumber':0,'sameDayRechargeNumber':0,'betRecodeTotal':0,'betRecodeProfitloss':0,'thirdBetAmount':0,'winMoney':0})
            })
            return targetObj;
        },
        renderFirst(date,depositData,withdrawData){
            var option1 = {
                grid: {
                    left: '6%',
                    right: '4%',
                    top: '12%',
                    containLabel: true
                },
                tooltip : {
                    trigger: 'axis'
                },
                color:['#5FB878','#1E9FFF'],
                legend: {
                    data:['存款','取款'],
                    x:'center',
                    y:'320'
                },
                xAxis : [
                    {
                        type : 'category',
                        data : date
                    }
                ],
                yAxis : [
                    {
                        type : 'value'
                    }
                ],
                series : [
                    {
                        name:'存款',
                        type:'bar',
                        data:depositData,
                    },
                    {
                        name:'取款',
                        type:'bar',
                        data:withdrawData,
                    }
                ]
            };
            var ele = document.getElementById('layui-deposit-withdraw');
            ele.style.width=this.width;
            ele.style.height=this.height;
            var chart1=echarts.init(ele);
            chart1.setOption(option1,true);
        },
        renderSecond(date,newData,converData){
            var option2 = {
                tooltip : {
                    trigger: 'axis',
                },
                color:['#5FB878','#1E9FFF'],
                legend: {
                    data:['新增','转化'],
                    x:'center',
                    y:'320'
                },
                grid: {
                    left: '6%',
                    right: '4%',
                    top: '12%',
                    containLabel: true
                },
                xAxis: {
                    type: 'category',
                    boundaryGap: false,
                    data: date
                },
                yAxis: {
                    type: 'value'
                },
                series: [
                    {
                        name:'新增',
                        type:'line',
                        areaStyle: {},
                        data:newData
                    },
                    {
                        name:'转化',
                        type:'line',
                        areaStyle: {},
                        data:converData
                    }
                ]
            };
            var ele = document.getElementById('layui-new-transfer');
            ele.style.width=this.width;
            ele.style.height=this.height;
            var chart2=echarts.init(ele);
            chart2.setOption(option2);
        },
        renderThird(date,orderData,profitData){
            var option3 = {
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow'
                    }
                },
                legend: {
                    data: ['投注', '中奖'],
                    x:'center',
                    y:'320'
                },
                grid: {
                    left: '6%',
                    right: '4%',
                    top: '12%',
                    containLabel: true
                },
                xAxis: {
                    type: 'value',
                    boundaryGap: [0, 0.01]
                },
                color:['#5FB878','#1E9FFF'],
                yAxis: {
                    type: 'category',
                    data:date
                },
                series: [
                    {
                        name: '投注',
                        type: 'bar',
                        data: orderData
                    },
                    {
                        name: '中奖',
                        type: 'bar',
                        data: profitData
                    }
                ]
            };
            var ele = document.getElementById('layui-bet-lottery');
            ele.style.width=this.width;
            ele.style.height=this.height;
            var chart3=echarts.init(ele);
            chart3.setOption(option3);
        },
        renderFour(date,arr1,arr2,arr3,arr4){
            var option4 = {
                color:['#5FB878','#1E9FFF','#FFB800','#FF5722'],
                tooltip : {
                    trigger: 'axis',
                    axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                        type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                    }
                },
                legend: {
                    data: ['充值人数', '提款人数','投注人数','活动参与'],
                    x:'center',
                    y:'320'
                },
                grid: {
                    left: '6%',
                    right: '4%',
                    top: '12%',
                    containLabel: true
                },
                xAxis:  {
                    type: 'value'
                },
                yAxis: {
                    type: 'category',
                    data: date
                },
                series: [
                    {
                        name: '充值人数',
                        type: 'bar',
                        stack: '总量',
                        label: {
                            normal: {
                                show: true,
                                position: 'insideRight',
                                formatter: function(params) {
                                    if (params.value > 0) {
                                        return params.value;
                                    } else {
                                        return ' ';
                                    }
                                }
                            }
                        },
                        data: arr1
                    },
                    {
                        name: '提款人数',
                        type: 'bar',
                        stack: '总量',
                        label: {
                            normal: {
                                show: true,
                                position: 'insideRight',
                                formatter: function(params) {
                                    if (params.value > 0) {
                                        return params.value;
                                    } else {
                                        return ' ';
                                    }
                                }
                            }
                        },
                        data: arr2
                    },
                    {
                        name: '投注人数',
                        type: 'bar',
                        stack: '总量',
                        label: {
                            normal: {
                                show: true,
                                position: 'insideRight',
                                formatter: function(params) {
                                    if (params.value > 0) {
                                        return params.value;
                                    } else {
                                        return ' ';
                                    }
                                }
                            }
                        },
                        data: arr3
                    },
                    {
                        name: '活动参与',
                        type: 'bar',
                        stack: '总量',
                        label: {
                            normal: {
                                show: true,
                                position: 'insideRight',
                                formatter: function(params) {
                                    if (params.value > 0) {
                                        return params.value;
                                    } else {
                                        return ' ';
                                    }
                                }
                            }
                        },
                        data: arr4
                    }
                ]
            } 
            var ele = document.getElementById('layui-active-vip');
            ele.style.width=this.width;
            ele.style.height=this.height;
            var chart4=echarts.init(ele);
            chart4.setOption(option4);
        },
        getOptions:function(){
            var arr=[
            { field: 'reportDate', title: '日期', width: 120,sort:true,totalRowText:'合计'}
            , { field: 'depositAmount', title: '充值', width: 120,sort:true,templet:function(d){return d.depositAmount ? globalAdmin.commafy(d.depositAmount.toFixed(2)) : 0},totalRow:true}
            , { field: 'withdrawAmount', title: '提款', width: 100,sort:true,templet:function(d){return d.withdrawAmount ? globalAdmin.commafy(d.withdrawAmount.toFixed(2)) : 0},totalRow:true}
            , { field: 'newUserNum', title: '新增会员', width: 120,sort:true,totalRow:true,noDigits:true}
            , { field: 'thatDayRegisteredNum', title: '当日注册(首充)', width: 140,sort:true,totalRow:true,noDigits:true}
            , { field: 'betUserNum', title: '投注人数', width: 110,sort:true,totalRow:true,noDigits:true}
            , { field: 'betAmount', title: '经典投注', width: 120,sort:true,templet:function(d){return d.betAmount ? globalAdmin.commafy(d.betAmount.toFixed(2)) : 0},totalRow:true}
            , { field: 'winAmount', title: '中奖总额', width: 120,templet:function(d){return d.winAmount ? globalAdmin.commafy(d.winAmount.toFixed(2)) : 0},sort:true,totalRow:true}
            , { field: 'kjBetAmount', title: '传统投注', width: 120,sort:true,templet:function(d){return d.kjBetAmount ? globalAdmin.commafy(d.kjBetAmount.toFixed(2)) : 0},totalRow:true}
            , { field: 'kjWinAmount', title: '中奖总额', width: 120,templet:function(d){return d.kjWinAmount ? globalAdmin.commafy(d.kjWinAmount.toFixed(2)) : 0},sort:true,totalRow:true}
            , { field: 'wtBetAmount', title: '微投投注', width: 120,sort:true,templet:function(d){return d.wtBetAmount ? globalAdmin.commafy(d.wtBetAmount.toFixed(2)) : 0},totalRow:true}
            , { field: 'wtWinAmount', title: '中奖总额', width: 120,templet:function(d){return d.wtWinAmount ? globalAdmin.commafy(d.wtWinAmount.toFixed(2)) : 0},sort:true,totalRow:true}
            , { field: 'thirdBetAmount', title: '第三方投注', width: 120,sort:true,templet:function(d){return d.thirdBetAmount ? globalAdmin.commafy(d.thirdBetAmount.toFixed(2)) : 0},totalRow:true}
            , { field: 'thirdWinAmount',title: '中奖总额',templet:function(d){return d.thirdWinAmount ? globalAdmin.commafy(d.thirdWinAmount.toFixed(2)) : 0},sort:true,totalRow:true}
            ]
            return arr
        },
        dealTableData(data){
            var tempArr=[];
            var targetObj = this.monthDate;
            for(var i in targetObj){
                if(data.length > 0){
                    data.forEach((iv,ik)=>{
                        if(i == iv.reportDate){
                            targetObj[i].inMoneyTotal=iv.inMoneyTotal ? iv.inMoneyTotal : 0;
                            targetObj[i].outMoneyTotal=iv.outMoneyTotal ? iv.outMoneyTotal : 0;
                            targetObj[i].newUserNumber=iv.newUserNumber ? iv.newUserNumber : 0;
                            targetObj[i].sameDayRechargeNumber=iv.sameDayRechargeNumber ? iv.sameDayRechargeNumber : 0;
                            targetObj[i].betRecodeNumber=iv.betRecodeNumber ? iv.betRecodeNumber : 0;
                            targetObj[i].betRecodeTotal=iv.betRecodeTotal ? iv.betRecodeTotal : 0;
                            targetObj[i].betWinmoney=iv.betRecodeTotal ? iv.betRecodeProfitloss + iv.betRecodeTotal : 0;
                            
                            targetObj[i].kjbetRecodeTotalSum=iv.kjbetRecodeTotal ? iv.kjbetRecodeTotal : 0;
                            targetObj[i].kjbetWinmoney=iv.kjbetRecodeTotal ? iv.kjbetRecodeProfitloss + iv.kjbetRecodeTotal : 0;
                            
                            targetObj[i].wtbetRecodeTotalSum=iv.wtbetRecodeTotal ? iv.wtbetRecodeTotal : 0;
                            targetObj[i].wtbetWinmoney=iv.wtbetRecodeTotal ? iv.wtbetRecodeProfitloss + iv.wtbetRecodeTotal : 0;

                            targetObj[i].thirdBetAmount=iv.thirdBetAmount ? iv.thirdBetAmount : 0;
                            targetObj[i].thirdWinAmount=iv.thirdBetRecodeProfitloss ?  iv.thirdBetAmount + iv.thirdBetRecodeProfitloss : 0;
                        }
                    })
                }
            }
            for(var i in targetObj){
                tempArr.push(targetObj[i])
            }
            return tempArr;
        },
        renderTable(){
            var _this = this;
            this.monthDate = this.getMonthArr();
            var options = this.getOptions();
            var height = this.monthDate.length * 41 + 80;
            table.render({
                elem: '#demo'
                , height: height
                , url: '/kjmanager/getHomePageMonthData.mvc' //数据接口
                , method: 'get'
                , page:false
                , totalRow:true
                , initSort:{field:'reportDate',type:'desc'}
                , cols: [options],
                where: {
                }
                , parseData: function (res) {
                //   var data = _this.dealTableData(res.results[0]);
                //   12-30数据结构变更,前端不要处理日期匹配
                //   return;
                  var result = {
                    "code": res.resultCode,
                    "msg": res.resultMessage, 
                    "count": res.results[0].length,
                    "data": res.results[0]
                  };
                  return result
                },
                response: {
                  statusCode: '0'
                },
                done: function (res, cur, count) {
                }
            });
        },
        refresh(){
            setInterval(()=>{
                this.getBaseInfo();
                this.get7Data();
                this.renderTable();
            },20 * 60 * 1000)
        }
    }

    overView.init();//初始化数据

    overView.refresh();

    // tips事件处理
    $(".layuiadmin-big-font").mouseover(function() {
        layer.tips($(this).siblings('div').attr('data-des')+" : "+$(this).text(), this, {
          tips: [1, "#4794ec"],
          time: 40e3
        });
    }).mouseout(function(){
        layer.closeAll();
    })
    $(".layui-new-title").mouseover(function() {
        layer.tips('新增：某日注册会员人数<br/>转化：会员自注册日起，首次充值，完成转化的人数', this, {
          tips: [1, "#4794ec"],
          time: 40e3
        });
    }).mouseout(function(){
        layer.closeAll();
    })
    // 刷新按钮事件
    $(document).on('click','.layui-icon-refresh',function(){
        var id = $(this).attr('data-id');
        var obj = {
            "1":'今日',
            "2":'7日'
        }
        id != 3 && layer.msg(`正在刷新${obj[id]}数据`, {
            shade: 0.01,
            time:1e3,
            icon:16
        });
        if(id==1){
            overView.getBaseInfo();
        }else if(id==2){
            overView.get7Data();
        }else{
            overView.renderTable();
        }
        $(this).siblings('.layui-icon-log').attr('title','刷新时间'+util.toDateString(new Date().getTime(),"yyyy-MM-dd HH:mm:ss"));
    })
})