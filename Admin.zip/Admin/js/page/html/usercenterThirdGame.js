
var usercenterThirdGame = {
  table:null,
  upload:null,
  toolbarHtml:'',
  hasDel:false,
  hasSet:false,
  hasTop:false,
  pageNumber:1,
  subPlayObj:{},
  thirdPlat:{},
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        var obj = {
          '修改':'hasSet',
          '删除':'hasDel',
          '置顶':'hasTop'
        }
        if(i !='新增'){
          this[obj[i]]=true;
        }else{
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${otherHtml}</div>`;
    this.getThirdPlat();
  },
  reloadTable:function(){
    var _this =this
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  getThirdPlat(){
    var _this = this;
    parent.ajaxService.doGet('/getThirdPartyPlatform.mvc',null,function(res){
      if(res.resultCode == 0){
        _this.thirdPlat = res.results[0];
        _this.renderSubplay('#layui-thirdPlat',_this.thirdPlat,!0);
      }else{
        layer.msg(res.resultMessage)
      }
    })
  },
  getThirdGamePlay(form){
    var _this = this;
    var p = new Promise(function(resolve,reject){
      parent.ajaxService.doGet('/getEnumByName.mvc',{enumName:'Game_SubType'},function(res){
        if(res.resultCode == 0){
          _this.subPlayObj = res.results[0];
          _this.renderSubplay('#subPlatform',_this.subPlayObj);
          resolve(_this.subPlayObj);
          form.render('select');
        }
      })
    })
    return p;
  },
  renderSubplay(ele,data,is){
    var html = ``;
    for(var i in data){
      html +=`<option value='${i}'>${ is ? i : data[i]}</option>`
    }
    $(ele).append(html);
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util,data){
    var _this = this;
    var arr=[
      { title: '操作', toolbar:'#barDemo',width:170}
      , { field: 'name', title: '游戏名称', width: 100,sort: true}
      , { field: 'platform', title: '平台名称', width: 100, sort: true}
      , { field: 'webImgUrl', title: 'web图片路径', width: 160, sort: true}
      , { field: 'h5ImgUrl', title: 'h5图片路径', width: 160, sort: true}
      , { field: 'appImgUrl', title: 'app图片路径', width: 160, sort: true}
      , { field: 'appImgUrlSquare', title: 'app方图片路径', width: 160, sort: true}
      , { field: 'webSupport', title: '是否支持web', width: 130, sort: true,templet:function(d){return d.webSupport ? '是' : '否'}}
      , { field: 'h5Support', title: '是否支持H5', width: 130, sort: true,templet:function(d){return d.h5Support ? '是' : '否'}}
      , { field: 'appSupport', title: '是否支持app', width: 130, sort: true,templet:function(d){return d.appSupport ? '是' : '否'}}
      , { field: 'sequence', title: '排序', width: 80, sort: true}
      , { field: 'isOpen', title: '是否开启', width: 120, sort: true,templet:function(d){return d.isOpen ? '是' : '否'}}
      , { field: 'subPlatform', title: '子类型', sort: true,templet:function(d){return data[d.subPlatform]}}
    ]
    return arr
  },
  renderLabel(value){
    $('.layui-gameCode label').text(value == 1  ? '平台编码' :'游戏编码');
    $('.layui-h5GameCode label').text(value == 1  ? 'PC游戏编码' :'H5游戏编码');
    $('.layui-appGameCode label').text(value == 1  ? 'App(H5)游戏编码' :'App游戏编码');
  },
  editImgUpload(title,form,data){
    var _this = this;
    var isAdd = title=='新增' ? !0 : 0;
    layer.open({
      title:title,
      type: 1,
      skin: 'layui-layer-test',
      area: ['600px', '820px'],
      content: htmlTpl.addHtml,
      success:function(){
        _this.renderSubplay('#layui-subPlatform',_this.subPlayObj);
        _this.renderSubplay('.layui-thirdPlat',_this.thirdPlat,!0);
        var uploadUrl = usercenterThirdGame.globalAdmin.uploadInfo.uploadImgUrl+'/file-upload/upload-image';
        var platform = $("#layui-thirdPlat").val();
        var obj={
          "platform": isAdd ? platform : data.platform,
          "isOpen": isAdd ? '1' : data.isOpen,
          "isIndex": isAdd ? '0' : data.isIndex,
          "name": isAdd ? '' : data.name,
          "gameCode": isAdd ? '' : data.gameCode,
          "webImgUrl": isAdd ?  '' : data.webImgUrl,
          "h5ImgUrl": isAdd ? '' : data.h5ImgUrl,
          "appImgUrl": isAdd ? '' : data.appImgUrl,
          "webSupport": isAdd ? '1' : data.webSupport,
          "h5Support": isAdd ? '' : data.h5Support,
          "appSupport": isAdd ? '' : data.appSupport,
          "isIndex": isAdd ? '0' :  data.isIndex,
          "subPlatform": isAdd ?  '1' : data.subPlatform,
          "appImgUrlSquare":isAdd ? '' : data.appImgUrlSquare,
          "isHot":isAdd ? 0 : data.isHot,
          "h5GameCode":isAdd ? '' : data.h5GameCode,
          "appGameCode":isAdd ? '' : data.appGameCode,
          "appDisplayMode":isAdd ? 0 : data.appDisplayMode
        }
        _this.renderLabel(data.isIndex);
        form.val('add', obj);
        var obj = {
          "#layui-upload-web":'webImgUrl',
          "#layui-upload-h5":'h5ImgUrl',
          "#layui-upload-app":'appImgUrl',
          "#layui-upload-appSquare":'appImgUrlSquare',
        };
        for(var i in obj){
          if(!isAdd)$(i).siblings('.layui-preview').attr('data-src',data[obj[i]]);
          picUpload(i)
        }
        function picUpload(ele){
          usercenterThirdGame.upload.render({
            elem: ele//绑定元素
            ,url: uploadUrl //上传接口  
            ,choose:function(obj){
              obj.preview(function(index,file,result){//预览图片
              })
            }
            ,before:function(obj){//文件上传前的回调
              layer.load(2);
            }
            ,data:{
              tenantCode:usercenterThirdGame.globalAdmin.uploadInfo.tenantCode,
              category:'thirdGame'
            }
            ,done: function(res,index){//上传完毕回调
              layer.closeAll('loading');
              var data = res.data;
              $(ele).siblings('.layui-imgurl').val(data);
              $(ele).siblings('.layui-preview').attr('data-src',data);
            }
            ,error: function(data){//请求异常回调
              layer.closeAll('loading')
            }
            ,size:1024*2
            ,acceptMime:'.jpg,.png,.svg,.jpeg,.webp'
          })
        }
        
        $('.layui-preview').on('click',function(){
          var src = $(this).attr('data-src');
          if(src){
            var imgHtml = `<img src="${usercenterThirdGame.globalAdmin.uploadInfo.viewImgUrl+'/'+src}" style='width:300px;height:200px;'/>`
            layer.open({  
                type: 1,  
                title: '图片预览',  
                area: ['300px','250px'],  
                content: imgHtml, 
                cancel: function () {  
                }
            })  
          }else{
            layer.alert('请先上传图片!')
          }
          return false;
        })
        // 备注类型切换
        form.on('select(isIndex)',function(data){
          _this.renderLabel(data.value);
        })
        form.on('submit(formAdd)',function(submitData){
          var reqData = submitData.field;
          if(!isAdd)reqData.id=data.id;
          delete reqData.file;
          var reqUrl = isAdd ? '/thirdGameSub/addSubGame.mvc' : '/thirdGameSub/edit.mvc';
          parent.ajaxService.doPost(reqUrl,reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              usercenterThirdGame.layerCallback(msg);
            }else{
              layer.msg(msg)
            }
          })
          return false;
        })
      }
    })
  }
}

usercenterThirdGame.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util','upload'], function () {
  var laydate = layui.laydate;
  usercenterThirdGame.table = layui.table;
  usercenterThirdGame.upload = layui.upload;
  
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  usercenterThirdGame.getThirdGamePlay(form).then(function(data){
    usercenterThirdGame.table.render({
      elem: '#demo'
      , height: 'full-80'
      , url: '/thirdGameSub/search.mvc'
      , toolbar: usercenterThirdGame.toolbarHtml
      , defaultToolbar:[]
      , page: true
      , method: 'get'
      , cols: [ usercenterThirdGame.getOptions(util,data)],
      where: {
        platform:$("#layui-thirdPlat").val()
      }
      , parseData: function (res) {
        var result = {
          "code": res.resultCode, 
          "msg": res.resultMessage,
          "count": res.meta.totalRecord,
          "data": res.results
        };
        return result
      },
      response: {
        statusCode: '0'
      },
      done: function (res, cur, count) {
        usercenterThirdGame.pageNumber=cur;
      }
    });
  })
  
  
  // 工具栏操作
  usercenterThirdGame.table.on("toolbar(demo)",function(res){
    var checkStatus = usercenterThirdGame.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    var event = res.event;
    switch (res.event) {
      case '新增':
        usercenterThirdGame.editImgUpload(event,form,data)
      break;
      default:
        break;
    }
  })
  //监听行工具事件
  usercenterThirdGame.table.on('tool(demo)', function(obj){
    var data = obj.data;
    var event = obj.event;
    if(event === 'del' || event == 'top'){
      var obj = {
        'del':{txt:'删除',reqUrl:'/thirdGameSub/delete.mvc'},
        'top':{txt:'置顶',reqUrl:'/thirdGameSub/stick.mvc'}
      }
      layer.confirm(`是否${obj[event].txt}?`,{
          btn:['确定','取消']
        },function(){
        var reqData = {
          id:data.id
        }
        if(event==='top'){
          Object.assign(reqData,{platform:data.platform,subPlatform:data.subPlatform})
        }
        parent.ajaxService.doPost(obj[event].reqUrl,reqData,function(res){
          var msg = res.resultMessage;
          if(res.resultCode ==0){
            usercenterThirdGame.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(event ==='set'){
      usercenterThirdGame.editImgUpload('修改',form,data)
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    usercenterThirdGame.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



