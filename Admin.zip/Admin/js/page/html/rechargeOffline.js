
var rechargeOffline = {
  table:null,
  toolbarHtml:'',
  hasVerify:false,
  hasRefuse:false,
  hasReject:false,
  pageNumber:1,
  token:'',
  editIdArr:[],
  tableData:[],
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    var obj={
      '审核':'hasVerify',
      '拒绝':'hasRefuse',
      '驳回拒绝':'hasReject',
    }
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i !='批量拒绝'){
          this[obj[i]]=true;
        }else{
          otherHtml +='<button class="layui-btn layui-btn-danger layui-btn-disabled" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml = `<div>${otherHtml}</div>`
  },
  reloadTable:function(){
    var _this  =this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  getShopList:function(){
    parent.ajaxService.doGet("/userLevel/listAllEnabled.mvc",null,function(res){
      if(res.resultCode==0){
        var data = res.results
        var html='';
        data.forEach(function(v,k){
          html+=`<option value="${v.id}">${v.payName}-${v.accountname}</option>`
        })
        $("#account").append(html);
      }
    })
  },
  getStatus:function(status){
    var obj={
      '0':'未处理',
      '1':'已通过',
      '2':'已拒绝',
      '3':'充值成功',
      '4':'充值失败'
    }
    return `<span class=${status ==2 ? 'red' :''} >${obj[status]}</span>`
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getBankType(form){
    parent.ajaxService.doGet('/platformBank/platformBankList.mvc',null,function(res){
      if(res.resultCode == 0){
        var data = res.results;
        var html='';
        data.forEach(function(v,k){
          html+=`<option value="${v.id}">${v.payName}</option>`
        })
        $("#bankType").append(html);
        form.render('select')
      }
    })
  },
  getOptions:function(util,type){
    var arr=[];
    if(type=='demo'){
      arr=[
        {type:'checkbox'}
        , { title: '操作', width: 120,toolbar: '#barDemo'}
        , { field: 'ordernumber', title: '订单号', width: 160, sort: true}
        , { field: 'username', title: '用户账号', width: 120,sort: true}
        , { title: '充值银行', width: 180, sort: true,templet:function(d){return d.bankname+"/"+d.accountno}}
        , { field: 'amount', title: '充值金额', width: 120, sort: true,templet:function(d){return d.amount.toFixed(3)}}
        , { field: 'fee', title: '手续费', width: 100, sort: true,templet:function(d){return d.fee.toFixed(3)}}
        , { field: 'platformbankaccountname', title: '收款账户', width: 120, sort: true}
        , { field: 'applydt', title: '申请时间', width: 180, sort: true,templet:function(d){return util.toDateString(d.applydt, "yyyy-MM-dd HH:mm:ss")}}
        , { field: 'status', title: '审核状态', width: 120, sort: true,templet:function(d){return rechargeOffline.getStatus(d.status)}}
        , { title: '耗时', width: 160, sort: true,templet:function(d){return d.status != '0' ? parent.globalAdmin.diffTime(d.processTime,d.applydt) : ''}}
        , { field: 'operator', title: '操作者', width: 120, sort: true}
        , { field: 'remark', title: '备注'}
      ]
    }else if(type=='transfer'){
      arr=[
        { field: 'sourcebankname', title: '源银行名称', width: 160, sort: true}
        , { title: '源银行卡号', width: 220,sort: true,templet:function(d){return d.sourceaccountno+"/"+d.sourceaccountname}}
        , { field: 'targetbankname', title: '目标银行名称', width: 180, sort: true}
        , { title: '目标银行卡号', width: 240, sort: true,templet:function(d){return d.targetaccountno+"/"+d.targetaccountname}}
        , { field: 'money', title: '金额', width: 210, sort: true,templet:function(d){return d.money.toFixed(3)}}
        , { field: 'fee', title: '手续费', width: 100, sort: true,templet:function(d){return d.fee.toFixed(3)}}
        , { field: 'optdt', title: '操作时间', width: 180, sort: true,templet:function(d){return util.toDateString(d.optdt, "yyyy-MM-dd HH:mm:ss")}}
        , { field: 'operator', title: '操作者', sort: true}
      ]
    }else{
      arr=[
        { field: 'bankName', title: '银行名称', width: 180,sort: true}
        , { title: '银行卡号', width: 240, sort: true,templet:function(d){return d.accountName+'/'+d.accountNo}}
        , { field: 'rechargetimes', title: '充值次数', width: 120, sort: true}
        , { field: 'rechargemoney', title: '充值总额', width: 120, sort: true,templet:function(d){return d.rechargemoney.toFixed(3)}}
        , { field: 'rechargefee', title: '充值手续费', width: 160, sort: true,templet:function(d){return d.rechargefee.toFixed(3)}}
        , { field: 'transfertimes', title: '转移次数', width: 100, sort: true}
        , { field: 'transfermoney', title: '转移金额', width: 120, sort: true,templet:function(d){return d.transfermoney.toFixed(3)}}
        , { field: 'transfertimes', title: '转移次数', width: 120, sort: true}
        , { field: 'transferfee', title: '转移手续费', sort: true,templet:function(d){return d.transferfee.toFixed(3)}}
      ]
    }
    return arr
  },
  renderTotal(res){
    if (res.data && res.data.length > 0 && res.total){
      var total = res.total;
      var id = $('.layui-this').attr('data-id');
      var tr = '<tr class="table-total"><td colspan="50">总量合计：<span>充值成功金额： '+ (id==1 ? total.amount : total.rechargeMoneySum)+'</span>'+
            '<span>手续费： '+(id==1 ? total.fee : total.rechargeFeeSum) +'</span></td></tr>'
      $('.layui-table-body table').append(tr)
    }
  }
}

rechargeOffline.getToolbarHtml();
rechargeOffline.getShopList();
layui.use(['laydate', 'table', 'form', 'layer','util','element'], function () {
  var laydate = layui.laydate;
  rechargeOffline.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;

  var element = layui.element;
  var isTransfer=0;
  var isReport = 0;
  form.render("select",'orderForm');
  rechargeOffline.table.render(getOptions('demo','/moneyInVerify/search.mvc'))

  element.on('tab(table_box)', function (data) {
    $(document).resize()
   if(data.index==1 && !isReport){
      isReport=!0;
      rechargeOffline.table.render(getOptions('report','/platformBankDailyStatistics/statistics.mvc'));
      rechargeOffline.getBankType(form);
      submitTable('report');
    }
  });

  function getOptions(id,reqUrl){
    var obj={
      elem: `#${id}`
      , height: 'full-156'
      , url: `${reqUrl}` 
      , page: true
      , method: 'get'
      , cols: [rechargeOffline.getOptions(util,id)],
      where: {
      }
      , parseData: function (res) {
        var result = {
          "code": res.resultCode, 
          "msg": res.resultMessage,
          "count": res.meta.totalRecord,
          "data": Array.isArray(res.results[0]) ? res.results[0] : res.results,
          "total": res.results.length==2 && res.results[1]
        };
        return result
      },
      response: {
        statusCode: '0'
      },
      done: function (res, cur, count) {
        if(id=='demo')(rechargeOffline.pageNumber = cur,rechargeOffline.tableData = res.data);
        rechargeOffline.renderTotal(res);
      }
    }
    if(id=='report'){
      Object.assign(obj.where,{'bankType':1});
    }
    if(id=='demo'){
      Object.assign(obj,{toolbar: rechargeOffline.toolbarHtml,defaultToolbar:[]})
      Object.assign(obj.where,{'status':'-1'});
    }
    return obj
  }
  
  setTimeout(()=>{
    form.render("select",'orderForm');
  },500)
  //监听行工具事件
  rechargeOffline.table.on('tool(demo)', function(obj){
    var data = obj.data;
    var event = obj.event;
    if(event === 'verify' || event === 'refuse'){
      var isVerify = event === 'verify' ? !0 : 0;
      var titleObj = {
        'verify':'审核',
        'refuse':'拒绝'
      }
      var height=0;
      isVerify ? height = 560 : height = 440;
      layer.open({
        title:titleObj[event],
        type: 1,
        skin: 'layui-layer-test',
        area: ['600px', `${height}px`],
        content: htmlTpl.verifyHtml,
        success:function(){
          $(".layui-switch label").text(isVerify ? '手续费' : '拒绝原因');
          $(".layui-switch input").attr("name",isVerify ? 'fee' : 'remark');
          var balance = 0;
          var tempObj={
            "username":data.username,
            "amount":data.amount,
            "platformbankaccountname":data.platformbankaccountname,
            "applydt":util.toDateString(data.applydt, "yyyy-MM-dd HH:mm:ss")
          }
          if(isVerify){
            parent.ajaxService.doGet('/platformBank/getCurrentMoney.mvc',{platformBankId:data.platformBankId},function(res){
              if(res.resultCode ==0){
                balance = res.results[0];
                tempObj.fee = data.fee;
                tempObj.balance = balance;
                form.val('verify', tempObj)
              }
            })
            parent.ajaxService.doGet('/systemDepositAndWithdraw/getToken.mvc',{userId:data.userid},function(res){
              if(res.resultCode == 0 ){
                rechargeOffline.token = res.results[0];
              }
            })
          }else{
            $('.layui-balance,.layui-remark').remove();
            tempObj.remark = data.remark;
            form.val('verify', tempObj)
          }
          var reqUrl = isVerify ? '/moneyInVerify/verify.mvc' : '/moneyInVerify/refuse.mvc'
          form.on('submit(formVerify)',function(submitData){
            $('button[lay-filter="formVerify"]').addClass('layui-btn-disabled').html('提交中');
            var reqData =  submitData.field;
            delete reqData.platformbankaccountname;
            delete reqData.applydt;
            if(isVerify){
              delete reqData.balance;
              reqData.id = data.id;
              reqData.userid = data.userid; 
              reqData.token = rechargeOffline.token
            }else{
              reqData.moneyInVerifyId = data.id;
            }
            parent.ajaxService.doPost(reqUrl,reqData,function(res){
              var msg = res.resultMessage;
              if(res.resultCode==0){
                if(rechargeOffline.token)rechargeOffline.token = '';
                rechargeOffline.layerCallback(msg);
              }else{
                layer.msg(msg)
              }
            })
            return false;
          })
        }
      })
    }else if(obj.event === 'reject'){
      layer.confirm(`您确认要驳回拒绝重新操作此订单吗?`,function(index){
        var reqData={
          moneyInVerifyId:data.id,
          remark:data.remark,
          username:data.username,
          amount:data.amount
        }
        parent.ajaxService.doPost("/moneyInVerify/reject.mvc",reqData,function(res){
          var msg = res.resultMessage
          if(res.resultCode == 0){
            rechargeOffline.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }
    layui.stope();
  })
  submitTable('demo');
  parent.globalAdmin.checkboxEdit(rechargeOffline,window.name)

   // 工具栏操作
   rechargeOffline.table.on("toolbar(demo)",function(res){
    var checkStatus = rechargeOffline.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    var event = res.event;
    var checkLen = data.length;
    var tempLen = 0;
    var tempArr = [];
    if(event =='批量拒绝'){
      data.forEach(v=>{
        if(v.status == 0){
          tempLen++;
        }else{
          tempArr.push(v)
        }
      })
    }
    if(tempLen == checkLen){
      layer.prompt({title:'请输入批量拒绝的原因' , formType: 2},function(value,index2){
        var reqData = {
          moneyInVerifyIds:rechargeOffline.editIdArr.join(),
          remark:value
        }
        parent.ajaxService.doPost('/moneyInVerify/batchRefuse.mvc',reqData,function(res){
          var msg = res.resultMessage;
          if(res.resultCode == 0){
            rechargeOffline.editIdArr=[];
            rechargeOffline.layerCallback(msg)
          }else{
            layer.msg(msg)
          }
        })
      })
    }else{
      layer.alert(`单号:${tempArr[0].ordernumber}，不能被${event.replace('批量','')}`)
    }
  })
  function submitTable(id){
    globalAdmin.renderRechargeDate(laydate,util,id);
    form.on('submit(form'+id+')', function (data) {
      rechargeOffline.table.reload(`${id}`,{
          where:data.field,
          page:{
              curr:1  
          },
          done:function(res, cur, count){
             rechargeOffline.renderTotal(res);
          }
      })
      return false;
    });
  }
  
  parent.globalAdmin.selectTable(window.name);
});



