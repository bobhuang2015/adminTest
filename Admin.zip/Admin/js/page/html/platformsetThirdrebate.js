
var platformsetThirdrebate = {
  table:null,
  hasLock:false,
  hasSet:false,
  pageNumber:1,
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        var obj = {
          '修改':'hasSet',
          '启用禁用':'hasLock'
        }
        this[obj[i]]=true;
      })
    }
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  formatStatus(status){
    var obj={
      "0":'禁用',
      "1":'启用'
    }
    return obj[status];
  },
  getOptions:function(util){
    var arr=[
      { field: 'thirdcode', title: '平台', width: 140,sort: true}
      , { field: 'level', title: '级别', width: 140,sort: true}
      , { field: 'amount', title: '金额', width: 240,sort: true}
      , { field: 'state', title: '状态', width: 180,sort: true,templet:function(d){return platformsetThirdrebate.formatStatus(d.state)}}
      , { field: 'operator', title: '操作人', width: 200,sort: true}
      , { title: '操作时间', width: 180,sort: true,templet:function(d){return util.toDateString(d.operatordt, "yyyy-MM-dd HH:mm:ss")}}
      , { title: '操作',toolbar:"#barDemo"}
    ]
    return arr
  }
}

platformsetThirdrebate.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util','jquery'], function () {
  var laydate = layui.laydate;
  platformsetThirdrebate.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  platformsetThirdrebate.table.render({
    elem: '#demo'
    , height: 'full-60'
    , url: '/thridMaintenanceConf/searchThirdBonus.mvc' 
    , page: true
    , method: 'get'
    , cols: [ platformsetThirdrebate.getOptions(util)],
    where: {
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      platformsetThirdrebate.pageNumber=cur;
    }
  });
  
  //监听行工具事件
  platformsetThirdrebate.table.on('tool(demo)', function(obj){
    var data = obj.data;
    var event = obj.event;
    if(event === 'lock'){
      var text = data.state == 1 ? '禁用' : '启用'; 
      layer.confirm(`是否确认<span class='red'>${text}${data.thirdcode}</span> 平台?`, function(index){
        var reqData={
          id:data.id,
          state:data.state==1 ? 0 : 1
        }
        parent.ajaxService.doPost("/thridMaintenanceConf/updateThirdBonus.mvc",reqData,function(res){
          var msg = res.resultMessage;
          if(res.resultCode ==0){
            platformsetThirdrebate.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(event==='set'){
      layer.open({
        title:'修改',
        type: 1,
        skin: 'layui-layer-test',
        area: ['600px', '300px'],
        content: htmlTpl.addHtml,
        success:function(){
          var obj={
            "level": data.level,
            "amount":data.amount
          }
          form.val('add', obj);

          form.on('submit(formAdd)',function(submitData){
            var reqData =Object.assign(submitData.field,{id:data.id}) ;
            parent.ajaxService.doPost('/thridMaintenanceConf/updateThirdBonus.mvc',reqData,function(res){
              var msg = res.resultMessage;
              if(res.resultCode==0){
                platformsetThirdrebate.layerCallback(msg);
              }else{
                layer.msg(msg)
              }
            })
            return false;
          })
        }
      })
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    platformsetThirdrebate.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



