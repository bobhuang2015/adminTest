
var peimissionGlobalLog = {
  table:null,
  toolbarHtml:'',
  getToolbarHtml(){ 
  },
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getName(str){
    var obj={
      '投注内容':'投注内容(传统注单)',
      '用户操作日志':'用户操作日志(经典注单)'
    }
    return str=='投注内容' || str=='用户操作日志' ? obj[str] : str ? str : ''
  },
  getContent(data){
    var targetStr = '';
    var txt1 = '投注号码'
    if(data.content.includes(txt1)){
      let tempArr=data.content.split(' |');
      let userStr = tempArr[0].split('|<')[0];
      let touzhuInfoObj = JSON.parse(tempArr[0].split('|<')[1].match(/【(.*?)】/)[1]); 
      targetStr=`投注号码:${touzhuInfoObj[0].touZhuHaoMa}; 投注类型/玩法:${touzhuInfoObj[0].playtypename};&nbsp;&nbsp;${userStr}; ${tempArr[1]}; ${tempArr[2]}; ${tempArr[3]}`
    }else{
      targetStr = data.content ? data.content : '';
    }
    return targetStr;
  },
  getOptions:function(util){
    var _this = this;
    var arr=[
       { field: 'account', title: '用户账号',sort: true,width:100}
      , { field: 'host', title: 'IP地址', width: 120, sort: true}
      , { field: 'serviceName', title: '服务名称', width: 110, sort: true}
      , { field: 'threadName', title: '线程名称', width: 200, sort: true}
      , { field: 'className', title: '类名', width: 180, sort: true}
      , { field: 'description', title: '注释', width: 130, sort: true,templet:function(d){return _this.getName(d.description)}}
      , { field: 'line', title: '行号', width: 80, sort: true}
      , { field: 'tenantCode', title: '租户编码', width: 110, sort: true}
      , { field: 'level', title: '日志级别', width: 110, sort: true}
      , { field: 'content', title: '日志内容', width:360, sort: true,templet:function(d){return _this.getContent(d)}}
      , { field:'timestamp',title: '操作时间',sort: true}
    ]
    return arr
  },
}

layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  peimissionGlobalLog.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  parent.globalAdmin.renderIntDate(laydate,util)
  
  var topHeight = ~~($(".layui-row").height()+40);
  
  var today =  util.toDateString(new Date().getTime(),'yyyy-MM-dd');
  var tomorrow =  util.toDateString(new Date().getTime() + 1000 * 60 * 60 * 24,'yyyy-MM-dd');
  peimissionGlobalLog.table.render({
    elem: '#demo'
    , height: `full-${topHeight}`
    , url: '/logger/search.mvc'
    , page: true
    ,request: {
      pageName: 'pageNum' 
      ,limitName: 'pageSize'
    }
    , method: 'get'
    , cols: [ peimissionGlobalLog.getOptions(util)],
    where: {
      timestampBegin:today,
      timestampEnd:tomorrow
    }
    , parseData: function (res) {
      var result = {
        "code": res.responseCode, 
        "msg": res.responseMessage,
        "count":res.responseData ?  res.responseData.total : 0,
        "data": res.responseData ? res.responseData.list :[]
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
    }
  });
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    peimissionGlobalLog.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



