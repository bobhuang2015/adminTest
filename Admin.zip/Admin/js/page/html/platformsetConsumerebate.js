
var platformsetConsumerebate = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  hasLimit:false,
  hasSet:false,
  hasDel:false,
  currentType:'',
  getToolbarHtml(){ 
    var action = window.name;
    var permision = parent.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    var obj={
      '启用禁用':'hasLock',
      '修改':'hasSet',
      '删除':'hasDel',
      '限制用户':'hasLimit'
    }
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i!='新增'){
          this[obj[i]]=true;
        }else{
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${otherHtml}</div>`;
  },
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1  
      }
	  })
  },
  thirdTypeObj:{},
  getType(form){
    var _this = this;
    var p = new Promise((resove,reject)=>{
        parent.ajaxService.doGet("/consumerRebated/getEnumThirdBonus.mvc",null,function(res){
          if(res.resultCode==0){
            var html="";
            var data = res.results[0];
            _this.thirdTypeObj=data;
            _this.renderHtml(data,'#rebateType');
            resove(data);
            form.render('select');
          }
        })
      })
    return p
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  formatStatus(status){
    var obj={
      "1":'否',
      "2":'是'
    }
    return obj[status];
  },
  getOptions:function(util,data){
    var _this = this;
    var arr=[
      { field: 'type', title: '返利类型', width: 140,sort: true,templet:function(d){return data[d.type]}}
      , { field: 'beginamt', title: '起始金额', width: 140,sort: true}
      , { field: 'endamt', title: '截止金额', width: 140,sort: true}
      , { field: 'rebatelevel', title: '返利级数', width: 140,sort: true}
      , { field: 'rebateamt', title: '返利金额', width: 140,sort: true}
      , { field:'isenable',title: '是否启用', width: 120,sort: true,templet:function(d){return _this.formatStatus(d.isenable)}}
      ,{ title: '操作',toolbar:'#barDemo'}
    ]
    return arr
  },
  renderHtml(data,ele){
    var html='';
    for(var i in this.thirdTypeObj){
      html+=`<option value="${i}">${this.thirdTypeObj[i]}</option>`
    }
    $(ele).append(html);
  },
  tableData:[],
  showLayer: function(title, url, w, h) {//此方法为公用弹窗，适用于打开一个html弹窗进行编辑
    if (title == null || title == "") {
      title = false;
    }
    if (url == null || url == "") {
      url = "404.html";
    }
    if (w == null || w == "") {
      w = $(window).width() * 0.9;
    }
    if (h == null || h == "") {
      h = $(window).height() - 50;
    }
    layer.open({
      type: 2,
      area: [w + "px", h + "px"],
      fix: false, //不固定
      shadeClose: false,
      shade: 0.4,
      title: title,
      content: url,
      btn:['','取消'],
      yes:function(index){
          layer.closeAll()
      },
      success:function(layero,index){
        // top.globalAdmin.limitWindowName = window[layero.find('iframe')[0]['name']].name;
        // 这里赋值全局变量，后面取不到,改为存到localStorage;
        $('.layui-layer-btn0').hide();
        sessionStorage.setItem('limitWindowName',window[layero.find('iframe')[0]['name']].name)
      }
    });
  },
  editAlert(title,form,data){
    var _this = this;
    var isAdd = title == '新增' ? 1 : 0;
    layer.open({
      title:title,
      type: 1,
      skin: 'layui-layer-test',
      area: ['600px', '400px'],
      content: htmlTpl.addHtml,
      success:function(){
        _this.renderHtml(_this.thirdTypeObj,'.layui-type');
        var obj={
          "type": isAdd ? '' :data.type,
          "beginamt": isAdd ? '' :data.beginamt,
          "endamt":isAdd ? '' :data.endamt,
          "rebatelevel":isAdd ? '' :data.rebatelevel,
          "rebateamt":isAdd ? '' :data.rebateamt
        }
        form.val('add', obj);
        form.render();
        form.on('submit(formAdd)',function(submitData){
          var reqUrl = isAdd ? '/consumerRebated/addConsumerAndLoss.mvc' : '/consumerRebated/updateConsumerAndLoss.mvc';
          var reqData = isAdd ? submitData.field : Object.assign(submitData.field,{id:data.id});
          parent.ajaxService.doPost(reqUrl,reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              platformsetConsumerebate.layerCallback(msg);
            }else{
              layer.msg(msg)
            }
          })
          return false;
        })
      }
    })
  }
}

platformsetConsumerebate.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  platformsetConsumerebate.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  platformsetConsumerebate.getType(form).then(function(data){
    platformsetConsumerebate.table.render({
      elem: '#demo'
      , height: 'full-100'
      , url: '/consumerRebated/searchConsumerAndLoss.mvc'
      , toolbar: platformsetConsumerebate.toolbarHtml
      , defaultToolbar:[]
      , page: true
      , method: 'get'
      , cols: [ platformsetConsumerebate.getOptions(util,data)]
      , where: {}
      , parseData: function (res) {
        var result = {
          "code": res.resultCode, 
          "msg": res.resultMessage,
          "count": res.meta.totalRecord,
          "data": res.results
        };
        platformsetConsumerebate.tableData=res.results;
        return result
      },
      response: {
        statusCode: '0'
      },
      done: function (res, cur, count) {
      }
    });
  })
  
  // 工具栏操作
  platformsetConsumerebate.table.on("toolbar(demo)",function(res){
    var checkStatus = platformsetConsumerebate.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    switch (res.event) {
      case '新增':
        platformsetConsumerebate.editAlert(res.event,form)
      break;
      default:
      break;
    }
  })
  //监听行工具事件
  platformsetConsumerebate.table.on('tool(demo)', function(obj){
    var data = obj.data;
    var event = obj.event;
    if(event === 'lock'){
      var text = data.isenable==1 ? '启用' : '禁用'; 
      layer.confirm(`是否${text}选中行?`, function(index){
        parent.ajaxService.doPost("/consumerRebated/updateByConsumerAndLossisenable.mvc",{id:data.id},function(res){
          var msg = res.resultMessage;
          if(res.resultCode ==0){
            platformsetConsumerebate.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(event === 'set'){
      platformsetConsumerebate.editAlert('修改',form,data);
    }else if(event =='del'){
      layer.confirm(`是否删除选中行?`, function(index){
        parent.ajaxService.doPost("/consumerRebated/deteteConsumerAndLoss.mvc",{id:data.id},function(res){
          var msg = res.resultMessage;
          if(res.resultCode ==0){
            platformsetConsumerebate.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(event =='limit'){
        platformsetConsumerebate.currentType = data.type;
        platformsetConsumerebate.showLayer('限制用户','./platformset-limitUser.html',800,600)
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    platformsetConsumerebate.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



