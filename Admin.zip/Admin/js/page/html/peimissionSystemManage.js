(function(){
  var peimissionSystemManage = {
    table:null,
    toolbarHtml:'',
    editHtml:'',
    roleList:[],
    pageNumber:1,
    globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
    getToolbarHtml(){ 
      var action =window.name ||  parent.globalAdmin.getUrlParam('code');
      var permision = this.globalAdmin.menuObj[action].permision;
      var otherHtml = "";
      var editHtml = "";
      if(permision){
        permision.forEach((v,k)=>{
          var i = v.menuName;
          if(i!='新增'){
            editHtml +='<a class="layui-btn layui-btn-operator layui-btn-normal '+(i == '删除' ? 'layui-btn-danger' : '')+'" lay-event="'+i+'">'+i+'</a>'
          }else{
            otherHtml ='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
          }
        })
      }
      this.toolbarHtml =`<div>${otherHtml}</div>`;
      this.editHtml = `<div>${editHtml}</div>`;
    },
    reloadTable:function(){
      var _this = this;
      this.table.reload('demo',{
        // where:data.field,
        page:{
          curr:_this.pageNumber  
        }
      })
    },
    getRoleList(){
      var _this = this;
      parent.ajaxService.doGet('/kjmanager/permission.mvc',null,function(res){
        if(res.resultCode == 0){
          _this.roleList = res.results;
        }
      })
    },
    layerCallback(msg){
      var _this = this;
      layer.alert(msg,function(){
        layer.closeAll();
        _this.reloadTable();
      })
    },
    getOptions:function(util){
      var arr=[
        { field: 'account', title: '管理员账户', width: 140, sort: true}
        , { field: 'username', title: '真实姓名', width: 140, sort: true}
        , { field: 'roleName', title: '管理员角色', width: 180,sort: true}
        , { field: 'operator', title: '创建者', width: 180, sort: true}
        , { field: 'createtime', title: '创建时间',sort: true,width:200}
        , { title: '操作', templet:function(d){return d.account != 'admin' ? peimissionSystemManage.editHtml : `<div id='layui-admin'>${peimissionSystemManage.editHtml}</div>`}}
      ]
      return arr
    },
    tableData:[]
  }
  
  peimissionSystemManage.getToolbarHtml();
  peimissionSystemManage.getRoleList();


  layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
    var laydate = layui.laydate;
    peimissionSystemManage.table = layui.table;
    var form = layui.form;
    var layer = layui.layer;
    var util = layui.util;
    
    var topHeight = ~~($(".layui-row").height()+40);
    
    peimissionSystemManage.table.render({
      elem: '#demo'
      , height: `full-${topHeight}`
      , url: '/kjmanager/list.mvc'
      , toolbar: peimissionSystemManage.toolbarHtml
      , defaultToolbar:[]
      , page:true
      , method: 'get'
      , cols: [ peimissionSystemManage.getOptions(util)],
      where: {
      }
      , parseData: function (res) {
        var result = {
          "code": res.resultCode, 
          "msg": res.resultMessage,
          "count": res.meta.totalRecord,
          "data": res.results
        };
        return result
      },
      response: {
        statusCode: '0'
      },
      done: function (res, cur, count) {
        peimissionSystemManage.pageNumber=cur;
        $("#layui-admin") && $('#layui-admin a[lay-event="权限"],#layui-admin a[lay-event="删除"]').remove();
      }
    });
    
    // 工具栏操作
    peimissionSystemManage.table.on("toolbar(demo)",function(res){
      var checkStatus = peimissionSystemManage.table.checkStatus(res.config.id);
      var data = checkStatus.data;
      switch (res.event) {
        case '新增':
          layer.open({
            title:res.event,
            type: 1,
            skin: 'layui-layer-test',
            area: ['600px', '400px'],
            content: htmlTpl.addHtml,
            success:function(){
              var obj={
                "username": '',
                "account": '',
                "password":'',
                "newpassword":''
              }
              form.val('add', obj);
              document.querySelector('.layui-account').onkeyup=function(){
                this.value=this.value.replace(/[\u4E00-\u9FA5]|[\uFE30-\uFFA0]/g,''); 
              }
              form.on('submit(formAdd)',function(submitData){
                var reqData = submitData.field;
                if(reqData.password != reqData.newpassword){
                  layer.alert('两次输入密码不一致');
                  return false;
                }
                parent.ajaxService.doPost('/kjmanager/add.mvc',reqData,function(res){
                  var msg = res.resultMessage;
                  if(res.resultCode==0){
                    peimissionSystemManage.layerCallback(msg);
                  }else{
                    layer.msg(msg)
                  }
                })
                return false;
              })
            }
          })
        break;
        default:
        break;
      }
    })
    //监听行工具事件
    peimissionSystemManage.table.on('tool(demo)', function(obj){
      var data = obj.data;
      var event = obj.event;
      if(event === '修改'){
        layer.open({
          title:'修改',
          type: 1,
          skin: 'layui-layer-test',
          area: ['600px', '240px'],
          content: htmlTpl.setHtml,
          success:function(){
            var obj={
              "username": data.username,
              "id": data.id,
            }
            form.val('set', obj)
            form.on('submit(formSet)',function(submitData){
              var reqData = submitData.field;
              parent.ajaxService.doPost('/kjmanager/update.mvc',reqData,function(res){
                var msg = res.resultMessage;
                if(res.resultCode==0){
                  peimissionSystemManage.layerCallback(msg);
                }else{
                  layer.msg(msg)
                }
              })
              return false;
            })
          }
        })
      }else if(event === '权限'){
        layer.open({
          title:'修改权限',
          type: 1,
          skin: 'layui-layer-test',
          area: ['600px', '340px'],
          content: htmlTpl.permissonHtml,
          success:function(){
            var html = '';
            peimissionSystemManage.roleList.forEach((v,k)=>{
              html +=`<input type="radio" name="role" title="${v.rolename}" value="${v.id}" lay-skin="primary">`
            })
            $(".role-list").html(html);
            var userPermissionId = [];
            var roleIds = data.permissionRoleIds || '';
            if(roleIds.indexOf(",")>-1){
              var tempArr=roleIds.split(',');
              tempArr.forEach((v,k)=>{
                userPermissionId.push(v)
              })
            }else if(roleIds !=''){
              userPermissionId.push(roleIds)
            }
            
            var obj={username:data.username};
            if(userPermissionId[0] !=''){
              userPermissionId.forEach(function(v,k){
                $("input[name='role'][value='"+v+"']").prop("checked", "checked");
                // Object.assign(obj,{['role['+v+']']:true})
              })
              form.render('checkbox','role');
            }
            form.val('role',obj);
  
            form.on('submit(role)',function(submitData){
              var arr = [];
              for(var i in submitData.field){
                if(i !='username'){
                  arr.push(submitData.field[i])
                }
              }
              if(arr.length==0){
                layer.msg("请选择用户角色!")
                return false;
              }
              var reqData = {
                id: data.id,
                roleIds:arr.join(),
                username:data.username
              }
              parent.ajaxService.doPost('/kjmanager/authorizeManager.mvc',reqData,function(res){
                var msg = res.resultMessage
                if(res.resultCode==0){
                  peimissionSystemManage.layerCallback(msg);
                }else{
                  layer.msg(msg);
                }
              })
              return false;
            })
          }
        })
      }else if(event === '删除' || event === '重置密码'){
        var obj= {
          '删除':{reqTxt:`是否删除管理员账号 ${data.username}`,reqUrl:'/kjmanager/delete.mvc'},
          '重置密码':{reqTxt:'是否重置密码？', reqUrl:'/kjmanager/resetpassword.mvc'}
        }
        layer.confirm(obj[event].reqTxt, function(index){
          var reqData={
            managerId:data.id
          }
          parent.ajaxService.doPost(obj[event].reqUrl,reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode ==0){
              peimissionSystemManage.layerCallback(msg + `${event ==='重置密码' ? `<br/>  新密码:<b> ${res.results[0]}</b>` : ''}`);
            }else{
              layer.msg(msg);
            }
          })
          },function(index){
            layer.close(index)
          }
        )
      }
    })
    // 表单提交demo
    form.on('submit(formDemo)', function (data) {
      peimissionSystemManage.table.reload('demo',{
          where:data.field,
          page:{
              curr:1  
          }
      })
      return false;
    });
  });
  
})()



