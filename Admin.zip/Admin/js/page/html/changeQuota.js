
var userInfo = {
  table:null,
}

layui.use([ 'table', 'layer'], function () {
  var laydate = layui.laydate;
  userInfo.table = layui.table;
  var layer = layui.layer;
  userInfo.table.render({
    elem: '#changeQuota'
    , height: 300
    , url: '/userQuota/list.mvc' //数据接口
    , limit: 10
    , method: 'post'
    , cols: [[ //表头
       { field: 'username', title: '当前用户', width: 100 }
      , { title: '当前返点(始)', width: 120, sort: true ,templet:'<div>{{d.limit.beginbonus}}</div>'}
      , { title: '当前返点(末)', width: 120, sort: true ,templet:'<div>{{d.limit.endbonus}}</div>'}
      , { title: '上级配额', width: 120, sort: true ,templet:'<div>{{d.limit.endbonus}}</div>'}
      , { title: '当前配额', width: 120, sort: true,edit: 'text',templet:'<div>{{d.limit.currency}}</div>' }
    ]],
    where: {
      userid: location.search.split("=")[1]
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, //解析接口状态
        "msg": res.resultMessage, //解析提示文本
        "count": 100, //解析数据长度
        "data": res.results[0] //解析数据列表
      };
      return result
    },
    response: {
      statusCode: '0' //成功的状态码，默认：0
    },
    done: function (res, cur, count) {
    }
  });

  //监听工具条===编辑信息处理
  userInfo.table.on('tool(demo)', function (obj) { //注：tool是工具条事件名，test是table原始容器的属性 lay-filter="对应的值"
      
  });

});
