
var vipCoefficient = {
  table:null,
  toolbarHtml:'',
  hasSet:false,
  hasDel:false,
  pageNumber:1,
  bankList:[],
  subPlatArr:[],
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action ='vip-set';
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    var obj={
      '修改':'hasSet',
      '删除':'hasDel'
    }
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i!='新增'){
          this[obj[i]]=true;
        }else{
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${otherHtml}</div>`;//toolbar 跟表格联动
  },
  renderHtml(ele,data,is){
    var html='';
    if(is){
      html +='<option value="">请选择</option>'
      data.forEach(v=>{
        html+=`<option value="${v.subPlatfromId}">${v.subPlatfromName}</option>`  
      })
      $(ele).html(html);
    }else{
      for(var i in data){
        html+=`<option value="${i}">${data[i]}</option>`  
      }
      $(ele).append(html);
    }
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getSub(){
    var _this = this;
    parent.ajaxService.doGet('/getEnumByName.mvc',{enumName:'Game_SubType'},function(res){
      if(res.resultCode ==0 ){
        _this.subPlatObj = res.results[0]
      }
    })
  },
  getOptions:function(util){
    var arr=[
      { field: 'platformName', title: '平台名称', width: 100, sort: true}
      , { field: 'subPlatformName', title: '子类型名称', width: 120,sort: true}
      , { field: 'expRatio', title: '系数(每百元)', width: 140, sort: true}
      , { title: '操作',toolbar: '#barDemo'}
    ]
    return arr
  },
  editIdArr:[],
  tableData:[],
  editAlert(title,data,form){
    var isAdd = title == '新增' ? 1 : 0;
    var _this = this;
    layer.open({
      title:title,
      type: 1,
      skin: 'layui-layer-test',
      area: ['400px', '300px'],
      content: htmlTpl.addHtml,
      success:function(){
        _this.renderHtml('.layui-platformId',top.globalAdmin.thirdPlatform);
        var tempArr=[];
        if(!isAdd){
          tempArr=vipCoefficient.subPlatArr.filter(v=>{
            return v.platformId == data.platformId
          })
          _this.renderHtml('.layui-subPlatformId',tempArr,!0)
        }
        
        var obj={
          "platformId": isAdd ? '' :data.platformId,
          "subPlatformId":isAdd ? '' :data.subPlatformId,
          "expRatio":isAdd ? '' :data.expRatio
        }
        form.render('select');
        form.val('add',obj);
        form.on('select(platformId)',function(subData){
          tempArr = vipCoefficient.subPlatArr.filter(v=>{
            return v.platformId==subData.value
          })
          if(tempArr.length == 0)layer.msg('当前平台没有子平台,不能新增!')
          _this.renderHtml('.layui-subPlatformId',tempArr,!0)
          form.render('select')
        })
        form.on('submit(formAdd)',function(submitData){
          var reqUrl = isAdd ? '/vipExpRation/add.mvc' : '/vipExpRation/edit.mvc';
          var fieldData = submitData.field;
          var tempArr=[];
          var isExpratio = new RegExp(/^\d{1,10}(\.\d)?$/).test(fieldData.expRatio);
          if(!isExpratio){
            layer.msg('系数只能输入一位小数');
            return false;
          }
          var reqData = isAdd ? fieldData : Object.assign(fieldData,{id:data.id}) && tempArr.push(fieldData) && 'vipExpRatioList='+JSON.stringify(tempArr);
          parent.ajaxService.doPost(reqUrl,reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              vipCoefficient.layerCallback(msg);
            }else{
              layer.msg(msg)
            }
          })
          return false;
        })
      }
    })
  }
}

vipCoefficient.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  vipCoefficient.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  
  vipCoefficient.table.render({
    elem: '#demo'
    , height: `full-20`
    , url: '/vipExpRation/getList.mvc'
    , toolbar: vipCoefficient.toolbarHtml
    , defaultToolbar:[]
    , page: true
    , initSort:{field:'platformName',type:'desc'}
    , method: 'get'
    , cols: [ vipCoefficient.getOptions(util)],
    where: {
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results[0]
      };
      vipCoefficient.tableData=res.results[0];
      vipCoefficient.subPlatArr = res.results[1].subPlatform;
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      vipCoefficient.pageNumber = cur;
    }
  });
  
  // 工具栏操作
  vipCoefficient.table.on("toolbar(demo)",function(res){
    var checkStatus = vipCoefficient.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    switch (res.event) {
      case '新增':
        vipCoefficient.editAlert(res.event,data,form)
      break;
      default:
        // layer.msg("接口文档未完善，需要相应人员支持!")
        break;
    }
  })
  //监听行工具事件
  vipCoefficient.table.on('tool(demo)', function(obj){
    var data = obj.data;
    var event = obj.event;
    if(event ==='del'){
      layer.confirm("是否删除选中的平台?",{
          btn:['确定','取消']
        },function(){
        var reqData = {
          ids:data.id
        }
        parent.ajaxService.doPost("/vipExpRation/delete.mvc",reqData,function(res){
          var msg = res.resultMessage;
          if(res.resultCode ==0){
            vipCoefficient.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(event === 'set'){
      vipCoefficient.editAlert('修改',data,form)
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    vipCoefficient.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



