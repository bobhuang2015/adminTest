var dataLossLotterybet = {
  calMax(arr){
    let max = 0;
    arr.forEach((el) => {
      el.forEach((el1) => {
        if (!(el1 === undefined || el1 === '')) {
          if (max < el1) {
            max = el1;
          }
        }
      })
    })
    let maxint = Math.ceil(max / 9.5);
    let maxval = maxint * 10;
    return maxval;
  },
  calMin(arr){
    let min = 0;
    arr.forEach((el) => {
      el.forEach((el1) => {
        if (!(el1 === undefined || el1 === '')) {
          if (min > el1) {
            min = el1;
          }
        }
      })
    })
    let minint = Math.floor(min / 10);
    let minval = minint * 10;
    return minval;
  },
  getTable(data,id){
    var html = '';
    data.forEach(v=>{
      html +=`<tr><td>${v.name}</td><td>${v.value}</td></tr>`;
    })
    return `<table class="layui-table" lay-size="sm" style="width:100%;"><thead><tr><th><div class="table_th">${id =='layui-bet-rate' ? '游戏名称' : '平台名称'}</div></th><th><div class="table_th">投注额</div></th></tr></thead><tbody class="tbody">${html}</tbody></table>`
  },
  getTable2(data){
    var html = '';
    data.forEach(v=>{
      html +=`<tr><td>${v.date}</td><td>${v.jdAmount || 0}</td><td>${v.ctAmount || 0}</td><td>${v.wtAmount || 0}</td><td>${v.perCapita || 0}<td>${v.betUser || 0}</td><td>${v.activeNum || 0}</td></tr>`;
    })
    var headHtml=``;
    var headArr=['日期','经典彩票','传统彩票','微投彩票','人均投注额','投注人数','活跃人数'];
    for(var i=0;i<headArr.length;i++){
      headHtml +=`<th><div class="table_th2">${headArr[i]}</div></th>`
    }
    return `<table class="layui-table" lay-size="sm" style="width:100%;"><thead><tr>${headHtml}</tr></thead><tbody class="tbody">${html}</tbody></table>`
  },
  renderPie(legendData,seriesData,id) {
    if(seriesData.length ==0){
      $(`#${id}`).html('<div class="layui-nodata">暂无数据!</div>')
      return
    }
    var _this = this;
    var option = {
        title : {},
        tooltip : {
          trigger: 'item',
          formatter: "{b} : {c} [{d}%]"
        },
        toolbox: {
          show: true,
          feature:{
            dataView: {
              lang:['','关闭'],
              show: true,
              title:'表格',
              readOnly: true,
              optionToContent:function(opt){
                var dataview = opt.toolbox[0].feature.dataView;
                var table = _this.getTable(seriesData,id);
                return table;
              },
            },
          }
        },
        legend: {
          orient: 'horizontal',
          left: 'center',
          top:'10%',
          data: legendData
        },
        series : [
            {
                name: '数据统计',
                type: 'pie',
                radius : '55%',
                center: ['50%', '60%'],
                data:seriesData,
                itemStyle: {
                    emphasis: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                }
            }
        ]
    };
    id == 'layui-bet-moshi' && Object.assign(option,{color:['#5FB878','#1E9FFF','#FFB800']})
    var myChart = echarts.init(document.getElementById(id));
    myChart.setOption(option,true);
  },
  optionToContent(){

  },
  renderLine(date,data1,data2,data3,activeData, betUserArr, perCapitaBetArr){
    if(data1.length ==0){
      $(`#layui-bet-trend`).html('<div class="layui-nodata">暂无数据!</div>')
      return
    }
    var arr1 = [...data1,...data2,...data3, ...perCapitaBetArr];
    var Max1 = Math.max(...arr1);
    var Max3 = Math.max(...betUserArr);
    var totalData = [];
    var _this = this;
    date.forEach((v,k)=>{
      var obj={};
      obj.jdAmount = data1[k];
      obj.ctAmount = data2[k];
      obj.wtAmount = data3[k];
      obj.activeNum = activeData[k]
      obj.betUser = betUserArr[k]
      obj.perCapita = perCapitaBetArr[k]
      obj.date = v;
      totalData.push(obj)
    })
    option = {
        color:['#5FB878','#1E9FFF','#FFB800','#FF5722', '#5793f3', '#675bba'],
        tooltip: {
            trigger: 'axis',
        },
        legend: {
            data:['经典投注','传统投注','微投投注','人均投注额','投注人数','活跃人数']
        },
        toolbox: {
          show: true,
          feature:{
            dataView: {
              lang:['','关闭'],
              show: true,
              title:'表格',
              readOnly: true,
              optionToContent:function(opt){
                var dataview = opt.toolbox[0].feature.dataView;
                var table = _this.getTable2(totalData);
                return table;
              },
            },
          }
        },
        xAxis: [
            {
                type: 'category',
                data: date,
                axisPointer: {
                    type: 'shadow'
                },
                splitLine: {
                  "show": false
                }
            }
        ],
        yAxis: [
            {
                type: 'value',
                name: '投注额',
                min: 0,
                max: Max1,
                axisLabel: {
                    formatter: '{value}'
                },
                interval: Math.ceil(Max1 / 5)
            },
          {
            type: 'value',
            name: '人数',
            min: 0,
            max: Max3,
            axisLabel: {
              formatter: '{value}'
            },
            interval: Math.round(Max3/5* 10) / 10,
          }
        ],
        series: [
            {
                name:'经典投注',
                type:'bar',
                data:data1
            },
            {
                name:'传统投注',
                type:'bar',
                data:data2
            },
            {
                name:'微投投注',
                type:'bar',
                data:data3
            },
          {
            name:'人均投注额',
            type:'bar',
            data:perCapitaBetArr
          },
            {
                name:'活跃人数',
                type:'line',
                yAxisIndex: 1,
                data:activeData
            },
          {
            name:'投注人数',
            type:'line',
            yAxisIndex: 1,
            data:betUserArr
          }
        ]
    };
    var ele = document.getElementById('layui-bet-trend')
    var myChart = echarts.init(ele);
    myChart.setOption(option,true);
  },
  getData(reqData) {
    var _this = this;
    top.ajaxService.doGet("/gameGatherDaily/statisByGameType.mvc",reqData,function(res) {
        if (res.resultCode == 0) {
          if($('.layui-nodata'))$('.layui-nodata').remove();
          var data = res.results[0];
          var lotteryData = []; //彩种投注图
          var moshiData = [];//模式总览
          var activeData = []; //活跃人数
          var betUser = []; //投注人数
          var perCapitaBet = []; //人均投注额
          var betData = []; //有效投注
          var total = 0;
          var betAmountSevenDaysScale = 0;
          if (data) {
            lotteryData = data.gameTypeList || []; //彩种投注图
            moshiData = data.gameTypePlatformList || [];//模式总览
            activeData = data.activityUserList || []; //活跃人数
            betUser = data.betUserNumList || []; //投注人数
            perCapitaBet = data.perCapitaBetAmountList || []; //人均投注额
            betData = data.gameTypeBetTrendList || []; //有效投注
            total = data.gameTypeAllTotalAmount || 0;
            betAmountSevenDaysScale = data.betAmountSevenDaysScale || 0;
          }
          var staticTotal = 0;
          var seriesDataArr = [];
          var legendDataArr = [];
          var moshiNameArr = [];
          var moshiSeriesArr = [];
          // 投注走势数据
          var dateArr=[];
          var jdArr =[];
          var ctArr=[];
          var wtArr=[];
          var activeArr=[];
          var betUserArr = []
          var perCapitaBetArr = []
          lotteryData.forEach((v,k)=>{
            if(v.betAmount * 100 / total > 1){
              legendDataArr.push(v.gameTypeName);
              var tempObj = {};
              tempObj.value = v.betAmount.toFixed(2);
              tempObj.name = v.gameTypeName;
              staticTotal += +tempObj.value;
              seriesDataArr.push(tempObj);
            }
          })
          var obj={
            name:'其他',
            value:(+total - staticTotal).toFixed(2)
          }
          moshiData.forEach((v,k)=>{
            if(+v.betAmount){
              var tempObj = {};
              tempObj.value = v.betAmount.toFixed(2);
              tempObj.name = v.platformName;
              moshiSeriesArr.push(tempObj);
              moshiNameArr.push(v.platformName)
            }
          })
          activeData.length > 0 && activeData.forEach((v,k)=>{
            activeArr.push(v.activityUserNum)
          })
          betUser.length > 0 && betUser.forEach((v,k)=>{
            betUserArr.push(v.betUserNum)
          })
          perCapitaBet.length > 0 && perCapitaBet.forEach((v,k)=>{
            perCapitaBetArr.push(Object.values(v)[0])
          })
          var arr = []
          betData.length >0 && betData.forEach((v,k,arr)=>{
            if(v.platformCode == 10){
              jdArr.push(v.betAmount)
              dateArr.push(v.reportDate.substr(5).replace(/-/g,'\/'));
            }else if(v.platformCode == 11){
              ctArr.push(v.betAmount)
            }else if(v.platformCode == 12){
              wtArr.push(v.betAmount)
            }
          })
          if(+total){
            seriesDataArr.push(obj);
            legendDataArr.push('其他');
          }else{
            // $('#demo').before('<div class="layui-nodata">无数据!</div>')
          }
          _this.renderPie(legendDataArr,seriesDataArr,'layui-bet-rate');
          _this.renderPie(moshiNameArr,moshiSeriesArr,'layui-bet-moshi');
          _this.renderLine(dateArr,jdArr,ctArr,wtArr,activeArr, betUserArr, perCapitaBetArr);
          $('.bet-money b').text(total.toFixed(2));
          var isUp = betAmountSevenDaysScale > 0 ? !0 :0;
          $('.rate').html(total > 0 && (`近7日环比 <b>${((betAmountSevenDaysScale)*100).toFixed(2)}%&nbsp;<i class="layui-icon layui-icon-return"></i></b>`)).addClass(`${isUp ? 'up' : 'down'}`)
        }else{
          layer.msg(res.resultMessage)
        }
      }
    );
  }
};

layui.use(["laydate", "form","util"], function() {
  var laydate = layui.laydate;
  var form = layui.form;
  var util = layui.util;
  parent.globalAdmin.isYesterday = !0;
  parent.globalAdmin.renderIntDate(laydate,util);

  var reqData = {
    reportdate_begin:$('#start').val(),
    reportdate_end:$('#end').val(),
  }
  dataLossLotterybet.getData(reqData);

  // 表单提交demo
  form.on("submit(formDemo)", function(data) {
    var reqData = {
      reportdate_begin:data.field.reportdate_begin,
      reportdate_end:data.field.reportdate_end
    }
    dataLossLotterybet.getData(reqData);
    return false;
  });
});
