
var betLotterynumber = {
  table:null,
  toolbarHtml:'',
  stateObj:{},
  hasLottery:false,
  hasPrepare:false,
  hasInvalid:false,
  hasSettlement:false,
  hasRenew:false,
  hasPoint:false,
  hasAward:false,
  pageNumber:1,
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action = window.name || parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var obj = {
      // '手动开奖':'hasLottery',
      // '预设号码':'hasPrepare',
      '本期作废':'hasInvalid',
      '手动结算':'hasSettlement',
      '重新结算':'hasRenew',
      '手动返点':'hasPoint',
      '手动派奖':'hasAward'
    }
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        this[obj[i]]=true
      })
    }
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  getOperatorHtml(d){
    var html = '';
    /**
     * 规则
     * 采集失败:手动开奖,本期作废
     * 返点失败:手动返点
     * 已完成:本期作废,重新结算
     * 已封盘:手动开奖,本期作废
     * 除了以上状态都有:手动结算(已作废没有)
     * 未开盘,已开盘,已封盘,并且是自营彩种: 预设号码
     */
    if(this.hasLottery){
      if(d.state ==-5  || d.state == 3){
        // html +='<a class="layui-btn layui-btn-operator" lay-event="lottery">手动开奖</a>'
      }
    }
    if(this.hasInvalid){
      if(d.state ==-5 || d.state == 3 || d.state == 8){
        html +='<a class="layui-btn layui-btn-danger layui-btn-operator" lay-event="invalid">本期作废</a>'
      }
    }
    if(this.hasSettlement){
      if(d.state !=-5 && d.state != -7 && d.state != -8  && d.state != 3 && d.state !=9){
        html +='<a class="layui-btn layui-btn-normal layui-btn-operator" lay-event="settlement">手动结算</a>'
      }
    }
    if(this.hasPoint){
      if(d.state == -8){
        html +='<a class="layui-btn layui-btn-normal layui-btn-operator" lay-event="point">手动返点</a>'
      }
    }
    if(this.hasAward){
      if(d.state == -7){
        html +='<a class="layui-btn layui-btn-normal layui-btn-operator" lay-event="award">手动派奖</a>'
      }
    }
    if(this.hasRenew){
      if(d.state == 8){
        html +='<a class="layui-btn layui-btn-normal layui-btn-operator" lay-event="renew">重新结算</a>'
      }
    }
    // if(this.hasPrepare){
    //   if(parent.globalAdmin.selfGameList[d.gametype]){
    //     if(d.state == 1 || d.state == 2 || d.state ==3){
    //       html +='<a class="layui-btn layui-btn-warm layui-btn-operator" lay-event="prepare">预设号码</a>'
    //     }
    //   }
    // }
    html +='<div>'+html+'</div>';
    return html;
  },
  getStates(){
    var _this = this;
    parent.ajaxService.doGet("/lotteryNums/getOpenWinState.mvc",null,function(res){
      if(res.resultCode == 0){
        var data = res.results[0];
        _this.stateObj = data;
        _this.renderState(data);
      }
    })
  },
  renderGametype(data){
    this.getStates();
    var html='';
    data.forEach((v,k)=>{
      html+=`<option value="${v.id}">${v.name}</option>`
    })
    $(".gameType").append(html);
  },
  renderState(data){
    var html='';
    for(var i  in  data){
      html+=`<option value="${i}">${data[i]}</option>`
    }
    $(".state").append(html);
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var arr=[
      { title: '操作', width: 100,templet:function(d){return betLotterynumber.getOperatorHtml(d)}}
      , { field:'state', title: '状态', width: 80, sort: true,templet:function(d){return betLotterynumber.stateObj[d.state]}}
      , { field: 'gametypename', title: '游戏类型', width: 110, sort: true}
      , { field: 'issueno', title: '期号', width: 120,sort: true}
      , { field:'opentime', title: '投注时间', width:290, sort: true,templet:function(d){return util.toDateString(d.opentime, "yyyy-MM-dd HH:mm:ss")+"-"+util.toDateString(d.closetime, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'nums', title: '开奖号码', width: 200, sort: true}
      // , { field: 'defaultnums', title: '预设号码', width: 120, sort: true}
      , { field: 'lotterydt', title: '开奖时间', width: 150, sort: true,templet:function(d){return util.toDateString(d.lotterydt, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'orderCounter', title: '注单数', width: 100, sort: true}
      , { field: 'betmoneytotal', title: '投注总额', width: 110, sort: true,templet:function(d){return d.betmoneytotal.toFixed(3)}}
      , { field: 'winmoneytotal', title: '中奖总额', width: 110, sort: true,templet:function(d){return d.winmoneytotal.toFixed(3)}}
      , { field: 'kjorderCounter', title: '传统注单数', width: 130, sort: true}
      , { field: 'kjbetmoneytotal', title: '传统投注总额', width: 130, sort: true,templet:function(d){return d.kjbetmoneytotal.toFixed(3)}}
      , { field: 'kjwinmoneytotal', title: '传统中奖总额', width: 130, sort: true,templet:function(d){return d.kjwinmoneytotal.toFixed(3)}}
      , { field: 'moneyoutcount', title: '投注盈亏', width: 110, sort: true,templet:function(d){return ((d.winmoneytotal - d.betmoneytotal) + (d.kjwinmoneytotal - d.kjbetmoneytotal)).toFixed(3)}}
      , { field: 'operatingTime', title: '操作时间', width: 150 ,templet:function(d){return d.operatingTime ? util.toDateString(d.operatingTime, "yyyy-MM-dd HH:mm:ss") : ''}}
      , { field: 'operator', title: '操作者', width: 100, sort: true}
    ]
    return arr
  },
  editAlert(event,form,data,util){
    var _this = this;
    var initData={
      "lottery":{'title':'本期开奖号码设置','url':'/lotteryNums/award.mvc'},
      "renew":{'title':'重新结算','url':'/lotteryNums/award.mvc'},
      "prepare":{'title':'预设号码','url':'/lotteryNums/presetNums.mvc'}
    }
    layer.open({
      title:initData[event].title,
      type: 1,
      skin: 'layui-layer-test',
      area: ['620px', '550px'],
      content: htmlTpl.lotteryHtml,
      success:function(){
        var obj={
          "gametypename": data.gametypename,
          "issueno":data.issueno,
          "state":betLotterynumber.stateObj[data.state],
          "opentime":util.toDateString(data.opentime, "yyyy-MM-dd HH:mm:ss"),
          "closetime":util.toDateString(data.closetime, "yyyy-MM-dd HH:mm:ss"),
          "lotterydt":util.toDateString(data.lotterydt, "yyyy-MM-dd HH:mm:ss"),
          "nums":data.nums ? data.nums : ''
        }
        form.val('lottery', obj);
        var digits = parent.globalAdmin.gameDigits[data.gametype].digits;
        var long =parent.globalAdmin.gameDigits[data.gametype].long;
        var maxLength =  digits * long + (long -1);
        $(".layui-nums").attr('maxLength', maxLength);
        $(".layui-nums").val(data.nums ? data.nums :'');
        document.querySelector(".layui-nums").onkeyup=document.querySelector(".layui-nums").onblur=function(){
          if(digits ==1){
            this.value =this.value.replace(/\s/g,'').replace(/[^\d]/g,'').replace(/(\d{1})(?=\d)/g,'$1 ');
          }else if(digits ==2){
            this.value =this.value.replace(/\s/g,'').replace(/[^\d]/g,'').replace(/(\d{2})(?=\d)/g,'$1 ');
          }
        }
        form.on('submit(formLottery)',function(submitData){
          var nums =  $(".layui-nums").val();
          if(nums.length != maxLength){
            layer.msg("请输入正确的开奖号码");
            return false;
          }
          var reqData = {
            id:data.id,
            nums:nums,
            state:data.state,
            issueno:data.issueno,
            gametypename:data.gametypename
          }
          if(event == 'renew' || event == 'prepare')reqData.gametype = data.gametype;
          parent.ajaxService.doPost(initData[event].url,reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              betLotterynumber.layerCallback(msg);
            }else{
              layer.msg(msg)
            }
          })
          return false;
        })
      }
    })
  },
  renderTotal(res){
    if(res.data && res.data.length>0){
      res.data.forEach((v,k)=>{
        if(v.state ==9){
          $('.layui-table tr:eq('+(k+1)+')').addClass('red');
        }
      })
    }
  }
}

betLotterynumber.getToolbarHtml();
betLotterynumber.renderGametype(parent.globalAdmin.gameListArr);
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  betLotterynumber.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  var is = !0;
  globalAdmin.renderIntDate(laydate,util);
  betLotterynumber.table.render({
    elem: '#demo'
    , height: 'full-80'
    , url: '/lotteryNums/search.mvc'
    ,toolbar: betLotterynumber.toolbarHtml
    , page: true
    , method: 'get'
    , cols: [ betLotterynumber.getOptions(util)],
    where: {
      // startDate: ''
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      if(is){
        is=!is;
        form.render('select','test')
      }
      betLotterynumber.pageNumber=cur;
      betLotterynumber.renderTotal(res)
    }
  });
  
  //监听行工具事件
  betLotterynumber.table.on('tool(demo)', function(obj){
    var data = obj.data;
    var event = obj.event;
    if(event === 'settlement' || event == 'invalid' || event == 'award' || event =='point'){
      var temp={
        'settlement':{txt:'是否手动结算?',reqUrl:'/lotteryNums/billingLotteryNum.mvc'},
        'invalid':{txt:'是否本期作废?',reqUrl:'/lotteryNums/invalidate.mvc'},
        'award':{txt:'是否手动派奖?',reqUrl:'/lotteryNums/settlePrize.mvc'},
        'point':{txt:'是否手动返点操作?',reqUrl:'/lotteryNums/settleBonus.mvc'}
      }
      layer.confirm(temp[event].txt, function(index){
        var reqData={
          gametype:data.gametype,
          issueno:data.issueno,
          gametypename:data.gametypename
        }
        if(event =='award' || event =='point')reqData.id = data.id;
        parent.ajaxService.doPost(temp[event].reqUrl,reqData,function(res){
          var msg = res.resultMessage;
          if(res.resultCode ==0){
            betLotterynumber.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(event === 'lottery' || event === 'prepare'){
      betLotterynumber.editAlert(event,form,data,util)
    }else if(event === 'renew'){
      layer.confirm(`是否重新结算?`, function(index){
        var reqData= {
          'gametype':data.gametype,
          'issueno':data.issueno,
          'gametypename':data.gametypename
        }
        parent.ajaxService.doPost('/lotteryNums/afreshSettlement.mvc',reqData,function(res){
          if(res.resultCode == 0 ){
            layer.close(index);
            betLotterynumber.reloadTable();
            data.state = res.results[0];
            betLotterynumber.editAlert(event,form,data,util);
          }else{
            layer.alert(res.resultMessage);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    betLotterynumber.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        },
        done:function(res){
          betLotterynumber.renderTotal(res);
        }
    })
    return false;
  });
});



