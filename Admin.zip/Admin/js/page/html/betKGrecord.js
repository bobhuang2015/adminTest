
var betKGrecord = {
  table:null,
  toolbarHtml:'',
  hasInvalid:false,
  hasCancel:false,
  hasWithdrawal:false,
  hasDaochu:false,
  stateObj:{},
  pageNumber:1,
  tableIns:null,
  name:'betKGRecordList',
  mobileBetObj:{
    '0':'电脑投注',
    '1':'安卓投注',
    '2':'苹果投注',
    '3':'H5投注',
    '4':'安卓H5投注',
    '5':'苹果H5投注',
  },
  playTypeArr:[],
  wtPlayTypeArr:[],
  clPlayTypeArr:[],
  currentPlayTypeArr:[],
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    var obj = {
      '作废':'hasInvalid',
      '撤销派奖':'hasCancel',
      '导出数据':'hasDaochu'
    }
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i !='批量作废' && i !='批量撤销派奖'){
          this[obj[i]]=true
        }else{
          editHtml +='<button id="'+i+'" class="layui-btn layui-btn-disabled" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    if(this.hasDaochu){
      $('button[lay-filter="formDaochu"]').show();
    }
    this.toolbarHtml =`<div>${editHtml}</div>`
  },
  reloadTable:function(){
    var _this=this;
    this.editIdArr=[];
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  getOperatorHtml(d){
    var html = '';
    if(this.hasInvalid){
      if(d.state !=2 && d.state != 7){
        html +='<a class="layui-btn layui-btn-danger layui-btn-operator" lay-event="invalid">作废</a>'
      }
    }
    if(this.hasCancel){
      if(d.state ==4){
        html +='<a class="layui-btn layui-btn-operator" lay-event="cancel">撤销派奖</a>'
      }
    }
    /**
     * 没有撤单和 批量撤单 找朱哥确认了
     */
    // if(this.hasWithdrawal){
    //   if(d.state ==1 || d.state == 8){
    //     html +='<a class="layui-btn" lay-event="cancel">撤单</a>'
    //   }
    // }
    html +='<div>'+html+'</div>';
    return html;
  },
  getStates(form){//注单状态
    var _this = this;
    parent.ajaxService.doGet("/getEnumByName.mvc",{enumName:'BetRecord_State'},function(res){
      if(res.resultCode == 0){
        var data = res.results[0];
        _this.stateObj = data;
        _this.renderHtml(data,'state');
        form.render('select');
      }
    })
  },
  renderHtml(data,ele,is){
    var html='';
    if(is){
      ele =='gameType' && (html='<option value="-1">游戏类型</option>');
      ele =='betType' && (html='<option value="">投注类型</option>');
      data.forEach((v,k)=>{
        html+=`<option value="${v.id}">${v.name}</option>`
      })
     $(`.${ele}`).html(html);
    }else{
      for(var i  in  data){
        html+=`<option value="${i}">${data[i]}</option>`
      }
      $(`.${ele}`).append(html);
    }
  },
  renderPlayHtml(data,ele){
    var html='';
    for(var i  in  data){
      html+=`<option value="${i}">${i}</option>`
    }
    $(`.${ele}`).append(html);
  },
  getGameType(form,key){//游戏类型，玩法
    var _this = this;
    var obj = {
      '0':"/gameType/getKjGamePlayType.mvc",
      '1':"/gameType/getWtGamePlayType.mvc",
      '2':"/gameType/getKjGamePlayType.mvc"
    }
    parent.ajaxService.doGet(obj[key],null,function(res){
      if(res.resultCode == 0 ){
        var data = res.results;
        _this.playTypeArr = data;
        _this.currentPlayTypeArr = data;
        _this.renderHtml(data,'gameType',!0)
        form.render('select');
      }
    })
  },
  getWtGameList(form){
    var _this = this;
    if(this.wtPlayTypeArr.length == 0){
      parent.ajaxService.doGet("/gameType/getWtGamePlayType.mvc",null,function(res){
        if(res.resultCode == 0 ){
          var data = res.results;
          _this.wtPlayTypeArr = data;
          _this.currentPlayTypeArr = data;
          _this.renderHtml(data,'gameType',!0)
          form.render('select');
        }
      })
    }else{
      _this.currentPlayTypeArr = this.wtPlayTypeArr;
      _this.renderHtml(this.wtPlayTypeArr,'gameType',!0)
      form.render('select');
    }
  },
  getClGameList(form){
    var _this = this;
    if(this.clPlayTypeArr.length ==0 ){
      parent.ajaxService.doGet("/gameType/getClGamePlayType.mvc",null,function(res){
        if(res.resultCode == 0 ){
          var data = res.results;
          _this.clPlayTypeArr = data;
          _this.currentPlayTypeArr = data;
          _this.renderHtml(data,'gameType',!0)
          form.render('select');
        }
      })
    }else{
      _this.currentPlayTypeArr = this.clPlayTypeArr;
      _this.renderHtml(this.clPlayTypeArr,'gameType',!0)
      form.render('select');
    }
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  initSelect(){
    $(".playType").html('<option value="">玩法类型</option>');
    $(".betType").html('<option value="">玩法类型</option>');
  },
  getOptions:function(util){
    var arr=[
      {type:'checkbox'}
      , { field: 'ordernumber', title: '投注单号', width: 140, templet:function(d){return '<div class="layui-table-ordernumber" lay-event="orderDetail">'+d.ordernumber+'</div>'}}
      , { title: '操作', width: 140,templet:function(d){return betKGrecord.getOperatorHtml(d)}}
      , { title: '状态', width: 90, templet:function(d){return betKGrecord.stateObj[d.state]+(d.iswin==1 ? '(<span style="color:red">中奖</span>)' : '')}}
      , { field: 'username', title: '用户账号', width: 110, sort: true}
      , { field: 'gametypename', title: '游戏类型', width: 110, sort: true}
      , { field: 'playtypename', title: '玩法', width: 120, sort: true}
      , { field: 'issueno', title: '期号', width: 130,sort: true}
      , { field: 'nums', title: '投注号码', width: 120, sort: true}
      , { field: 'betcount', title: '投注注数/总额', width: 140,templet:function(d){return d.betcount+'/'+d.betmoneytotal.toFixed(3)}}
      // , { field: 'betmoneytotal', title: '投注总额', width: 100, templet:function(d){return d.betmoneytotal.toFixed(3)}}
      , { field: 'betdt', title: '投注时间', width: 150, templet:function(d){return util.toDateString(d.betdt, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'winmoney', title: '中奖总额', width: 100, templet:function(d){return d.winmoney.toFixed(3)}}
      , { title: '盈亏金额', width: 110, templet:function(d){return `<div class="${d.winmoney - d.betmoneytotal > 0 ? 'red' :'green'}">${(d.winmoney - d.betmoneytotal).toFixed(3)}</div>`}}
      // , { field: 'selfBonusMoney',title: '自身返点', width: 100, sort: true}
      , { title: '投注方式', templet:function(d){return betKGrecord.mobileBetObj[d.mobileBet] ? betKGrecord.mobileBetObj[d.mobileBet] : '--'}}
    ]
    return arr
  },
  editIdArr:[],
  tableData:[]
}

betKGrecord.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  betKGrecord.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  var currentPlayType = [];
  var targetPlayObj={};
  var targetBetArr=[];
  
  betKGrecord.getStates(form);
  
  betKGrecord.tableIns=betKGrecord.table.render({
    elem: '#demo'
    , height: `full-100`
    , url: '/kjbetrecord/search.mvc'
    , toolbar: betKGrecord.toolbarHtml
    , defaultToolbar:[]
    , page: true
    , method: 'get'
    , cols: [ betKGrecord.getOptions(util)],
    where: {
      usernameQuery:1,
      cathecticType:0
    }
    , parseData: function (res) {
      var resData = res.results.length > 0 &&  res.results[0];
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": resData,
        'total':res.results[1] || ''
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      betKGrecord.pageNumber = cur;
      betKGrecord.tableData = res.data || [];
      betKGrecord.editIdArr=[];
      $('.layui-table-tool-temp > button').addClass('layui-btn-disabled');
      if(res.data.length > 0){
        res.data.forEach((v,k)=>{
          if(v.state ==7){
            $('.layui-table tr:eq('+(k+1)+')').addClass('red');
          }
        })
      }
      if (res.data && res.data.length > 0 && res.total){
        var tr ='<tr class="table-total"><td colspan="50">总量合计：<span>(即时)投注总额:'+res.total.normalBetMoneyTotal+'</span> <span>(已完成)投注总额： '+(+res.total.betmoneytotal).toFixed(3)+'</span>'+
              '<span>自身返点总额： '+(+res.total.selfBonusMoney).toFixed(3) +'</span>'+'<span>中奖总额： '+(+res.total.winmoney).toFixed(3)+'</span>'+'盈亏总额： <span class="'+parent.globalAdmin.getColor(res.total.profitMoneyTotal)+'">'+(+res.total.profitMoneyTotal).toFixed(3)+'</span></td></tr>'
        $('.layui-table-body table').append(tr)
      }
    }
  });
  
  parent.globalAdmin.checkboxEdit(betKGrecord,window.name,'record');
  
  betKGrecord.getGameType(form,'0');
  
  // 工具栏操作
  betKGrecord.table.on("toolbar(demo)",function(res){
    var checkStatus = betKGrecord.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    var dataObj = {
      '批量作废':{txt:'是否批量作废选中的投注记录?',reqUrl:'/kjbetrecord/invalidateBatch.mvc'},
      '批量撤销派奖':{txt:'是否批量撤销派奖选中的投注记录?',reqUrl:'/kjbetrecord/cancelPrizeBatch.mvc'}
    }
    var event = res.event;
    var checkedLength = data.length;
    var tempLen = 0;
    var tempArr = [];
    if(event =='批量作废'){
      data.forEach((v,k)=>{
        if(v.state !=2 && v.state != 7){
          tempLen++;
        }else{
          tempArr.push(v)
        }
      })
    }else if(event == '批量撤销派奖'){
      data.forEach((v,k)=>{
        if(v.state == 4){
          tempLen++;
        }else{
          tempArr.push(v)
        }
      })
    }
    if(tempLen == checkedLength){
      layer.confirm(dataObj[event].txt,{
          btn:['确定','取消']
        },function(){
        var reqData = {
          ids:betKGrecord.editIdArr.join()
        }
        layer.load(2)
        parent.ajaxService.doPost(dataObj[event].reqUrl,reqData,function(res){
          if(res.resultCode ==0){
            betKGrecord.layerCallback(res.resultMessage);
            betKGrecord.editIdArr=[];
          }else{
            layer.msg(res.resultMessage);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else{
      layer.alert(`单号:${tempArr[0].ordernumber}，不能被${event.replace('批量','')}`)
    }
  })
  //监听行工具事件
  betKGrecord.table.on('tool(demo)', function(obj){
    var data = obj.data;
    var event = obj.event;
    if(event === 'invalid' || event === 'cancel'){
      var dataTemp = {
        'invalid':{txt:'是否作废?',reqUrl:'/kjbetrecord/invalidate.mvc'},
        'cancel':{txt:'是否撤销派奖?',reqUrl:'/kjbetrecord/cancelPrize.mvc'},
      }
      var reqData={
        id:data.id,
        username:data.username,
        ordernumber:data.ordernumber
      }
      layer.confirm(dataTemp[event].txt, function(index){
        parent.ajaxService.doPost(dataTemp[event].reqUrl,reqData,function(res){
          var msg = res.resultMessage
          if(res.resultCode ==0){
            betKGrecord.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(event ==='orderDetail'){
      parent.ajaxService.doGet('/kjbetrecord/view.mvc',{id:data.id},function(res){
        if(res.resultCode == 0){
          var data = res.results[0];
          var lotteryData = res.results[1];
          layer.open({
            title:'投注详情',
            type: 1,
            skin: 'layui-layer-test',
            area: ['800px', '500px'],
            content: htmlTpl.zhuiHtml,
            success:function(){
              data.status = betKGrecord.stateObj[data.state];
              data.digit='';
              betAlert.renderTouHtml(data,lotteryData,util,'KG');
              $('.mask-box .layui-table').removeClass('zhui-table');
            }
          })
        }else{
          layer.alert(res.resultMessage)
        }
      })
    }
    layui.stope();
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    var reqData = data.field;
    if(reqData.gametype !=-1 && reqData.playtype !='' && reqData.playtypeArr == ''){
      for(var i in targetPlayObj){
        if(i == reqData.playtype){
          var tempArr = [];
          targetPlayObj[i].forEach(v=>{
            tempArr.push(v.id)
          })
        }
      }
      reqData.playtypeArr = tempArr.join();
    }
    delete reqData.isAll;
    delete reqData.playtype;
    betKGrecord.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        },
        done:function(res,cur){
          betKGrecord.pageNumber=cur;
          betKGrecord.tableData = res.data || [];
          if(res.data.length > 0){
            res.data.forEach((v,k)=>{
              if(v.state ==7){
                $('.layui-table tr:eq('+(k+1)+')').addClass('red');
              }
            })
            if (res.data && res.data.length > 0 && res.total){
              var tr ='<tr class="table-total"><td colspan="50">总量合计：<span>(即时)投注总额:'+res.total.normalBetMoneyTotal+'</span> <span>(已完成)投注总额： '+(+res.total.betmoneytotal).toFixed(3)+'</span>'+
                    '<span>自身返点总额： '+(+res.total.selfBonusMoney).toFixed(3) +'</span>'+'<span>中奖总额： '+(+res.total.winmoney).toFixed(3)+'</span>'+'盈亏总额： <span class="'+parent.globalAdmin.getColor(res.total.profitMoneyTotal)+'">'+(+res.total.profitMoneyTotal).toFixed(3)+'</span></td></tr>'
              $('.layui-table-body table').append(tr)
            }
          }
        }
    })
    return false;
  });

  // 导出数据
  form.on('submit(formDaochu)', function (data) {
    betKGrecord.hasDaochu && parent.globalAdmin.exportData(form,data,betKGrecord)
    return false;
  });
  // 游戏玩法，下拉选择操作
  form.on('select(gametype)', function(selectData){
    var value = selectData.value;
    betKGrecord.initSelect();
    if(value==-1){
      form.render('select','test');
    }
    betKGrecord.currentPlayTypeArr.forEach((v,k)=>{
      if(v.id == value ){
        targetPlayObj = v.playType;
        betKGrecord.renderPlayHtml(targetPlayObj,'playType')
        form.render('select','test');
      }
    })
  })
  // 游戏玩法，下拉选择操作
  form.on('select(playtype)', function(selectData){
    var value = selectData.value;
    if(value==-1){
      form.render('select','test');
    }
    for(var i in targetPlayObj){
      if(i==value){
        targetBetArr = targetPlayObj[i];
        betKGrecord.renderHtml(targetBetArr,'betType',!0)
        form.render('select','test');
      }
    }
  })
  // 传统、微投、长龙切换 cathecticType
  form.on('select(cathecticType)', function(selectData){
    var key = selectData.value;
    betKGrecord.initSelect();
    if(key != -1){
      betKGrecord.getGameType(form,key);
    }else{

    }
    // switch (key) {
    //   case '0':
    //     betKGrecord.getGameType(form);
    //     break;
    //   case '1':
    //     betKGrecord.getWtGameList(form);
    //     break;
    //   case '2':
    //     betKGrecord.getClGameList(form);
    //     break;
    //   default:
    //     break;
    // }
  })

  globalAdmin.renderRechargeDate(laydate,util);
  parent.globalAdmin.selectTable(window.name);
  // 更多选项操作
  parent.globalAdmin.showMore('.layui-second-search-condition',window.name)
});



