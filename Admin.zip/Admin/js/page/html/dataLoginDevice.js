var dataLoginDevice = {
  renderwordCloud(data, id) {
    var _this = this;
    if(data.length ==0){
      $(`#${id}`).html('<div class="layui-nodata">暂无数据!</div>')
      return
    }
    var option = {
      backgroundColor: '#F7F7F7',
      tooltip: {
        formatter: function (params) {
          return `省份/城市：${params.name}<br/>访问量：${params.value}`
        }
      },
      toolbox: {
        show: true,
        feature:{
          dataView: {
            lang:['','关闭'],
            show: true,
            title:'表格',
            readOnly: true,
            optionToContent:function(opt){
              let table = _this.getTable(data,id);
              return table;
            },
          },
        }
      },
      series: [{
        name: '地域分布',
        type: 'wordCloud',
        sizeRange: [20, 25],
        //textRotation: [0, 45, 90, -45],
        rotationRange: [0, 0],
        //shape: 'circle',
        textPadding: 0,
        autoSize: {
          enable: true,
          minSize: 20
        },
        textStyle: {
          normal: {
            color: function() {
              return 'rgb(' + [
                Math.round(Math.random() * 160),
                Math.round(Math.random() * 160),
                Math.round(Math.random() * 160)
              ].join(',') + ')';
            }
          },
          emphasis: {
            shadowBlur: 10,
            shadowColor: '#333'
          }
        },
        data: data
      }]
    };
    var myChart = echarts.init(document.getElementById(id));
    myChart.setOption(option,true);
  },
  createData (data, dataName, name) {
    let seriesData = [];
    for (let i = 0; i < dataName.length; i++) {
      let series = {name: '', barGap: '0', type: 'bar', data: []}
      series.name = dataName[i][name]
      for (let j = 0; j < data.length; j++) {
        let object = {}
        if (data[j][name] === series.name) {
          object.name = data[j].reportDate
          object.value = data[j].acccessNum
          series.data.push(object)
        }
      }
      seriesData.push(series)
    }
    return seriesData
  },
  renderBar(data, id, domainData){
    if(data.length ==0){
      $(`#${id}`).html('<div class="layui-nodata">暂无数据!</div>')
      return
    }
    let _this = this;
    // 创建对应数据
    let xData = [];
    let seriesData = [];
    let allData = []
    for (let key in data) {
      xData.push(key + '')
      allData.push(...data[key])
    }
    // 筛选数据
    seriesData = _this.createData(allData, domainData, 'domain')
    let option = {
      tooltip: {
        formatter: function (params) {
          return `${params.name}<br/>${params.seriesName}：${params.value}`
        }
      },
      toolbox: {
        show: true,
        feature:{
          dataView: {
            lang:['','关闭'],
            show: true,
            title:'表格',
            readOnly: true,
            optionToContent:function(opt){
              let table = _this.getTable2(data);
              return table;
            },
          },
        }
      },
      xAxis: [
        {
          type: 'category',
          data: xData
        }
      ],
      yAxis: [
        {
          type: 'value'
        }
      ],
      series: seriesData
    };
    var ele = document.getElementById(id);
    var myChart = echarts.init(ele);
    myChart.setOption(option,true);
  },
  renderDomain(data, id){
    if(data.length ==0){
      $(`#${id}`).html('<div class="layui-nodata">暂无数据!</div>')
      return
    }
    var _this =this;
    var option = {
      dataset: {
          source: data
      },
      toolbox: {
        show: true,
        feature:{
          dataView: {
            lang:['','关闭'],
            show: true,
            title:'表格',
            readOnly: true,
            optionToContent:function(opt){
              let table = _this.getTable(data,id);
              return table;
            },
          },
        }
      },
      color:['#4cabce'],
      grid: {containLabel: true},
      xAxis: {name: 'amount',show:false},
      yAxis: {
        type: 'category',
        inverse: true,
        axisLabel:{},
        max: 8,
        axisLine: {
            show: false
        },
        axisTick: {
            show: false
        }
      },
      series: [
          {
              type: 'bar',
              encode: {
                  x: 'amount',
                  y: 'product'
              },
              itemStyle: {
                  normal: {
                      label: {
                          show: true,
                          position: 'right',
                          textStyle: {
                              color: 'black',
                              fontSize: 14
                          }
                      }
                  }
              },
            barMaxWidth: 25,
          }
      ]
    };
    var myChart = echarts.init(document.getElementById(id));
    myChart.setOption(option,true);
  },
  getData(reqData) {
    var _this = this;
    top.ajaxService.doGet("/userLoginLog/getLoginDevice.mvc",reqData,function(res) {
        if (res.resultCode == 0) {
          var data = res.results[0];
          var domainData = data.domainList; //域名访问data
          var addressData = data.addressList;//登录地域data
          var trendData = data.trendMap;//域名访问量走势
          var tempDomainArr = [];
          tempDomainArr.length=domainData.length;
          var seriesDataArr = [];
          var legendDataArr = [];

          // 域名访问数据处理;
          domainData.forEach((v,k)=>{
            tempDomainArr[k]=[];
            tempDomainArr[k][0]=+v.acccessNum;
            tempDomainArr[k][1]=v.domain;
          })
          getUsefulData();

          function getUsefulData(){
            addressData.length > 0 && addressData.forEach((v,k)=>{
              var tempObj = {};
              tempObj.value = +v.acccessNum;
              tempObj.name = v.address;
              legendDataArr.push(v.address);
              seriesDataArr.push(tempObj);
            })
          }
          _this.renderDomain(tempDomainArr, 'layui-bet-domain')
          _this.renderwordCloud(seriesDataArr, 'layui-bet-area')
          _this.renderBar(trendData, 'layui-bet-views', domainData);
        }else{
          layer.msg(res.resultMessage)
        }
      }
    );
  },
  getTable(data,id){
    var html = '';
    if (id === 'layui-bet-domain') {
      data.forEach(v=>{
        html +=`<tr><td>${v[1]}</td><td>${v[0]}</td></tr>`;
      })
    } else {
      data.forEach(v=>{
        html +=`<tr><td>${v.name}</td><td>${v.value}</td></tr>`;
      })
    }
    return `<table class="layui-table" lay-size="sm" style="width:100%;"><thead><tr><th><div class="table_th">${id==='layui-bet-domain'?'域名':'地域'}</div></th><th><div class="table_th">${id =='layui-bet-domain' ? '访问次数' : '访问量'}</div></th></tr></thead><tbody class="tbody">${html}</tbody></table>`
  },
  getTable2(data){
    var html = '';
    for (let key in data) {
      let firstTR = `<tr ><td rowspan="${data[key].length}">${key}</td><td>${data[key][0].domain}</td><td>${data[key][0].acccessNum}</td></tr>`
      html += firstTR
      for (let i = 1; i < data[key].length; i++) {
        let tr = `<tr><td>${data[key][i].domain}</td><td>${data[key][i].acccessNum}</td></tr>`
        html += tr
      }
    }
    var headHtml=``;
    var headArr=['日期','域名','次数'];
    for(var i=0;i<headArr.length;i++){
      headHtml +=`<th><div class="table_th2">${headArr[i]}</div></th>`
    }
    return `<table class="layui-table" lay-size="sm" style="width:100%;"><thead><tr>${headHtml}</tr></thead><tbody class="tbody">${html}</tbody></table>`
  }
};

layui.use(["laydate", "form","util"], function() {
  var laydate = layui.laydate;
  var form = layui.form;
  var util = layui.util;
  parent.globalAdmin.isYesterday = !0;
  parent.globalAdmin.renderIntDate(laydate,util);
  var reqData = {
    reportDateBegin:$('#start').val(),
    reportDateEnd:$('#end').val(),
  }
  dataLoginDevice.getData(reqData);

  // 表单提交demo
  form.on("submit(formDemo)", function(data) {
    var reqData = {
      reportDateBegin:data.field.reportDateBegin,
      reportDateEnd:data.field.reportDateEnd
    }
    dataLoginDevice.getData(reqData);
    return false;
  });
});
