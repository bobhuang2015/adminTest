
var peimissionAdminLog = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  getToolbarHtml(){ 
  },
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var arr=[
      { field: 'managername', title: '管理员账号', width: 140, sort: true}
      , { field: 'operatemenuname', title: '操作菜单名称', width: 140, sort: true}
      , { field:'operationtime',title: '操作时间', width: 180, sort: true,templet:function(d){return util.toDateString(d.operationtime, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'operationdetails', title: '操作详情',sort: true}
    ]
    return arr
  },
}

layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  peimissionAdminLog.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  
  var topHeight = ~~($(".layui-row").height()+40);
  parent.globalAdmin.renderIntDate(laydate,util)
  peimissionAdminLog.table.render({
    elem: '#demo'
    , height: `full-${topHeight}`
    , url: '/operateLog/search.mvc'
    , page: true
    , method: 'get'
    , cols: [ peimissionAdminLog.getOptions(util)],
    where: {
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
    }
  });
  
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    peimissionAdminLog.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



