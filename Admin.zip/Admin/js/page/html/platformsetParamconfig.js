
var platformsetParamconfig = {
  table:null,
  toolbarHtml:'',
  hasSet:false,
  pageNumber:1,
  type:{},
  paramtype:{},
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = '';
    var editHtml = "";
    if(permision){
      var obj = {
        '修改':'hasSet'
      }
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i !='新增'){
          this[obj[i]]=true;
        }else{
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${otherHtml}</div>`;
  },
  renderHtml(ele,data){
    var html='';
    for(var i  in  data){
      html+=`<option value="${i}">${data[i]}</option>`
    }
    $(`${ele}`).append(html);
  },
  getStates(form){//参数类型
    var _this = this;
    var p = new Promise((resovle,reject)=>{
      parent.ajaxService.doGet("/getEnumByNames.mvc",{enumName:'Platform_Sys_Type,Platform_Sys_Param_Type'},function(res){
        if(res.resultCode == 0){
          var data = res.results[0];
          _this.type = data.Platform_Sys_Type;
          _this.paramtype = data.Platform_Sys_Param_Type;
          _this.renderHtml('#layui-paramtype',_this.paramtype);
          form.render('select');
          resovle(data)
        }
      })
    })
    return p;
  },
  reloadTable:function(){
    var _this=this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var _this = this;
    var arr=[
      { field: 'paramtype', title: '分类', width: 100,sort: true,templet:function(d){return d.paramtype ? _this.paramtype[d.paramtype] : ''}}
      , { field: 'paramname', title: '参数', width: 280,sort: true}
      , { field: 'paramvalue', title: '参数值', width: 460,sort: true}
      , { field: 'paramdes', title: '参数值描述', width: 420,sort: true}
      , { field: 'operator', title: '操作人', width: 120,sort: true}
      , { field: 'operatordt', title: '操作时间',sort: true,templet:function(d){return util.toDateString(d.operatordt, "yyyy-MM-dd HH:mm:ss")}}
    ]
    if(_this.hasSet){
      arr.forEach((v,k)=>{
        if(v.field=='paramname' || v.field=='paramvalue' || v.field =='paramdes'){
          Object.assign(v,{edit: 'text'})
        }
      })
    }
    return arr
  },
}

platformsetParamconfig.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  platformsetParamconfig.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  var reqUrl = '/platformSysparam/query.mvc';
  var toolbar =  platformsetParamconfig.toolbarHtml;
  platformsetParamconfig.getStates(form).then((data)=>{
    platformsetParamconfig.table.render({
      elem: '#demo'
      , height: 'full-80'
      , url: reqUrl
      , toolbar: toolbar
      , defaultToolbar:[]
      , page: true
      , method: 'get'
      , cols: [ platformsetParamconfig.getOptions(util)],
      where: {
      }
      , parseData: function (res) {
        var result = {
          "code": res.resultCode, 
          "msg": res.resultMessage,
          "count": res.meta.totalRecord,
          "data": res.results[0]
        };
        return result
      },
      response: {
        statusCode: '0'
      },
      done: function (res, cur, count) {
        platformsetParamconfig.pageNumber=cur;
        // if(res.data.length> 0){
        //   layui.each($("select[name='type']"), function (index, item) {
        //       var elem = $(item);
        //       elem.val(elem.data('value'));
        //   });
        //   form.render('select');
        // }
      }
    })  
  });
  
  // 工具栏操作
  platformsetParamconfig.table.on("toolbar(demo)",function(res){
    var checkStatus = platformsetParamconfig.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    switch (res.event) {
      case '新增':
        layer.open({
          title:res.event,
          type: 1,
          skin: 'layui-layer-test',
          area: ['600px', '480px'],
          content: htmlTpl.addHtml,
          moveType:1,
          success:function(){
            platformsetParamconfig.renderHtml('.layui-type',platformsetParamconfig.type);
            platformsetParamconfig.renderHtml('.layui-paramtype',platformsetParamconfig.paramtype);
            var obj={
              "type": '',
              "paramtype": '',
              "markcode": '',
              "paramname": '',
              "paramvalue": '',
              "paramdes": '',
            }
            form.val('add', obj);
            form.render('select');
            form.on('select(paramType)',function(data){
              var val = data.value;
              if(val ==1){
                $(".layui-paramtype").removeAttr('lay-verify')
                $('#layui-paramType-box').hide()
              }else{
                $(".layui-paramtype").attr('lay-verify','required');
                $('#layui-paramType-box').show()
              }
            })
            form.on('submit(formAdd)',function(submitData){
              var reqData = submitData.field;
              parent.ajaxService.doPost('/platformSysparam/add.mvc',reqData,function(res){
                var msg = res.resultMessage;
                if(res.resultCode==0){
                  platformsetParamconfig.layerCallback(msg);
                }else{
                  layer.msg(msg)
                }
              })
              return false;
            })
          }
        })
      break;
      default:
        break;
    }
  })
  //监听行工具事件
  platformsetParamconfig.table.on('tool(demo)', function(obj){
    var data = obj.data;
    if(obj.event === 'lock'){
      var text = data.locked==0 ? '锁定' : '解锁'; 
      layer.confirm(`是否${text}账号 ${data.username}?`, function(index){
        var reqData={
          userid:data.userid,
          locked:data.locked
        }
        parent.ajaxService.doPost("/platformsetParamconfig/updateplatformsetParamconfigState.mvc",reqData,function(res){
          if(res.resultCode ==0){
            platformsetParamconfig.layerCallback(res.resultMessage);
          }else{
            layer.msg(res.resultMessage);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    platformsetParamconfig.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
  //监听select;
  form.on('select(type)',function(data){
    if(platformsetParamconfig.hasSet){
      var reqData = {
        id:$(data.elem).attr('data-id'),
        type:data.value
      }
      parent.ajaxService.doPost('/platformSysparam/updateType.mvc',reqData,function(res){
        var msg = res.resultMessage;
        if(res.resultCode==0){
          platformsetParamconfig.layerCallback(msg);
        }else{
          layer.msg(msg);
        }
      })
    }else{
      layer.alert('您没有权限修改，请联系系统管理员!')
    }
  })
  //监听单元格编辑
  platformsetParamconfig.table.on('edit(demo)', function(obj){
    var value = obj.value 
    ,data = obj.data 
    ,field = obj.field; 
    var reqData = {
      id:data.id,
      markcode:data.markcode,
      paramname:field=='paramname' ? value : data.paramname,
      paramvalue:field=='paramvalue' ? value :data.paramvalue,
      operator:data.operator,
      type:data.type,
      paramdes:data.paramdes,
      paramtype:data.paramtype
    }
    parent.ajaxService.doPost('/platformSysparam/update.mvc',reqData,function(res){
      var msg = res.resultMessage;
      if(res.resultCode==0){
        platformsetParamconfig.layerCallback(msg);
      }else{
        layer.msg(msg);
      }
    })
  });
});



