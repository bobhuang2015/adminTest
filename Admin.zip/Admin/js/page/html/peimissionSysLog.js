
var peimissionSysLog = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  hasSet:false,
  hasDel:false,
  pageNumber:1,
  layeditIndex:0,
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action ='permission-sys-log';
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    var obj={
      '修改':'hasSet',
      '删除':'hasDel'
    }
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i!='新增'){
          this[obj[i]]=true;
        }else{
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${otherHtml}</div>`;//toolbar 跟表格联动
  },
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var arr=[
      { field: 'updateTime', title: '更新时间', width: 160, sort: true,templet:function(d){return util.toDateString(d.updateTime, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'content', title: '更新内容', width:600}
      , { field: 'operator', title: '创建者', width: 120, sort: true}
      , { field: 'operateTime', title: '编辑时间', width: 160, sort: true,templet:function(d){return util.toDateString(d.operateTime, "yyyy-MM-dd HH:mm:ss")}}
      , {title:'操作',toolbar:'#barDemo'}
    ]
    return arr
  },
  editAlert(title,data,form,laydate,layedit){
    var isAdd = title == '新增' ? 1 : 0;
    var _this = this;
    layer.open({
      title:title,
      type: 1,
      skin: 'layui-layer-test',
      area: ['760px', '520px'],
      content: htmlTpl.addHtml,
      success:function(){
        laydate.render({
          elem: "#startFresh"
          ,max:1
          // ,min:-30
          ,type:'datetime'
          ,btns: ["clear", "confirm"]
        });
        var obj = {
          'updateTime':isAdd ? '' : data.updateTime,
        }
        form.val('add',obj)
        var reqUrl = isAdd ? '/sysUpdateLog/insert.mvc' : '/sysUpdateLog/update.mvc';
        form.on('submit(formAdd)',function(submitData){
          var reqData = submitData.field;
          !isAdd && Object.assign(reqData,{id:data.id})
          reqData.content=layedit.getContent(peimissionSysLog.layeditIndex);
          parent.ajaxService.doPost(reqUrl,reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              _this.layerCallback(msg);
            }else{
              layer.msg(msg)
            }
          })
          return false;
        })
      }
    })
    setTimeout(()=>{
      peimissionSysLog.layeditIndex = layedit.build('LAY_demo2',{tool: ['fontSize','colorpicker','strong', 'italic','underline','del','|','left','center','right','|','link','unlink','face']});
      layedit.setContent(peimissionSysLog.layeditIndex, isAdd ? "" : data.content);
    },200)
  }
}

layui.use(['laydate', 'table', 'form', 'layer','util','layedit'], function () {
  var laydate = layui.laydate;
  peimissionSysLog.table = layui.table;
  peimissionSysLog.getToolbarHtml();
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  var laydate = layui.laydate;
  var layedit = layui.layedit;
  
  var topHeight = ~~($(".layui-row").height()+40);
  parent.globalAdmin.renderIntDate(laydate,util)
  peimissionSysLog.table.render({
    elem: '#demo'
    , height: `full-${topHeight}`
    , url: '/sysUpdateLog/list.mvc'
    , toolbar: peimissionSysLog.toolbarHtml
    , defaultToolbar:[]
    , page: true
    , method: 'get'
    , cols: [ peimissionSysLog.getOptions(util)],
    where: {
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
    }
  });
  

    // 工具栏操作
    peimissionSysLog.table.on("toolbar(demo)",function(res){
      var checkStatus = peimissionSysLog.table.checkStatus(res.config.id);
      var data = checkStatus.data;
      switch (res.event) {
        case '新增':
          peimissionSysLog.editAlert(res.event,data,form,laydate,layedit)
        break;
        default:
          // layer.msg("接口文档未完善，需要相应人员支持!")
          break;
      }
    })
    //监听行工具事件
    peimissionSysLog.table.on('tool(demo)', function(obj){
      var data = obj.data;
      var event = obj.event;
      if(event ==='set'){
        peimissionSysLog.editAlert('修改',data,form,laydate,layedit)
      }else if(event ==='del'){
        layer.confirm("是否删除?",{
            btn:['确定','取消']
          },function(){
          var reqData = {
            id:data.id
          }
          parent.ajaxService.doPost("/sysUpdateLog/delete.mvc",reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode ==0){
              peimissionSysLog.layerCallback(msg);
            }else{
              layer.msg(msg);
            }
          })
          },function(index){
            layer.close(index)
          }
        )
      }
    })


  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    peimissionSysLog.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



