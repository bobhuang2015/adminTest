
var setUserlimit = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  getToolbarHtml(){ 
    var action = window.name;
    var permision = parent.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i !='解锁' && i!='增加'){
          editHtml +='<button id="'+i+'" class="layui-btn layui-btn-disabled" lay-event="'+i+'">'+i+'</button>'
        }
        if(i=='解锁'){
          this.hasLock=true;
        }
        if(i=='增加'){
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${editHtml}<div style="display:inline-block;margin-left:10px;">${otherHtml}</div></div>`;
  },
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var arr=[
      {type:'checkbox',width:80}
      ,{ title: '操作', width: 140}
      , { field: 'username', title: '用户名称', width: 140,sort: true}
      , { field: 'gameTypeName', title: '彩票种类', width: 180,sort: true}
      , { field: 'lastoperator', title: '最后操作人', width: 180,sort: true}
      , { title: '最后操作时间', width: 200,sort: true,templet:function(d){return util.toDateString(d.lastoperationtime, "yyyy-MM-dd HH:mm:ss")}}
    ]
    return arr
  },
  editIdArr:[],
  tableData:[]
}

// setUserlimit.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  setUserlimit.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  var requestUrl = '/userKill/queryList.mvc';
  setUserlimit.table.render({
    elem: '#demo'
    , height: 600
    , url: requestUrl
    ,toolbar: setUserlimit.toolbarHtml
    , page: true
    , method: 'get'
    , cols: [ setUserlimit.getOptions(util)],
    where: {
      gametype:66
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results
      };
      setUserlimit.tableData=res.results;
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
    }
  });
  parent.globalAdmin.checkboxEdit(setUserlimit,window.name)
  
  // 工具栏操作
  setUserlimit.table.on("toolbar(demo)",function(res){
    var checkStatus = setUserlimit.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    switch (res.event) {
      case '增加':
      case '修改':
        var isAdd = res.event == '增加' ? 1 : 0;
        layer.open({
          title:res.event,
          type: 1,
          skin: 'layui-layer-test',
          area: ['600px', '400px'],
          content: htmlTpl.addHtml,
          success:function(){
            var obj={
              "username": isAdd ? '' :data[0].username,
              "bankname": isAdd ? '' :data[0].bankname,
              "branchname":isAdd ? '' :data[0].branchname,
              "accountname":isAdd ? '' :data[0].accountname,
              "accountno":isAdd ? '' :data[0].accountno
            }
            form.val('add', obj)
            form.on('submit(formAdd)',function(submitData){
              var reqUrl = isAdd ? '/setUserlimit/addsetUserlimit.mvc' : '/setUserlimit/updatesetUserlimit.mvc';
              var reqData = isAdd ? submitData.field : Object.assign(submitData.field,{id:data[0].id,userid:data[0].userid});
              parent.ajaxService.doPost(reqUrl,reqData,function(res){
                var msg = res.resultMessage;
                if(res.resultCode==0){
                  setUserlimit.layerCallback(msg);
                  setUserlimit.editIdArr=[];
                }else{
                  layer.msg(msg)
                }
              })
              return false;
            })
          }
        })
      break;
      case '删除':
        layer.confirm("是否删除选中的银行?",{
            btn:['确定','取消']
          },function(){
          var reqData = {
            id:setUserlimit.editIdArr.join()
          }
          parent.ajaxService.doPost("/setUserlimit/deletesetUserlimit.mvc",reqData,function(res){
            if(res.resultCode ==0){
              setUserlimit.layerCallback(res.resultMessage);
              setUserlimit.editIdArr=[];
            }else{
              layer.msg(res.resultMessage);
            }
          })
          },function(index){
            layer.close(index)
          }
        )
      break;
      default:
        // layer.msg("接口文档未完善，需要相应人员支持!")
        break;
    }
  })
  //监听行工具事件
  setUserlimit.table.on('tool(demo)', function(obj){
    var data = obj.data;
    if(obj.event === 'lock'){
      var text = data.locked==0 ? '锁定' : '解锁'; 
      layer.confirm(`是否${text}账号 ${data.username}?`, function(index){
        var reqData={
          userid:data.userid,
          locked:data.locked
        }
        parent.ajaxService.doPost("/setUserlimit/updatesetUserlimitState.mvc",reqData,function(res){
          if(res.resultCode ==0){
            setUserlimit.layerCallback(res.resultMessage);
          }else{
            layer.msg(res.resultMessage);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    setUserlimit.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
  laydate.render({
    elem: '#start' 
  });
  laydate.render({
    elem: '#end' 
  });
});



