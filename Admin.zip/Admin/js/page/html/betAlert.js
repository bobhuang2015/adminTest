
var betAlert = {
    //弹窗第一个表格
    renderFirstTable(data,util,ordernumber,ele){
      var titleHtml = data.stopped==2 ? `<th colspan="4"><font color="red">追号已停止,停止时间:${util.toDateString(data.stopdt, "yyyy-MM-dd HH:mm:ss")},说明:<b>${data.remark}</b></font></th>` : '';
      var firstTableHtml = `<tbody>
                          <tr>
                              ${titleHtml}
                          </tr>
                          <tr>
                              <td width="20%" align="right">用户账号</td>
                              <td width="30%">${data.username}</td>
                              <td width="20%" align="right">追号单号</td>
                              <td width="30%">${ordernumber}</td>
                          </tr>
                          <tr>
                              <td align="right">游戏类型</td>
                              <td>${data.gametypename}</td>
                              <td align="right">投注总额</td>
                              <td >${data.betmoneytotal.toFixed(3)}</td>
                          </tr>
                          <tr>
                              <td align="right">中奖停止追号</td>
                              <td >${data.iswinstop ? '是' : '否'} </td>
                              <td align="right">下单时间</td>
                              <td >${util.toDateString(data.optdt, "yyyy-MM-dd HH:mm:ss")}</td>
                          </tr>
                          <tr>
                              <td align="right">剩余期数/总期数</td>
                              <td><font color="green"><b>${data.issuelave}</b></font> / ${data.issuecount}</td>
                              <td align="right">最后追号期号</td>
                              <td>${data.lastbetissueno ? data.lastbetissueno : ''}</td>
                          </tr>
                          <tr>
                              <td align="right">状态</td>
                              <td><span class="label label-info" style="font-size: 11px;">${data.stopped==1 ? '追号中' :'已停止'}</span></td>
                              <td align="right">状态备注</td>
                              <td>${data.remark ? data.remark : ''}</td>
                          </tr>
                      </tbody>`
          $(ele).html(firstTableHtml);
    },
    //第二个table弹窗
    renderSecondTable(secondTableData){
        var secondListHtml ='';
        secondTableData.forEach((v,k)=>{
          secondListHtml +=`<tr><td>${v.ordernumber}</td><td>${v.bettypename+'/'+v.playtypename}</td><td>${v.nums}</td><td>${v.betmoneytotal.toFixed(3)}</td><td>${v.scale.toFixed(3)}</td></tr>`
        })
       var secondTableHtml = `<table>
                                <thead>
                                  <tr><th>订单号</th><th>玩法</th><th>投注内容</th><th>投注总额</th><th>奖金</th></tr>
                                </thead>
                                <tbody>
                                  ${secondListHtml}
                                </tbody>
                            </table>`
        $('.second-table').html(secondTableHtml);
    },
    // 投注弹窗
    renderTouHtml(data,lotteryData,util,type){
    var titleHtml = data.state==7 ? `<td colspan="4" align="center" ><font color="red">${data.operator} 于 ${util.toDateString(data.changeTime, "yyyy-MM-dd HH:mm:ss")},<b>已作废</b>该注单</font></td>` : '';
      var html = `<tbody>
                    <tr>${titleHtml}</tr>
                    <tr>
                        <td width="15%" align="right">用户账号</td>
                        <td width="35%">${data.username}</td>
                        <td width="15%" align="right">投注单号</td>
                        <td width="35%">${data.ordernumber}</td>
                    </tr>
                    <tr>
                        <td align="right">游戏类型</td>
                        <td>${data.gametypename}</td>
                        <td align="right">期号</td>
                        <td> ${data.issueno} ${data.iszhuihao ==1 ? `<span class="red">追</span> <span data-id="${data.zhid}" data-ordernumber="${data.ordernumber}" class="zhuiDetail" style="cursor:pointer;">追号详细</span>` : '' }                                                                                                                                                        					</a>                    </td>
                    </tr>
                    <tr>
                        <td align="right">玩法</td>
                        <td colspan="3">${type!='KG' ? (data.playTypeDoc ? data.playTypeDoc +'/ ' : '') : ''}${data.playtypename} / ${data.bettypename} ${data.digit  ? data.digit : ''}</td>
                    </tr>
                    <tr>
                        <td align="right">赔率</td>
                        <td>${data.bonus.toFixed(3)} </td>
                        <td align="right">返点金额</td>
                        <td> ${data.selfBonusMoney} </td>
                    </tr>
                    <tr>
                        <td align="right">投注号码</td>
                        <td colspan="3"><textarea rows="4" readonly="readonly" class="layui-textarea">${data.nums}</textarea></td>
                    </tr>
                    <tr>
                        <td align="right">投注时间</td>
                        <td>${util.toDateString(data.betdt, "yyyy-MM-dd HH:mm:ss")}</td>
                        <td align="right">投注总额</td>
                        <td>${data.betmoneytotal.toFixed(3)} (<span title="单注金额 * 倍数 * 投注注数">¥ ${data.betmoney} * ${data.multiple}倍 * ${data.betcount} 注</span>)</td>
                    </tr>
                    <tr>
                        <td align="right">用户返点</td>
                        <td>${data.userbonus.split(":")[data.userbonus.split(":").length-1]}</td>
                        <td align="right">所选返点</td>
                        <td>${data.bonuspct}</td>
                    </tr>
                    <tr>
                        <td align="right">开奖时间</td>
                        <td>${lotteryData ? util.toDateString(lotteryData.lotterydt, "yyyy-MM-dd HH:mm:ss") : '--'}</td>
                        <td align="right">开奖号码</td>
                        <td>${lotteryData ? lotteryData.nums : ''}</td>
                    </tr>
                    <tr>
                        <td align="right">状态</td>
                        <td>${data.status} <span class="red">${data.iswin ? '中奖' : data.iswin ==0 ? '未中奖' : '未结算'}</span> </td>
                        <td align="right">中奖金额</td>
                        <td>¥ ${data.winmoney.toFixed(3)} / ${data.wincount}注</td>
                    </tr>
                    <tr>
                        <td align="right">实际盈亏</td>
                        <td colspan="3"> <span class="${data.winmoney - data.betmoneytotal > 0 ? 'red' : 'green'}" style="font-weight:bold;font-size: 18px; ">${(data.winmoney - data.betmoneytotal).toFixed(3)} <span></td>                                                                                                     					                                                                                                                                                             					 6.6330                     					</span>                    </td>
                    </tr>
                </tbody>`
      $('.zhui-table').html(html);
    },
    // 追号列表table渲染
    renderThirdTable(thirdTableData,stateObj){
      var thirdListHtml ='';
      thirdTableData.forEach((v,k)=>{
        thirdListHtml +=`<tr><td class="layui-table-zhuihaonumber" data-zhid="${v.zhid}" data-zhinfoid="${v.id}" data-ordernumber="${v.ordernumber}">${v.ordernumber}</td><td>${v.issueno}</td><td>${v.multiple}</td><td>${v.betmoneytotal.toFixed(3)}</td><td>${stateObj[v.status]}</td><td>${v.status == 0 ? `<div class="layui-btn layui-btn-danger layui-cancle layui-btn-xs" data-id="${v.id}">取消</div>` : ''}</td><td>${v.remark ? v.remark : ''}</td></tr>`
      })
     var thirdTableHtml = `<table>
                              <thead>
                                <tr><th>订单号</th><th>期号</th><th>倍数</th><th>追号金额</th><th>状态</th><th>操作</th><th>备注</th></tr>
                              </thead>
                              <tbody>
                                ${thirdListHtml}
                              </tbody>
                          </table>`
      $('.third-table').html(thirdTableHtml);
    }
  }