
var userCenterHelpList = {
  table:null,
  toolbarHtml:'<div><button class="layui-btn" lay-event="新增">新增</button></div>',
  hasSet:true,
  hasDel:true,
  pageNumber:1,
  ParentObj:{},
  parentArr:[],
  floor:parent.$('.layui-tab-title li.layui-this').attr('data-id'),
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    var obj={
      '解锁':'hasLock',
      '修改':'hasSet',
      '删除':'hasDel'
    }
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i!='新增'){
          this[obj[i]]=true;
        }else{
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${otherHtml}</div>`;//toolbar 跟表格联动
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util,id){
    switch (+id) {
      case 1:
      var arr=[
          { field: 'title', title: '名称', width: 140, sort: true}
          , { field: 'ranking', title: '排序',sort: true,width:140}
          , { title: '操作',toolbar: '#barDemo'}
        ]
        break;
      case 2:
      case 3:
      var arr=[
          { field: 'title', title: '名称', width: 140, sort: true}
          , { field: 'bigTypeName', title: '父级名称',sort: true,width:140}
          , { field: 'ranking', title: '排序',sort: true,width:140}
          , { title: '操作',toolbar: '#barDemo'}
        ]
      break; 
      case 4:
      var arr=[
          { field: 'title', title: '名称', width: 140, sort: true}
          , { field: 'bigTypeName', title: '父级名称',sort: true,width:140}
          , { field: 'question', title: '问题',sort: true,width:300}
          , { field: 'answer', title: '答案',sort: true,width:600}
          , { field: 'ranking', title: '排序',sort: true,width:140}
          , { title: '操作',toolbar: '#barDemo'}
        ]
      break; 
      default:
        break;
    }
    return arr
  },
  getParentId(floor){
    var _this =this;
    top.ajaxService.doGet('/questionCenter/searchType.mvc',{floor:floor},function(res){
      if(res.resultCode == 0){
        var data = res.results[0];
        _this.parentArr = data;
        data.forEach((v,k)=>{
          Object.assign(_this.ParentObj,{[v.id]:[v.title]})
        })
      }
    })
  },
  editBigAlert(title,data,form){
    var _this = this;
    var isAdd = title == '新增' ? 1 : 0;
    layer.open({
      title:title,
      type: 1,
      skin: 'layui-layer-test',
      area: ['600px', '300px'],
      content: htmlTpl.addBigHtml,
      success:function(){
        var obj={
          "title": isAdd ? '' :data.title,
          "ranking": isAdd ? '' :data.ranking
        }
        form.val('add', obj)
        form.on('submit(formAdd)',function(submitData){
          var reqUrl = isAdd ? '/questionCenter/add.mvc' : '/questionCenter/edit.mvc';
          var reqData = isAdd ? Object.assign(submitData.field,{floor: _this.floor}) : Object.assign(submitData.field,{id:data.id,floor:_this.floor});
          parent.ajaxService.doPost(reqUrl,reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              userCenterHelpList.layerCallback(msg);
            }else{
              layer.msg(msg)
            }
          })
          return false;
        })
      }
    })
  },
  renderSelect(data,ele){
    var html = '';
    data.forEach((v,k)=>{
      html+=`<option value="${v.id}">${v.title}</option>`
    })
    $(ele).html(html);
  },
  editMiddleAlert(title,data,form){
    if(this.parentArr.length ==0 )return;
    var _this = this;
    var isAdd = title == '新增' ? 1 : 0;
    layer.open({
      title:title,
      type: 1,
      skin: 'layui-layer-test',
      area: ['600px', '300px'],
      content: htmlTpl.addMiddleHtml,
      success:function(){
        _this.renderSelect(_this.parentArr,'.layui-parent')
        var obj={
          "title": isAdd ? '' :data.title,
          "ranking": isAdd ? '' :data.ranking,
          "parentId":isAdd ? '' :data.parentId
        }
        form.val('add', obj);
        form.render('select');
        form.on('submit(formAdd)',function(submitData){
          var reqUrl = isAdd ? '/questionCenter/add.mvc' : _this.floor == 2 ? '/questionCenter/edit.mvc' : '/questionCenter/editSmallType.mvc';
          var reqData = isAdd ? Object.assign(submitData.field,{floor: _this.floor}) : Object.assign(submitData.field,{id:data.id,floor:_this.floor});
          parent.ajaxService.doPost(reqUrl,reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              userCenterHelpList.layerCallback(msg);
            }else{
              layer.msg(msg)
            }
          })
          return false;
        })
      }
    })
  }
}

// userCenterHelpList.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  userCenterHelpList.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  var is = true;
  var obj={
    '1':'/questionCenter/searchType.mvc',
    '2':'/questionCenter/mediumTypeList.mvc',
    '3':'/questionCenter/mediumTypeList.mvc',
  }
  userCenterHelpList.table.render({
    elem: '#demo'
    , height: `full-40`
    , url: obj[userCenterHelpList.floor]
    , toolbar: userCenterHelpList.toolbarHtml
    , defaultToolbar:[]
    , page: true
    , method: 'get'
    , cols: [ userCenterHelpList.getOptions(util,userCenterHelpList.floor)],
    where: {
      floor: userCenterHelpList.floor
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results[0]
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      userCenterHelpList.pageNumber = cur;
      if(is){
        if(userCenterHelpList.floor !=1){
          setTimeout(()=>{
            userCenterHelpList.getParentId(userCenterHelpList.floor-1);
          },500)
          is = !is;
        }
      }
    }
  });
  // userCenterHelpList.checkboxEdit()
  
  // 工具栏操作
  userCenterHelpList.table.on("toolbar(demo)",function(res){
    var checkStatus = userCenterHelpList.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    switch (res.event) {
      case '新增':
        if(userCenterHelpList.floor ==1){
          userCenterHelpList.editBigAlert(res.event,data,form)
        }else if(userCenterHelpList.floor ==2 || userCenterHelpList.floor == 3){
          userCenterHelpList.editMiddleAlert(res.event,data,form)
        }
      break;
      default:
        // layer.msg("接口文档未完善，需要相应人员支持!")
        break;
    }
  })
  //监听行工具事件
  userCenterHelpList.table.on('tool(demo)', function(obj){
    var data = obj.data;
    var event = obj.event;
     if(event ==='set'){
       
      if(userCenterHelpList.floor ==1){
        userCenterHelpList.editBigAlert('修改',data,form)
      }else if(userCenterHelpList.floor ==2 || userCenterHelpList.floor == 3){
        userCenterHelpList.editMiddleAlert('修改',data,form)
      }
    }else if(event ==='del'){
      layer.confirm("是否删除选中的银行?",{
          btn:['确定','取消']
        },function(){
        var reqData = {
          id:data.id
        }
        // parent.ajaxService.doPost("/userCenterHelpList/deleteUserBank.mvc",reqData,function(res){
        //   var msg = res.resultMessage;
        //   if(res.resultCode ==0){
        //     userCenterHelpList.layerCallback(msg);
        //   }else{
        //     layer.msg(msg);
        //   }
        // })
        },function(index){
          layer.close(index)
        }
      )
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    userCenterHelpList.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



