
var platformPreview = {
  table:null,
  dateObj:{},
  pageNumber:1,
  getTargetMoney(data){
    var arr  = (''+data).split('.');
    if(arr[1] && arr[1].length > 3){
      return arr[0]+'.'+arr[1].substr(0,3)
    }else{
      return arr[0]+(arr[1] ? '.'+arr[1] : '');
    }
  },
  getOptions:function(util){
    var _this = this;
    var arr=[
      { field: 'username', title: '用户账号', width: 120}
      , { field: 'profitlosstypeid', title: '返点类型', width: 120,templet:function(d){return parent.platformsetTaskmanage.stateObj[d.profitlosstypeid]}}
      , { field: 'profitlossmoney', title: '返点金额', width: 100,templet:function(d){return  _this.getTargetMoney(d.profitlossmoney)}}
      , { field: 'baseAmount', title: '基础金额', width: 100,templet:function(d){return  _this.getTargetMoney(d.baseAmount) }}
      , { field: 'rebateRatio', title: '返点比例', width: 100 }
      , { field: 'description', title: '备注', width: 180 }
      , { field: 'currentavailableamount', title: '当前余额', width: 140}
      , { field: 'profitLossDt', title: '账变时间',templet:function(d){return util.toDateString(d.profitLossDt, "yyyy-MM-dd HH:mm:ss")}}
    ]
    return arr
  }
}

layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  platformPreview.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  var url = `/quzrtz/${parent.platformsetTaskmanage.currentPlatform}Preview.mvc`;
  var yesterday = new Date().getTime() - 60 *24 *60 *1000;
  laydate.render({
    elem: `#start`,
    value: util.toDateString(yesterday,"yyyy-MM-dd"),
    btns: ["clear", "confirm"],
    max:-1
  });
  platformPreview.dateObj={
    'betTime':$('#start').val()
  }
  platformPreview.table.render({
    elem: `#demo`
    , height: 560
    , url: `${url}` 
    , page: true
    , limits: [10, 20]
    , limit: 10
    , method: 'get'
    , cols: [platformPreview.getOptions(util)],
    where: {}
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results[0]
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
    }
  })

  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    platformPreview.dateObj = data.field;
    platformPreview.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



