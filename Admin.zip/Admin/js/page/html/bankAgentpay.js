
var bankAgentpay = {
  table:null,
  index:9999999,
  toolbarHtml:'',
  isFirstRender:true,
  hasLock:false,
  hasDel:false,
  hasTransfer:false,
  rechargeList:[],
  selfBankList:[],
  merchantTypeList:[],
  merchantTypeObj:{},
  pageNumber:1,
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){
    var action = window.name || globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    var obj={
      '修改':'hasSet',
      '禁用/启用':'hasLock',
      // '转移':'hasTransfer',
      '删除':'hasDel'
    }
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i !=='新增' && i !=='支付类别'){
          this[obj[i]]=true;
        }else{
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>';
          if(i=='支付类别'){
            parent.globalAdmin.rechargeMethod = v.childrens;
          }
        }
      })
    }
    this.toolbarHtml =`<div>${otherHtml}</div>`;
    this.getRechargeList();
  },
  getRechargeList(){
    var _this = this;
    parent.ajaxService.doGet("/rechargType/list.mvc",{enabled:1},function(res){
      if(res.resultCode==0){
        _this.rechargeList = res.results[0];
      }
    })
  },
  getMerchantType(util,layer){
    var _this = this;
    _this.table.render({
      elem: '#demo'
      , height: 800
      , url: '/agentPayMerchant/select.mvc'
      ,toolbar: _this.toolbarHtml
      , defaultToolbar:[]
      , page: true
      , method: 'get'
      , cols: [_this.getOptions(util)],
      where: {}
      , parseData: function (res) {
        if(_this.isFirstRender){
          _this.selfBankList = res.results[1];
          _this.isFirstRender = !_this.isFirstRender;
        }
        var result = {
          "code": res.resultCode,
          "msg": res.resultMessage,
          "count": res.meta.totalRecord,
          "data": res.results[0]
        };
        return result
      },
      response: {
        statusCode: '0'
      },
      done: function (res, cur, count) {
        _this.pageNumber=cur;
      }
    });
  },
  renderData(id,data){
    var html='';
    data.forEach(function(v,k){
      html+=`<option value="${v.code ? v.code : v.id}" type="${v.type}">${v.name}</option>`
    })
    $(`.${id}`).append(html);
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber
      }
    })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  formatType(type){
    var obj={
      "0":'全部',
      "1":'网页端',
      "2":'APP'
    }
    return obj[type]
  },
  getOptions:function(util){
    var _this = this;
    var arr=[
      { field: 'sort', title: '排序', sort: true,width:100}
      , { field: 'merchantName', title: '商户名', width: 120}
      , { field: 'merchantNo', title: '商户号', width: 120}
      , { field: 'privateKey', title: '商户私钥', width: 120}
      , { field: 'thirdGateway', title: '第三方网关', width: 120}
      , { field: 'minLimit', title: '最小金额', width: 140, sort: true}
      , { field: 'maxLimit', title: '最大金额', width: 140, sort: true}
      , { field: 'fee', title: '手续费', width: 140, sort: true}
      , { field: 'enabled',title: '状态', width: 80,templet:function(d){return d.enabled === 1 ? '已启用' : '已禁用'}}
      , { field: 'operator',title: '操作人', width: 120}
      , { field: 'operateTime', title: '操作时间', width: 120, sort: true,templet:function(d){return util.toDateString(d.operateTime, "yyyy-MM-dd")}}
      , { field: 'remark', title: '备注', width: 120}
      , { title: '操作', toolbar: '#barDemo'}
    ]
    return arr
  },
  editAlert(isAdd,title,form,data){
    var _this = this;
    layer.open({
      title:title,
      type: 1,
      skin: 'layui-layer-test',
      area: ['700px', '900px'],
      content: htmlTpl.addHtml,
      success:function(){
        form.render("select",'add');
        var obj={
          "merchantName": isAdd ? '' : data.merchantName,
          "agentCode": isAdd ? '' : data.agentCode,
          "merchantNo": isAdd ? '' : data.merchantNo,
          "tranCode": isAdd ? '' : data.tranCode,
          "privateKey": isAdd ? '' : data.privateKey,
          "publicKey": isAdd ? '' : data.publicKey,
          "otherKey": isAdd ? '' : data.otherKey,
          "thirdGateway": isAdd ? '' : data.thirdGateway,
          "payGateway": isAdd ? '' : data.payGateway,
          "minLimit": isAdd ? '' : data.minLimit,
          "maxLimit": isAdd ? '' : data.maxLimit,
          "fee": isAdd ? '' : data.fee,
          "feeRate": isAdd ? '' : data.feeRate,
          "withdrawType": isAdd? '': data.withdrawType,
          "thirdQuery": isAdd? '' : data.thirdQuery,
          "thirdIp": isAdd? '': data.thirdIp,
          "remark": isAdd ? '' : data.remark,
          "enabled": isAdd ? '' : data.enabled,
          "sort": isAdd ? '' : data.sort
        }
        form.val('add', obj);
        form.render('checkbox','add');
        form.on('submit(formAdd)',function(submitData){
          var reqUrl = isAdd ? '/agentPayMerchant/insert.mvc' : '/agentPayMerchant/update.mvc';
          // 参数类型转换(string 转 number)
          if (submitData.field.minLimit) { submitData.field.minLimit = +submitData.field.minLimit }
          if (submitData.field.maxLimit) { submitData.field.maxLimit = +submitData.field.maxLimit }
          if (submitData.field.sort) { submitData.field.sort = +submitData.field.sort }
          if (submitData.field.enabled) { submitData.field.enabled = +submitData.field.enabled }
          if (submitData.field.withdrawType) { submitData.field.withdrawType = +submitData.field.withdrawType }
          if (submitData.field.fee) { submitData.field.fee = +submitData.field.fee }
          if (submitData.field.feeRate) { submitData.field.feeRate = +submitData.field.feeRate }
          if (isAdd) {
            var reqData = JSON.stringify(submitData.field)
          } else {
            var reqData = JSON.stringify(Object.assign({id: data.id}, submitData.field))
          }
          parent.ajaxService.doPost(reqUrl,reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              bankAgentpay.layerCallback(msg);
            }else{
              layer.msg(msg)
            }
          },'baofoo')
          return false;
        })
      }
    })
  }
}

bankAgentpay.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  bankAgentpay.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  bankAgentpay.getMerchantType(util,layer);
  // 工具栏操作
  bankAgentpay.table.on("toolbar(demo)",function(res){
    var checkStatus = bankAgentpay.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    switch (res.event) {
      case '新增':
        bankAgentpay.editAlert(!0,res.event,form)
        break;
      case '支付类别':
        var url = "html/bank-recharge.html";
        parent.tab.tabAdd(res.event, url, bankAgentpay.index,'');
        parent.tab.tabChange(bankAgentpay.index);
        bankAgentpay.index++;
        break;
      default:
        // layer.msg("接口文档未完善，需要相应人员支持!")
        break;
    }
  })
  //监听行工具事件
  bankAgentpay.table.on('tool(demo)', function(obj){
    var data = obj.data;
    if(obj.event === 'lock'){
      var text = data.enabled === 1 ? '禁用' : '启用';
      layer.confirm(`是否${text}?`, function(index){
          var reqData={
            id:data.id,
            enabled:data.enabled === 1 ? 2: 1
          }
          parent.ajaxService.doPost("/agentPayMerchant/setEnabled.mvc",reqData,function(res){
            var msg = res.resultMessage
            if(res.resultCode == 0){
              bankAgentpay.layerCallback(msg);
            }else{
              layer.msg(msg);
            }
          })
        },function(index){
          layer.close(index)
        }
      )
    }else if(obj.event === 'del'){
      layer.confirm(`是否删除?`, function(index){
          var reqData={
            id:data.id
          }
          parent.ajaxService.doPost("/agentPayMerchant/delete.mvc",reqData,function(res){
            var msg = res.resultMessage
            if(res.resultCode == 0){
              bankAgentpay.layerCallback(msg);
            }else{
              layer.msg(msg);
            }
          })
        },function(index){
          layer.close(index)
        }
      )
    }else if(obj.event === 'transfer'){
      layer.open({
        title:'转移',
        type: 1,
        skin: 'layui-layer-test',
        area: ['620px', '550px'],
        content: htmlTpl.transferHtml,
        success:function(){
          var obj={
            "sourcemerchantid": data.merchantid,
            "targetbankname":'',
            "targetbranchname":'',
            "targetaccountname":'',
            "targetaccountno":'',
            "money":'',
            "fee":0,
          }
          form.val('transfer', obj)
          form.on('submit(formTrsansfer)',function(submitData){
            var reqData =  submitData.field;
            parent.ajaxService.doPost('/baoFooTransfer/add.mvc',reqData,function(res){
              var msg = res.resultMessage;
              if(res.resultCode==0){
                bankAgentpay.layerCallback(msg);
              }else{
                layer.msg(msg)
              }
            })
            return false;
          })
        }
      })
    }else if(obj.event === 'set'){
      bankAgentpay.editAlert(0,'修改',form,data);
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    bankAgentpay.table.reload('demo',{
      where:data.field,
      page:{
        curr:1
      }
    })
    return false;
  });
});



