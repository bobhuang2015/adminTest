var profitLossTeamLotteryUser = {
  table:null,
  playTypeArr:[],
  reqUrl:'',
  currentIndex:parent.profitLossTeam.currentId,
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  renderGametype(data){
    var html='';
    data.forEach((v,k)=>{
      html+=`<option value="${v.id}">${v.name}</option>`
    })
    $(".gameType").append(html);
  },
  controlInput(){
    if(this.currentIndex == 2){
      this.renderGametype(this.globalAdmin.gameListArr)
    }else{
      $(".layui-input-inline").remove();
    }
    var obj={
      '2':'/betrecord/getBetProfitAndLoss',
      '3':'/betrecord/getBetProfitAndLossGameType'
    }
    this.reqUrl = obj[this.currentIndex];
  },
  getOptions:function(){
    var _this = this;
    var arr=[
      { field: 'sumProfitAndLoss', width: 160, sort:true,title:'总盈亏',rowspan: 2,templet:function(d){ return `<span class='${parent.globalAdmin.getColor(d.sumProfitAndLoss)}'>${globalAdmin.commafy(_this.formatData(d.sumProfitAndLoss))}</span>`}}
      , { align: 'center',  title:'经典彩票',colspan: 4}
      , { align: 'center',  title:'传统彩票',colspan: 4}
    ]
    if(this.currentIndex == 2){
      arr.unshift({ field: 'username', width: 160, title:'用户名称',rowspan: 2})
    }else{
      arr.unshift({ field: 'gametypename', width: 160, title:'游戏名称',rowspan: 2})
    }
    arr[0].totalRowText='合计:'
    return arr
  },
  formatData(data){
    return data ? data.toFixed(3) : '0.000'
  },
  getSmallOption(){
    var _this = this;
    var arr=[
      { field: 'betCount', width: 150, title:'注单数',sort:true,templet:function(d){return d.betCount ? d.betCount : 0}}
      , { field: 'betMoneyTotal', width: 150,sort:true, title:'投注额',templet:function(d){return globalAdmin.commafy(_this.formatData(d.betMoneyTotal))}}
      , { field: 'winMoney', width: 150,sort:true, title:'中奖额',templet:function(d){return globalAdmin.commafy(_this.formatData(d.winMoney))}}
      , { field: 'profitAndLoss', width: 150,sort:true, title:'投注盈亏',templet:function(d){return `<span class='${parent.globalAdmin.getColor(_this.formatData(d.profitAndLoss))}'>${globalAdmin.commafy(_this.formatData(d.profitAndLoss))}</span>`}}
      , { field: 'kjbetCount', width: 150,sort:true, title:'注单数',templet:function(d){return d.kjbetCount ? d.kjbetCount : 0}}
      , { field: 'kjbetMoneyTotal', width: 150, sort:true,title:'投注额',templet:function(d){return globalAdmin.commafy(_this.formatData(d.kjbetMoneyTotal))}}
      , { field: 'kjwinMoney', width: 150,sort:true, title:'中奖额',templet:function(d){return globalAdmin.commafy(_this.formatData(d.kjwinMoney))}}
      , { field: 'kjprofitAndLoss',sort:true, title:'投注盈亏',templet:function(d){return `<span class='${parent.globalAdmin.getColor(_this.formatData(d.kjprofitAndLoss))}'>${globalAdmin.commafy(_this.formatData(d.kjprofitAndLoss))}</span>`}}
    ]
    return arr
  },
}

profitLossTeamLotteryUser.controlInput();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  profitLossTeamLotteryUser.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  var arr1 = profitLossTeamLotteryUser.getOptions();
  var arr2 = profitLossTeamLotteryUser.getSmallOption();
  globalAdmin.renderIntDate(laydate,util);

  profitLossTeamLotteryUser.table.render({
    elem: '#demo'
    , height: 670
    , url: `${profitLossTeamLotteryUser.reqUrl}.mvc`
    , page: true
    , method: 'get'
    , cols: [arr1,arr2],
    where: {
      betdt_begin:$("#start").val(),
      betdt_end:$('#end').val(),
      gametype:1
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.results[0].length,
        "data": res.results[0]
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      // $('table tbody').after('<tr><td><div class="layui-table-cell" style="width:160px">合计:</div></td><td><div style="width:160px">0</div></td><td><div style="width:160px">0</div></td><td><div style="width:160px">0</div></td><td><div style="width:160px">0</div></td><td><div style="width:160px">0</div></td><td><div style="width:160px">0</div></td><td><div style="width:160px">0</div></td><td><div style="width:160px">0</div></td></tr>')
    }
  });
  
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    profitLossTeamLotteryUser.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



