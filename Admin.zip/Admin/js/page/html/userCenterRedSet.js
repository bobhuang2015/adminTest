
var userCenterRedSet = {
  table:null,
  toolbarHtml:'',
  hasSet:false,
  hasDel:false,
  hasRed:false,
  pageNumber:1,
  roomList:[],
  roomObj:{
    // "0":'全部厅'
  },
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action ="userCenter-red-set";
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    var obj={
      '修改':'hasSet',
      '删除':'hasDel',
      '发红包':'hasRed',
    }
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i!='新增'){
          this[obj[i]]=true;
        }else{
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${otherHtml}</div>`;
  },
  getRoomList:function(form){
    var _this = this;
    var p = new Promise((resovle,reject)=>{
      parent.ajaxService.doGet('/redPacket/roomList.mvc',{tenantCode:parent.globalAdmin.tenantCode},function(res){
        if(res.resultCode ==0){
          var data = res.results[0];
          if(data.length !=0){
            _this.roomList = data;
            _this.renderHtml('#layui-roomList',data);
            form.render('select');
            resovle(data);
          }else{
            layer.msg('房间不存在!')
          }
        }else{
          layer.msg(res.resultMessage);
        }
      })
    })
    return p
  },
  renderHtml(ele,data){
    var html='';
    data.forEach((v,k)=>{
      html+=`<option value="${v.roomId}">${v.customerName}</option>`
      Object.assign(this.roomObj,{[v.roomId]:v.customerName})
    })
    $(ele).append(html);
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getVipRang(str){ //转换提款信息
    var arr=[];
    var temp = str && str.split(",");
    var _this = this;
    temp && temp.forEach(function(v,k){
      arr.push(_this.roomObj[v])
    })
    return arr.join()
  },
  getOptions:function(util){
    var _this = this;
    var arr=[
      { title: '操作',fixed: 'left', width: 180,toolbar: '#barDemo'}
      , { field: 'packetType', title: '活动类型', width: 110, sort: true}
      , { field: 'title', title: '红包标题', width: 140,sort: true}
      , { field: 'userRange', title: '会员范围', width: 280, sort: true,templet:function(d){return _this.getVipRang(d.userRange)}}
      , { field: 'amount', title: '发送总额', width: 110, sort: true,templet:function(d){return d.amount.toFixed(2)}}
      , { field: 'total', title: '发送个数', width: 110, sort: true}
      , { field: 'multiple', title: '打码额(%)', width: 110, sort: true}
      , { field: 'status', title: '发放状态', width: 110, sort: true,templet:function(d){return d.status == 1 ? '已发放' : '待发放'}}
      , { field: 'failureTime', title: '失效时间', width: 120, sort: true,templet:function(d){return d.failureTime+'分钟'}}
      , { field: 'time', title: '最近更新', width: 160, sort: true,templet:function(d){return util.toDateString(d.time, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'operator', title: '更新人', width: 120, sort: true}
      , { field: 'note', title: '备注', sort: true}
    ]
    return arr
  },
  editIdArr:[],
  tableData:[],
  editAlert(title,data,form){
    var isAdd = title == '新增' ? 1 : 0;
    var _this = this;
    layer.open({
      title:title,
      type: 1,
      skin: 'layui-layer-test',
      area: ['800px', '680px'],
      content: htmlTpl.addHtml,
      success:function(){
        var obj={
          "title": isAdd ? '' :data.title,
          "amount": isAdd ? '' :data.amount,
          "total":isAdd ? '' :data.total,
          "note":isAdd ? '' :data.note,
          "limitIp":isAdd ? '' :data.limitIp,
          "failureTime":isAdd ? '' :data.failureTime,
          "multiple":isAdd ? '' :data.multiple
        }
        
        var html='';
        _this.roomList.forEach((v,k)=>{
          html +=`<input type="checkbox" name="userRange[${v.roomId}]" title="${v.customerName}" value="${v.roomId}" lay-skin="primary" class="layui-range">`
        })
        $('.checkbox-list').append(html);

        isAdd && _this.roomList.forEach(v=>{
          Object.assign(obj,{['userRange['+v.roomId+']']:true})
        })
        !isAdd && data.userRange.split(',').forEach(function(v,k){
          Object.assign(obj,{['userRange['+v+']']:true})
        })
        !isAdd && data.requirements.split(',').forEach(function(v,k){
          Object.assign(obj,{['requirements['+v+']']:true})
        })
        !isAdd && data.status && $('button[lay-filter="formAdd"]').addClass('layui-btn-disabled layui-btn-primary');
        !isAdd && data.userRange == 0 && ($('.layui-range').prop('disabled',true));
        !isAdd && data.status == 1 && ($('.mask-box .layui-input,.layui-textarea').addClass('layui-btn-view'),$('.layui-form-item:last-child').remove(),$('.mask-box input[type="checkbox"],.mask-box input[type="radio"]').prop('disabled',true));
        form.val('add',obj)
        form.render(null,'add');
        form.on('checkbox(add)', function(data){
          var checked = data.elem.checked;
          $('.fanwei-list input:not([name="userRange[0]"])').prop('disabled',checked ? true :false );
          checked && $('.layui-range').prop('checked',false);
          form.render('checkbox');
        })
        form.on('submit(formAdd)',function(submitData){
          $('button[lay-filter="formAdd"]').addClass('layui-btn-disabled').html('提交中');
          var reqUrl = isAdd ? '/redPacket/insert.mvc' : '/redPacket/update.mvc';
          var fieldData = submitData.field;
          var requirementsArr=[],userRangeArr=[];
          for(var i in fieldData){
            if(i.indexOf("userRange")>-1){
              userRangeArr.push(fieldData[i])
            }
            if(i.indexOf("requirements")>-1){
              requirementsArr.push(fieldData[i])
            }
          }
          var reqData={
            title:fieldData.title,
            amount:fieldData.amount,
            total:fieldData.total,
            note:fieldData.note,
            userRange:userRangeArr.includes('0') ? 0 : userRangeArr.join(),
            requirements:requirementsArr.join(),
            limitIp:fieldData.limitIp,
            failureTime:fieldData.failureTime,
            multiple:fieldData.multiple
          }
          if(userRangeArr.length ==0){
            layer.msg('请至少选择一个会员范围!')
            return false
          }
          var reqData = isAdd ? reqData : Object.assign(reqData,{id:data.id});
          parent.ajaxService.doPost(reqUrl,reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              userCenterRedSet.layerCallback(msg);
            }else{
              layer.msg(msg)
            }
          })
          return false;
        })
      }
    })
  }
}

userCenterRedSet.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  userCenterRedSet.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  
  var topHeight = ~~($(".layui-row").height()+40);
  var startDate = `${new Date().getFullYear()}-01-01`;
  var endDate = util.toDateString(new Date().getTime()+1000*60*60*24,'yyyy-MM-dd'); 
  userCenterRedSet.getRoomList(form).then((roomData)=>{
    userCenterRedSet.table.render({
      elem: '#demo'
      , height: `full-${topHeight}`
      , url: '/redPacket/list.mvc'
      , toolbar: userCenterRedSet.toolbarHtml
      , defaultToolbar:[]
      , page: true
      , method: 'get'
      , cols: [ userCenterRedSet.getOptions(util)],
      where: {
        status:'-1'
      }
      , parseData: function (res) {
        var data = res.results[0]
        var result = {
          "code": res.resultCode, 
          "msg": res.resultMessage,
          "count": data.total,
          "data": data.list
        };
        userCenterRedSet.tableData=data;
        return result
      },
      response: {
        statusCode: '0'
      },
      done: function (res, cur, count) {
        userCenterRedSet.pageNumber = cur;
      }
    });

  })
  
  // 工具栏操作
  userCenterRedSet.table.on("toolbar(demo)",function(res){
    var checkStatus = userCenterRedSet.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    switch (res.event) {
      case '新增':
        userCenterRedSet.editAlert(res.event,data,form)
      break;
    }
  })
  //监听行工具事件
  userCenterRedSet.table.on('tool(demo)', function(obj){
    var data = obj.data;
    var event = obj.event;
    if(event ==='set'){
      var txt = data.status ==0 ? '修改' : '查看'
      userCenterRedSet.editAlert(txt,data,form)
    }else if(event ==='del'){
      layer.confirm("是否删除选中?",{
          btn:['确定','取消']
        },function(){
        var reqData = {
          id:data.id
        }
        $('.layui-layer-btn0').addClass('layui-btn-disabled').html('提交中');
        parent.ajaxService.doPost("/redPacket/remove.mvc",reqData,function(res){
          var msg = res.resultMessage;
          if(res.resultCode ==0){
            userCenterRedSet.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(event ==='send'){
      data.status==0 && layer.confirm("是否发红包?",{
          btn:['确定','取消']
        },function(){
        var reqData = {
          id:data.id,
          room:data.userRange
        }
        $('.layui-layer-btn0').addClass('layui-btn-disabled').html('提交中');
        parent.ajaxService.doPost("/redPacket/send.mvc",reqData,function(res){
          var msg = res.resultMessage;
          if(res.resultCode ==0){
            userCenterRedSet.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    userCenterRedSet.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



