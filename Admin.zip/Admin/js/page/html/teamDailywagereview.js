
var teamDailywagereview = {
  table:null,
  toolbarHtml:'',
  hasSet:false,
  hasReview:false,
  typeObj:{},
  pageNumber:1,
  getToolbarHtml(){ 
    var action = window.name;
    var permision = parent.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    var obj = {
      '修改':'hasSet',
      '审核':'hasReview'
    }
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        this[obj[i]]=true;
      })
    }
  },
  reloadTable:function(){
    var _this=this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  getGameType(){//账变类型及细类
    var _this = this;
    parent.ajaxService.doGet("/dividendWage/gameType.mvc",null,function(res){
      if(res.resultCode == 0){
        _this.typeObj = res.results[0];
        _this.renderHtml(_this.typeObj,'gametype');
      }
    })
  },
  renderHtml(data,ele){
    var html='';
    for(var i in data){
      html+=`<option value="${i}">${data[i]}</option>`
    }
    $(`.${ele}`).append(html);
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var arr=[
      {title:'操作',width:'130',toolbar:'#barDemo'}
      , { field: 'status', title: '状态', width: 140, sort: true,templet:function(d){return d.status == 1 ? '已审核' : '未审核'}}
      , { field: 'agentusername', title: '上级', width: 180, sort: true}
      , { field: 'username', title: '用户账号', width: 140, sort: true}
      , { field: 'reportdate', title: '期次', width: 140, sort: true}
      , { field: 'type', title: '类型', width: 140, sort: true,templet:function(d){return d.type == 1 ? '日工资' : '分红'}}
      , { field: 'gametype', title: '游戏类型', width: 140, sort: true,templet:function(d){return teamDailywagereview.typeObj[d.gametype]}}
      , { field: 'betorloss', title: '盈亏/日量', width: 140, sort: true}
      , { field: 'amout', title: '分红/日工资', width: 140, sort: true}
      , { field: 'lastoperator', title: '最后操作人', width: 140, sort: true}
      , { title: '操作时间', sort: true,width: 200,templet:function(d){return util.toDateString(d.lastoperationtime, "yyyy-MM-dd HH:mm:ss")}}
    ]
    return arr
  },
  editIdArr:[],
  tableData:[]
}

teamDailywagereview.getToolbarHtml();
teamDailywagereview.getGameType();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  teamDailywagereview.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  globalAdmin.renderIntDate(laydate,util);

  teamDailywagereview.table.render({
    elem: '#demo'
    , height: 600
    , url: '/dividendWage/getDWVerifys.mvc'
    , page: true
    , method: 'get'
    , cols: [teamDailywagereview.getOptions(util)],
    where: {
      type:-1,
      status:-1,
      gametype:-1
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results[0]
      };
      teamDailywagereview.tableData=res.results;
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      teamDailywagereview.pageNumber=cur;
    }
  });
  
  //监听行工具事件
  teamDailywagereview.table.on('tool(demo)', function(obj){
    var data = obj.data;
    if(obj.event === 'set'){
      layer.open({
        title:'修改',
        type: 1,
        skin: 'layui-layer-test',
        area: ['600px', '240px'],
        content: htmlTpl.setHtml,
        success:function(){
          var obj={
            "username": data.username,
            "amout": data.amout,
          }
          form.val('set', obj);
          form.on('submit(formSet)',function(submitData){
            var reqData = Object.assign(submitData.field,{id:data.id});
            parent.ajaxService.doPost('/dividendWage/updateDMVAmout.mvc',reqData,function(res){
              var msg = res.resultMessage;
              if(res.resultCode==0){
                teamDailywagereview.layerCallback(msg);
              }else{
                layer.msg(msg)
              }
            })
            return false;
          })
        }
      })
    }else if(obj.event =='review'){
      layer.confirm(`是否有对派发金额进行仔细核对?`, function(index){
        var reqData= {
          'id':data.id
        }
        parent.ajaxService.doPost('/dividendWage/sendAmout.mvc',reqData,function(res){
          var msg = res.resultMessage;
          if(res.resultCode == 0 ){
            teamDailywagereview.layerCallback(msg);
          }else{
            layer.alert(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    teamDailywagereview.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



