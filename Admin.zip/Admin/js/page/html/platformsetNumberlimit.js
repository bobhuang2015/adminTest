
var platformsetNumberlimit = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  getToolbarHtml(){ 
    var action = window.name;
    var permision = parent.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i !='解锁' && i!='增加'){
          editHtml +='<button id="'+i+'" class="layui-btn layui-btn-disabled" lay-event="'+i+'">'+i+'</button>'
        }
        if(i=='解锁'){
          this.hasLock=true;
        }
        if(i=='增加'){
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${editHtml}<div style="display:inline-block;margin-left:10px;">${otherHtml}</div></div>`;
  },
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1  
      }
	  })
  },
  gameTypeObj:{},
  getGameType(){
    var _this = this;
    parent.ajaxService.doGet("/cache/getGameTypeMap.mvc",null,function(res){
      if(res.resultCode==0){
        var html="";
        _this.gameTypeObj=res.results;
        res.results.forEach((v,k)=>{
          html+=`<option value='${v.id}'>${v.name}</option>`
        })
        $("#gameType").append(html);
      }
    })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  formatStatus(status){
    var obj={
      "0":'启用',
      "1":'禁用'
    }
    return obj[status];
  },
  getOptions:function(util){
    var arr=[
      {type:'checkbox',width:80}
      ,{ title: '操作', width: 140}
      , { field: 'gametypename', title: '游戏类型', width: 140,sort: true}
      , { field: 'issueNo', title: '当前期号', width: 140,sort: true}
      , { field: 'opentime', title: '开盘时间', width: 180,sort: true,templet:function(d){return util.toDateString(d.opentime, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'closetime', title: '封盘时间', width: 180,sort: true,templet:function(d){return util.toDateString(d.closetime, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'nums', title: '号码', width: 120,sort: true}
      , { field: 'betmoneylimit', title: '号码限额', width: 140,sort: true}
      , { field: 'betmoneytotal', title: '投注总额', width: 140,sort: true}
      , { field: 'enabled', title: '额度状态', width: 100,sort: true,templet:function(d){return platformsetNumberlimit.formatStatus(d.enabled)}}
      , { field: 'numenabled', title: '号码状态', width: 100,sort: true,templet:function(d){return platformsetNumberlimit.formatStatus(d.numenabled)}}
    ]
    return arr
  },
  editIdArr:[],
  tableData:[]
}

// platformsetNumberlimit.getToolbarHtml();
platformsetNumberlimit.getGameType();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  platformsetNumberlimit.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  platformsetNumberlimit.table.render({
    elem: '#demo'
    , height: 600
    , url: '/betMoneyLimit/search.mvc'
    ,toolbar: platformsetNumberlimit.toolbarHtml
    , page: true
    , method: 'get'
    , cols: [ platformsetNumberlimit.getOptions(util)],
    where: {
      // startDate: ''
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results
      };
      platformsetNumberlimit.tableData=res.results;
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
    }
  });
  parent.globalAdmin.checkboxEdit(platformsetNumberlimit,window.name)
  
  // 工具栏操作
  platformsetNumberlimit.table.on("toolbar(demo)",function(res){
    var checkStatus = platformsetNumberlimit.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    switch (res.event) {
      case '增加':
      case '修改':
        var isAdd = res.event == '增加' ? 1 : 0;
        layer.open({
          title:res.event,
          type: 1,
          skin: 'layui-layer-test',
          area: ['600px', '400px'],
          content: htmlTpl.addHtml,
          success:function(){
            var obj={
              "username": isAdd ? '' :data[0].username,
              "bankname": isAdd ? '' :data[0].bankname,
              "branchname":isAdd ? '' :data[0].branchname,
              "accountname":isAdd ? '' :data[0].accountname,
              "accountno":isAdd ? '' :data[0].accountno
            }
            form.val('add', obj)
            form.on('submit(formAdd)',function(submitData){
              var reqUrl = isAdd ? '/platformsetNumberlimit/addplatformsetNumberlimit.mvc' : '/platformsetNumberlimit/updateplatformsetNumberlimit.mvc';
              var reqData = isAdd ? submitData.field : Object.assign(submitData.field,{id:data[0].id,userid:data[0].userid});
              parent.ajaxService.doPost(reqUrl,reqData,function(res){
                var msg = res.resultMessage;
                if(res.resultCode==0){
                  platformsetNumberlimit.layerCallback(msg);
                  platformsetNumberlimit.editIdArr=[];
                }else{
                  layer.msg(msg)
                }
              })
              return false;
            })
          }
        })
      break;
      case '删除':
        layer.confirm("是否删除选中的银行?",{
            btn:['确定','取消']
          },function(){
          var reqData = {
            id:platformsetNumberlimit.editIdArr.join()
          }
          parent.ajaxService.doPost("/platformsetNumberlimit/deleteplatformsetNumberlimit.mvc",reqData,function(res){
            if(res.resultCode ==0){
              platformsetNumberlimit.layerCallback(res.resultMessage);
              platformsetNumberlimit.editIdArr=[];
            }else{
              layer.msg(res.resultMessage);
            }
          })
          },function(index){
            layer.close(index)
          }
        )
      break;
      default:
        // layer.msg("接口文档未完善，需要相应人员支持!")
        break;
    }
  })
  //监听行工具事件
  platformsetNumberlimit.table.on('tool(demo)', function(obj){
    var data = obj.data;
    if(obj.event === 'lock'){
      var text = data.locked==0 ? '锁定' : '解锁'; 
      layer.confirm(`是否${text}账号 ${data.username}?`, function(index){
        var reqData={
          userid:data.userid,
          locked:data.locked
        }
        parent.ajaxService.doPost("/platformsetNumberlimit/updateplatformsetNumberlimitState.mvc",reqData,function(res){
          if(res.resultCode ==0){
            platformsetNumberlimit.layerCallback(res.resultMessage);
          }else{
            layer.msg(res.resultMessage);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    platformsetNumberlimit.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
  laydate.render({
    elem: '#start' 
  });
  laydate.render({
    elem: '#end' 
  });
});



