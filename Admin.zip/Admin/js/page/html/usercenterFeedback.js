
var usercenterFeedback = {
  table:null,
  toolbarHtml:'',
  pageNumber:1,
  getToolbarHtml(){ 
    var action = window.name;
    var permision = parent.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        otherHtml +='<a class="layui-btn layui-btn-operator" lay-event="'+i+'">'+i+'</a>'
      })
    }
    this.toolbarHtml =`<div>${otherHtml}</div>`;
  },
  reloadTable:function(){
    var _this = this
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },  
  getOptions:function(util){
    var _this = this;
    var arr=[
      { field: 'content', title: '意见内容', width: 380,sort: true}
      , { field: 'parem1', title: '回馈内容', width: 380,sort: true}
      , { field: 'username', title: '用户', width: 130, sort: true}
      , { field: 'parem2', title: '回馈人', width: 130, sort: true}
      , { field:'opiniondate',title: '提交时间', width: 180, sort: true,templet:function(d){return util.toDateString(d.opiniondate,'yyyy-MM-dd')}}
      , {title:'操作',toolbar:this.toolbarHtml}
    ]
    return arr
  },
}

usercenterFeedback.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  usercenterFeedback.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  
  var topHeight = ~~($(".layui-row").height()+40);
  usercenterFeedback.table.render({
    elem: '#demo'
    , height: `full-${topHeight}`
    , url: '/userInfo/getOpinionList.mvc'
    , page: true
    , method: 'get'
    , cols: [ usercenterFeedback.getOptions(util)],
    where: {
      // startDate: ''
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results[0]
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      usercenterFeedback.pageNumber = cur;
    }
  });
  
  // 工具栏操作
  usercenterFeedback.table.on("toolbar(demo)",function(res){
    var checkStatus = usercenterFeedback.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    switch (res.event) {
      case '增加':
      case '修改':
        var isAdd = res.event == '增加' ? 1 : 0;
        layer.open({
          title:res.event,
          type: 1,
          skin: 'layui-layer-test',
          area: ['600px', '400px'],
          content: htmlTpl.addHtml,
          success:function(){
            var obj={
              "username": isAdd ? '' :data[0].username,
              "bankname": isAdd ? '' :data[0].bankname,
              "branchname":isAdd ? '' :data[0].branchname,
              "accountname":isAdd ? '' :data[0].accountname,
              "accountno":isAdd ? '' :data[0].accountno
            }
            form.val('add', obj)
            form.on('submit(formAdd)',function(submitData){
              var reqUrl = isAdd ? '/usercenterFeedback/addusercenterFeedback.mvc' : '/usercenterFeedback/updateusercenterFeedback.mvc';
              var reqData = isAdd ? submitData.field : Object.assign(submitData.field,{id:data[0].id,userid:data[0].userid});
              parent.ajaxService.doPost(reqUrl,reqData,function(res){
                var msg = res.resultMessage;
                if(res.resultCode==0){
                  usercenterFeedback.layerCallback(msg);
                  usercenterFeedback.editIdArr=[];
                }else{
                  layer.msg(msg)
                }
              })
              return false;
            })
          }
        })
      break;
      case '删除':
        layer.confirm("是否删除选中的银行?",{
            btn:['确定','取消']
          },function(){
          var reqData = {
            id:usercenterFeedback.editIdArr.join()
          }
          parent.ajaxService.doPost("/usercenterFeedback/deleteusercenterFeedback.mvc",reqData,function(res){
            if(res.resultCode ==0){
              usercenterFeedback.layerCallback(res.resultMessage);
              usercenterFeedback.editIdArr=[];
            }else{
              layer.msg(res.resultMessage);
            }
          })
          },function(index){
            layer.close(index)
          }
        )
      break;
      default:
        // layer.msg("接口文档未完善，需要相应人员支持!")
        break;
    }
  })
  //监听行工具事件
  usercenterFeedback.table.on('tool(demo)', function(obj){
    var data = obj.data;
    if(obj.event === '回馈用户'){
      layer.open({
        title:obj.event,
        type: 1,
        skin: 'layui-layer-test',
        area: ['600px', '500px'],
        content: htmlTpl.addHtml,
        success:function(){
          var obj={
            "username": data.username,
            "parem1": data.parem1
          }
          form.val('add', obj)
          form.on('submit(formAdd)',function(submitData){
            var reqData = Object.assign(submitData.field,{id:data.id,userid:data.userid});
            parent.ajaxService.doPost('/userInfo/sengOpinionMsg.mvc',reqData,function(res){
              var msg = res.resultMessage;
              if(res.resultCode==0){
                usercenterFeedback.layerCallback(msg);
              }else{
                layer.msg(msg)
              }
            })
            return false;
          })
        }
      })
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    usercenterFeedback.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
  laydate.render({
    elem: '#start',
    value:new Date()
  });
  laydate.render({
    elem: '#end',
    value: new Date(new Date().getTime() + 1000*60*60*24)
  });
});



