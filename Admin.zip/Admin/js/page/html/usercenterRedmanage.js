
var usercenterRedmanage = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  getToolbarHtml(){ 
    var action = window.name;
    var permision = parent.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i !='解锁' && i!='增加'){
          editHtml +='<button id="'+i+'" class="layui-btn layui-btn-disabled" lay-event="'+i+'">'+i+'</button>'
        }
        if(i=='解锁'){
          this.hasLock=true;
        }
        if(i=='增加'){
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${editHtml}<div style="display:inline-block;margin-left:10px;">${otherHtml}</div></div>`;
  },
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1  
      }
	  })
  },
  getShopList:function(){
    parent.ajaxService.doGet("/userLevel/listAllEnabled.mvc",null,function(res){
      if(res.resultCode==0){
        var data = res.results
        var html='';
        data.forEach(function(v,k){
          html+=`<option value="${v.id}">${v.bankname}-${v.accountname}</option>`
        })
        $("#account").append(html);
      }
    })
  },
  getStatus:function(status){
    var obj={
      '0':'未处理',
      '1':'已通过',
      '2':'已拒绝',
      '3':'充值成功',
      '4':'充值失败',
    }
    return obj[status]
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util,type){
    var arr=[];
    if(type=='send'){
      arr=[
        { field: 'username', title: '发送者', width: 120,sort: true}
        , { field: 'money', title: '发送金额', width: 140, sort: true,templet:function(d){return d.money.toFixed(3)}}
        , { field: 'getmoney', title: '已领取金额', width: 160, sort: true,templet:function(d){return d.getmoney.toFixed(3)}}
        , { field: 'fsmath', title: '发送个数', width: 160, sort: true}
        , { field: 'getmath', title: '已领取个数', width: 160, sort: true}
        , { field: 'createtime', title: '发送时间', width: 180, sort: true}
        , { field: 'text', title: '标题内容', width: 180, sort: true}
        , { field: 'moneysz', title: '红包详情', width: 220, sort: true}
        , { field: 'remark', title: '备注'}
      ]
    }else if(type=='receive'){
      arr=[
        { field: 'username', title: '领取者', width: 180, sort: true}
        , { field: 'money', title: '领取金额', width: 180, sort: true}
        , { field: 'hqtime', title: '领取时间', sort: true}
      ]
    }
    return arr
  },
  editIdArr:[],
  tableData:[]
}

// usercenterRedmanage.getToolbarHtml();
usercenterRedmanage.getShopList();
layui.use(['laydate', 'table', 'form', 'layer','util','element'], function () {
  var laydate = layui.laydate;
  usercenterRedmanage.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;

  var element = layui.element;
  var isReceive=0;
  var isReport = 0;
  form.render("select",'senForm');
  usercenterRedmanage.table.render(getOptions('send','/hongbao/hbsendlist.mvc'))

  element.on('tab(table_box)', function (data) {
    $(document).resize()
    if( data.index == 1 && !isReceive){
      isReceive=!0;
      usercenterRedmanage.table.render(getOptions('receive','/hongbao/hblqrecordlist.mvc'));
      parent.globalAdmin.renderRechargeDate(laydate, util, 'receive')
      submitTable('receive');
    }
  });

  function getOptions(id,reqUrl){
    var obj={
      elem: `#${id}`
      , height: 600
      , url: `${reqUrl}` 
      , page: true
      , method: 'get'
      , cols: [usercenterRedmanage.getOptions(util,id)],
      where: {
        t:(new Date()).valueOf()
      }
      , parseData: function (res) {
        var result = {
          "code": res.resultCode, 
          "msg": res.resultMessage,
          "count": res.meta.totalRecord,
          "data": Array.isArray(res.results[0]) ? res.results[0] : res.results
        };
        return result
      },
      response: {
        statusCode: '0'
      },
      done: function (res, cur, count) {
      }
    }
    if(id=='report'){
      Object.assign(obj.where,{'bankType':1});
    }
    return obj
  }
  submitTable('send');
  parent.globalAdmin.renderRechargeDate(laydate, util, 'send')


  function submitTable(id){
    form.on('submit(form'+id+')', function (data) {
      usercenterRedmanage.table.reload(`${id}`,{
          where:data.field,
          page:{
              curr:1  
          }
      })
      return false;
    });
  }
});



