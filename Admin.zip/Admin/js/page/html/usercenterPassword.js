
var usercenterPassword = {
  initName(){
    document.getElementById("myInput").innerText=parent.globalAdmin.baseInfo.account
  }
}
usercenterPassword.initName();
layui.use(['form', 'layer'], function () {
  var form = layui.form;
  var layer = layui.layer;
  
  form.on('submit(formDemo)', function (data) {
    var obj = Object.assign(data.field,{id:parent.globalAdmin.baseInfo.id});
    parent.ajaxService.doPost("/kjmanager/changepassword.mvc",obj,function(res){
      if(res.resultCode==0){
        layer.msg("修改成功！");
        form.val("test",{
          'password':'',
          'newpassword':'',
          'renewpassword':'',
        })
      }else{
        layer.msg(res.resultMessage)
      }
    })
    return false;
  });

  // document.getElementById("resetButton").onclick = function(){
  //   var myInput = document.getElementById("myInput");
  //   myInput.defaultValue = myInput.value;
  //   document.forms[0].reset()
  // }
});



