layui.use('element', function(){
  element = layui.element;
  tab = {
    tabAdd: function(title, url, id) {
      //新增一个Tab项
      element.tabAdd("xbs_tab", {
        title: title,
        content:'<iframe tab-id="' +id +'" frameborder="0" src="' +url +'" scrolling="no" class="x-iframe" style="width:100%;height:760px;"></iframe>',
        id: id
      });
    },
    tabChange: function(id) {
      //切换到指定Tab项
      element.tabChange("xbs_tab", id); 
    }
  };
});
$("#profitLoss li").click(function(){
  var pageUrl = "./profitloss-platform-"+$(this).attr("data-page")+'.html';
  var name = $(this).text();
  var index = $(this).index();
  $(this).addClass("layui-this").siblings().removeClass("layui-this");
   //触发事件
  //  debugger;
  for (var i = 0; i < $(".x-iframe").length; i++) {
    if ($(".x-iframe").eq(i).attr("tab-id") ==index+1) {
      tab.tabChange(index+1);
      event.stopPropagation();
      return;
    }
  }
  tab.tabAdd(name,pageUrl,index+1);
  tab.tabChange(index+1);
})



