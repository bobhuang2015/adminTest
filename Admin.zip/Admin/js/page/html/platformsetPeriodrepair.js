
var pplatformsetPeriodrepair = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  getToolbarHtml(){ 
    var action = window.name;
    var permision = parent.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i !='解锁' && i!='增加'){
          editHtml +='<button id="'+i+'" class="layui-btn layui-btn-disabled" lay-event="'+i+'">'+i+'</button>'
        }
        if(i=='解锁'){
          this.hasLock=true;
        }
        if(i=='增加'){
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${editHtml}<div style="display:inline-block;margin-left:10px;">${otherHtml}</div></div>`;
  },
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1  
      }
	  })
  },
  thirdTypeObj:{},
  getGametype(){
    var _this = this;
    parent.ajaxService.doGet("/gameType/list.mvc",null,function(res){
      if(res.resultCode==0){
        var html="";
        var data = res.results;
        _this.thirdTypeObj=data;
        data.forEach((v,k)=>{
          html+=`<option value='${v.id}'>${v.name}</option>`
        })
        $("#gameType").append(html);
      }
    })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  formatStatus(status){
    var obj={
      "1":'否',
      "2":'是'
    }
    return obj[status];
  },
}

// pplatformsetPeriodrepair.getToolbarHtml();
pplatformsetPeriodrepair.getGametype();
layui.use(['laydate', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    return false;
  });
  // 日期初始化
  lay('.test-item').each(function(){
    laydate.render({
      elem: this
      ,trigger: 'click'
      ,type: 'datetime'
      ,value:(util.toDateString(new Date().getTime(), "yyyy-MM-dd")+" 00:00:00")
    });
  });
});



