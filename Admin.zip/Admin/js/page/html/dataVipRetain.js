
var dataVipRetain = {
  table:null,
  toolbarHtml:'',
  hasMark:false,
  hasSet:false,
  pageNumber:1,
  type:0,
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){
    var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var obj = {
      '标记完成':'hasMark',
      '修改':'hasSet'
    }
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        this[obj[i]]=true
      })
    }
  },
  reloadTable:function(){
    var _this=this;
    this.table.reload('day',{
      // where:data.field,
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util,type){
    var _this = this;
    switch (type) {
      case 'rank':
          var arr=[
            { fixed: 'left',field: 'username', title: '用户账号', width: 116,templet:function(d){return (d.top ==0 || d.top ==1 || d.top ==2) ? `${d.username}<i class="layui-top"> Top${d.top+1}</i>` : d.username}}
            , { fixed: 'left',field: 'agentUserName', title: '所属上级', width: 100}
            , { fixed: 'left',field: 'floor', title: '层级', width: 80,sort:true,hide:true}
            , { fixed: 'left',field: 'betMoneyTotal', title: '有效投注', width: 120, sort: true,templet:function(d){return globalAdmin.commafy(d.betMoneyTotal.toFixed(2))}}
            , { field: 'winMoneyTotal', title: '中奖总额', width: 120,sort: true,templet:function(d){return globalAdmin.commafy(d.winMoneyTotal.toFixed(2))}}
            , { field: 'payoutRate',title: '派奖率', width: 80,templet:function(d){return (d.payoutRate * 100).toFixed(2)+'%'}}
            , { field: 'profitloss', title: '盈亏', width: 80,sort: true,templet:function(d){return globalAdmin.commafy(d.profitloss.toFixed(2))}}
            , { field: 'killRate',title: '杀率', width: 80,templet:function(d){return (-(d.killRate*100)).toFixed(6)+'%'}}
            , { field: 'inMoneyTotal', title: '总存款', width: 120,sort: true,templet:function(d){return globalAdmin.commafy(d.inMoneyTotal.toFixed(2))}}
            , { field: 'depositRatio', title: '存投比', width: 100,sort: true,templet:function(d){return (d.depositRatio*100).toFixed(6)+'%'}}
            , { field: 'preferential', title: '总优惠', width: 100,sort: true,templet:function(d){return globalAdmin.commafy(d.preferential.toFixed(2))}}
            , { field: 'preferentialPercentage', title: '优惠占比', width: 120,sort: true,templet:function(d){return (d.preferentialPercentage*100).toFixed(6)+'%'}}
            , { field: 'regDt', title: '注册时间', width: 140,sort: true,templet:function(d){return util.toDateString(d.regDt, "yyyy-MM-dd")}}
            , { field: 'lastlogindt', title: '最近来访时间', width: 140,sort: true,templet:function(d){return util.toDateString(d.lastlogindt, "yyyy-MM-dd")}}
            , { field: 'lastGameTime', title: '最近游戏时间', width: 140,sort: true,templet:function(d){return d.lastGameTime ? util.toDateString(d.lastGameTime, "yyyy-MM-dd") : ''}}
            , { field: 'dayTime', title: '未投注天数',sort: true,templet:function(d){return d.dayTime ? (d.warning ? `<span class='red'>${d.notGameDay}</span>` : d.notGameDay) : ''}}
          ]
        break;
      case 'day':
      case 'week':
      case 'month':
          var arr=[
            { field: 'reportDate', title: '注册时间', width: 160,fixed: 'left',}
            , { field: 'newUserTotal', title: '新增人数', width: 120,fixed: 'left',}
          ]
          var tempArr=[];
          var obj = {
            '0':[30,'天'],
            '1':[7,'周'],
            '2':[7,'月']
          }
          var targetCol = obj[_this.type][0];
          var txt = obj[_this.type][1];
          for(var i=1;i<=targetCol;i++){
             var obj={
              title:`${i}${txt}后`,
              width:190,
              templet:`<div>{{ d.day${i} ? '<div class="data-box" data-preview="'+((d.day${i}.allUserCount) ? '1' : '0')+'" data-info="'+d.day${i}.allProportion+'-'+d.day${i}.allUserCount+'-'+d.day${i}.count+'-'+d.day${i}.newProportion+'-'+d.day${i}.newUserCount+'"><span class="blue" style="width:'+d.day${i}.allProportion+'%">'+d.day${i}.allProportion+'%</span><span class="green" style="width:'+d.day${i}.newProportion+'%">'+d.day${i}.newProportion+'%</span></div>' : ""}}</div>`
             };
             tempArr.push(obj)
          }
          arr.push(...tempArr);
          type !='day' && (arr[0].width = 200,delete arr[tempArr.length - 1].width)
      default:
        break;
    }
    return arr
  },
  tableData:[]
}

layui.use(['laydate', 'table', 'form', 'layer','util','element'], function () {
  var laydate = layui.laydate;
  dataVipRetain.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  var element = layui.element;
  var topHeight = ~~($(".layui-row").height()+40);
  parent.globalAdmin.renderRechargeDate(laydate, util)
  parent.globalAdmin.renderRechargeDate(laydate, util,'Bet')

  var isRank=0;
  var isWeek=0;
  var isMonth=0;
  var rankTable = null;
  dataVipRetain.table.render(getOptions('day','/userRetained/dayRetained.mvc'))

  element.on('tab(tab_box)', function (data) {
    $(document).resize()
    if( data.index == 1 && !isRank){
      isRank=!0;
      rankTable=dataVipRetain.table.render(getOptions('rank','/userRetained/getMonthData.mvc'));
      submitTable('rank');
    }
  });
  element.on('tab(tab_box2)', function (data) {
    dataVipRetain.type = data.index;
    if( data.index == 1 && !isWeek){
      isWeek=!0;
      dataVipRetain.table.render(getOptions('week','/userRetained/weekRetained.mvc'));
    }else if(data.index ==2 && !isMonth){
      isMonth=!0;
      dataVipRetain.table.render(getOptions('month','/userRetained/monthRetained.mvc'));
    }
    if(data.index){
      $('.layui-fresh').hide()
    }else{
      $('.layui-fresh').show()
    }
  });

  function getOptions(id,url){
    var obj={
      elem: `#${id}`
      , height: `full-140`
      , url: url
      , method: 'get'
      , cols: [dataVipRetain.getOptions(util,id)]
      , parseData: function (res) {
        if(id=='rank'){
          var data = res.results;
          var rankData = [];
          rankData = data.filter(v=>{return v.betMoneyTotal >0})
          rankData.forEach((v,k)=>{
            v.dayTime = v.lastGameTime
          })
        }else{
          res.results.forEach((v,k)=>{
            var obj={};
            v.dayRetainedVoList.forEach((iv,ik)=>{
              iv.allProportion = (100 * iv.allProportion).toFixed(1);
              iv.newProportion = (100 * iv.newProportion).toFixed(1);
              obj[`day${ik+1}`]=iv;
            })
            Object.assign(v,obj);
            delete v.dayRetainedVoList
          })
        }
        var result = {
          "code": res.resultCode,
          "msg": res.resultMessage,
          "count": res.meta.totalRecord,
          "data": id!='rank' ? res.results : rankData
        };
        return result
      },
      response: {
        statusCode: '0'
      },
      done: function (res, cur, count) {
        dataVipRetain[id]={}
        dataVipRetain[id].pageNumber = cur;
        id=="rank" && (dataVipRetain.tableData = res.data);
        if($('.data-box'))$(".data-box[data-preview='0']").remove()
          // tips事件处理
        var index = 0;
        $(".data-box").mouseenter(function() {
          var data = $(this).attr('data-info').split('-');
          var allProportion = data[0];//占比全体
          var allUserCount = data[1];//全体会员
          var count = data[2];//留存
          var newProportion = data[3];//新增占比
          var newUserCount = data[4];//新增人数
          var divHtml = `<div class='layui-tips-box'><ul><li>留存 : ${count}人</li><li>留存占比 : ${allProportion}%</li><li>新增 : ${newUserCount}人</li><li>新增占比 : ${newProportion}%</li><li>累计会员 : ${allUserCount}人</li></ul></div>`
          index=layer.tips(divHtml, this, {
            tips: [3, "rgba(0,0,0,.9)"],
            time: 40e3
          });
        }).mouseleave(function(){
            layer.close(index);
        })
      }
    }
    id=='rank' && Object.assign(obj,{where:{month:1},page: true})
    return obj
  }


  function submitTable(id){
    form.on('submit(form'+id+')', function (data) {
      var obj = {
          where:data.field,
          page:{
              curr:1
          },
          done: function (res, cur, count) {
          }
      }
      if(id=='rank' && data.field.username){
        Object.assign(obj,{initSort:{field:'floor',type:'asc'}})
      }
      dataVipRetain.table.reload(`${id}`,obj)
      return false;
    });
  }
  // 导出数据;
  $(document).on('click',"#layui-download-month",function(){
    var reqData = {
      username:$('.layui-month-username').val(),
      page:dataVipRetain['rank'].pageNumber,
      limit:rankTable.config.limit,
      startTime:$('#start').val(),
      endTime:$('#end').val(),
      betStartTime:$('#startBet').val(),
      betEndTime:$('#endBet').val(),
    }
    if(dataVipRetain.tableData.length==0){
      layer.msg('当前没有数据导出!')
      return;
    }
    var targetUrl = location.protocol+'//'+location.host+'/userRetained/monthDataDownload.mvc?username='+`${reqData.username}`+'&startTime='+`${reqData.startTime}`+'&endTime='+`${reqData.endTime}`+'&page='+reqData.page+'&limit='+reqData.limit;
    window.open(targetUrl)
  })
  $(document).on('click','.layui-data',function(){
    var reqData = {
      '0':'/userRetained/getDayRetainedDownload.mvc',
      '1':'/userRetained/getWeekRetainedDownload.mvc',
      '2':'/userRetained/getMonthRetainedDownload.mvc',
    }
    var targetUrl = location.protocol+'//'+location.host+reqData[dataVipRetain.type]
    window.open(targetUrl);
  })
  // 刷新日留存
  $(document).on('click','.layui-fresh',function(){
    layer.open({
      title:'选择日期',
      type: 1,
      skin: 'layui-layer-test',
      area: ['400px', '240px'],
      content: htmlTpl.addHtml,
      success:function(){
        laydate.render({
          elem: "#startFresh"
          ,max:-1
          ,min:-30
          ,btns: ["clear", "confirm"]
        });
        form.on('submit(formAdd)',function(submitData){
          parent.ajaxService.doGet('/userRetained/repairRetained.mvc',{date:submitData.field.date},function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              dataVipRetain.layerCallback(msg);
            }else{
              layer.msg(msg)
            }
          })
          return false;
        })
      }
    })
  })
});





