
var setRedis = {
}
layui.use(['form', 'layer'], function () {
  var form = layui.form;
  var layer = layui.layer;
  
  form.on('submit(formDemo)', function (data) {
    var obj = data.field;
    $(".layui-refresh-btn").addClass("layui-btn-disabled");
    parent.ajaxService.doGet("/menu/initStaticData.mvc",obj,function(res){
      layer.msg(res.resultMessage)
      $(".layui-refresh-btn").removeClass("layui-btn-disabled");
    })
    return false;
  });

});



