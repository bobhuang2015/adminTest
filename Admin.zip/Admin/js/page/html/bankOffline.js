
var bankOffline = {
  table:null,
  toolbarHtml:'',
  previewUrl:'',//图片预览地址
  isFirstRender:true,
  hasLock:false,
  hasDel:false,
  // hasTransfer:false,
  rechargeList:[],
  merchantTypeList:[],
  otherBankList:[],
  merchantTypeObj:{},
  pageNumber:1,
  wyObj:{
    name:'',
    code:'',
    type:'wy'
  },
  getToolbarHtml(){
    var action = window.name;
    var permision = parent.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    var obj={
      '修改':'hasSet',
      '禁用/启用':'hasLock',
      // '转移':'hasTransfer',
      '删除':'hasDel'
    }
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i !=='新增'){
          this[obj[i]]=true
        }else{
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${otherHtml}</div>`;//toolbar 跟表格联
  },
  getMerchantType(util){
    var _this = this;
    parent.ajaxService.doGet("/bank/getMerchantType.mvc",{type:2},function(res){
      if(res.resultCode==0){
        var data = res.results[0];
        data.forEach((v,k)=>{
          if(v.type == _this.wyObj.type){
            _this.wyObj.name = v.name;
            _this.wyObj.code = v.code;
          }else{
            _this.otherBankList.push(v);
          }
          Object.assign(_this.merchantTypeObj,{[v.code]:{type:v.type,name:v.name}})
        })
        _this.table.render({
          elem: '#demo'
          , height: 'full-40'
          , url: '/platformBank/list.mvc'
          , toolbar: _this.toolbarHtml
          , defaultToolbar:[]
          , page: true
          , method: 'get'
          , cols: [ _this.getOptions(util)],
          where: {}
          , parseData: function (res) {
            if(_this.isFirstRender){
              var selfBankList = res.results[1];
              if(_this.wyObj.name){
                selfBankList.forEach((v,k)=>{
                  v.type=_this.wyObj.type;
                  v.code=_this.wyObj.code;
                })
                _this.otherBankList.forEach((v,k)=>{
                  selfBankList.push(v)
                })
                _this.merchantTypeList = selfBankList
              }else{
                _this.merchantTypeList = _this.otherBankList;
              }
              _this.isFirstRender = false;
            }
            // _this.selfBankList = res.results[1];
            var result = {
              "code": res.resultCode,
              "msg": res.resultMessage,
              "count": res.meta.totalRecord,
              "data": res.results[0]
            };
            return result
          },
          response: {
            statusCode: '0'
          },
          done: function (res, cur, count) {
            _this.pageNumber=cur;
          }
        });
      }
    })
  },
  getRechargeList(layer){
    var _this = this;
    parent.ajaxService.doGet("/rechargType/list.mvc",{enabled:1},function(res){
      if(res.resultCode==0){
        _this.rechargeList = res.results[0];
      }else{
        layer.msg(res.resultMessage);
      }
    })
  },
  renderData(id,data){
    var html='';
    var _this = this;
    if(id=='merchantType'){
      data.forEach(function(v,k){
        html+=`<option value="${v.type+(v.type=='wy' ? '&'+v.id :'')+'&'+ v.code}" type="${v.type}">${v.type=='wy' ? (v.name +'-'+_this.wyObj.name) :v.name}</option>`
      })
    }else{
      data.forEach(function(v,k){
        html+=`<option value="${v.id}" type="${v.type}">${v.name}</option>`
      })
    }
    $(`.${id}`).append(html);
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  formatType(type){
    var obj={
      "0":'全部',
      "1":'网页端',
      "2":'APP'
    }
    return obj[type]
  },
  getOptions:function(util){
    var _this = this;
    var arr=[
      { field: 'sort', title: '排序', sort: true,width:100}
      , { field: 'payName', title: '支付名称', sort: true,width:180}
      , { field: 'merchantType', title: '商户类型', width: 160, sort: true,templet:function(d){return _this.merchantTypeObj[d.merchantType].name}}
      , { field: 'rechargtypename', title: '支付类别', width: 200,sort: true}
      , { field: 'accountname', title: '户名', width: 120, sort: true}
      , { field: 'accountno', title: '卡号', width: 200, sort: true}
      , { field: 'enabled',title: '状态', width: 80,templet:function(d){return d.enabled ? '启用' : '禁用'}}
      , { field: 'viewtype',title: '显示终端', width: 100, sort: true,templet:function(d){return _this.formatType(d.viewtype)}}
      , { field: 'currentmoney', title: '累积充值', width: 160, sort: true,templet:function(d){return d.currentmoney.toFixed(3)}}
      , { title: '操作', toolbar: '#barDemo'}
    ]
    return arr
  },
  editAlert(isAdd,title,form,data){
    var _this = this;
    layer.open({
      title:title,
      type: 1,
      skin: 'layui-layer-test',
      area: ['620px', '800px'],
      content: htmlTpl.addHtml,
      success:function(){
        if(!isAdd){
          if(!data.bankId){
            $('.layui-card-no label').html('收款卡号');
            $('.layui-card').hide();
            $('.layui-card input').attr('lay-verify','')
            $('.layui-code-box').show();
            data.merchantType = data.type+'&'+data.merchantType
            bankOffline.previewUrl = data.icon ? data.icon : '';
          }else{
            data.merchantType = data.type+'&'+data.bankId+'&'+data.merchantType;
          }
        }
        _this.renderData('merchantType',_this.merchantTypeList);
        _this.renderData('rechargtype',_this.rechargeList);
        form.render("select",'add');
        var obj={
          "payName": isAdd ? '' :data.payName,
          "merchantType": isAdd ? '' :data.merchantType,
          "rechargtype": isAdd ? '' :data.rechargtype,
          "REMARK_TYPE":isAdd ? '' :data.remark_TYPE,
          "ispoint":isAdd ? '' :data.ispoint ? 1 : 0,
          "sort":isAdd ? '' :data.sort,
          "rechargeremark":isAdd ? '' :data.rechargeremark,
          "viewtype":isAdd ? '' :data.viewtype,
          "accountname":isAdd ? '' :data.accountname,
          "accountno":isAdd ? '' :data.accountno,
          "accountnoname":isAdd ? '' :data.accountnoname,
          "rate":isAdd ? '' :data.rate,
          "amountConfig": isAdd ? '' : data.amountConfig,
          "todayGiveMaxMoney": isAdd ? '0' : data.todayGiveMaxMoney || '0',
          "giveDemanRate": isAdd ? '0' : data.giveDemanRate || '0',
          "icon":isAdd ? '' :data.icon
        }
        var index=0;
        form.val('add', obj);
        isAdd ? $('.layui-edit-merchantBox').remove() : ($('.layui-edit-merchantBox input').attr('disabled',true),$('.layui-add-merchantBox').remove(),data.type!='sm' && $('.layui-code-box').remove());
        $("#layui-tips").mouseover(function() {
          index=layer.tips('值为 0 表示不限制', this, {
            tips: [1, "#4794ec"],
            time: 40e3
          });
        }).mouseout(function(){
            layer.close(index);
        })
        form.on('select(merchantType)',function(data){
          //扫码类型才有上传图片;
          var targetType = data.value.split('&')[0];
          if(targetType !='sm'){
            $('.layui-card').show();
            $('.layui-card input').attr('lay-verify','required');
            $('.layui-card input[name=accountno]').attr('lay-verify','required|number');
            $('.layui-code-box').hide();
          }else{
            $('.layui-card-no label').html('收款卡号');
            $('.layui-card').hide();
            $('.layui-card input').attr('lay-verify','');
            $('.layui-code-box').show();//二维码上传图片盒子
          }
        })
        //扫码二维码上传
        var uploadUrl = parent.globalAdmin.uploadInfo.uploadImgUrl+'/file-upload/upload-image';
        bankOffline.upload.render({
          elem: '#layui-upload' //绑定元素
          ,url: uploadUrl //上传接口
          ,choose:function(obj){
            obj.preview(function(index,file,result){//预览图片
            })
          }
          ,before:function(obj){//文件上传前的回调
            layer.load(2)
          }
          ,data:{
            tenantCode:parent.globalAdmin.uploadInfo.tenantCode,
            category:'bank'
          }
          ,done: function(res,index){//上传完毕回调
            layer.closeAll('loading');
            var data = res.data;
            $('.layui-imgurl').val(data);
            bankOffline.previewUrl = data;
          }
          ,error: function(data){//请求异常回调
            layer.closeAll('loading')
          }
          ,size:1024*1
          // ,acceptMime:'.jpg,.png,.svg,.jpeg,.webp'
        })

        $('#layui-preview').on('click',function(){
          if(bankOffline.previewUrl){
            var img = `<img src="${parent.globalAdmin.uploadInfo.viewImgUrl+'/'+bankOffline.previewUrl}" style='width:300px;height:200px;'/>`
            layer.open({
                type: 1,
                title: '图片预览',
                area: ['300px','250px'],
                content: img,
                cancel: function () {
                }
            })
          }else{
            layer.alert('请先上传图片!')
          }
          return false;
        })

        form.on('submit(formAdd)',function(submitData){
          var reqUrl = isAdd ? '/platformBank/add.mvc' : '/platformBank/update.mvc';
          var dataObj = submitData.field;
          var tempArr = dataObj.merchantType.split('&');
          dataObj.merchantType = tempArr[2] ? tempArr[2] : tempArr[1];
          dataObj.type=tempArr[0];
          if(tempArr[0]=='wy'){//网银类型需要bankId
            dataObj.bankId = tempArr[1];
            delete dataObj.icon;
          }else if(tempArr[0]=='sm'){
            if(!bankOffline.previewUrl){
              layer.msg('请上传二维码图片!');
              return false;
            }
          }
          delete dataObj.file;
          var reqData = isAdd ? dataObj : Object.assign(dataObj,{id:data.id});
          reqData.ispoint = reqData.ispoint == '1' ? true : false;
          parent.ajaxService.doPost(reqUrl,reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              bankOffline.layerCallback(msg);
            }else{
              layer.msg(msg)
            }
          })
          return false;
        })
      }
    })
  }
}

bankOffline.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util','upload'], function () {
  var laydate = layui.laydate;
  bankOffline.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  bankOffline.upload = layui.upload;

  bankOffline.getMerchantType(util);
  bankOffline.getRechargeList(layer);

  // 工具栏操作
  bankOffline.table.on("toolbar(demo)",function(res){
    var checkStatus = bankOffline.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    switch (res.event) {
      case '新增':
        bankOffline.previewUrl="";
        bankOffline.editAlert(!0,res.event,form)
      break;
    }
  })
  //监听行工具事件
  bankOffline.table.on('tool(demo)', function(obj){
    var data = obj.data;
    if(obj.event === 'lock'){
      var text = data.enabled ? '禁用' : '启用';
      layer.confirm(`是否${text}?`, function(index){
        var reqData={
          id:data.id,
          enabled:!data.enabled
        }
        parent.ajaxService.doPost("/platformBank/changestate.mvc",reqData,function(res){
          var msg = res.resultMessage
          if(res.resultCode == 0){
            bankOffline.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(obj.event === 'del'){
      layer.confirm(`是否删除?`, function(index){
        var reqData={
          platformBankId:data.id
        }
        parent.ajaxService.doPost("/platformBank/delete.mvc",reqData,function(res){
          var msg = res.resultMessage
          if(res.resultCode == 0){
            bankOffline.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(obj.event === 'transfer'){
      layer.open({
        title:'转移',
        type: 1,
        skin: 'layui-layer-test',
        area: ['620px', '700px'],
        content: htmlTpl.transferHtml,
        success:function(){
          bankOffline.renderData('targetbankname',bankOffline.bankList,!0);
          var obj={
            "sourcebankname":data.bankname,
            "sourcebranchname":data.branchname,
            "sourceaccountname":data.accountname,
            "sourceaccountno":data.accountno,
            "targetbankname":'',
            "targetbranchname":'',
            "targetaccountname":'',
            "targetaccountno":'',
            "money":'',
            "fee":0,
          }
          form.val('transfer', obj)
          form.on('submit(formTrsansfer)',function(submitData){
            var reqData =  submitData.field;
            parent.ajaxService.doPost('/platformBankTransfer/add.mvc',reqData,function(res){
              var msg = res.resultMessage;
              if(res.resultCode==0){
                bankOffline.layerCallback(msg);
              }else{
                layer.msg(msg)
              }
            })
            return false;
          })
        }
      })
    }else if(obj.event === 'set'){
      bankOffline.editAlert(0,'修改',form,data);
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    bankOffline.table.reload('demo',{
        where:data.field,
        page:{
            curr:1
        }
    })
    return false;
  });
});



