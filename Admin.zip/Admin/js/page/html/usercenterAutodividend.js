
var usercenterAutodividend = {
  table:null,
  toolbarHtml:'',
  hasDetail:false,
  pageNumber:1,
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i=='领取详情'){
          this.hasDetail=true;
        }
      })
    }
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  formatMsgtype(type){
    return type==1 ? '用户消息' : '系统消息'
  },
  getOptions:function(util){
    var arr=[
      { title: '操作', width: 100,toolbar:'#barDemo'}
      , { field: 'sendtime', title: '发送时间', width: 180, sort: true,templet:function(d){return util.toDateString(d.sendtime, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'totalmoney', title: '发送总金额', width: 120,sort: true}
      , { field: 'dividendtotalmoney', title: '领取总金额', width: 120,sort: true}
      , { field: 'quantity', title: '数量', width: 100,sort: true}
      , { field: 'avgmaxratio', title: '平均值最大百分比', width: 180,sort: true}
      , { field: 'avgmixratio', title: '平均值最小百分比', width: 180,sort: true}
      , { field: 'allowtime', title: '红包领取允许时间', width: 220,sort: true}
      , { field: 'demandorderamount', title: '打码额', width: 100, sort: true}
      , { field: 'createtime', title: '创建时间', width: 180, sort: true,templet:function(d){return util.toDateString(d.createtime, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'remark', title: '备注', sort: true}
    ]
    return arr
  },
  editIdArr:[],
  tableData:[]
}

usercenterAutodividend.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  usercenterAutodividend.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  globalAdmin.renderIntDate(laydate,util);
  
  var topHeight = ~~($(".layui-row").height()+40);
  usercenterAutodividend.table.render({
    elem: '#demo'
    , height: `full-${topHeight}`
    , url: '/dividendManager/getDividendInfos.mvc'
    , page: true
    , method: 'get'
    , cols: [ usercenterAutodividend.getOptions(util)],
    where: {
      // startDate: ''
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results
      };
      usercenterAutodividend.tableData=res.results;
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      usercenterAutodividend.pageNumber=cur;
    }
  });
  
  //监听行工具事件
  usercenterAutodividend.table.on('tool(demo)', function(obj){
    var data = obj.data;
    if(obj.event === 'detail'){
      parent.globalAdmin.showLayer('领取详情','./html/userCenter-autodividend-table.html?param='+data.id+'','800','600')
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    usercenterAutodividend.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



