// BB、AG可以合并到一起，以后合；5-30
var betBB = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  playTypeArr:[],
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var arr=[
      , { field: 'billNo', title: '投注单号', width: 180, sort: true}
      , { field: 'userName', title: '用户账号', width: 140, sort: true}
      , { title: '投注时间', width:180, sort: true,templet:function(d){return util.toDateString(d.bettime, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'betMoney', title: '投注金额', width: 140, sort: true}
      , { field: 'validBetMoney', title: '有效投注额', width: 140, sort: true}
      , { title: '结算状态', width: 140, sort: true,templet:function(d){return top.globalAdmin.thirdStateObj[d.settleStatus]}}
      , { field: 'profitMoney', title: '投注盈亏', width: '30%', sort: true,minWidth:140}
    ]
    return arr
  },
}

layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  betBB.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  top.globalAdmin.renderIntDate(laydate,util);
  var platformId = parent.$(".layui-this").attr("data-id");

  betBB.table.render({
    elem: '#demo'
    , height: 600
    , url: '/thirdPartyBetRecordsWeb/search.mvc'
    ,toolbar: betBB.toolbarHtml
    , page: true
    , method: 'get'
    , cols: [ betBB.getOptions(util)],
    where: {
      platform:platformId
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results[0]
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
    }
  });
  
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    betBB.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



