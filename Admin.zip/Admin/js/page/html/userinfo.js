  var userInfo = {
    table:null,
    form:null,
    isOnce:true,
    index:1000,
    pageNumber:1,
    tableIns:null,
    name:'userInfo',
    isAll:'1',
    hasDaochu:false,
    globalAdmin:JSON.parse(parent.localStorage.getItem('globalAdmin')),
    renderUserlevel:function(data){//渲染层级下拉框
      var html='';
      data.forEach((v,k)=>html+=`<option value="${v.id}">${v.name}</option>`)
      $(".userLevel").append(html);
    },
    renderRoles:function(data){//渲染角色下拉框
      var html='';
      data.forEach((v,k)=>html+=`<option value="${v.id}">${v.rolename}</option>`)
      $("#role").append(html);
    },
    getTransferpower(str){ //转换提款信息
      var arr=[];
      var temp = str.split(",");
      var obj={
        "0":'-',
        "1":'其他',
        "2":'充值',
        "3":'分红',
        "4":'日工资'
      }
      temp.forEach(function(v,k){
        arr.push(obj[v])
      })
      return arr.join()
    },
    getToolbarHtml(item){ //可操作菜单选项
      var action = globalAdmin.getUrlParam('permision') || window.name ||  globalAdmin.getUrlParam('code');
      var permision = this.globalAdmin.menuObj[action].permision;
      var editHtml = "";
      var _this = this;
      if(permision){
        permision.forEach((v,k)=>{
          var name = v.menuName;
          if(name !== '刷新' && name !== '解锁登录' && name !=='开闭转账' && name !=='激锁用户' && name !=='锁解钱包' && name !='解除设备锁' && name !='导出数据'){
            editHtml +='<li lay-event="'+name+'"><a>'+name+'</a></li>'
          }else if (name === '解锁登录' && (String(item.loginlocked) === '2')) {
            editHtml +='<li lay-event="'+name+'"><a>'+name+'</a></li>'
          }else if(name ==='开闭转账'){
            editHtml +=`<li lay-event="${name}"><a>${item.transferpower != 0 ? '关闭' : '开启'}转账</a></li>`
          }else if(name === '激锁用户'){
            editHtml += `<li lay-event="${name}"><a>${item.userstate == 1 ? '锁定' : '激活'}用户</a></li>`
          }else if(name === '锁解钱包'){
            editHtml +=`<li lay-event="${name}"><a>${item.capitalCenter.state==0 ? '锁定' :'激活'}钱包</a></li>`
          }else if (name === '解除设备锁' && (String(item.loginlocked) === '3')) {
            editHtml +='<li lay-event="'+name+'"><a>'+name+'</a></li>'
          }else if (name=='导出数据'){
            _this.hasDaochu=true;
            $('button[lay-filter="formDaochu"]').show();
          }
        })
        return `<div><div class="layui-btn-dropdown"><button type="button" class="layui-btn layui-btn-xs" data-toggle="dropdown">操作 <span class="layui-icon" style="font-size: 14px"></span></button><ul class="layui-dropdown-menu">${editHtml}</ul></div></div>`
      }else{
       self == parent && ($('body').html(''),layer.alert('您无权操作',function(){
         location.href="../login.html"
       }))
      }
    },
    reloadTable:function(){//layuiTable重载
      var _this = this;
      this.table.reload('demo',{
        page:{
          curr:_this.pageNumber
        }
      })
    },
    layerCallback(msg){//ajax请求回调弹窗
      var _this = this;
      layer.alert(msg,function(){
        layer.closeAll();
        _this.reloadTable();
      })
    },
    formatUsertype(type){//用户类型
      return type==1 ? '代理' : '会员'
    },
    getRoleAndLevel(){
      // this.getToolbarHtml();
      this.renderUserlevel(this.globalAdmin.userLevelArr);
      this.renderRoles(this.globalAdmin.roleidArr);
    },
    getUserLevel(level){
      var localUserLevel =this.globalAdmin.userLevelObj;
      return localUserLevel[level];
    },
    getColor(num){
      return num > 0 ? 'red' : 'green'
    },
    renderThirdHtml(responseData,id){
      var html='';
      for(var i in responseData){
        html+=`<div class="layui-form-item">
                  <label class="layui-form-label">${i.split('Balance')[0]}余额:</label>
                  <div class="layui-input-inline layui-input-amount">${responseData[i]}</div>
                  <div class="layui-btn layui-btn-transfer layui-btn-operator" data-balance="${responseData[i]}" data-type="${i}" data-id="${id}">全部转换</div>
                  <div class="layui-btn layui-btn-transfer layui-btn-amount" data-balance="${responseData[i]}" data-type="${i}"  data-id="${id}">输入金额转换</div>
              </div>`
      }
      return html;
    },
    changeInfoHtml:htmlTpl.changeInfo,//修改信息弹窗模板
    linkHtml:htmlTpl.linkHtml,//注册链接弹窗模板
    transferHtml:htmlTpl.transferHtml,//转换信息弹窗模板
    levelHtml:htmlTpl.levelHtml,//设置层级弹窗模板
    roleHtml:htmlTpl.roleHtml,//设置角色弹窗模板
    thirdStatusHtml:htmlTpl.thirdStatusHtml,//第三方状态模板
    passwordHtml:htmlTpl.passwordHtml,//修改密码弹窗模板
    walletHtml:htmlTpl.walletHtml,//钱包详情弹窗模板
    getOptions:function(util){//layuiTable选项
      var _this = this;
      var arr=[
        {width:52,templet:function(d){return `<i class="iconfont icon-jiahao" data-id="${d.id}"></i>`}}
        , { title: '操作', width: 100, align: 'center', templet:function(a){return _this.getToolbarHtml(a)}}
        , { field: 'username', title: '用户账号', width: 120}
        , { field: 'agentUserName', title: '直属代理', width: 120, sort: true,templet:function(d){return d.agentUserName ? d.agentUserName : ''}}
        , { field: 'regdt', title: '注册时间', width: 160, sort: true,templet:function(d){return util.toDateString(d.regdt, "yyyy-MM-dd HH:mm:ss")}}
        , { field: 'lastlogindt', title: '最近登录时间', width: 160,sort: true,templet:function(d){return util.toDateString(d.lastlogindt ? d.lastlogindt : d.regdt, "yyyy-MM-dd HH:mm:ss")}}
        , { title: '状态', width: 140, templet:'#statusTpl'}
        , { field: 'bonus', title: '返点', width: 120}
        , { field: 'money',title: '钱包中心', width: 120, sort: true,templet:'<div><div class="layui-wallet red" data-userid="{{d.id}}" data-username="{{d.username}}">{{d.money.toFixed(3)}}</div></div>'}
        , { field: 'capitalCenter.moneyinamount',title: '充值金额', width: 100,templet:'<div>{{d.capitalCenter.moneyinamount.toFixed(3)}}</div>' }
        , { field: 'capitalCenter.systemmoneyin',title: '系统充值', width: 120,templet:'<div>{{d.capitalCenter.systemmoneyin}}</div>'}
        , { title: '充值次数', width: 160, sort: true,templet:'<div>{{d.capitalCenter.moneyincount}}</div>' }
        , { title: '日提现次数', width: 120, sort: true ,templet:'<div>{{d.capitalCenter.withdrawdaytimes}}</div>',hide:true}
        , { field: 'outmoneytotal', title: '提现总额',sort:true}
      ]
      return arr
    },
    editIdArr:[],
    tableData:[],
    detailData:{},
    toggleClick(){
      var _this = this;
      $('.layui-table-main table tr').on('click','.iconfont',function(){
        var targetId = $(this).attr('data-id');
        var iconJia = 'icon-jiahao',iconJian = 'icon-jianhao'
        if($(this).hasClass(iconJia)){
          $(this).addClass(iconJian).removeClass(iconJia);
          var targetArr = _this.tableData.filter(v=>{return v.id == targetId});
          _this.detailData = targetArr[0];
          $(this).parents('tr').after('<tr class="detail'+targetId+'"><td colspan="14"><iframe src="./userInfo-detail.html?time='+new Date().getTime()+'" frameborder="0" style="width:95%;padding-left:154px;height:80px;"></iframe></td></tr>')
        }else{
          $(this).addClass(iconJia).removeClass(iconJian);
          $(`tr.detail${targetId}`).remove();
        }
      })
    }
  }
  
  userInfo.getRoleAndLevel();
  
  // 以下都是在layui里边操作，参考layerApi https://www.layui.com/doc/
  layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
    var laydate = layui.laydate;
    userInfo.table = layui.table;
    var form = layui.form;
    var layer = layui.layer;
    var util = layui.util;
    var options =userInfo.getOptions(util);
    var isContentWindow = globalAdmin.getUrlParam('makeLevel') || globalAdmin.getUrlParam('limitUser');
    var topHeight = ~~($(".layui-row").height()+60);
    if(isContentWindow){
      globalAdmin.getUrlParam('makeLevel') && $("#makeLevel").show();
      $("#refresh").hide();
      options.splice(1,1);
      options.unshift({type:'checkbox'});
    }
    form.render();
    //table实例
    userInfo.table.render({
      elem: '#demo'
      , height: `full-${topHeight}`
      , url: '/userInfo/queryList.mvc' //数据接口
      , page: true //开启分页
      , limits: [30, 100,300,500]
      , limit: 30
      // , toolbar:true
      // , defaultToolbar:['filter']
      , method: 'get'
      , cols: [options],
      where: {
      }
      , parseData: function (res) {
        var data = res.results[0] ? res.results[0] : 0;
        data.list.forEach((v,k)=>{
          v.money = v.capitalCenter.accountbalance;
          v.outmoneytotal = v.capitalCenter.outmoneytotal
        })
        var result = {
          "code": res.resultCode, //解析接口状态
          "msg": res.resultMessage, //解析提示文本
          "count": data.total, //解析数据长度
          "data": data.list //解析数据列表
        };
        userInfo.tableData = data.list;
        return result
      },
      response: {
        statusCode: '0' //成功的状态码，默认：0
      },
      done: function (res, cur, count) {
        if(userInfo.isOnce){
          // form.render("select",'test');
          // userInfo.isOnce=false;
        }
        userInfo.pageNumber = cur;
        userInfo.toggleClick();
      }
    });
  
    //监听工具条===编辑信息处理
    userInfo.table.on('tool(demo)', function (obj) { //注：tool是工具条事件名，test是table原始容器的属性 lay-filter="对应的值"
      var data = obj.data , layEvent = obj.event;
      if (layEvent ==='修改信息') {
        layer.open({
          title:'修改信息',
          type: 1,
          skin: 'layui-layer-test',
          area: ['680px', '490px'],
          content: userInfo.changeInfoHtml,
          success:function(){
            form.val('example', {
              "username": data.username,
              "nickname":data.nickname,
              "usertype":data.usertype,
              "bonus":data.bonus,
              "isfollow":data.isfollow,
              "isextends":data.isextends,
              "regMaxbonus":data.regMaxbonus,
              "remark":data.remark,
              "isshare":data.isshare
            })
            form.on('submit(formLayer)',function(submitData){
              var obj = Object.assign(submitData.field,{id:data.id});
              parent.ajaxService.doPost('/userInfo/editBonus.mvc',obj,function(res){
                var msg = res.resultMessage;
                if(res.resultCode==0){
                  userInfo.layerCallback(msg)
                }else{
                  layer.msg(msg)
                }
              })
              return false;
            })
          }
        })
      }else if(layEvent === '联系信息') {
        layer.open({
          title:'联系信息',
          type: 1,
          skin: 'layui-layer-test', 
          area: ['600px', '300px'],
          content:userInfo.linkHtml ,
          success:function(index){
            form.val('contact', {
              "username": data.username,
              "nickname":data.nickname,
              "email":data.email || '',
              "qq":data.qq || '',
              "telephone":data.telephone || '',
              "remark":data.remark || '',
              })
            var reqData = {id:data.id}
            form.on('submit(formLayer)',function(data){
              var obj = Object.assign(data.field,reqData);
              parent.ajaxService.doPost('/userInfo/updateUserLink.mvc',obj,function(res){
                var msg = res.resultMessage;
                if(res.resultCode==0){
                  userInfo.layerCallback(msg);
                }else{
                  layer.msg(msg);
                }
              })
              return false;
            })
          }
        })
      }else if(layEvent ==='锁解钱包') {
        var txt = data.capitalCenter.state==0 ? '锁定' :'解锁'
        layer.confirm("是否"+txt+'钱包',{
            btn:['确定','取消']
          },function(){
          var reqData = {
            userid:data.id
          }
          parent.ajaxService.doPost("/capitalCenter/lock.mvc",reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode ==0){
              userInfo.layerCallback(msg)
            }else{
              layer.msg(msg);
            }
          })
          },function(index){
            layer.close(index)
          }
        )
      }else if(layEvent==='激锁用户'){
        var state = data.userstate;
        var obj = {
          "1":{txt:'锁定',title:'请输入原因',initValue:''},
          "2":{txt:'激活',title:'是否激活',initValue:data.remark}
        }
        layer.confirm('是否'+obj[state].txt+'该用户',{
          btn:['确定','取消']
          },function(){
            layer.prompt({title:obj[state].title , formType: 2, value:obj[state].initValue},function(value,index){
              var reqData = {
                id:data.id,
                remark:value
              }
              parent.ajaxService.doPost("/userInfo/lockUser.mvc",reqData,function(res){
                var msg = res.resultMessage;
                if(res.resultCode==0){
                  userInfo.layerCallback(msg)
                }else{
                  layer.msg(msg);
                }
              })
            })
          },function(index){
            layer.close(index);
          }
        )
      }else if(layEvent==='下线'){
        layer.confirm('是否强制下线该用户',{
            btn:['确定','取消']
          },function(){
            var reqData = {
              id:data.id
            }
            parent.ajaxService.doPost("/userInfo/offline.mvc",reqData,function(res){
              var msg = res.resultMessage;
              if(res.resultCode==0){
                userInfo.layerCallback(msg)
              }else{
                layer.msg(msg);
              }
            })
          },function(index){
            layer.close(index);
        })
      }else if(layEvent==='开闭转账'){
        layer.open({
          title:'转账',
          type: 1,
          skin: 'layui-layer-test',
          area: ['520px', '200px'],
          content: userInfo.transferHtml,
          success:function(){
            var obj={};
            data.transferpower.split(",").forEach(function(v,k){
              if(v){
                Object.assign(obj,{['like['+v+']']:true})
              }
            })
            form.val('transfer',obj);
            form.render('checkbox','transfer')
            var reqData = {id:data.id,transferAccounts:2}
            form.on('submit(formLayer)',function(data){
              var arr = [];
              for(var i in data.field){
                arr.push(data.field[i])
              }
              if(arr.length == 0){
                reqData.transferAccounts=1
                reqData.transferpower=0
              }else{
                reqData.transferpower=arr.join();
              }
              parent.ajaxService.doPost('/userInfo/editTransferAccounts.mvc',reqData,function(res){
                var msg = res.resultMessage;
                if(res.resultCode==0){
                  userInfo.layerCallback(msg);
                }else{
                  layer.msg(msg);
                }
              })
              return false;
            })
          }
        })
      }else if(layEvent ==='层级转移'){
        layer.open({
          title:'层级转移 '+data.username,
          type: 1,
          skin: 'layui-layer-test',
          area: ['500px', 'auto'],
          content: userInfo.levelHtml,
          success:function(){
            userInfo.renderUserlevel(userInfo.globalAdmin.userLevelArr);
            form.render("select",'level');
            form.val('level', {
              "usertype": userInfo.formatUsertype(data.usertype),
              "userlevel":data.userlevel,
              "isteam":0
            })
            form.on('submit(level)',function(submitData){
              var fieldData = submitData.field;
              var reqData = {
                id:data.id,
                usertype:data.usertype,
                userlevel:fieldData.userlevel,
                isteam:fieldData.isteam
              }
              if(data.userlevel == fieldData.userlevel){
                layer.msg("未进行任何层级操作");
                return false;
              }
              parent.ajaxService.doPost('/userInfo/userTransferLevel.mvc',reqData,function(res){
                var msg = res.resultMessage;
                if(res.resultCode==0){
                  userInfo.layerCallback(msg)
                }else{
                  layer.msg(msg)
                }
              })
              return false;
            })
          }
        })
      }else if(layEvent ==='设置角色'){
        layer.open({
          title:'设置角色',
          type: 1,
          skin: 'layui-layer-test',
          area: ['700px', '500px'],
          content: userInfo.roleHtml,
          success:function(){
            var html = '';
            userInfo.globalAdmin.roleidArr.forEach((v,k)=>{
              html +=`<input type="radio" name="role" title="${v.rolename}" value="${v.id}" lay-skin="primary">`
            })
            $(".role-list").html(html);
            var userPermissionId = [];
            parent.ajaxService.doGet("/userInfo/permission.mvc",{userId:data.id},function(res){
              if(res.resultCode==0){
                var roleIds = res.results[0].permissionRoleIds;
                if(roleIds.indexOf(",")>-1){
                  var tempArr=roleIds.split(',');
                  tempArr.forEach((v,k)=>{
                    userPermissionId.push(v)
                  })
                }else{
                  userPermissionId.push(roleIds)
                }
  
                var obj={username:data.username};
                userPermissionId.forEach(function(v,k){
                  $("input[name='role'][value='"+v+"']").prop("checked", "checked");
                  // Object.assign(obj,{[v]:true})
                })
                form.val('role',obj)
                form.render()
              }
            })
            form.on('submit(role)',function(submitData){
              var arr = [];
              for(var i in submitData.field){
                if(i !='username' && i !='usernameQuery'){
                  arr.push(submitData.field[i])
                }
              }
              var reqData = {
                userids: data.id,
                roleIds:arr.join(),
                usernameQuery:submitData.field.usernameQuery
              }
              if(arr.length==0){
                layer.msg("请选择需要转账的权限")
                return;
              }
              parent.ajaxService.doPost('/userInfo/authorizeUser.mvc',reqData,function(res){
                var msg = res.resultMessage;
                if(res.resultCode==0){
                  userInfo.layerCallback(msg);
                }else{
                  layer.msg(msg);
                }
              })
              return false;
            })
          }
        })
      }else if(layEvent ==='第三方状态修改'){
        layer.open({
          title:'第三方状态修改',
          type: 1,
          skin: 'layui-layer-test',
          area: ['700px', '500px'],
          content: userInfo.thirdStatusHtml,
          success:function(){
            function getValue(str){
              return str ? str : '0'
            }
            form.val('thirdStatus', {
              "username": data.username,
              "isBBINState":getValue(data.isBBINState),
              "isAGState":getValue(data.isAGState),
              "isPTState":getValue(data.isPTState),
              "isMGState":getValue(data.isMGState),
              "isLKState":getValue(data.isLKState),
              "isVRState":getValue(data.isVRState),
              "isSBState":getValue(data.isSBState),
              "isXJState":getValue(data.isXJState),
              "isKYState":getValue(data.isKYState),
              "isKXState":getValue(data.isKXState),
              "isBGState":getValue(data.isBGState),
            })
            form.on('submit(thirdStatus)',function(submitData){
              var reqData = submitData.field;
              var obj = Object.assign(reqData,{id:data.id})
              for(var i in obj){
                if (i != 'id' && i !='username'){
                  obj[i]= +obj[i]
                }
              }
              parent.ajaxService.doPost('/userInfo/updateThridStart.mvc',obj,function(res){
                var msg = res.resultMessage;
                if(res.resultCode==0){
                  userInfo.layerCallback(msg)
                }else{
                  layer.msg(msg)
                }
              })
              return false;
            })
          }
        })
      }else if(layEvent ==='修改密码'){
        layer.open({
          title:'修改密码',
          type: 1,
          skin: 'layui-layer-test',
          area: ['600px', '260px'],
          content: userInfo.passwordHtml,
          success:function(){
            form.val('password',{
              "username":data.username,
              "usertype":userInfo.formatUsertype(data.usertype),
              "password":'',
              "moneyPwd":''
            })
            form.on('submit(password)',function(submitData){
              var reqData = Object.assign(submitData.field,{id:data.id});
              reqData.usertype = data.usertype;
              parent.ajaxService.doPost('/userInfo/updatePassword.mvc',reqData,function(res){
                var msg = res.resultMessage;
                if(res.resultCode==0){
                  userInfo.layerCallback(msg)
                }else{
                  layer.msg(msg)
                }
              })
              return false;
            })
          }
        })
      }else if(layEvent ==='提现打码' || layEvent ==='充值记录' || layEvent ==='提现记录' || layEvent ==='用户银行' || layEvent ==='投注记录' || layEvent=='账变明细'){
        var obj = {
          '用户银行':'iframe_14',
          '充值记录':'iframe_24',
          '提现记录':'iframe_25',
          '提现打码':'iframe_29',
          '投注记录':'iframe_32',
          '账变明细':'iframe_38'
        }
        var key = obj[layEvent];
        var openUrl = userInfo.globalAdmin.menuObj[key].page+".html?userName="+data.username+"&code="+key+"";
        var url = "html/"+openUrl;
        var action = userInfo.globalAdmin.menuObj[key].action;
        if(self != parent){
          parent.tab.tabAdd(layEvent, url, userInfo.index,action);
          parent.tab.tabChange( userInfo.index);
          userInfo.index++;
        }else{
          window.open(openUrl);
        }
      }else if(layEvent ==='设置禁用功能'){
        layer.open({
          title:'设置禁用功能',
          type: 1,
          skin: 'layui-layer-test',
          area: ['700px', '500px'],
          content: htmlTpl.setRole,
          success:function(){
          }
          ,btn: ['确定', '取消']
          ,yes:function(index){
            layer.msg("确定按钮")
          }
          ,btn2:function(index){
            layer.msg("我是取消按钮")
          }
        })
      }else if(layEvent ==='解锁登录'){
        layer.confirm('是否解锁登录该用户',{
          btn:['确定','取消']
        },function(){
          var reqData = {
            id:data.id
          }
          parent.ajaxService.doPost("/userInfo/unLockLongin.mvc",reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              userInfo.layerCallback(msg)
            }else{
              layer.msg(msg);
            }
          })
        },function(index){
          layer.close(index);
        })
      }else if(layEvent === '第三方操作'){
        var index = layer.load(2);
        parent.ajaxService.doGet('/userInfo/thirBalancer.mvc',{userid:data.id},function(res){
          if(res.resultCode == 0){
            var responseData = res.results[0];
            layer.open({
              title:'第三方操作',
              type: 1,
              skin: 'layui-layer-test',
              area: ['800px', '600px'],
              content: htmlTpl.thirdChangeHtml,
              success:function(){
                layer.close(index);
                $('.layui-layer-content').css('overflow-y','scroll');
                var html = userInfo.renderThirdHtml(responseData,data.id);
                $('.layui-third-cancle').before(`<div id="layui-third-info">${html}</div>`);
                $('.layui-btn-refreshBalance').attr('data-id',data.id);
                var obj = {
                  username:data.username
                }
                form.val('third',obj);
              }
            })
          }
        })
      }else if(layEvent==='解除设备锁'){
        layer.confirm('是否解除设备锁?',{
            btn:['确定','取消']
          },function(){
            var reqData = {
              id:data.id,
              changeType:false
            }
            parent.ajaxService.doPost("/userInfo/updateLockDevice.mvc",reqData,function(res){
              var msg = res.resultMessage;
              if(res.resultCode==0){
                userInfo.layerCallback(msg)
              }else{
                layer.msg(msg);
              }
            })
          },function(index){
            layer.close(index);
        })
      }
    });
    userInfo.table.on("checkbox(demo)",function(obj){
      if(obj.type == 'all' && obj.checked){
        // 全选
        userInfo.editIdArr=[];
        userInfo.tableData.forEach((v,k)=>{
          userInfo.editIdArr.push(v.username);
        })
      }else if(obj.type =='all' && !obj.checked){
        // 全不选
        userInfo.editIdArr=[];
      }else if(obj.checked && obj.type=='one'){
        // 单选
        userInfo.editIdArr.push(obj.data.username);
      }else if(!obj.checked && obj.type=='one'){
        // 单不选
        var index = userInfo.editIdArr.findIndex((v)=> v== obj.data.username);
        userInfo.editIdArr.splice(index,1);
      }
      top.globalAdmin.limitUserArr= userInfo.editIdArr;
      
    })
    // 表单提交demo
    form.on('submit(formDemo)', function (data) {
      userInfo.table.reload('demo',{
          where:data.field,
          page:{
              curr:1
          }
      })
      return false;
    });
    
    // 导出数据
    form.on('submit(formDaochu)', function (data) {
      if(userInfo.hasDaochu){
        data.field.regLink="";//此输入框暂时屏蔽;
        parent.globalAdmin.exportData(form,data,userInfo)
      }
      return false;
    });
    $(document).on('click',"#makeLevel",function(){
      if(userInfo.editIdArr.length){
        layer.open({
          title:'用户转移层级',
          type: 1,
          skin: 'layui-layer-test',
          area: ['600px', '400px'],
          content: htmlTpl.makeLevelHtml,
          success:function(){
            userInfo.renderUserlevel(userInfo.globalAdmin.userLevelArr);
            form.render("select",'makeLevel');
            form.val('makeLevel', {
              "username": userInfo.editIdArr.join(),
            })
            form.on('submit(makeLevel)',function(submitData){
              var reqData = {
                username:userInfo.editIdArr.join(),
                userlevel:submitData.field.userlevel,
              }
              parent.ajaxService.doPost('/userInfo/makelevel.mvc',reqData,function(res){
                var msg = res.resultMessage;
                if(res.resultCode==0){
                  userInfo.layerCallback(msg);
                  userInfo.editIdArr=[];
                }else{
                  layer.msg(msg)
                }
              })
              return false;
            })
          }
  
        })
      }else{
        layer.msg("请勾选需要分层的用户")
      }
    })
  
    //同时绑定多个日期选择器
    lay('.test-item').each(function(){
      laydate.render({
        elem: this
        ,trigger: 'click'
        ,btns: ['clear', 'confirm']
        ,max:1
      });
    });
    // 钱包详情
    $(document).on('click','.layui-wallet',function(){
      var userid = $(this).attr('data-userid');
      var username = $(this).attr('data-username');
      var index = layer.load(2);
      parent.ajaxService.doGet('/capitalCenter/view.mvc',{userid:userid},function(res){
        if(res.resultCode == 0){
          layer.open({
            title:`钱包详情--用户账号:<span class="red">${username}</span>`,
            type: 1,
            skin: 'layui-layer-test',
            area: ['800px', '600px'],
            content: userInfo.walletHtml,
            success:function(){
              layer.close(index);
              var capitalObj = res.results[0];
              var thirdPlatArr = res.results[1];
              var html=`<tbody>
                          <tr height="25px">
                              <td width="20%" align="left" style="font-size:14px;font-weight:bold;text-align:left;" colspan="4">钱包账户</td>
                          </tr>
                          <tr>
                              <td width="20%" align="right">钱包中心余额</td>
                              <td width="30%" colspan="3"> <span class="blue" style="font-weight:bold;font-size: 18px; ">${capitalObj.accountbalance.toFixed(3)}</span></td>
                          </tr>
                          <tr>
                              <td width="20%" align="right">充值总额</td>
                              <td width="30%">
                                  <font class="${userInfo.getColor(capitalObj.systemmoneyin)}">${capitalObj.systemmoneyin.toFixed(3)} </font> (<a style="cursor: pointer;" title="系统充值总额: ${capitalObj.systemmoneyin.toFixed(3)}">?</a>) </td>
                              <td width="20%" align="right">提现总额</td>
                              <td width="30%">
                                  <font class="${userInfo.getColor(capitalObj.outmoneytotal)}">${capitalObj.outmoneytotal.toFixed(3)} </font>
                              </td>
                          </tr>
                          <tr>
                              <td align="right">上级转入总额</td>
                              <td>
                                  <font class="${userInfo.getColor(capitalObj.transfermoneyintotal)}">${capitalObj.transfermoneyintotal.toFixed(3)}</font>
                              </td>
                              <td align="right">转给下级总额</td>
                              <td>
                                  <font class="${userInfo.getColor(capitalObj.transfermoneyouttotal)}">${capitalObj.transfermoneyouttotal.toFixed(3)}</font>
                              </td>
                          </tr>
                          <tr>
                              <td align="right">游戏转入总额</td>
                              <td>
                                  <font class="${userInfo.getColor(capitalObj.inTotal)}">${capitalObj.inTotal.toFixed(3)}</font> (<a style="cursor: pointer;" title="额度转换返还: ${capitalObj.inTotal.toFixed(3)}">?</a>) </td>
                              <td align="right">转入游戏总额</td>
                              <td>
                                  <font class="${userInfo.getColor(capitalObj.outTotal)}">${capitalObj.outTotal.toFixed(3)} </font>
                              </td>
                          </tr>
                      </tbody>`
              $('.wallet-table').html(html);
              if(thirdPlatArr.length > 0){
                $('.layui-layer-content').css("overflow-y","scroll");
                var thirdHtml ='';
                thirdPlatArr.forEach((v,k)=>{
                  thirdHtml += `<table class="layui-table" lay-size="sm">
                                    <tbody>
                                      <tr height="25px">
                                          <td width="20%" colspan="4" style="font-size:14px;font-weight:bold;text-align:left;">${userInfo.globalAdmin.thirdPlatform[v.platform]}</td>
                                      </tr>
                                      ${v.platform !=10 && v.platform !=11 && v.platform !=12 ?  `<tr><td width="20%" align="right">账户余额</td><td width="30%" colspan="3"> <span class="layui-third-balance" style="font-weight:bold;font-size: 18px; ">--</span><span class="layui-third-refresh" data-type="${v.platform}" data-userid="${userid}" data-username="${username}"><i class="layui-icon layui-icon-refresh"></i>刷新</span></td>
                                      </tr>
                                      <tr>
                                          <td width="20%" align="right">钱包转入</td>
                                          <td width="30%">
                                              <font class="${userInfo.getColor(v.transferInTotal)}">${v.transferInTotal.toFixed(3)} </font></td>
                                          <td width="20%" align="right">转到钱包</td>
                                          <td width="30%">
                                              <font class="${userInfo.getColor(v.transferOutTotal)}">${v.transferOutTotal.toFixed(3)} </font>
                                          </td>
                                      </tr>` : ''}
                                      <tr>
                                          <td align="right" width="20%">投注总额</td>
                                          <td width="30%">
                                              <font class="${userInfo.getColor(v.orderMoneyTotal)}">${v.orderMoneyTotal.toFixed(3)}(<a style="cursor: pointer;" title="投注注数: ${v.orderNumber}">?</a>)</font>
                                          </td>
                                          <td align="right" width="20%">中奖总额</td>
                                          <td width="30%">
                                              <font class="${userInfo.getColor(v.profitlossMoneyTotal + v.orderMoneyTotal)}">${(v.profitlossMoneyTotal + v.orderMoneyTotal).toFixed(3)}</font>
                                          </td>
                                      </tr>
                                      <tr>
                                          <td align="right" width="20%">自身返点</td>
                                          <td width="30%">
                                              <font class="${userInfo.getColor(v.selfBonusMoney)}">${v.selfBonusMoney.toFixed(3)}</font></td>
                                          <td align="right" width="20%">代理返点</td>
                                          <td width="30%">
                                              <font class="${userInfo.getColor(v.agentBonusMoney)}">${v.agentBonusMoney.toFixed(3)} </font>
                                          </td>
                                      </tr>
                                      <tr>
                                          <td align="right" width="20%">投注盈亏总额</td>
                                          <td width="30%">
                                              <font class="${userInfo.getColor(v.profitlossMoneyTotal)}">${v.profitlossMoneyTotal.toFixed(3)}</font></td>
                                          <td align="right" width="20%">实际盈亏总额</td>
                                          <td width="30%">
                                              <font class="${userInfo.getColor(v.profitlossMoneyTotal + v.selfBonusMoney)}">${(v.profitlossMoneyTotal + v.selfBonusMoney).toFixed(3)} </font>
                                          </td>
                                      </tr>
                                    </tbody>
                                  </table>`
  
                })
                $('.layui-form-item').append(thirdHtml);
              }
            }
          })
        }else{
          layer.msg(res.resultMessage)
        }
      })
    })
    // 刷新第三方余额
    $(document).on('click','.layui-third-refresh',function(){
      var userid = $(this).attr('data-userid');
      var type = $(this).attr("data-type");
      var username = $(this).attr("data-username");
      var $thirdBalanceDom = $(this).siblings('.layui-third-balance');
      var reqData={
        userid:userid,
        type:type,
        username:username
      }
      layer.load(2);
      parent.ajaxService.doPost('/capitalCenter/getThirdBalance.mvc',reqData,function(res){
        var msg = res.resultMessage;
        if(res.resultCode == 0){
          $thirdBalanceDom.html(res.results[0].balance.toFixed(3));
        }else{
          layer.msg(msg);
        }
        layer.closeAll('loading');
      })
    })
  });
  // 刷新余额;
  $(document).on('click','.layui-btn-refreshBalance',function(){
    var id = $(this).attr('data-id');
    var index = layer.load(2);
    parent.ajaxService.doGet('/userInfo/thirBalancer.mvc',{userid:id},function(res){
      if(res.resultCode == 0){
        layer.msg('刷新成功!');
        layer.close(index);
        var responseData = res.results[0];
        var html = userInfo.renderThirdHtml(responseData,id);
        $('#layui-third-info').html(html);
      }else{
        layer.msg(res.resultMessage)
      }
    })
  })
  //全部转换
  $(document).on('click','.layui-btn-operator',function(){
    var balance = $(this).attr('data-balance');
    var userid = $(this).attr('data-id');
    var $targetInput = $(this).siblings('.layui-input-amount');
    var $targetAllEle = $(this).siblings('.layui-btn-operator');
    var _this = $(this);
    var reqData = {
      userid:userid,
      balance:'-1',
      type:$(this).attr('data-type')
    }
    if(balance =='未开通' || balance ==0 ){
      layer.msg('该用户未开通或余额为0')
    }else{
      parent.ajaxService.doPost('/userInfo/thirBalancerTransf.mvc',reqData,function(res){
        var msg = res.resultMessage;
        layer.msg(msg);
        var balance = res.results[0].balance;
        $targetInput.text(balance);
        $targetAllEle.attr('data-data-balance',balance);
        _this.attr('data-balance',balance);
      })
    }
  })
  // 输入金额转换
  $(document).on('click','.layui-btn-amount',function(){
    var initValue = $(this).attr('data-balance');
    var userid = $(this).attr('data-id');
    var type = $(this).attr('data-type');
    var $targetInput = $(this).siblings('.layui-input-amount');
    var $targetAllEle = $(this).siblings('.layui-btn-operator');
    var _this = $(this);
    if(initValue && Number(initValue)){
      layer.prompt({title:'请输入转换的金额' , formType: 0, value:initValue,maxlength:8},function(value,index2){
        var reqData = {
          userid:userid,
          balance:value,
          type:type
        }
        var lastValue = +initValue - +value;
        if(lastValue >= 0){
          parent.ajaxService.doPost("userInfo/thirBalancerTransf.mvc",reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              layer.alert('操作成功',function(index3){
                layer.close(index3);
                var balance = res.results[0].balance;
                $targetInput.text(balance);
                $targetAllEle.attr('data-data-balance',balance);
                _this.attr('data-balance',balance);
                layer.close(index2);
              })
            }else{
              layer.msg(msg);
            }
          })
        }else{
          layer.msg('输入金额不能大于原始金额!')
        }
      })
    }else{
      layer.msg('该账号此平台不能转换')
    }
  })
  // 更多选项操作
  parent.globalAdmin.showMore('.layui-second-search-condition',window.name)
