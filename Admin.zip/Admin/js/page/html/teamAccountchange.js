
var teamAccountchange = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  typeObj:{},
  detailObj:{},
  totalData:{},
  getToolbarHtml(){ 
    var action = window.name;
    var permision = parent.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
  },
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1  
      }
	  })
  },
  stateObj:{},
  getStates(){//注单状态
    var _this = this;
    parent.ajaxService.doGet("/getEnumByName.mvc",{enumName:'BetRecord_State'},function(res){
      if(res.resultCode == 0){
        var data = res.results[0];
        _this.stateObj = data;
      }
    })
  },
  getAccountType(form,util,multiSelect){//账变类型及细类
    var _this = this;
    parent.ajaxService.doGet("/bdbProfitLoss/getProfitLossTypeAndSub.mvc",null,function(res){
      if(res.resultCode == 0){
        _this.typeObj = res.results[0];
        _this.detailObj = res.results[1];
        _this.renderHtml(_this.typeObj,'accountType');
        _this.renderHtml(_this.detailObj,'accountDetail');

        multiSelect.render('select','accountType')
        multiSelect.render('select','accountDetail');

        _this.table.render({
          elem: '#demo'
          , height: 'full-80'
          , url: '/bdbProfitLoss/search.mvc'
          , page: true
          , method: 'get'
          , cols: [_this.getOptions(util)],
          where: {
            username:$(".layui-input[name='username']").val(),
            usernameQuery:1
          }
          , parseData: function (res) {
            var resData = res.results.length > 0 &&  res.results[0];
            if(resData && resData.length > 0){
              resData.forEach((v,k,arr)=>{
                arr[k].profitlossmoney = arr[k].profitlossmoney.toFixed(3);
                arr[k].currentavailableamount = arr[k].currentavailableamount.toFixed(3);
                arr[k].pay = v.betmoneytotal - v.winmoney
              })
            }
            var result = {
              "code": res.resultCode, 
              "msg": res.resultMessage,
              "count": res.meta.totalRecord,
              "data": resData,
              "total":res.results[0] && res.results[0].length > 0 && res.results[1]
            };
            return result
          },
          response: {
            statusCode: '0'
          },
          done: function (res, cur, count) {
            _this.getTotalData();
          }
        });
      }
    })
  },
  renderHtml(data,ele){
    var html='';
    for(var i in data){
      html+=`<option value="${i}">${data[i]}</option>`
    }
    $(`.${ele}`).append(html);
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getUrlParam(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); //构造一个含有目标参数的正则表达式对象
    var r = window.location.search.substr(1).match(reg);  //匹配目标参数
    if (r != null) return unescape(r[2]); return null; //返回参数值
  },  
  getOptions:function(util){
    var _this = this;
    var arr=[
        { field: 'ordernumber', title: '订单号', width: 180, sort: true,templet:function(d){return +d.profitlosssubtypeid<=10 ? '<div class="layui-table-ordernumber" lay-event="orderDetail">'+d.ordernumber+'</div>' : d.ordernumber}}
      , { field: 'username', title: '用户账号', width: 140, sort: true}
      , { field: 'floor', title: '用户级数', width: 140, sort: true}
      , { field: 'profitlosstypeid', title: '账变类型', width: 200, sort: true,templet:function(d){return `<span class="layui-arrow ${d.changetpe == 1 ? 'layui-moneyIn' : ''}"><i class="layui-icon layui-icon-return"></i></span>`+_this.typeObj[d.profitlosstypeid] +'/'+ _this.detailObj[d.profitlosssubtypeid]}}
      , { field: 'profitlossmoney', title: '收入', width: 140,sort: true,templet:function(d){return d.changetpe == 1 ? `<span class="red">${d.profitlossmoney}</span>` : ''}}
      , { field: 'profitlossmoney', title: '支出', width: 140,sort: true,templet:function(d){return d.changetpe == 5 ? `<span class="green">${d.profitlossmoney}</span>` : ''}}
      , { field: 'currentavailableamount', title: '当前余额', width: 140, sort: true, totalRow: true}
      , { field: 'profitlossdt', title: '账变时间', width: 180, sort: true,templet:function(d){return util.toDateString(d.profitlossdt, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'description', title: '备注',  sort: true}
    ]
    return arr
  },
  getTotalData(obj=null){
    var _this = this;
    if($('.table-total'))$('.table-total').remove();
    if(JSON.stringify(this.totalData) === '{}'){
      parent.ajaxService.doGet('/bdbProfitLoss/searchAllStatistics.mvc',obj,function(res){
        if(res.resultCode ==0){
          _this.totalData = res.results[0];
          _this.renderTotal( _this.totalData);
        }
      })
    }else{
      _this.renderTotal( _this.totalData);
    }
    
  },
  renderTotal(data){
    if (data){
      var tr = '<tr class="table-total"><td colspan="50">总量合计:'+
            '<span>投注派奖：'+data.winMoney +'</span>'+'<span>自身返点：'+data.discountOfLottery+'</span>'+
            '<span>代理返点：'+data.otherDiscount +'</span>'+'<span>转入(充值)：'+data.moneyInLottery +'</span>'+
            '<span>活动存入：'+data.activityMoneyIn +'</span>'+'<span>返佣金额：'+data.rebateSumMoney +'</span>'+
            '<span>投注扣款：'+data.payForLottery +'</span>'+'<span>追号扣款：'+data.zhForLottery +'</span>'+
            '<span>转出(提现)：'+data.moneyOutLottery +'</span>'+'<span>实际盈亏：<a class="'+parent.globalAdmin.getColor(data.actualProfitLossMoney)+'">'+data.actualProfitLossMoney +'</span></span></td></tr>'
      $('.layui-table-body table').append(tr)
    }
  }
}
layui.config({
  base: '../lib/layui_extends/module/',
}).use(['laydate', 'table', 'form', 'layer','util','multiSelect'], function () {
  var laydate = layui.laydate;
  teamAccountchange.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  var multiSelect = layui.multiSelect;
  teamAccountchange.getAccountType(form,util,multiSelect);
  teamAccountchange.getStates();
  globalAdmin.renderIntDate(laydate,util);


  var userName = teamAccountchange.getUrlParam('userName',window.location.search);
  if(userName)$(".layui-input[name='username']").val(userName);
  
  // 工具栏操作
  teamAccountchange.table.on("toolbar(demo)",function(res){
    var checkStatus = teamAccountchange.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    switch (res.event) {
      case '增加':
      case '修改':
        var isAdd = res.event == '增加' ? 1 : 0;
        layer.open({
          title:res.event,
          type: 1,
          skin: 'layui-layer-test',
          area: ['600px', '400px'],
          content: htmlTpl.addHtml,
          success:function(){
            var obj={
              "username": isAdd ? '' :data[0].username,
              "bankname": isAdd ? '' :data[0].bankname,
              "branchname":isAdd ? '' :data[0].branchname,
              "accountname":isAdd ? '' :data[0].accountname,
              "accountno":isAdd ? '' :data[0].accountno
            }
            form.val('add', obj);
            form.on('submit(formAdd)',function(submitData){
              var reqUrl = isAdd ? '/teamAccountchange/addteamAccountchange.mvc' : '/teamAccountchange/updateteamAccountchange.mvc';
              var reqData = isAdd ? submitData.field : Object.assign(submitData.field,{id:data[0].id,userid:data[0].userid});
              parent.ajaxService.doPost(reqUrl,reqData,function(res){
                var msg = res.resultMessage;
                if(res.resultCode==0){
                  teamAccountchange.layerCallback(msg);
                  teamAccountchange.editIdArr=[];
                }else{
                  layer.msg(msg)
                }
              })
              return false;
            })
          }
        })
      break;
      case '删除':
        layer.confirm("是否删除选中的银行?",{
            btn:['确定','取消']
          },function(){
          var reqData = {
            id:teamAccountchange.editIdArr.join()
          }
          parent.ajaxService.doPost("/teamAccountchange/deleteteamAccountchange.mvc",reqData,function(res){
            if(res.resultCode ==0){
              teamAccountchange.layerCallback(res.resultMessage);
              teamAccountchange.editIdArr=[];
            }else{
              layer.msg(res.resultMessage);
            }
          })
          },function(index){
            layer.close(index)
          }
        )
      break;
      default:
        break;
    }
  })
  //监听行工具事件
  teamAccountchange.table.on('tool(demo)', function(obj){
    var data = obj.data;
    var event = obj.event;
    if(event == 'orderDetail'){
      var id = data.id;
      var ordernumber = data.ordernumber;
      var url = data.cpType ==1 ? '/betrecord/view.mvc' : '/kjbetrecord/view.mvc';
      parent.ajaxService.doGet(url,{ordernumber:ordernumber},function(res){
        if(res.resultCode == 0){
          var data = res.results[0];
          var lotteryData = res.results[1];
          layer.open({
            title:'投注详情',
            type: 1,
            skin: 'layui-layer-test',
            area: ['800px', '520px'],
            content: htmlTpl.zhuiHtml,
            success:function(){
              data.status = teamAccountchange.stateObj[data.state];
              betAlert.renderTouHtml(data,lotteryData,util);
              $('.mask-box .layui-table').removeClass('zhui-table');
            }
          })
        }else{
          layer.alert(res.resultMessage)
        }
      })
    }else{
      layer.msg('该订单没有详情数据!')
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    teamAccountchange.totalData={};
    var reqData = data.field;
    var profitlosstypeidArr=[];
    var profitlosssubtypeidArr=[];
    $('.layui-multi-box[data-id="1"] select[multiple] option:selected').each(function(){
      profitlosstypeidArr.push($(this).val())
    })
    $('.layui-multi-box[data-id="2"] select[multiple] option:selected').each(function(){
      profitlosssubtypeidArr.push($(this).val())
    })
    reqData.profitlosstypeidStr=reqData.profitlosssubtypeidStr='-1';

    if(profitlosstypeidArr.length > 0){
      Object.assign(reqData,{profitlosstypeidStr:profitlosstypeidArr.join()})
    }

    if(profitlosssubtypeidArr.length > 0){
      Object.assign(reqData,{profitlosssubtypeidStr:profitlosssubtypeidArr.join()})
    }
    teamAccountchange.table.reload('demo',{
        where:reqData,
        page:{
            curr:1  
        },
        done: function (res, cur, count) {
          teamAccountchange.getTotalData(reqData);
        }
    })
    return false;
  });
  // 更多选项操作
  parent.globalAdmin.showMore('.layui-second-search-condition',window.name)
  // 重置事件处理
  $("#layui-reset").on('click',function(res){
    // $('input[name="username"],input[name="ordernumber"],input[name="profitlossmoney_begin"],input[name="profitlossmoney_end"]').val('');
    // return false;
  })
  $('.layui-account-box').on('click',function(){
    $(this).find('dl').scrollTop(0);
  })
});



