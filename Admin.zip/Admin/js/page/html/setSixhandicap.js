
var setSixhandicap = {
  table:null,
  toolbarHtml:'',
  hasDel:false,
  hasSet:false,
  status:{},
  getToolbarHtml(){ 
    var action = window.name;
    var permision = parent.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      var obj = {
        '修改期号':'hasSet',
        '删除':'hasDel'
      }
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i !='新增'){
          this[obj[i]]=true
        }else{
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${otherHtml}</div>`;
    this.getStatus();
  },
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1  
      }
	  })
  },
  getStatus(){
    var _this = this;
    parent.ajaxService.doGet('/getEnumByName.mvc',{enumName:'OpenWin_State'},function(res){
      if(res.resultCode == 0){
        _this.status = res.results[0];
      }
    })
  },
  renderState(ele){
    var html = '';
    var data = this.status;
    for(var i in data){
      html +=`<option value="${i}">${data[i]}</option>`
    }
    $(ele).append(html);
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var arr=[
      { field: 'gametypename', title: '游戏类型', width: 180,sort: true}
      , { field: 'issueno', title: '期号', width: 120,sort: true}
      , { field: 'opentime',title: '开盘时间', width: 180,sort: true,templet:function(d){return util.toDateString(d.opentime, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'closetime',title: '封盘时间', width: 180,sort: true,templet:function(d){return util.toDateString(d.closetime, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'nums', title: '开奖号码', width: 180,sort: true}
      , { title: '开奖时间', width: 200,sort: true,templet:function(d){return util.toDateString(d.lotterydt, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'orderCounter', title: '注单数', width: 100,sort: true}
      , { field: 'betmoneytotal', title: '投注总额', width: 120,sort: true}
      , { field: 'winmoneytotal', title: '中奖总额', width: 120,sort: true}
      , { field: 'betmoneytotal', title: '投注盈亏',sort: true}
      // , { title: '操作',toolbar:'#barDemo'}
    ]
    return arr
  },
  editAlert(title,form,laydate,util,data){
    var isAdd = title == '新增' ? 1 : 0;
    layer.open({
      title:title,
      type: 1,
      skin: 'layui-layer-test',
      area: ['600px', '440px'],
      content: htmlTpl.addHtml,
      success:function(){
        lay('.layui-date').each(function(){
          laydate.render({
            elem: this
            ,trigger: 'click'
            ,type:'datetime'
          });
        });
        setSixhandicap.renderState('.layui-state');
        var obj={
          "issueno": isAdd ? '' : data.issueno,
          "opentime": isAdd ? '' : util.toDateString(data.opentime, "yyyy-MM-dd HH:mm:ss"),
          "closetime":isAdd ? '' : util.toDateString(data.closetime, "yyyy-MM-dd HH:mm:ss"),
          "lotterydt":isAdd ? '' : util.toDateString(data.lotterydt, "yyyy-MM-dd HH:mm:ss"),
          "state":isAdd ? '' : data.state
        }
        form.val('add', obj);
        form.render('select','add');
        form.on('submit(formAdd)',function(submitData){
          var fieldData = submitData.field;
          var opentime = new Date(fieldData.opentime).getTime();
          var closetime = new Date(fieldData.closetime).getTime();
          var lotteryTime = new Date(fieldData.lotterydt).getTime();
          if(opentime > closetime){
            layer.msg('开盘时间不能大于封盘时间!');
            return false;
          }else if(opentime > lotteryTime){
            layer.msg('开盘时间不能大于开奖时间!');
            return false;
          }else if(closetime > lotteryTime){
            layer.msg('封盘时间不能大于开奖时间!');
            return false;
          }
          layer.load(2);
          var reqUrl = '/lotteryConfig/addLotteryNums.mvc';
          var reqData = isAdd ? submitData.field : Object.assign(submitData.field,{id:data.id});
          parent.ajaxService.doPost(reqUrl,reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              setSixhandicap.layerCallback(msg);
            }else{
              layer.msg(msg)
            }
          })
          return false;
        })
      }
    })
  }
}

// setSixhandicap.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  setSixhandicap.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  var requestUrl = '/lotteryConfig/searchSixMarkNums.mvc';
  setSixhandicap.table.render({
    elem: '#demo'
    , height: 'full-40'
    , url: requestUrl
    , toolbar: setSixhandicap.toolbarHtml
    , defaultToolbar:[]
    , method: 'get'
    , cols: [ setSixhandicap.getOptions(util)],
    where: {
      gametype:66
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results
      };
      setSixhandicap.tableData=res.results;
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
    }
  });
  
  // 工具栏操作
  setSixhandicap.table.on("toolbar(demo)",function(res){
    var checkStatus = setSixhandicap.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    switch (res.event) {
      case '新增':
      setSixhandicap.editAlert(res.event,form,laydate,util,data)
      break;
    }
  })
  //监听行工具事件
  setSixhandicap.table.on('tool(demo)', function(obj){
    var data = obj.data;
    if(obj.event === 'set'){
      setSixhandicap.editAlert('修改期号',form,laydate,util,data)
    }else if(obj.event ==='del'){
      layer.confirm("是否删除选中?",{
          btn:['确定','取消']
        },function(){
        var reqData = {
          id:data.id
        }
        parent.ajaxService.doPost("/lotteryConfig/deleteLotteryNums.mvc",reqData,function(res){
          var msg = res.resultMessage;
          if(res.resultCode ==0){
            setSixhandicap.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }
  })
});



