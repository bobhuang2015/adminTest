
var profitLossThirdUser = {
  platform:top.globalAdmin.thirdPlatform,
  thirdData:parent.profitLossTeamProxy ? parent.profitLossTeamProxy.thirdData : parent.profitLossTeamDaily.thirdData,
  getSubType(data){
    var obj={
      "1":'视讯',
      "2":'电子',
      "3":'体育',
      "4":'棋牌',
      "5":'彩票',
      "6":'真人',
      "7":'捕鱼'
    }
    return obj[data];
  },
  renderData(data){
    var html = '';
    if(data && data.length>0){
      data.forEach((v,k)=>{
        html +=`<tr>
          <td>${this.platform[v.platform]}</td>
          <td>${v.orderNumber}</td>
          <td>${top.globalAdmin.commafy(v.orderMoneyTotal.toFixed(3))}</td>
          <td>${top.globalAdmin.commafy(v.selfBonusMoney.toFixed(3))}</td>
          <td>${top.globalAdmin.commafy(v.agentBonusMoney.toFixed(3))}</td>
          <td class='${top.globalAdmin.getColor(v.profitlossMoneyTotal)}'>${top.globalAdmin.commafy(v.profitlossMoneyTotal.toFixed(3))}</td>
        </tr>`
      })
      $(".tbody").append(html);
    }else{
      $('table').after('<div class="layui-none">无数据</div>')
    }
  }
}
profitLossThirdUser.renderData(profitLossThirdUser.thirdData)


