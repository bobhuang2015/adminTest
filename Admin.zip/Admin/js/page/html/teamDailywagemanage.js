
var teamDailywagemanage = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  typeObj:{},
  index:1,
  page:1,
  divdendWageinfos:[],
  getToolbarHtml(){ 
    var action = window.name;
    var permision = parent.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i=='新增'){
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${otherHtml}</div>`;//toolbar 跟表格联动
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.page  
      }
	  })
  },
  getGameType(){//账变类型及细类
    var _this = this;
    parent.ajaxService.doGet("/dividendWage/gameType.mvc",null,function(res){
      if(res.resultCode == 0){
        _this.typeObj = res.results[0];
        _this.renderHtml(_this.typeObj,'gametype');
      }
    })
  },
  checkUser(name){
    var _this = this;
    parent.ajaxService.doPost("/systemDepositAndWithdraw/findUser.mvc",{userName:name},function(res){
      if(res.resultCode ==0){
        var data = res.results[0].capitalCenter;
        $(".layui-userid").val(data.userid);
      }else{
        layer.msg("没有该操作用户")
      }
    })
  },
  renderHtml(data,ele){
    var html='';
    for(var i in data){
      html+=`<option value="${i}">${data[i]}</option>`
    }
    $(`.${ele}`).append(html);
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getPeriod(period){
    var obj={
      '0':'每日',
      '1':'半月',
      '2':'一月',
    }
    return obj[period]
  },
  getType(type){
    var obj={
      '0':'分红',
      '1':'日工资'
    }
    return obj[type]
  },
  getOptions:function(util){
    var arr=[
      {title:'操作', width: 130,toolbar:'#barDemo'}
      , { field: 'agentusername', title: '上级', width: 120, sort: true}
      , { field: 'username', title: '用户账号', width: 120, sort: true}
      , { field: 'type', title: '类型', width: 120, sort: true,templet:function(d){return teamDailywagemanage.getType(d.type)}}
      , { field: 'isauto', title: '自动分红', width: 140, sort: true,templet:function(d){return d.isauto == 1 ? '自动' : '手动'}}
      , { field: 'gametype', title: '游戏类型', width: 140, sort: true,templet:function(d){return teamDailywagemanage.typeObj[d.gametype]}}
      , { field: 'divdendplot', title: '分红策略', width: 140, sort: true,templet:function(d){return d.divdendplot == 1 ? '累积盈亏' : '累积不盈亏'  }}
      , { title: '分红期数', width: 140, sort: true,templet:function(d){return teamDailywagemanage.getPeriod(d.divendperiod) }}
      , { field: 'lastoperator', title: '最后操作人', width: 140, sort: true}
      , { title: '操作时间', sort: true,templet:function(d){return util.toDateString(d.lastoperationtime, "yyyy-MM-dd HH:mm:ss")},minWidth:180}
    ]
    return arr
  },
  controlInput(){
    $(".layui-nums").keyup(function(){     
      var tmptxt=$(this).val();     
      $(this).val(tmptxt.replace(/\D|^0/g,''));     
    }).bind("paste",function(){     
      var tmptxt=$(this).val();     
      $(this).val(tmptxt.replace(/\D|^0/g,''));     
    })
  }
}

teamDailywagemanage.getToolbarHtml();
teamDailywagemanage.getGameType();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  teamDailywagemanage.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  var is = !0;
  globalAdmin.renderIntDate(laydate,util);
  teamDailywagemanage.table.render({
    elem: '#demo'
    , height: 'full-80'
    , defaultToolbar:[]
    , url: '/dividendWage/getDWConfigs.mvc'
    , page: true
    , toolbar: teamDailywagemanage.toolbarHtml
    , method: 'get'
    , cols: [teamDailywagemanage.getOptions(util)],
    where: {
      type:-1,
      isauto:-1,
      gametype:-1,
      divdendplot:-1,
      divendperiod:-1
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results[0]
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      teamDailywagemanage.page = cur;
    }
  });
  
  // 工具栏操作
  teamDailywagemanage.table.on("toolbar(demo)",function(res){
    var checkStatus = teamDailywagemanage.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    switch (res.event) {
      case '新增':
        layer.open({
          title:res.event,
          type: 1,
          skin: 'layui-layer-test',
          area: ['800px', '600px'],
          content: htmlTpl.addHtml,
          success:function(){
            $('.layui-teamManage').parent('.layui-layer-content').addClass("test");
            teamDailywagemanage.renderHtml(teamDailywagemanage.typeObj,'layui-gametype');
            $("#username").blur(function(){
              var value = $(this).val();
              teamDailywagemanage.checkUser(value);
            })
            var obj={
              "username": '',
              "userid": '',
              "type": 0,
              "isauto": 0,
              "gametype": 0,
              "divdendplot": 0,
              "divendperiod": 0
            }
            form.val('add', obj)
            form.on('select(type)',function(data){
              if(data.value ==1){
                $('.layui-hong').hide()
              }else{
                $('.layui-hong').show()
              }
            })
            
            teamDailywagemanage.controlInput();
            $('.layui-new').on("click",function(){
              var html = `<div class="layui-detail-item">
                          <input type="text" name="datequantity" placeholder="日量>=" autocomplete="off" class="layui-input layui-nums"  lay-verify="required" >
                          <input type="text" name="vaildusers" placeholder="有效会员>=" autocomplete="off" class="layui-input layui-nums"  lay-verify="required" >
                          <div class="layui-inline" style="width:150px;">
                            <div class="layui-input-inline"  style="width:150px;">
                              <select name="rewardtype">
                                <option value="0">固定</option>
                                <option value="1">比率</option>
                                </select>
                            </div>
                          </div>
                          <input type="text" name="rewardamout" placeholder="金额/比率" autocomplete="off" class="layui-input layui-nums"  lay-verify="required" >
                          <div class="layui-btn layui-del">删除</div>
                        </div>`
              $('.layui-detail-first').append(html);
              form.render('select');
              teamDailywagemanage.controlInput();
              teamDailywagemanage.index++;
            })
            $(document).on('click',".layui-del",function(){
              var parent = $(this).parent();
              parent.remove();
              teamDailywagemanage.index--;
            })
            form.on('submit(formAdd)',function(submitData){
              var reqData={};
              var fieldData = submitData.field;
              var arr = [];
              for(var i=0;i<teamDailywagemanage.index;i++){
                var tempObj = {};
                tempObj.datequantity=$(`.layui-detail-item:eq(${i}) input[name='datequantity']`).val();
                tempObj.vaildusers=$(`.layui-detail-item:eq(${i}) input[name='vaildusers']`).val();
                tempObj.rewardtype=$(`.layui-detail-item:eq(${i}) .layui-this`).attr('lay-value');
                tempObj.rewardamout=$(`.layui-detail-item:eq(${i}) input[name='rewardamout']`).val();
                arr.push(tempObj)
              }
              teamDailywagemanage.divdendWageinfos = arr;
              var divdendWageinfos = JSON.stringify(teamDailywagemanage.divdendWageinfos);
              var isHong = fieldData.type == 0 ? !0 : 0;
              var reqData = {
                username:fieldData.username,
                userid:fieldData.userid,
                type:fieldData.type,
                gametype:fieldData.gametype,
                divdendplot: isHong ? fieldData.divdendplot : 0,
                divendperiod:isHong ? fieldData.divendperiod : 0,
                divdendWageinfos:divdendWageinfos
              }
              
              parent.ajaxService.doPost('/dividendWage/addDWConfig.mvc',reqData,function(res){
                var msg = res.resultMessage;
                teamDailywagemanage.divdendWageinfos=[];
                teamDailywagemanage.index=1;
                if(res.resultCode==0){
                  teamDailywagemanage.layerCallback(msg);
                }else{
                  layer.msg(msg)
                }
              })
              return false;
            })
          }
        })
      break;
      default:
        // layer.msg("接口文档未完善，需要相应人员支持!")
        break;
    }
  })
  //监听行工具事件
  teamDailywagemanage.table.on('tool(demo)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
      layer.confirm(`是否删除?`, function(index){
        var reqData= {
          'id':data.id
        }
        parent.ajaxService.doPost('/dividendWage/deleleDWConfig.mvc',reqData,function(res){
          var msg = res.resultMessage;
          if(res.resultCode == 0 ){
            teamDailywagemanage.layerCallback(msg);
          }else{
            layer.alert(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(obj.event == 'set'){
      parent.ajaxService.doPost('/dividendWage/getDWInfos.mvc',{divdendnewid:data.id},function(res){
        if(res.resultCode == 0){
          var dataObj = res.results[0];
          teamDailywagemanage.divdendWageinfos = dataObj;
          var html = '';
          var j = 0;
          for(var i=0;i<dataObj.length;i++){
            html+=`<div class="layui-detail-item ${i==0 ? 'layui-detail-first' :''}">
                  <input type="text" name="datequantity" placeholder="日量>=" autocomplete="off" class="layui-input layui-nums"  lay-verify="required" value="${dataObj[i].datequantity}">
                  <input type="text" name="vaildusers" placeholder="有效会员>=" autocomplete="off" class="layui-input layui-nums"  lay-verify="required" value="${dataObj[i].vaildusers}">
                  <div class="layui-inline" style="width:150px;">
                    <div class="layui-input-inline"  style="width:150px;">
                      <select name="rewardtype" class="rewardtype">
                        <option value="0" ${dataObj[i].rewardtype == 0 ? 'selected' : ''}>固定</option>
                        <option value="1" ${dataObj[i].rewardtype == 1 ? 'selected' : ''} >比率</option>
                      </select>
                    </div>
                  </div>
                  <input type="text" name="rewardamout" placeholder="金额/比率" autocomplete="off" class="layui-input layui-nums"  lay-verify="required" value="${dataObj[i].rewardamout}">
                  <div class="layui-btn ${i==0 ? 'layui-new' : 'layui-del'}">${i==0 ? '新增' : '删除'}</div>
                </div>
              </div>`
              j++;
          }
          if(j == dataObj.length){
            layer.open({
              title:'修改',
              type: 1,
              skin: 'layui-layer-test',
              area: ['800px', '600px'],
              content: htmlTpl.editHtml,
              success:function(){
                $('.layui-teamManage').parent('.layui-layer-content').addClass("test");
                teamDailywagemanage.index = dataObj.length;
                var obj={
                  "username": data.username,
                  "userid": data.userid,
                  "type": teamDailywagemanage.getType(data.type),
                  "isauto": data.isauto,
                  "gametype":teamDailywagemanage.typeObj[data.gametype],
                  "divdendplot": data.divdendplot,
                  "divendperiod": data.divendperiod
                }
                form.val('edit', obj);
                if(data.type==1)$('.layui-hong').hide();//日工资处理;
                $('#layui-detail-list').html(html);
                form.render('select');
                
                $('.layui-new').on("click",function(){
                  var html = `<div class="layui-detail-item">
                              <input type="text" name="datequantity" placeholder="日量>=" autocomplete="off" class="layui-input layui-nums"  lay-verify="required" >
                              <input type="text" name="vaildusers" placeholder="有效会员>=" autocomplete="off" class="layui-input layui-nums"  lay-verify="required" >
                              <div class="layui-inline" style="width:150px;">
                                <div class="layui-input-inline"  style="width:150px;">
                                  <select name="rewardtype">
                                    <option value="0">固定</option>
                                    <option value="1">比率</option>
                                    </select>
                                </div>
                              </div>
                              <input type="text" name="rewardamout" placeholder="金额/比率" autocomplete="off" class="layui-input layui-nums"  lay-verify="required" >
                              <div class="layui-btn layui-del">删除</div>
                            </div>`
                  $('#layui-detail-list').after(html);
                  form.render('select');
                  teamDailywagemanage.controlInput();
                  teamDailywagemanage.index++;
                })
                $(document).on('click',".layui-del",function(){
                  var parent = $(this).parent();
                  parent.remove();
                  teamDailywagemanage.index--;
                })
                teamDailywagemanage.controlInput();
                form.on('submit(formEdit)',function(submitData){
                  var reqData={};
                  var fieldData = submitData.field;
                  var arr = [];
                  for(var i=0;i<teamDailywagemanage.index;i++){
                    var tempObj = {};
                    tempObj.datequantity=$(`.layui-detail-item:eq(${i}) input[name='datequantity']`).val();
                    tempObj.vaildusers=$(`.layui-detail-item:eq(${i}) input[name='vaildusers']`).val();
                    tempObj.rewardtype=$(`.layui-detail-item:eq(${i}) .layui-this`).attr('lay-value');
                    tempObj.rewardamout=$(`.layui-detail-item:eq(${i}) input[name='rewardamout']`).val();
                    arr.push(tempObj)
                  }
                  teamDailywagemanage.divdendWageinfos = arr;
    
                  
                  var divdendWageinfos = JSON.stringify(teamDailywagemanage.divdendWageinfos);
                  var isHong = data.type == 0 ? !0 : 0;
                  var reqData = {
                    id:data.id,
                    username:fieldData.username,
                    userid:fieldData.userid,
                    type:data.type,
                    isauto:fieldData.isauto,
                    gametype:data.gametype,
                    divdendplot: isHong ? fieldData.divdendplot : 0,
                    divendperiod:isHong ? fieldData.divendperiod : 0,
                    divdendWageinfos:divdendWageinfos
                  }
                  
                  parent.ajaxService.doPost('/dividendWage/updateDWConfig.mvc',reqData,function(res){
                    var msg = res.resultMessage;
                    teamDailywagemanage.divdendWageinfos=[];
                    teamDailywagemanage.index=1;
                    if(res.resultCode==0){
                      teamDailywagemanage.layerCallback(msg);
                    }else{
                      layer.msg(msg)
                    }
                  })
                  return false;
                })
              }
            })
          }
          
        }
      })
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    teamDailywagemanage.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



