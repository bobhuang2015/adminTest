
var vipGrade = {
  table:null,
  toolbarHtml:'',
  hasSet:false,
  hasDel:false,
  cols:20,
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action ='vip-set';
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    var obj={
      '修改':'hasSet'
    }
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        this[obj[i]]=true;
      })
    }
    this.hasSet && $('.layui-save').show();
    this.toolbarHtml =`<div>${otherHtml}</div>`;//toolbar 跟表格联动
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(){
    var arr=[
      { field: 'level0', title: '等级', width: '8%',align:'center',templet:function(d){return 'L'+d.level0}}
      , { field: 'exp0', title: '所需经验', width: '12%',align:'center',toolbar:'#barDemo0'}
      , { field: 'level1', title: '等级', width: '8%',align:'center',templet:function(d){return 'L'+d.level1}}
      , { field: 'exp1', title: '所需经验', width: '12%',edit:'text',align:'center',toolbar:'#barDemo1'}
      , { field: 'level2', title: '等级', width: '8%',align:'center',templet:function(d){return 'L'+d.level2}}
      , { field: 'exp2', title: '所需经验', width: '12%',edit:'text',align:'center',toolbar:'#barDemo2'}
      , { field: 'level3', title: '等级', width: '8%',align:'center',templet:function(d){return 'L'+d.level3}}
      , { field: 'exp3', title: '所需经验', width: '12%',edit:'text',align:'center',toolbar:'#barDemo3'}
      , { field: 'level4', title: '等级', width: '8%',align:'center',templet:function(d){return 'L'+d.level4}}
      , { field: 'exp4', title: '所需经验', edit:'text',align:'center',toolbar:'#barDemo4'}
    ]
    return arr
  },
  editIdArr:[],
  tableData:[]
}

vipGrade.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer'], function () {
  var laydate = layui.laydate;
  vipGrade.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  
  vipGrade.table.render({
    elem: '#demo'
    , height: `full-20`
    , url: '/vipLevelExp/getList.mvc'
    , method: 'get'
    , limit:100
    , page:false
    , cols: [ vipGrade.getOptions()],
    where: {
    }
    , parseData: function (res) {
      var resData = res.results.reverse();
      vipGrade.tableData = resData;
      var len = vipGrade.getOptions().length / 2;
      var cols = vipGrade.cols;
      var tempArr=[];
      for(var i=0;i<cols;i++){
        var obj = {};
        for(var j=0;j<len;j++){
          obj['level'+j]=resData[i+cols*j].level;
          obj['exp'+j]=resData[i+cols*j].exp;
        }
        tempArr.push(obj)
      }
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": tempArr
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      $('tr[data-index="0"] td:eq(1) input').attr('disabled',true).addClass('layui-disabled');
      
      $('.layui-dengji').on('change',function(){
        var index = $(this).parents('tr').attr('data-index');
        var value = $(this).val();
        var targetLevel = $(this).parent('div').parent('td').prev().attr('data-content');
        if(value){
          if(+value <= vipGrade.tableData[+targetLevel - 1].exp ){
            $(this).val(vipGrade.tableData[targetLevel].exp)
            layer.msg('等级经验只能递增');
            return
          }
          if(targetLevel !=99 && +value >= vipGrade.tableData[+targetLevel + 1].exp ){
            $(this).val(vipGrade.tableData[targetLevel].exp)
            layer.msg('当前输入经验值不能大于或等于下一个等级经验!');
            return
          }
          var data = {
            id:+targetLevel+1,
            level:targetLevel,
            exp:value
          }
          var editIndex = vipGrade.editIdArr.findIndex(v=>{return v.level == data.level});
          if(editIndex != -1)vipGrade.editIdArr.splice(editIndex,1);
          vipGrade.editIdArr.push(data);
        }else{
          $(this).val(vipGrade.tableData[targetLevel].exp)
        }
      })
    }
  });
  // vipGrade.table.on('edit(demo)', function(obj){
  //   if(!vipGrade.hasSet){
  //     layer.msg('您没有修改权限哦!')
  //     return;
  //   }
  //   var value = obj.value //得到修改后的值
  //   ,field = obj.field; //得到字段
  //   var index = $(obj.tr).attr('data-index');
  //   var level = field[3];
  //   var hash={
  //     '0':0,
  //     '1':20,
  //     '2':40,
  //     '3':60,
  //     '4':80
  //   }
  //   var levelIndex = +index + (hash[level]);
  //   var dataIndex = vipGrade.tableData.findIndex(v=>{return v.level == levelIndex});
  //   if(index ==0 && level==0){
  //     layer.msg('等级0不可以修改!')
  //     // debugger;
  //     setTimeout(()=>{
  //       $(obj.tr).find('td[data-field="exp0"] div').text('0')
  //       $(obj.tr).find('td[data-field="exp0"] input').val('0')
  //     },300)
  //     return;
  //   }
  //   if(!/^[1-9]\d*$/.test(value)){
  //     layer.msg('只能输入正整数!')
  //     return;
  //   }
  //   if(levelIndex!=0 && (+value <= +vipGrade.tableData[dataIndex-1].exp)){
  //     layer.msg('等级经验只能递增!')
  //     return;
  //   }
  //   if(levelIndex!=99 && (+value >= +vipGrade.tableData[dataIndex+1].exp)){
  //     layer.msg('当前输入经验值不能大于或等于下一个等级经验!')
  //     return;
  //   }
  //   var reqData = {
  //     id:levelIndex+1,
  //     level:levelIndex,
  //     exp:value
  //   }
  //   var reqStr='';
  //   var editIndex = vipGrade.editIdArr.findIndex(v=>{return v.level == reqData.level});
  //   if(editIndex != -1)vipGrade.editIdArr.splice(editIndex,1);
  //   vipGrade.editIdArr.push(reqData);
  //   reqStr = 'vipLevelExpList='+JSON.stringify(vipGrade.editIdArr);
  // })
  $(document).on('click','.layui-save',function(){
    if(vipGrade.editIdArr.length==0){
      layer.msg('请选择经验修改!')
      return;
    }
    var reqStr='';
    reqStr = 'vipLevelExpList='+JSON.stringify(vipGrade.editIdArr);
    // reqStr = 'vipLevelExpList='+JSON.stringify(vipGrade.tableData);
    layer.load(2)
    parent.ajaxService.doPost('/vipLevelExp/edit.mvc',reqStr,function(res){
      if(res.resultCode ==0){
        vipGrade.layerCallback(res.resultMessage);
        vipGrade.editIdArr=[];
      }else{
        layer.msg(res.resultMessage)
        setTimeout(()=>{
          layer.closeAll();
        },2e3)
      }
    })
  })
  
});



