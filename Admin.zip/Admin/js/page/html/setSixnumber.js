
var setSixnumber = {
  animalArr:["鼠","牛","虎","兔","龙","蛇","马","羊","猴","鸡","狗","猪"],
  renderHtml(){
    var html = "";
    this.animalArr.forEach((v,k)=>{
      html +=`<option value="${v}|">${v}</option>`
    })
    $(".layui-animals").append(html);
  }
}
setSixnumber.renderHtml();
layui.use(['form', 'layer'], function () {
  var form = layui.form;
  var layer = layui.layer;
  
  form.on('submit(formDemo)', function (data) {
    var obj = data.field;
    parent.ajaxService.doGet("/lotteryOdds/updateLotteryOddsName.mvc",obj,function(res){
      if(res.resultCode == 0){
        form.val('test',{
          'gamename':''
        })
        layer.msg(res.resultMessage)

      }
    })
    return false;
  });

});



