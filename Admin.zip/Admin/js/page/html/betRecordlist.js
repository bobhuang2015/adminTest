
var betRecordlist = {
  table:null,
  toolbarHtml:'',
  pageNumber:1,
  stateObj:{},
  zhuiStateObj:{},
  mobileBetObj:{
    '0':'电脑投注',
    '1':'安卓投注',
    '2':'苹果投注',
    '3':'H5投注',
    '4':'安卓H5投注',
    '5':'苹果H5投注',
  },
  index:9999,
  playTypeArr:[],
  hasInvalid:false,
  hasCancel:false,
  hasWithdrawal:false,
  hasDaochu:false,
  tableIns:null,
  gameData:[],
  name:'betRecordList',
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){
    var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var editHtml = '';
    var obj = {
      '作废':'hasInvalid',
      '撤销派奖':'hasCancel',
      '导出数据':'hasDaochu'
    }
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i !='批量作废' && i !='批量撤销派奖'){
          this[obj[i]]=true
        }else{
          editHtml +='<button id="'+i+'" class="layui-btn layui-btn-disabled" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    if(this.hasDaochu){
      $('button[lay-filter="formDaochu"]').show();
    }
    this.toolbarHtml =`<div>${editHtml}</div>`
  },
  reloadTable:function(){
    var _this = this;
    this.editIdArr=[];
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber
      }
	  })
  },
  getOperatorHtml(d){
    var html = '';
    if(this.hasInvalid){
      if(d.state !=2 && d.state != 7){
        html +='<a class="layui-btn layui-btn-danger layui-btn-operator" lay-event="invalid">作废</a>'
      }
    }
    if(this.hasCancel){
      if(d.state ==4){
        html +='<a class="layui-btn layui-btn-operator" lay-event="cancel">撤销派奖</a>'
      }
    }
    html +='<div>'+html+'</div>';
    return html;
  },
  getZhuiState(url,name){
    var _this = this;
    parent.ajaxService.doGet(url,{enumName:name},function(res){
      if(res.resultCode == 0){
        if(name=='ZhuiHao_State')
        _this.zhuiStateObj = res.results[0];
      }
    })
  },
  getStates(){//注单状态
    var _this = this;
    parent.ajaxService.doGet("/getEnumByNames.mvc",{enumName:'BetRecord_State,ZhuiHao_State'},function(res){
      if(res.resultCode == 0){
        var data = res.results[0];
        _this.stateObj = data.BetRecord_State;
        _this.zhuiStateObj = data.ZhuiHao_State;
        _this.renderHtml(_this.stateObj,'state');
      }
    })
  },
  getMobileBet(){//投注来源
    var _this = this;
    parent.ajaxService.doGet("/getEnumByName.mvc",{enumName:'BetRecord_MobileBet'},function(res){
      if(res.resultCode == 0){
        var data = res.results[0];
        _this.mobileBetObj = data;
        _this.renderHtml(data,'mobileBet');
      }
    })
  },
  renderHtml(data,ele,is){
    var html='';
    if(is){
      data.forEach((v,k)=>{
        html+=`<option value="${v.id}">${v.name}</option>`
      })
    }else{
      for(var i  in  data){
        html+=`<option value="${i}">${data[i]}</option>`
      }
    }
    $(`.${ele}`).append(html);
  },
  getGameType(form){//游戏类型，玩法，投注类型
    var _this = this;
    parent.ajaxService.doGet("/gameType/getGamePlayType.mvc",null,function(res){
      if(res.resultCode == 0 ){
        var data = res.results;
        _this.gameData = data;
        _this.renderHtml(data,'gameType',!0)
        form.render('select')
      }
    })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  initSelect(){
    $(".playType").html('<option value="-1">玩法类型</option>');
    $(".betType").html('<option value="-1">投注类型</option>');
  },
  getUrlParam(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); //构造一个含有目标参数的正则表达式对象
    var r = window.location.search.substr(1).match(reg);  //匹配目标参数
    if (r != null) return unescape(r[2]); return null; //返回参数值
  },
  getOptions:function(util){
    var arr=[
      {type:'checkbox'}
      , { field: 'ordernumber', title: '投注单号', width: 140, sort: true,templet:function(d){return '<div class="layui-table-ordernumber" lay-event="orderDetail">'+d.ordernumber+'</div>'}}
      , { title: '操作', width: 140,templet:function(d){return betRecordlist.getOperatorHtml(d)}}
      , { title: '状态', width: 90,templet:function(d){return betRecordlist.stateObj[d.state]+(d.iswin==1 ? '(<span class="red">中奖</span>)' : '')}}
      , { field: 'username', title: '用户账号', width: 110, sort: true}
      , { field: 'gametypename', title: '游戏类型', width: 110, sort: true}
      , { field: 'bettypename', title: '玩法', width: 126, sort: true,templet:function(d){return d.bettypename+'/'+d.playtypename}}
      , { title: '期号',width: 140,templet:function(d){return d.issueno+(d.iszhuihao==1 ? '(<span class="red">追</span>)' : '')}}
      , { field: 'nums', title: '投注号码', width: 130, sort: true}
      , { field: 'betcount', title: '投注注数/总额', width: 114,templet:function(d){return d.betcount+'/'+d.betmoneytotal.toFixed(3)}}
      , { field:'betdt',title: '投注时间', width: 150, sort: true,templet:function(d){return util.toDateString(d.betdt, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'winmoney', title: '中奖总额', width: 100, sort: true,templet:function(d){return d.winmoney.toFixed(3)}}
      , { title: '盈亏金额', width: 110, sort: true,templet:function(d){return `<div class="${d.winmoney - d.betmoneytotal > 0 ? 'red' :'green'}">${(d.winmoney - d.betmoneytotal).toFixed(3)}</div>`}}
      , { field:'mobileBet',title: '投注方式', width: 100, sort: true,templet:function(d){return betRecordlist.mobileBetObj[d.mobileBet] ? betRecordlist.mobileBetObj[d.mobileBet] :'--'}}
      , { field:'operator',title: '操作者'}
    ]
    return arr
  },
  editIdArr:[],
  requestZhuiDetail(id,ordernumber,util){
    var _this = this;
    parent.ajaxService.doGet('/zhuihao/view.mvc',{id:id},function(res){
      if(res.resultCode == 0){
        var firstTableData = res.results[0];
        var secondTableData = res.results[2];
        var thirdTableData = res.results[1];
        layer.open({
          title:'追号详情',
          type: 1,
          skin: 'layui-layer-test',
          area: ['900px', '700px'],
          content: htmlTpl.detailHtml,
          success:function(){
            if(secondTableData.length > 5 || thirdTableData.length > 5){
              $('.layui-layer-content').css("overflow-y","scroll");
            }
            betAlert.renderFirstTable(firstTableData,util,ordernumber,'.first-table');
            betAlert.renderSecondTable(secondTableData);
            betAlert.renderThirdTable(thirdTableData,_this.zhuiStateObj);
            }
        })
      }else{
        layer.alert(res.resultMessage)
      }
    })
  },
  tableData:[],
  renderTotal(res){
    this.editIdArr=[];
    $('.layui-table-tool-temp > button').addClass('layui-btn-disabled');
    if(res.data && res.data.length>0){
      res.data.forEach((v,k)=>{
        if(v.state ==7){
          $('.layui-table tr:eq('+(k+1)+')').addClass('red');
        }
      })
    }
    if (res.data && res.data.length > 0 && res.total){
      var tr = '<tr class="table-total"><td colspan="50">总量合计：<span>(即时)投注总额:'+res.total.normalBetMoneyTotal+'</span><span>(已完成)投注总额： '+(+res.total.betmoneytotal).toFixed(3)+'</span>'+
            '<span>自身返点总额： '+(+res.total.selfBonusMoney).toFixed(3) +'</span>'+'<span>中奖总额： '+res.total.winmoney+'</span>'+'<span>盈亏总额： <a class="'+parent.globalAdmin.getColor(res.total.profitMoneyTotal)+'">'+(+res.total.profitMoneyTotal).toFixed(3)+'</a></span></td></tr>'
      $('.layui-table-body table').append(tr)
    }
  }
}

betRecordlist.getToolbarHtml();
betRecordlist.getStates();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  betRecordlist.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;

  globalAdmin.renderRechargeDate(laydate,util);
  var userName = betRecordlist.getUrlParam('userName');
  if(userName)$(".layui-input[name='username']").val(userName);
  // 游戏玩法，下拉选择操作
  form.on('select(gametype)', function(selectData){
    var value = selectData.value;
    betRecordlist.initSelect();
    if(value==-1){
      betRecordlist.playTypeArr=[];
      form.render('select','test');
    }
    betRecordlist.gameData.forEach((v,k)=>{
      if(v.id == value ){
        betRecordlist.playTypeArr = v.playType;
        betRecordlist.renderHtml(v.playType,'playType',!0)
        form.render('select','test');
      }
    })
  })
  // 游戏玩法，下拉选择操作
  form.on('select(playtype)', function(selectData){
    var value1 = selectData.value;
    betRecordlist.playTypeArr.forEach((v,k)=>{
      if(v.id == value1 ){
        betRecordlist.renderHtml(v.betType,'betType',!0)
        form.render('select','test');
      }
    })
  })

  betRecordlist.tableIns = betRecordlist.table.render({
    elem: '#demo'
    , height: 'full-90'
    , url: ' /betrecord/search.mvc'
    , toolbar: betRecordlist.toolbarHtml
    , defaultToolbar:[]
    , page: true
    , method: 'get'
    , cols: [ betRecordlist.getOptions(util)],
    where: {
      username:$(".layui-input[name='username']").val(),
      usernameQuery:1
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode,
        "msg": res.resultMessage,
        "count": res.meta.totalRecord || 0,
        "data": res.results.length == 2 ? res.results[0] : [],
        'total':res.results.length == 2 ? res.results[1] : []
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      betRecordlist.tableData = res.data;
      betRecordlist.pageNumber = cur;
      betRecordlist.renderTotal(res)
    }
  });
  parent.globalAdmin.checkboxEdit(betRecordlist,window.name,'record')

  betRecordlist.getGameType(form);
  // betRecordlist.getZhuiState('/getEnumByName.mvc','ZhuiHao_State')
  // 工具栏操作
  betRecordlist.table.on("toolbar(demo)",function(res){
    var checkStatus = betRecordlist.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    var dataObj = {
      '批量作废':{txt:'是否批量作废选中的投注记录?',reqUrl:'/betrecord/invalidateBatch.mvc'},
      '批量撤销派奖':{txt:'是否批量撤销派奖选中的投注记录?',reqUrl:'/betrecord/cancelPrizeBatch.mvc'}
    }
    var event = res.event;
    var checkedLength = data.length;
    var tempLen = 0;
    var tempArr = [];
    if(event =='批量作废'){
      data.forEach((v,k)=>{
        if(v.state !=2 && v.state != 7){
          tempLen++;
        }else{
          tempArr.push(v)
        }
      })
    }else if(event == '批量撤销派奖'){
      data.forEach((v,k)=>{
        if(v.state == 4){
          tempLen++;
        }else{
          tempArr.push(v)
        }
      })
    }
    if(tempLen == checkedLength){
      layer.confirm(dataObj[event].txt,{
          btn:['确定','取消']
        },function(){
        var reqData = {
          ids:betRecordlist.editIdArr.join()
        }
        layer.load(2)
        parent.ajaxService.doPost(dataObj[event].reqUrl,reqData,function(res){
          if(res.resultCode ==0){
            betRecordlist.layerCallback(res.resultMessage);
            betRecordlist.editIdArr=[];
          }else{
            layer.msg(res.resultMessage);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else{
      layer.alert(`单号:${tempArr[0].ordernumber}，不能被${event.replace('批量','')}`)
    }
  })
let switchState = true;
  //监听行工具事件
  betRecordlist.table.on('tool(demo)', function(obj){
    var data = obj.data;
    var event = obj.event;
    if(event == 'invalid' || event == 'cancel'){
      var dataTemp = {
        'invalid':{txt:'是否作废?',reqUrl:'/betrecord/invalidate.mvc'},
        'cancel':{txt:'是否撤销派奖?',reqUrl:'/betrecord/cancelPrize.mvc'},
      }
      var reqData={
        id:data.id,
        username:data.username,
        ordernumber:data.ordernumber
      }
      layer.confirm(dataTemp[event].txt, function(index){
        if (!switchState) { return }
        switchState = false
        parent.ajaxService.doPost(dataTemp[event].reqUrl,reqData,function(res){
          var msg = res.resultMessage
          if(res.resultCode ==0){
            switchState = true
            betRecordlist.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(event == 'orderDetail'){
      var id = data.id;
      var ordernumber = data.ordernumber;
      parent.ajaxService.doGet('/betrecord/view.mvc',{id:id},function(res){
        if(res.resultCode == 0){
          var data = res.results[0];
          var lotteryData = res.results[1];
          layer.open({
            title:'投注详情',
            type: 1,
            skin: 'layui-layer-test',
            area: ['800px', '500px'],
            closeBtn:1,
            shadeClose:true,
            content: htmlTpl.zhuiHtml,
            // btn:['关闭','取消'],
            success:function(){
              $('.mask-box').parent('.layui-layer-content').addClass('layui-scroll');
              data.status = betRecordlist.stateObj[data.state];
              betAlert.renderTouHtml(data,lotteryData,util);
              $('.mask-box .layui-table').removeClass('zhui-table');
            }
          })
        }else{
          layer.alert(res.resultMessage)
        }
      })
    }
    layui.stope();
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    delete data.field.isAll
    betRecordlist.table.reload('demo',{
        where:data.field,
        page:{
            curr:1
        },
        done:function(res, cur, count){
          betRecordlist.pageNumber=cur;
          betRecordlist.renderTotal(res);
          betRecordlist.tableData = res.data;
        }
    })
    return false;
  });
  // 导出数据
  form.on('submit(formDaochu)', function (data) {
    if(betRecordlist.hasDaochu){
      parent.globalAdmin.exportData(form,data,betRecordlist)
    }
    return false;
  });
  //投注记录详情
  $(document).on('click',".layui-table-ordernumber",function(event){

  })
  //追号详情
  $(document).on('click','.zhuiDetail',function(){
    var id = $(this).attr('data-id');
    var ordernumber = $(this).attr('data-ordernumber');
    betRecordlist.requestZhuiDetail(id,ordernumber,util);
  })
  //追号列表点击详情
  $(document).on('click',".layui-table-zhuihaonumber",function(e){
    var zhid = $(this).attr('data-zhid');
    var zhinfoid = $(this).attr('data-zhinfoid');
    var ordernumber = $(this).attr('data-ordernumber')
    e.stopPropagation();
    parent.ajaxService.doGet('/betrecord/zhuihaoview.mvc',{zhinfoid:zhinfoid,zhid:zhid},function(res){
      if(res.resultCode == 0){
        layer.open({
          title:'追号投注详情',
          type: 1,
          skin: 'layui-layer-test',
          area: ['800px', '600px'],
          content: htmlTpl.zhuiHtml,
          success:function(){
            $('.zhui-table').addClass(betRecordlist.index);
            betRecordlist.index++;
            if(res.results[0].view =='MANYVIEN'){
              var firstTableData = res.results[0].zhuiHao;
              betAlert.renderFirstTable(firstTableData,util,ordernumber,'.zhui-table');
            }else if(res.results[0].view =='view'){
              var data = res.results[0].betRecord;
              var lotteryData = res.results[0].lotteryNums;
              data.status = betRecordlist.stateObj[data.state];
              betAlert.renderTouHtml(data,lotteryData,util)
            }
          }
        })
      }
    })
  })
  // 取消单条追号;
  $(document).on('click',".layui-cancle",function(){
    var id = $(this).attr('data-id');
    layer.confirm('请问是否取消追号？',{btn: ['确定', '取消']},function (btn1) {
      layer.close(btn1);
      parent.ajaxService.doGet('/zhuihao/cancel.mvc',{zhuiHaoInfoId:id},function(res){
        if(res.resultCode == 0){
          parent.ajaxService.doGet('/zhuihao/view.mvc',{id:betZhuihaolist.editId},function(res){
            if(res.resultCode == 0){
              var data = res.results[1];
              betAlert.renderThirdTable(data,betZhuihaolist.zhuiStateObj);
            }
          })
        }else{
          layer.alert(res.resultMessage);
        }
      })
    },function () {

    })
  })
  parent.globalAdmin.selectTable(window.name);
  // 更多选项操作
  parent.globalAdmin.showMore('.layui-second-search-condition',window.name)
});



