
var betThirdgame = {
  table:null,
  toolbarHtml:'',
  platformObj:{},
  getGameplatform(){
    var _this = this;
    parent.ajaxService.doGet("/thirdPartyBetRecordsWeb/getThirdPartyPlatform.mvc",null,function(res){
      if(res.resultCode == 0){
        var html='';
        var data = res.results[0];
        _this.platformObj = data;
        for(var i in data){
          html+=`<li class="${i==1 ? 'layui-this' :''}" data-id='${i}'>${data[i]}</li>`
        }
        $(".layui-tab-title").html(html);
      }
    })
  }
}

betThirdgame.getGameplatform();
layui.use(['element','layer'], function(){
  var element = layui.element;
  var layer = layui.layer;
  element.on('tab(third_tab)', function(data){
    var id = $(this).attr("data-id");
    // var page = id == 1 ? "ag" : (id==2 ? 'bb' : 'other');
    // 返回的字段统一，用一个字段;
    $("iframe").attr("src",`./bet-AG.html`)
  });
});



