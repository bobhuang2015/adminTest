
var betOther = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  stateObj:{},
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action = window.name || parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i !='解锁' && i!='增加'){
          editHtml +='<button id="'+i+'" class="layui-btn layui-btn-disabled" lay-event="'+i+'">'+i+'</button>'
        }
        if(i=='解锁'){
          this.hasLock=true;
        }
        if(i=='增加'){
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
      this.toolbarHtml =`<div>${editHtml}<div style="display:inline-block;margin-left:10px;">${otherHtml}</div></div>`;
    }
  },
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util,platformId){
    var arr = [];
    switch (+platformId) {
      case 3:
        arr=[
          { field: 'billNo', title: '投注单号', width: 180, sort: true}
          , { field: 'userName', title: '用户账号', width: 140, sort: true}
          , { title: '投注时间', width:180, sort: true,templet:function(d){return util.toDateString(d.betTime, "yyyy-MM-dd HH:mm:ss")}}
          , { field: 'gametypename', title: '交易额度', width: 140, sort: true}
          , { field: 'gameType', title: '交易类型', width: 140,sort: true}
          , { field: 'gameType', title: '游戏类型', width: 140,sort: true}
        ]
        break;
      case 4:
        arr=[
          { field: 'billNo', title: '投注单号', width: 180, sort: true}
          , { field: 'userName', title: '用户账号', width: 140, sort: true}
          , { field: 'gameType', title: '游戏类型', width: 140,sort: true}
          , { title: '投注时间', width:180, sort: true,templet:function(d){return util.toDateString(d.betTime, "yyyy-MM-dd HH:mm:ss")}}
          , { field: 'betMoney', title: '投注金额', width: 140, sort: true}
          , { field: 'validBetMoney', title: '有效投注额', width: 140, sort: true}
          , { field: 'profitMoney', title: '投注盈亏', width: 140,sort: true}
        ]
        break;
      case 5:
        arr=[
          { field: 'gameCode', title: '牌局编号', width: 180, sort: true}
          , { field: 'userName', title: '用户账号', width: 140, sort: true}
          , { field: 'gameType', title: '游戏类型', width: 140,sort: true}
          , { title: '开始时间', width:180, sort: true,templet:function(d){return util.toDateString(d.betTime, "yyyy-MM-dd HH:mm:ss")}}
          , { title: '结束时间', width:180, sort: true,templet:function(d){return util.toDateString(d.betTime, "yyyy-MM-dd HH:mm:ss")}}
          , { field: 'betMoney', title: '投注金额', width: 140, sort: true}
          , { field: 'validBetMoney', title: '有效投注额', width: 140, sort: true}
          , { field: 'profitMoney', title: '投注盈亏', width: 140,sort: true}
        ]
        break;
      case 6:
        arr=[
          { field: 'billNo', title: '投注单号', width: 180, sort: true}
          , { field: 'userName', title: '用户账号', width: 140, sort: true}
          , { field: 'gameType', title: '状态', width: 140,sort: true}
          , { field: 'gameType', title: '游戏名称', width: 140,sort: true}
          , { title: '投注时间', width:180, sort: true,templet:function(d){return util.toDateString(d.betTime, "yyyy-MM-dd HH:mm:ss")}}
          , { field: 'betMoney', title: '投注金额', width: 140, sort: true}
          , { field: 'validBetMoney', title: '有效投注额', width: 140, sort: true}
          , { field: 'profitMoney', title: '投注盈亏', width: 140,sort: true}
        ]
        break;
      case 7:
        arr=[
          { field: 'billNo', title: '投注单号', width: 180, sort: true}
          , { field: 'userName', title: '用户账号', width: 140, sort: true}
          , { field: 'gameType', title: '状态', width: 140,sort: true}
          , { title: '投注时间', width:180, sort: true,templet:function(d){return util.toDateString(d.betTime, "yyyy-MM-dd HH:mm:ss")}}
          , { field: 'validBetMoney', title: '有效投注额', width: 140, sort: true}
          , { field: 'profitMoney', title: '投注盈亏', width: 140,sort: true}
        ]
        break;
      case 8:
      case 9:
        arr=[
          { field: 'billNo', title: '投注单号', width: 180, sort: true}
          , { field: 'userName', title: '用户账号', width: 140, sort: true}
          , { title: '投注时间', width:180, sort: true,templet:function(d){return util.toDateString(d.betTime, "yyyy-MM-dd HH:mm:ss")}}
          , { field: 'validBetMoney', title: '有效投注额', width: 140, sort: true}
          , { field: 'profitMoney', title: '投注盈亏', width: 140,sort: true}
        ]
        break;
    }
    return arr
  },
  editIdArr:[],
  tableData:[]
}

// betOther.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  betOther.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  var platformId = parent.$(".layui-this").attr("data-id");

  betOther.table.render({
    elem: '#demo'
    , height: 600
    , url: '/thirdPartyBetRecordsWeb/search.mvc' 
    ,toolbar: betOther.toolbarHtml
    , page: true
    , method: 'get'
    , cols: [ betOther.getOptions(util,platformId)],
    where: {
      platform:platformId
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results[0]
      };
      betOther.tableData=res.results;
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
    }
  });
  parent.globalAdmin.checkboxEdit(betOther,window.name)
  
  // 工具栏操作
  betOther.table.on("toolbar(demo)",function(res){
    var checkStatus = betOther.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    switch (res.event) {
      case '增加':
      case '修改':
        var isAdd = res.event == '增加' ? 1 : 0;
        layer.open({
          title:res.event,
          type: 1,
          skin: 'layui-layer-test',
          area: ['600px', '400px'],
          content: htmlTpl.addHtml,
          success:function(){
            var obj={
              "username": isAdd ? '' :data[0].username,
              "bankname": isAdd ? '' :data[0].bankname,
              "branchname":isAdd ? '' :data[0].branchname,
              "accountname":isAdd ? '' :data[0].accountname,
              "accountno":isAdd ? '' :data[0].accountno
            }
            form.val('add', obj)
            form.on('submit(formAdd)',function(submitData){
              var reqUrl = isAdd ? '/betOther/addbetOther.mvc' : '/betOther/updatebetOther.mvc';
              var reqData = isAdd ? submitData.field : Object.assign(submitData.field,{id:data[0].id,userid:data[0].userid});
              parent.ajaxService.doPost(reqUrl,reqData,function(res){
                var msg = res.resultMessage;
                if(res.resultCode==0){
                  betOther.layerCallback(msg);
                  betOther.editIdArr=[];
                }else{
                  layer.msg(msg)
                }
              })
              return false;
            })
          }
        })
      break;
      case '删除':
        layer.confirm("是否删除选中的银行?",{
            btn:['确定','取消']
          },function(){
          var reqData = {
            id:betOther.editIdArr.join()
          }
          parent.ajaxService.doPost("/betOther/deletebetOther.mvc",reqData,function(res){
            if(res.resultCode ==0){
              betOther.layerCallback(res.resultMessage);
              betOther.editIdArr=[];
            }else{
              layer.msg(res.resultMessage);
            }
          })
          },function(index){
            layer.close(index)
          }
        )
      break;
      default:
        // layer.msg("接口文档未完善，需要相应人员支持!")
        break;
    }
  })
  //监听行工具事件
  betOther.table.on('tool(demo)', function(obj){
    var data = obj.data;
    if(obj.event === 'lock'){
      var text = data.locked==0 ? '锁定' : '解锁'; 
      layer.confirm(`是否${text}账号 ${data.username}?`, function(index){
        var reqData={
          userid:data.userid,
          locked:data.locked
        }
        parent.ajaxService.doPost("/betOther/updatebetOtherState.mvc",reqData,function(res){
          if(res.resultCode ==0){
            betOther.layerCallback(res.resultMessage);
          }else{
            layer.msg(res.resultMessage);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    betOther.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
  laydate.render({
    elem: '#start' //指定元素
  });
  laydate.render({
    elem: '#end' //指定元素
  });
});



