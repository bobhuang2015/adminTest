
var vipRecord = {
  table:null,
  toolbarHtml:'',
  typeObj:{},
  once:true,
  getToolbarHtml(){ 
  },
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1  
      }
	  })
  },
  renderHtml(data,ele,form){
    var html='';
    for(var i in data){
      html +=`<option value='${i}'>${data[i]}</option>`
    }
    $(ele).append(html);
    form.render('select');
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var arr=[
      { field: 'orderNumber', title: '订单号', width: 160, sort: true}
      , { field: 'userName', title: '会员账号', width: 120, sort: true}
      , { field: 'money', title: '金额', width: 100, sort: true}
      , { field: 'bonusType', title: '俸禄/晋级奖金', width: 160, sort: true}
      , { field:'sendTime',title: '领取时间', width: 180,sort: true,templet:function(d){return d.sendTime ? util.toDateString(d.sendTime, "yyyy-MM-dd HH:mm:ss") : ''}}
      , { field: 'remark', title: '备注'}
    ]
    return arr
  },
}

layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  vipRecord.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  parent.globalAdmin.renderIntDate(laydate,util)
  
  var topHeight = ~~($(".layui-row").height()+40);
  vipRecord.table.render({
    elem: '#demo'
    , height: `full-${topHeight}`
    , url: '/vipUserRecord/getList.mvc'
    , page: true
    , method: 'get'
    , cols: [ vipRecord.getOptions(util)],
    where: {
      "startTime":$("#start").val(),
      "endTime":$("#end").val()
    }
    , parseData: function (res) {
      if(vipRecord.once){
        vipRecord.typeObj = res.results[1][0];
        vipRecord.renderHtml(vipRecord.typeObj,'#layui-type',form);
        vipRecord.once = !vipRecord.once
      }
      var data = res.results[0];
      data.forEach(v=>{
        v.bonusType = vipRecord.typeObj[v.bonusType]
      })
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": data
      };
      return result
    },
    response: {
      statusCode: '0',

    },
    done: function (res, cur, count) {
    }
  });
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    vipRecord.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



