
var rechargeRecord = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  pageNumber:1,
  tableIns:null,
  tableData:[],
  hasDaochu:false,
  name:'rechargeRecord',
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){
    var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    permision.forEach(v=>{
      if(v.menuName.includes('导出数据')){
        this.hasDaochu=!0;
        $('button[lay-filter="formDaochu"]').show();
      }
    })
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getUrlParam(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); //构造一个含有目标参数的正则表达式对象
    var r = window.location.search.substr(1).match(reg);  //匹配目标参数
    if (r != null) return unescape(r[2]); return null; //返回参数值
  },
  WayObj:{},
  getWay(form){
    var _this = this;
    var p = new Promise(function(resolve,reject){
      parent.ajaxService.doGet("/moneyInRecord/getRechargeRecordWay.mvc",null,function(res){
        if(res.resultCode==0){
          for(var i in res.results[0]){
            var html="";
            _this.WayObj=res.results[0];
            html+=`<option value='${i}'>${res.results[0][i]}</option>`
            $(".rechargeWay").append(html);
            form.render('select');
            resolve(_this.WayObj)
          }
        }else{
          reject(res.resultMessage);
        }
      })
    })
    return p;
  },
  getOptions:function(util,data){
    var arr=[
        { field: 'ordernumber', title: '订单号', width: 180, sort: true,templet:function(d){return `<div lay-event="order" class="layui-table-ordernumber">${d.ordernumber}</div>`}}
      , { field: 'username', title: '用户账号', width: 120,sort: true}
      , { field: 'platformbankaccountname', title: '收款账户', width: 120,sort: true}
      , { field: 'way', title: '充值类型', width: 120, sort: true,templet:function(d){return data[d.way]}}
      , { field: 'amount', title: '充值金额', width: 120, sort: true,templet:function(d){return globalAdmin.formatNum(d.amount.toFixed(3))}}
      , { field: 'fee', title: '手续费', width: 100, sort: true,templet:function(d){return d.fee.toFixed(2)}}
      , { field: 'realRechargeMoney', title: '实际充值金额', width: 140, sort: true,templet:function(d){return globalAdmin.formatNum(d.realRechargeMoney.toFixed(3))}}
      , { field: 'rechargedt', title: '充值时间', width: 180, sort: true,templet:function(d){return util.toDateString(d.rechargedt, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'operator', title: '操作者', width: 120}
      , { field: 'remark', title: '备注'}
    ]
    return arr
  },
  renderTotal(res){
    if (res.data && res.data.length > 0 && res.total){
      var totalHtml = '';
      res.total.forEach((v,k)=>{
        totalHtml+=`<span>${v.rechargeName} : ${globalAdmin.formatNum(v.rechargeMoney)}</span>`
      })
      $('.layui-table-body table').append('<tr class="table-total"><td colspan="50">总量合计:'+totalHtml+'</td></tr>')
    }
  }
}

layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  rechargeRecord.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  globalAdmin.renderRechargeDate(laydate,util)

  var userName = rechargeRecord.getUrlParam('userName',window.location.search);
  if(userName)$(".layui-input[name='username']").val(userName);

  rechargeRecord.getWay(form).then(function(data){
    rechargeRecord.tableIns = rechargeRecord.table.render({
      elem: '#demo'
      , height: 'full-80'
      , url: '/moneyInRecord/search.mvc'
      // ,toolbar: rechargeRecord.toolbarHtml
      , page: true
      , method: 'get'
      , cols: [ rechargeRecord.getOptions(util,data)],
      where: {
        username:$(".layui-input[name='username']").val()
      }
      , parseData: function (res) {
        var result = {
          "code": res.resultCode, 
          "msg": res.resultMessage,
          "count": res.meta.totalRecord,
          "data": res.results[0],
          "total": res.results[0].length > 0 && res.results[1]
        };
        return result
      },
      response: {
        statusCode: '0'
      },
      done: function (res, cur, count) {
        rechargeRecord.pageNumber=cur;
        rechargeRecord.renderTotal(res)
        rechargeRecord.tableData=res.data;
      }
    });
  }).catch(function(error){
    layer.alert(error);
  })
  
  
  rechargeRecord.table.on('tool(demo)', function(obj){
    var data = obj.data;
    var event = obj.event;
    if(event === 'order'){
      parent.ajaxService.doGet('/moneyInRecord/detail.mvc',{ordernumber:data.ordernumber},function(res){
        if(res.resultCode==0){
          var resData=  res.results[0];
          layer.open({
              title:'详情',
              type: 1,
              skin: 'layui-layer-test',
              area: ['700px', '500px'],
              content: htmlTpl.detailHtml,
              success:function(){
                $('.mask-box input').attr('disabled',true);
                var obj={
                  "ordernumber": resData.ordernumber,
                  "username": resData.username,
                  "way": resData.way,
                  "amount": resData.amount,
                  "fee": resData.fee,
                  "rechargedt":  util.toDateString(resData.rechargedt,'yyyy-MM-dd HH:mm:ss'),
                  "operator": resData.operator,
                  "platformbankaccountname": resData.platformbankaccountname,
                  "platformbankaccountnov": resData.platformbankaccountnov,
                  "userbankaccountname": resData.userbankaccountname,
                  "userbankaccountno": resData.userbankaccountno
                }
                form.val('add', obj)
              }
            }
          )
        }else{
          layer.alert(res.resultMessage)
        }
      })
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    delete data.field.isAll
    rechargeRecord.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        },
        done: function (res, cur, count) {
          rechargeRecord.renderTotal(res)
          rechargeRecord.tableData = res.data;
        }
    })
    return false;
  });
  
  // 导出数据
  form.on('submit(formDaochu)', function (data) {
    rechargeRecord.hasDaochu && parent.globalAdmin.exportData(form,data,rechargeRecord)
    return false;
  });
});



