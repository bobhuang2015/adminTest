
var betZhuihaolist = {
  table:null,
  toolbarHtml:'',
  editId:'',
  hasStop:false,
  pageNumber:1,
  zhuiStateObj:{},
  betStateObj:{},
  currentZhuiNo:0,
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){
    var action =window.name ||  globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i == '停止')this.hasStop=true;
      })
    }
    var _this=this;
    this.getState('/getEnumByName.mvc','ZhuiHao_State').then((data)=>{
      if(data == 'load'){
        setTimeout(()=>{
          _this.getState('/getEnumByName.mvc','BetRecord_State')
        },500)
      }
    });
  },
  reloadTable:function(){
    var _this=this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber
      }
	  })
  },
  getState(url,name){
    var _this = this;
    var p = new Promise((resolve,reject)=>{
      parent.ajaxService.doGet(url,{enumName:name},function(res){
        if(res.resultCode == 0){
          if(name=='ZhuiHao_State'){
           _this.zhuiStateObj = res.results[0];
          }else{
            _this.betStateObj = res.results[0];
          }
          resolve('load')
        }
      })
    })
    return p
  },
  renderGametype(data){
    var html='';
    data.forEach((v,k)=>{
      html+=`<option value="${v.id}">${v.name}</option>`
    })
    $(".gameType").append(html);
  },
  renderState(data){
    var html='';
    for(var i  in  data){
      html+=`<option value="${i}">${data[i]}</option>`
    }
    $(".state").append(html);
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var arr=[
      { title: '操作', width: 70,toolbar:'#barDemo'}
      , { field: 'ordernumber', title: '追号单号', width: 160, sort: true,templet:function(d){return '<div class="layui-table-ordernumber" data-id='+d.id+' data-ordernumber='+d.ordernumber+'>'+d.ordernumber+'</div>'}}
      , { field: 'username', title: '用户账号', width: 120, sort: true}
      , { field: 'gametypename', title: '游戏类型', width: 130, sort: true}
      , { field: 'betmoneytotal', title: '投注总额', width: 120,sort: true,templet:function(d){return d.betmoneytotal.toFixed(3)}}
      , { field: 'optdt',title: '下单时间', width:180, sort: true,templet:function(d){return util.toDateString(d.optdt, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'iswinstop',title: '中奖停止', width: 120, sort: true,templet:function(d){return !d.iswinstop ? '否' : '是'}}
      , { title: '剩余/总期数', width: 140,templet:function(d){return d.issuelave + '/' + d.issuecount}}
      , { field: 'stopped',title: '状态', width: 100, sort: true,templet:function(d){return d.stopped == 1 ? '追号中' : '已停止'}}
      , { field: 'uniqueness', title: '最后追号期号', width: 140, sort: true}
      , { title: '停止时间', width: 180 ,templet:function(d){return util.toDateString(d.stopdt, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'remark', title: '备注',  sort: true}
    ]
    return arr
  },
  editIdArr:[],
  tableData:[],
  requestZhuiDetail(id,ordernumber,util){
    parent.ajaxService.doGet('/zhuihao/view.mvc',{id:id},function(res){
      if(res.resultCode == 0){
        var firstTableData = res.results[0];
        var secondTableData = res.results[2];
        var thirdTableData = res.results[1];
        layer.open({
          title:'追号详情',
          type: 1,
          skin: 'layui-layer-test',
          area: ['900px', '700px'],
          content: htmlTpl.detailHtml,
          success:function(){
            betAlert.renderFirstTable(firstTableData,util,ordernumber,'.first-table');
            betAlert.renderSecondTable(secondTableData);
            betAlert.renderThirdTable(thirdTableData,betZhuihaolist.zhuiStateObj);
            }
        })
      }else{
        layer.alert(res.resultMessage)
      }
    })
  }
}

betZhuihaolist.getToolbarHtml();
betZhuihaolist.renderGametype(parent.globalAdmin.gameListArr);
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  betZhuihaolist.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  globalAdmin.renderRechargeDate(laydate,util);
  betZhuihaolist.table.render({
    elem: '#demo'
    , height: 'full-100'
    , url: '/zhuihao/search.mvc'
    ,toolbar: betZhuihaolist.toolbarHtml
    , page: true
    , method: 'get'
    , cols: [ betZhuihaolist.getOptions(util)],
    where: {
      'usernameQuery':1
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode,
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results
      };
      betZhuihaolist.tableData=res.results;
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      betZhuihaolist.pageNumber = cur;
    }
  });

  //监听行工具事件
  betZhuihaolist.table.on('tool(demo)', function(obj){
    var data = obj.data;
    if(obj.event === 'stop'){
      layer.confirm(`是否停止该追号?`, function(index){
        var reqData={
          userid:data.userid,
          id:data.id
        }
        parent.ajaxService.doPost("/zhuihao/stop.mvc",reqData,function(res){
          var msg = res.resultMessage;
          if(res.resultCode ==0){
            betZhuihaolist.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    betZhuihaolist.table.reload('demo',{
        where:data.field,
        page:{
            curr:1
        }
    })
    return false;
  });

  $(document).on('click',".layui-table-ordernumber",function(){
    betZhuihaolist.editId = $(this).attr('data-id');
    var ordernumber = $(this).attr('data-ordernumber');
    betZhuihaolist.requestZhuiDetail(betZhuihaolist.editId,ordernumber,util);
    betZhuihaolist.currentZhuiNo = ordernumber;
  })
  $(document).on('click',".layui-table-zhuihaonumber",function(){
    var zhid = $(this).attr('data-zhid');
    var zhinfoid = $(this).attr('data-zhinfoid');
    var ordernumber = $(this).attr('data-ordernumber');
    parent.ajaxService.doGet('/betrecord/zhuihaoview.mvc',{zhinfoid:zhinfoid,zhid:zhid},function(res){
      if(res.resultCode == 0){
        layer.open({
          title:'追号投注详情',
          type: 1,
          skin: 'layui-layer-test',
          area: ['800px', '600px'],
          content: htmlTpl.zhuiHtml,
          success:function(){
            if(res.results[0].view =='MANYVIEN'){
              var firstTableData = res.results[0].zhuiHao;
              betAlert.renderFirstTable(firstTableData,util,betZhuihaolist.currentZhuiNo,'.zhui-table');
            }else if(res.results[0].view =='view'){
              var data = res.results[0].betRecord;
              var lotteryData = res.results[0].lotteryNums;
              data.status = betZhuihaolist.betStateObj[data.state];
              betAlert.renderTouHtml(data,lotteryData,util)
            }
          }
        })
      }
    })
  })
  // 取消单条追号;
  $(document).on('click',".layui-cancle",function(){
    var id = $(this).attr('data-id');
    layer.confirm('请问是否取消追号？',{btn: ['确定', '取消']},function (btn1) {
      layer.close(btn1);
      parent.ajaxService.doGet('/zhuihao/cancel.mvc',{zhuiHaoInfoId:id},function(res){
        if(res.resultCode == 0){
          parent.ajaxService.doGet('/zhuihao/view.mvc',{id:betZhuihaolist.editId},function(res){
            if(res.resultCode == 0){
              var data = res.results[1];
              betAlert.renderThirdTable(data,betZhuihaolist.zhuiStateObj);
            }
          })
        }else{
          layer.alert(res.resultMessage);
        }
      })
    },function () {

    })
  })
  //追号详情
  $(document).on('click','.zhuiDetail',function(){
    var id = $(this).attr('data-id');
    var ordernumber = $(this).attr('data-ordernumber');
    betZhuihaolist.requestZhuiDetail(id,ordernumber,util);
  })
});



