
var setSingle = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  getToolbarHtml(){ 
    var action = window.name;
    var permision = parent.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i !='解锁' && i!='增加'){
          editHtml +='<button id="'+i+'" class="layui-btn layui-btn-disabled" lay-event="'+i+'">'+i+'</button>'
        }
        if(i=='解锁'){
          this.hasLock=true;
        }
        if(i=='增加'){
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${editHtml}<div style="display:inline-block;margin-left:10px;">${otherHtml}</div></div>`;
  },
  editId:'',
  getSingleData(form){
    var _this = this;
    parent.ajaxService.doGet("/lotteryConfig/getSingledInfo.mvc",null,function(res){
      if(res.resultCode==0){
        var data = res.results[0];
        _this.editId = data.id;
        form.val("test",{
          "maxmoney"  : data.maxmoney,
          "maxmoney2" : data.maxmoney2,
          "maxmoney3" : data.maxmoney3,
          "maxmoney4" : data.maxmoney4,
          "scales"    : data.scales,
          "scales2"   : data.scales2,
          "scales3"   : data.scales3,
          "scales4"   : data.scales4
        })
      }
    })
  }
}

// setSingle.getToolbarHtml();
layui.use([ 'form', 'layer'], function () {
  var laydate = layui.laydate;
  setSingle.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  setSingle.getSingleData(form);
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    var reqData = Object.assign(data.field,{id:setSingle.editId})
    parent.ajaxService.doPost("/lotteryConfig/updateSingledInfo.mvc",reqData,function(res){
      layer.msg(res.resultMessage);
    })
    return false;
  });
});



