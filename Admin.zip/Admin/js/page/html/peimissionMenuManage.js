(function () {
    init()
})()

function init() {
    parent.ajaxService.doGet("/menu/getRootMenu.mvc", null, function (res) {
        var data = [];
        for (var key in res) {
            var item = res[key]
            for (var i = 0; i < item.length; i++) {
                var item1 = item[i]
                data.push(item1)
            }
        }
        var aa = render(data)
        $('#permission_menu_manage').html(aa)

        layui.use('layer', function () { //独立版的layer无需执行这一句
            var $ = layui.jquery, layer = layui.layer; //独立版的layer无需执行这一句

            $('.menu-tree-main dt span').on('click',function () {
                $(this).parent().siblings().toggle()
                var display = $(this).parent().siblings('dl').css('display')
                if (display === 'none'){
                    $(this).siblings('b').removeClass().addClass("menu-folder-close")
                }else {
                    $(this).siblings('b').removeClass().addClass("menu-folder-open")
                }
            })
            $('.menu-tree-main dt b').on('click',function () {
                $(this).parent().siblings().toggle()
                var display = $(this).parent().siblings('dl').css('display')
                if (display === 'none'){
                    $(this).removeClass().addClass("menu-folder-close")
                }else {
                    $(this).removeClass().addClass("menu-folder-open")
                }
            })

            $('.menu-del').on('click',function () {
                var _this = $(this)
                var name = this.name || ''
                var id = this.id
                layer.confirm('您确定要删除【' + name + '】菜单(包含下级)吗？', {
                    btn: ['确定', '取消'] //按钮
                }, function (btn1) {  // 确定
                    parent.ajaxService.doPost('/menu/delete.mvc', {id: id}, function (res) {
                        if (String(res.resultCode) === '0'){
                            _this.parent().parent('dl').remove()
                        }
                        layer.close(btn1);
                        layer.msg(res.resultMessage);
                    })
                }, function () { // 取消

                });
            })
            $('.menu-xiugai').on('click',function () {
                var _this = $(this)
                var data = this.name.split('-');
                var url = _this.attr('data-url');
                layer.open({
                    type: 1,
                    title: '修改',
                    shadeClose: true,
                    shade: 0.8,
                    area: ['500px', '380px'],
                    content: producedXiugai(data,url),
                    btn: ['确定', '取消'],
                    success:function(){
                        $('.menu-sort').keyup(function(){
                            $(this).val($(this).val().replace(/^(0+)|[^\d]+/g,''))
                        })
                    },
                    btn1: function(btn1){
                        data[0] = $('.menu-number').val() // 菜单编号
                        data[4] = $('.menu-name').val() // 菜单名称
                        url = $('.menu-url').val() || 'undefined' // 菜单地址
                        data[5] =  $('.menu-leaf').val() // 是否有子级 和 新增按钮
                        data[6] =  $('.menu-type').val() // 菜单类型
                        data[7] =  $('.menu-sort').val() // 菜单排序
                        var param = {
                            menuName:data[4],
                            url:url,
                            menuCode:data[0],
                            isLeaf:data[5],
                            type:data[6],
                            upperId:data[1],
                            id:data[3],
                            sortflag:data[7]
                        }
                        var dataXiugai = data.join('-')
                        parent.ajaxService.doPost('/menu/update.mvc',param,function (res) {
                            if (String(res.resultCode) === '0'){
                                _this.attr('name',dataXiugai)
                                _this.siblings('span').html(data[4])
                                if (String(data[5]) === 'false'){
                                    _this.siblings('.menu-add').hide()
                                }else {
                                    if (_this.siblings('.menu-add').length <= 0) {
                                        init() // 成功之后重新加载页面
                                    }else {
                                        _this.siblings('.menu-add').show()
                                    }
                                }
                            }
                            layer.close(btn1);
                            layer.msg(res.resultMessage);
                        })
                    },
                    btn2: function(btn2){
                        layer.close(btn2);
                    }
                });
            })

            $('.menu-add').on('click',function () {
                var _this = $(this)
                var id = this.id
                // var pName = this.name
                layer.open({
                    type: 1,
                    title: '新增',
                    shadeClose: true,
                    shade: 0.8,
                    area: ['500px', '380px'],
                    content: producedAdd(),
                    btn: ['确定', '取消'],
                    success:function(){
                        $('.menu-add-sort').keyup(function(){
                            $(this).val($(this).val().replace(/^(0+)|[^\d]+/g,''))
                        })
                    },
                    btn1: function(btn1){
                        var name = $('.menu-add-name').val()
                        var url = $('.menu-add-url').val()
                        var menuCode = $('.menu-add-number').val()
                        var leaf = $('.menu-add-leaf').val()
                        var type = $('.menu-add-type').val()
                        var sort = $('.menu-add-sort').val()
                        if (String(name).length <= 0){
                            layer.msg('请输入菜单名称');
                            return
                        }
                        if (String(sort).length <= 0){
                            layer.msg('请输入菜单排序');
                            return
                        }
                        if ((/^(\d+)$/g).test(sort) === false){
                            layer.msg('菜单排序只能输入数字');
                            return
                        }
                        if (menuCode.length <= 0){
                            layer.msg('请输入菜单编号');
                            return
                        }
                        if ((/^([a-zA-Z]+)$/g).test(menuCode) === false){
                            layer.msg('菜单编号只能输入字母');
                            return
                        }

                        var param = {
                            menuName:name,
                            url:url,
                            menuCode:menuCode,
                            isLeaf:leaf,
                            type:type,
                            upperId:id,
                            sortflag:sort
                        }
                        parent.ajaxService.doPost('/menu/add.mvc',param,function (res) {
                            if (String(res.resultCode) === '0'){
                                init() // 成功之后重新加载页面
                            }
                            layer.close(btn1);
                            layer.msg(res.resultMessage);
                        })
                    },
                    btn2: function(index){
                        layer.close(index);
                    },
                });
            })
        });
    })
}


function render(treeJson) {
    var ul = "";
    treeJson.forEach(function (item, i) {
        var li = "<dl class='menu-floor menu-floor-" + item.floor + "'><dt>"
        if (item.childrens && item.childrens.length > 0) {
            li += '<b class="menu-folder-close"></b>'
        } else {
            // li += '<b class="menu-folder-close">-</b>'
        }
        li += "<span class='tree-title'>" + item.menuName + "</span>";
        li += '<button class="menu-xiugai" ' +
            'name="' + item.menuCode + '-' + item.parentId + '-' + item.parentName + '-' + item.id + '-' +
            item.menuName+'-' +item.leaf + '-' +item.type+'-'+item.sortflag+'" data-url="'+item.url+'">修改</button>'
        if (String(item.leaf) === 'true') {
            li += '<button class="menu-add" ' +
                'id="' + item.id + '" name="'+item.menuName+'">新增</button>'
        }
        li += '<button  class="menu-del" id="' + item.id + '" name="' + item.menuName + '">删除</button>'
        li += "</dt>"
        if (item.childrens) {
            li += (render(item.childrens))
        }
        ul += (li + '</dl>');
    })
    return ul
}

function producedAdd() {
    var html = '<div class="menu-prompt menu-xiugai-prompt">'
    html +=  '<ul><li class="menu-first">菜单名称:</li><li>' +
            '<input type="text" class="menu-add-name">' +
            '</li></ul>'
    html +=  '<ul><li class="menu-first">菜单排序:</li><li>' +
        '<input type="text" class="menu-add-sort">' +
        '</li></ul>'
    html +=  '<ul><li class="menu-first">菜单地址:</li><li>' +
        '<input type="text" class="menu-add-url">' +
        '</li></ul>'
    html +=  '<ul><li class="menu-first">菜单编码<span>(名称首字母)</span>:</li><li>' +
        '<input type="text" class="menu-add-number">' +
        '</li></ul>'
    html +=  '<ul><li class="menu-first">是否为父级菜单:</li><li>' +
        '<select class="menu-add-leaf">' +
        '<option value="true">是</option>' +
        '<option value="false">否</option>' +
        '</select>'+
        '</li></ul>'
    html +=  '<ul><li class="menu-first">菜单类型:</li><li>' +
        '<select class="menu-add-type">' +
        '<option value="BUTTON" >BUTTON按钮</option>' +
        '<option value="MENU">MENU菜单</option>' +
        '</select>'+
        '</li></ul>'
    html += '</div>'
    return html
}

function producedXiugai(data,url) {
    var html = '<div class="menu-prompt menu-xiugai-prompt">'

    if (String(data[2]) !== 'undefined') {
        html +=  '<ul><li class="menu-first">上级菜单:</li><li>' +
                '<input type="text" readonly class="menu-parent" value="' +(String(data[2]) === 'undefined'?data[4]:data[2]) + '">' +
                '</li></ul>'
    }

    html +=
        '<ul>' +
        '<li class="menu-first">菜单名称:</li>' +
        '<li>' +
        '<input type="text"  class="menu-name" value="' + data[4] + '">' +
        '</li>' +
        '</ul>' +
        '<ul>' +
        '<li class="menu-first">菜单编号<span>(名称首字母)</span>:</li>' +
        '<li>' +
        '<input type="text"  class="menu-number" value="' + data[0] + '">' +
        '</li>' +
        '</ul>' +
        '<ul>' +
        '<li class="menu-first">菜单排序:</li>' +
        '<li>' +
        '<input type="text"  class="menu-sort" value="' + (String(data[7]) === 'undefined'?'':data[7]) + '">' +
        '</li>' +
        '</ul>' +
        '<ul>' +
        '<li class="menu-first">菜单地址:</li>' +
        '<li>' +
        '<input type="text"  class="menu-url" value="' + (String(url) === 'undefined'?'':url) + '">' +
        '</li>' +
        '</ul>' +
        '<ul>' +
        '<li class="menu-first">是否为父级菜单:</li>' +
        '<li>' +
        '<select class="menu-leaf">' +
        '<option value="true" ' + (String(data[5]) === 'true'?'selected':'') + '>是</option>' +
        '<option value="false" ' + (String(data[5]) === 'false'?'selected':'') + '>否</option>' +
        '</select>'+
        '</li>' +
        '</ul>' +
        '<ul>' +
        '<li class="menu-first">菜单类型:</li>' +
        '<li>' +
        '<select class="menu-type">' +
        '<option value="BUTTON" ' + ((String(data[6]) === 'BUTTON')?'selected':'') + '>BUTTON按钮</option>' +
        '<option value="MENU" ' + ((String(data[6]) === 'MENU')?'selected':'') + '>MENU菜单</option>' +
        '</select>'+
        '</li>' +
        '</ul>' +
        '</div>'
    return html
}
