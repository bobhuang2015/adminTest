
var interestDetail = {
  id:'',
  hasData:0,
  init(form){
    var _this = this;
    parent.ajaxService.doGet('/interestTreasure/config/search.mvc',null,function(res){
      if(res.resultCode ==0){
        var isAdd = res.results.length ==0 ? 1 : 0;
        _this.hasData = !isAdd && 1;
        var data = !isAdd && res.results[0];
        _this.id = data && data.id;
        var obj = {
          'effectiveTime':isAdd ? '' : data.effectiveTime/3600,
          'extractLimit':isAdd ? '' : data.extractLimit,
          'grantTime':isAdd ? '' : data.grantTime,
          'minAmount':isAdd ? '' : data.minAmount,
          'rate':isAdd ? '' : data.rate,
          'status':isAdd ? '1' : data.status
        }
        form.val('demo',obj)
      }
    })
  }
}
layui.use(['form', 'layer','laydate'], function () {
  var form = layui.form;
  var layer = layui.layer;
  var laydate = layui.laydate;
  interestDetail.init(form);
  form.on('submit(formDemo)', function (data) {
    $('button[lay-filter="formDemo"]').addClass('layui-btn-disabled');
    var index = layer.load(2);
    var submitData = data.field;
    submitData.status = submitData.status == 'on' ? '1' :'0';
    submitData.effectiveTime = submitData.type=='1' ? +submitData.effectiveTime * 60 *60 : +submitData.effectiveTime *60 *60 * 24
    delete submitData.type;
    var reqUrl = interestDetail.hasData ? '/interestTreasure/config/update.mvc' : '/interestTreasure/config/insert.mvc';
    var reqData = interestDetail.hasData ? Object.assign(submitData,{id:interestDetail.id}) : submitData;
    parent.ajaxService.doPost(reqUrl,reqData,function(res){
      var msg = res.resultMessage;
      if(res.resultCode == 0){
        layer.alert(msg,function(){
          location.reload(true)
        })
      }else{
        layer.alert(msg,function(){
          layer.closeAll();
        })
        $('button[lay-filter="formDemo"]').removeClass('layui-btn-disabled');
      }
    })
    return false;
  });

  lay('.layui-set-date').each(function(){
    laydate.render({
      elem: this
      ,trigger: 'click'
      ,type: "time"
      ,btns: ['clear', 'confirm']
    });
  });

  $(".layui-tikuan").focus(function() {
    layer.tips('利率 * 倍数', this, {
      tips: [1, "#4794ec"],
      time: 40e3
    });
  }).mouseout(function(){
      layer.closeAll();
  })
});



