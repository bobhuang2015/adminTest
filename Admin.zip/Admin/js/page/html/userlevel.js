
(function(){
  var userLevel = {
    table:null,
    form:null,
    toolbarHtml:'',
    pageNumber:1,
    globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
    getToolbarHtml(){
      var action =window.name ||  parent.globalAdmin.getUrlParam('code');
      var permision = this.globalAdmin.menuObj[action].permision;
      var otherHtml = "";
      var editHtml = "";
      if(permision){
        permision.forEach((v,k)=>{
          var i = v.menuName;
          if(i !='会员分层' && i !='新增'){
            editHtml +='<button id="'+i+'" class="layui-btn layui-btn-disabled" lay-event="'+i+'">'+i+'</button>'
          }else{
            otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
          }
        })
      }
      this.toolbarHtml =`<div>${editHtml}<div style="display:inline-block;margin-left:10px;vertical-align: top;">${otherHtml}</div></div>`;//toolbar 跟表格联动
    },
    reloadTable:function(){
      var _this = this;
      this.table.reload('demo',{
        page:{
          curr:_this.pageNumber
        }
      })
    },
    layerCallback(msg){
      var _this = this;
      layer.alert(msg,function(){
        layer.closeAll();
        _this.reloadTable();
      })  
    },
    getOptions:function(util){
      var arr=[
        {type:'checkbox'}
        , { field: 'name', title: '层级名称', width: 100}
        , { field: 'beginregdt', title: '注册时间(始)', width: 180, sort: true,templet:function(d){return util.toDateString(d.beginregdt, "yyyy-MM-dd")} }
        , { field: 'endregdt', title: '注册时间(末)', width: 180,sort: true,templet:function(d){return util.toDateString(d.endregdt, "yyyy-MM-dd")}}
        , { field: 'moneyincount', title: '充值次数', width: 120, sort: true}
        , { field: 'moneyintotal', title: '充值总额', width: 120, sort: true,templet:function(d){return d.moneyintotal.toFixed(3)}}
        , { field: 'moneyinmax', title: '最大充值', width: 120, sort: true,templet:function(d){return d.moneyinmax.toFixed(3)}}
        , { field: 'moneyoutcount', title: '提现次数', width: 120, sort: true}
        , { field: 'moneyouttotal', title: '提现总额', width: 120, sort: true,templet:function(d){return d.moneyouttotal.toFixed(3)}}
        , { field: 'usercount', title: '会员数', width: 120, sort: true}
        , { field: 'remark', title: '备注' }
      ]
      return arr
    },
    editIdArr:[],
    tableData:[]
  }
  
  userLevel.getToolbarHtml();
  layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
    var laydate = layui.laydate;
    userLevel.table = layui.table;
    var form = layui.form;
    var layer = layui.layer;
    var util = layui.util;
    var topHeight = ~~($(".layui-row").height()+40);
    userLevel.table.render({
      elem: '#demo'
      , height: `full-${topHeight}`
      , url: '/userLevel/queryList.mvc'
      ,toolbar: userLevel.toolbarHtml
      ,defaultToolbar:[]
      , page:true
      , method: 'get'
      , cols: [ userLevel.getOptions(util)],
      where: {}
      , parseData: function (res) {
        if(userLevel.isOnce){
          form.render("select",'test');
          userLevel.isOnce=false;
        }
        var result = {
          "code": res.resultCode,
          "msg": res.resultMessage,
          "count": res.meta.totalRecord,
          "data": res.results
        };
        return result
      },
      response: {
        statusCode: '0'
      },
      done: function (res, cur, count) {
        userLevel.pageNumber = cur;
        userLevel.editIdArr=[];
        $('.layui-table-tool-temp > button').addClass('layui-btn-disabled');
      }
    });
    parent.globalAdmin.checkboxEdit(userLevel,window.name)
    // userLevel.checkboxEdit();
    // 工具栏操作
    userLevel.table.on("toolbar(demo)",function(res){
      var checkStatus = userLevel.table.checkStatus(res.config.id);
      var data = checkStatus.data;
      switch (res.event) {
        case '新增':
        case '修改层级':
          var isAdd = res.event == '新增' ? 1 : 0;
          layer.open({
            title:res.event,
            type: 1,
            skin: 'layui-layer-test',
            area: ['780px', '560px'],
            content: htmlTpl.addHtml,
            success:function(){
              var obj={
                "moneyincount": isAdd ? 0 :data[0].moneyincount,
                "moneyintotal": isAdd ? 0 :data[0].moneyintotal,
                "moneyinmax":isAdd ? 0 :data[0].moneyinmax,
                "moneyoutcount":isAdd ? 0 :data[0].moneyoutcount,
                "moneyouttotal":isAdd ? 0 :data[0].moneyouttotal,
                "SingleMinTxAmount":isAdd ? 0 :data[0].singleMinTxAmount,
                "SingleMaxTxAmount":isAdd ? 0 :data[0].singleMaxTxAmount,
                "everyDayMaxTxNum":isAdd ? 0 :data[0].everyDayMaxTxNum,
                "everyDayMaxTxAmount":isAdd ? 0 :data[0].everyDayMaxTxAmount
              }
              if(!isAdd){
                Object.assign(obj,{
                  name:data[0].name,
                  beginregdt: util.toDateString(data[0].beginregdt, "yyyy-MM-dd"),
                  endregdt: util.toDateString(data[0].endregdt, "yyyy-MM-dd"),
                  remark:data[0].remark
                })
              }
              form.val('add', obj);
              laydate.render({
                elem:'#begin'
              })
              laydate.render({
                elem:'#end'
              })
              form.on('submit(formAdd)',function(submitData){
                var reqUrl = isAdd ? '/userLevel/addUserLevel.mvc' : '/userLevel/updateLevelAndLimit.mvc';
                var reqData = isAdd ? submitData.field : Object.assign(submitData.field,{id:data[0].id});
                parent.ajaxService.doPost(reqUrl,reqData,function(res){
                  var msg = res.resultMessage;
                  if(res.resultCode==0){
                    userLevel.layerCallback(msg);
                    if(isAdd)globalAdmin.getRoleAndLevel();
                    if(!isAdd)userLevel.editIdArr=[];
                  }else{
                    layer.msg(msg)
                  }
                })
                return false;
              })
            }
          })
        break;
        case '删除':
          layer.confirm("是否删除选中的层级?",{
              btn:['确定','取消']
            },function(){
            var reqData = {
              ids:userLevel.editIdArr.join()
            }
            parent.ajaxService.doPost("/userLevel/deleteLevelBatch.mvc",reqData,function(res){
              if(res.resultCode ==0){
                userLevel.layerCallback(res.resultMessage);
                globalAdmin.getRoleAndLevel();
                userLevel.editIdArr=[];
              }else{
                layer.msg(res.resultMessage);
              }
            })
            },function(index){
              layer.close(index)
            }
          )
        break;
        case '平台提现银行':
        case '线下充值银行':
        var isTX = res.event=='平台提现银行' ? !0 : 0;
          layer.open({
            title:res.event,
            type: 1,
            skin: 'layui-layer-test',
            area: ['960px', isTX ? '560px' : '500px'],
            content: htmlTpl.txBankHtml,
            success:function(){
              !isTX && ($('.mask-box').addClass('recharge-box'));
              var reqUrlObj ={
                list:isTX ? "/userLevel/withdrawalsBankTX.mvc" : "/userLevel/bankLineCZ.mvc",
                set : isTX ? "/userLevel/platformbanksetting.mvc" : "/userLevel/linebanksetting.mvc",
                reqKey: isTX ? 'platformBankIds' : 'lineBankIds'
              } ;
              parent.ajaxService.doGet(reqUrlObj.list,{id:data[0].id},function(res){
                if(res.resultCode==0){
                  var bankList = res.results[0];
                  var html = '';
                  bankList.forEach((v,k)=>{
                    html +=`<input type="checkbox" name="like[${v.id}]" title="${v.name ? v.name : v.payName}" value="${v.id}" lay-skin="primary" class="bank-input">`
                  })
                  $(".bank-list").html(html);
                  var obj={id:data[0].id,name:data[0].name};
                  bankList.forEach(function(v,k){
                    if(v.ischeck)Object.assign(obj,{['like['+v.id+']']:true})
                  })
                  form.val('txBank',obj)
                  form.render('checkbox','txBank')
                }
              })
              // form.on('checkbox(all)', function(data){
              //   if(data.elem.checked){
              //     $('.bank-input').prop("checked",true);
              //     form.render('checkbox');
              //   }else{
              //     $('.bank-input').prop("checked",false);
              //     form.render('checkbox');
              //   }
              // });  
              $(document).on('click','.layui-all',function(){
                $('.bank-input').prop("checked",true);
                form.render('checkbox');
                return false;
              })
              form.on('submit(txBank)',function(submitData){
                var arr = [];
                for(var i in submitData.field){
                  if(i !='name' && i!="all"){
                    arr.push(submitData.field[i])
                  }
                }
                var reqData = {
                  id: data[0].id,
                  [reqUrlObj.reqKey]:arr.join()
                }
                if(arr.length==0 && isTX){
                  layer.msg("请选择需要的平台提现银行")
                  return false;
                }
                parent.ajaxService.doPost(reqUrlObj.set,reqData,function(res){
                  if(res.resultCode==0){
                    userLevel.layerCallback(res.resultMessage);
                    userLevel.editIdArr=[];
                  }else{
                    layer.msg(res.resultMessage);
                  }
                })
                return false;
              })
            }
          })
        break;
        case '充值平台':
          layer.open({
            title:res.event,
            type: 1,
            skin: 'layui-layer-test',
            area: ['880px', '350px'],
            content: htmlTpl.rechargePFHtml,
            success:function(){
              parent.ajaxService.doGet("/userLevel/bankandbaofoo.mvc",{id:data[0].id},function(res){
                if(res.resultCode==0){
                  var rechargeList = res.results[0];
                  var html = '';
                  var selectHtml = '';
                  rechargeList.forEach((v,k)=>{
                    html +=`<input type="checkbox" name="baofu[${v.id}]" title="${v.descript}-${v.merchantTypeName}" value="${v.id}" lay-skin="primary">`
                    selectHtml+=`<option value="${v.id}">${v.merchantTypeName}</option>`
                  })
                  $(".recharge-list").html(html);
                  $(".shop-list").html(selectHtml);
  
                  var obj={id:data[0].id,name:data[0].name,selectId:''};
                  rechargeList.forEach(function(v,k){
                    if(v.ischeck)Object.assign(obj,{['baofu['+v.id+']']:true})
                  })
                  form.val('rechargePF',obj)
                  form.render('checkbox','rechargePF');
                }
              })
              // 选择商户去掉 这里要去道 0903
              // form.on('select(shop)', function(selectData){
              //   var shopHtml = '';
              //   if(!selectData.value)return;
              //   parent.ajaxService.doGet("/userLevel/getbaofubank.mvc",{baofuid:selectData.value,userlevelid:data[0].id},function(res){
              //     if(res.resultCode==0){
              //       var baofuList = res.results[0];
              //       var html = '';
              //       baofuList.forEach((v,k)=>{
              //         html +=`<div class="baofu-div"><input type="checkbox" name="bank[${v.id}]" value="${v.id}&${v.name}" lay-skin="primary"><img src="${parent.globalAdmin.hostUrl}/resources${v.icon}"></div>`
              //       })
              //       $(".rechargeBank-list").html(html);
  
              //       var obj={};
              //       baofuList.forEach(function(v,k){
              //         if(v.ischeck)Object.assign(obj,{['bank['+v.id+']']:true})
              //       })
              //       form.val('rechargePF',obj)
              //       form.render('checkbox','rechargePF')
              //     }
              //   })
              // })
              form.on('submit(rechargePF)',function(submitData){
                var baofuArr = [];
                // var bankArr = [];
                // var nameArr = [];
                for(var i in submitData.field){
                  if(i.indexOf("baofu")>-1){
                    baofuArr.push(submitData.field[i])
                  }
                  // if(i.indexOf("bank[")>-1){
                  //   let arr = submitData.field[i].split("&")
                  //   bankArr.push(arr[0]);
                  //   nameArr.push(arr[1]);
                  // }
                }
                var reqData = {
                  id: data[0].id,
                  baoFooMerchantIds:baofuArr.join(),
                  // baoFooid:submitData.field.selectId,
                  // baofuid:submitData.field.selectId,
                  // baoFooMerchantid:baofuArr,
                  // bankid:bankArr,
                  // baoFooBankIds:bankArr.join(),
                  // baoFooBankNames:nameArr.join()
                }
                if(baofuArr.length==0){
                  layer.msg("请选择充值银行!")
                  return false;
                }
                parent.ajaxService.doPost('/userLevel/bankandbaofoosetting.mvc',reqData,function(res){
                  if(res.resultCode==0){
                    userLevel.layerCallback(res.resultMessage);
                    userLevel.editIdArr=[];
                  }
                })
                return false;
              })
            }
          })
        break;
        case '会员分层':
          parent.globalAdmin.showLayer('会员分层',`./html/user-info.html?makeLevel=true&permision=iframe_12&time=${+new Date()}`);
        break;
        case '修改限制':
          layer.open({
            title:res.event,
            type: 1,
            skin: 'layui-layer-test',
            area: ['700px', '350px'],
            content: htmlTpl.limitHtml,
            success:function(){
              var inputObj={
                "moneyinoncemin":0,
                "moneyinoncemax":0
              }
              var limitList=[];
              parent.ajaxService.doGet("/userLevel/getUserLevelToOpenLimit.mvc",{userlevelid:data[0].id},function(res){
                if(res.resultCode==0){
                  limitList = res.results[0];
                  var selectHtml = '';
                  limitList.forEach((v,k)=>{
                    selectHtml+=`<option value="${v.baofuid}">${v.thirdname}</option>`
                  })
                  $(".limit-list").html(selectHtml);
                  inputObj.moneyinoncemin = limitList[0].moneyinoncemin;
                  inputObj.moneyinoncemax = limitList[0].moneyinoncemax;
                  form.render('select','limit');
                  form.val("limit",inputObj);
                }
              })
  
              var index=0;
              inputChange();
              function inputChange(){
                $(".money-min").on('change',function(){
                  limitList[index].moneyinoncemin= + $(".money-min").val()
                })
                $(".money-max").on('change',function(){
                  limitList[index].moneyinoncemax= + $(".money-max").val()
                })
              }
              form.on('select(limit)', function(selectData){
                index = limitList.findIndex((v)=> v.baofuid== selectData.value);
                inputObj.moneyinoncemin = limitList[index].moneyinoncemin;
                inputObj.moneyinoncemax = limitList[index].moneyinoncemax;
                form.val("limit",inputObj);
                inputChange();
              })
              form.on('submit(limit)',function(submitData){
                var reqStr = 'Thirdlimit='+JSON.stringify(limitList);
                parent.ajaxService.doPost("/userLevel/updateLevelLimit.mvc",reqStr,function(res){
                  if(res.resultCode==0){
                    if(res.resultCode==0){
                      userLevel.layerCallback(res.resultMessage);
                      userLevel.editIdArr=[];
                    }else{
                      layer.msg(res.resultMessage);
                    }
                  }
                })
                return false;
              })
            }
          })
        break;
        default:
          // layer.msg("接口文档未完善，需要相应人员支持!")
          break;
      }
    })
    parent.globalAdmin.selectTable(window.name);
  });
})()



