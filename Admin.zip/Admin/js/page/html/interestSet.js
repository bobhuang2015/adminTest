
var interestSet = {
  table:null,
  index:999999,
  statusObj:{
    '0':'转入中',
    '1':'已转入',
    '2':'已转出',
    '3':'已撤回'
  },
  getOptions:function(id,util){
    var arr = [];
    var _this =this;
    switch (id) {
      case 'login':
         arr=[
          { field: 'orderNumber', title: '订单号', width: 160, sort: true}
          , { field: 'userName', title: '用户名', width: 120,sort: true}
          , { field: 'effectiveTime', title: '时间', width: 180,sort: true,templet:function(d){return util.toDateString(d.effectiveTime, "yyyy-MM-dd HH:mm:ss")}}
          , { field: 'transAmount', title: '金额', width: 220, sort: true}
          , { field: 'currentAmount', title: '利息宝余额', width: 180, sort: true}
          , { field: 'status', title: '状态',sort: true,templet:function(d){return _this.statusObj[d.status]}}
        ]
        break;
      case 'check':
        arr=[
          { field: 'userName', title: '用户名', width: 120,sort: true}
          , { field: 'earningsTime', title: '时间', width: 180,sort: true,templet:function(d){return util.toDateString(d.earningsTime, "yyyy-MM-dd HH:mm:ss")}}
          , { field: 'earningsAmount', title: '收益', width: 220, sort: true,templet:function(d){return '+'+d.earningsAmount}}
          , { field: 'accumulateEarnings', title: '累计收益', width: 180, sort: true}
          , { field: 'settlementAmount', title: '利息宝余额', sort: true}
          , { field: 'amount', title: '利息宝最新余额', width: 180, sort: true}
        ]
    }
    return arr
  }
}

layui.use(['laydate', 'table', 'form', 'layer','util','element'], function () {
  var laydate = layui.laydate;
  interestSet.table = layui.table;
  var form = layui.form;
  var util = layui.util;
  var element = layui.element;
  var topHeight = ~~($(".layui-row").height()+40);
  submitTable('login');
  
  var isCheck=0;
  var isSet =0;
  var reqUrl = '/interestTreasure/trans/search.mvc';
  interestSet.table.render(getOptions('login',reqUrl,util))
  
  element.on('tab(tab_box)', function (data) {
    $(document).resize()
    
    if( data.index == 1 && !isCheck){
      isCheck=!0;
      submitTable('check');
      interestSet.table.render(getOptions('check','/interestTreasure/earnings/search.mvc',util));
    }else if(data.index ==2 && !isSet){
      isSet = !isSet;
      $('#layui-set').append(`<iframe src="./interest-setDetail.html" frameborder="0" style="width:100%;height:100vh;"></iframe>`)
    }
  });

  function getOptions(id,reqUrl,util){
    var obj={
      elem: `#${id}`
      , height: `full-140`
      , url: reqUrl 
      , page: true
      , method: 'get'
      , cols: [interestSet.getOptions(id,util)],
      where: {
        "startTime":$('.layui-start').val(),
        "endTime":$('.layui-end').val()
      }
      , parseData: function (res) {
        var result = {
          "code": res.resultCode, 
          "msg": res.resultMessage,
          "count": res.meta.totalRecord,
          "data": res.results
        };
        return result
      },
      response: {
        statusCode: '0'
      },
      done: function (res, cur, count) {
      }
    }
    return obj
  }

  
  
  function submitTable(id){
    laydate.render({
      elem: `#start${id}`
      ,value:  util.toDateString(new Date(),'yyyy-MM-dd')
      ,btns: ['clear', 'confirm']  
    });
    laydate.render({
      elem: `#end${id}`
      ,value:  util.toDateString(new Date().getTime()+1000*60*60*24,'yyyy-MM-dd')
      ,btns: ['clear', 'confirm'] 
    });
    form.on('submit(form'+id+')', function (data) {
      interestSet.table.reload(`${id}`,{
          where:data.field,
          page:{
              curr:1  
          }
      })
      return false;
    });
  }
  $(document).on('click','.layui-set',function(){
    var obj={
      'title':'利息设置',
      'url':'html/interest-setDetail.html'
    }
    parent.tab.tabAdd(obj.title, obj.url, interestSet.index,'');
    parent.tab.tabChange( interestSet.index);
    interestSet.index++;
  })
});



