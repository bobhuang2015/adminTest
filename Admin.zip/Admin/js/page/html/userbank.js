
var userBank = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  hasSet:false,
  hasDel:false,
  pageNumber:1,
  bankList:[],
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    var obj={
      '解锁':'hasLock',
      '修改':'hasSet',
      '删除':'hasDel'
    }
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i!='新增'){
          this[obj[i]]=true;
        }else{
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${otherHtml}</div>`;//toolbar 跟表格联动
  },
  getBankList:function(name,form,obj){
    var _this = this;
    parent.ajaxService.doGet('/userBank/getUserBankList.mvc',{username:name},function(res){
      if(res.resultCode ==0){
        var data = res.results;
        if(data.length !=0){
          obj.username=name;
          _this.renderHtml('.layui-bankList',data,form,obj);
        }else{
          layer.msg('该用户没有银行!')
        }
      }else{
        layer.msg(res.resultMessage);
      }
    })
  },
  renderHtml(ele,data,form,obj){
    var html='';
    data.forEach((v,k)=>{
      html+=`<option value="${v.id}-${v.name}">${v.name}</option>`
    })
    $(ele).append(html);
    form.render('select');
    form.val('add', obj);
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getUrlParam(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); //构造一个含有目标参数的正则表达式对象
    var r = window.location.search.substr(1).match(reg);  //匹配目标参数
    if (r != null) return unescape(r[2]); return null; //返回参数值
  },
  getOptions:function(util){
    var arr=[
      { title: '操作',fixed: 'left', width: 170,toolbar: '#barDemo'}
      , { fixed: 'left',field: 'username', title: '用户账号', width: 100, sort: true}
      , { field: 'bankname', title: '银行名称', width: 120,sort: true}
      , { field: 'branchname', title: '支行名称', width: 140, sort: true}
      , { field: 'accountname', title: '银行户名', width: 100, sort: true}
      , { field: 'accountno', title: '银行卡号', width: 200, sort: true}
      , { field: 'moneyoutcount', title: '提现次数', width: 100, sort: true}
      , { field: 'outmoneytotal', title: '提现总额', width: 100, sort: true,templet:function(d){return d.outmoneytotal.toFixed(3)}}
      , { field: 'adddt', title: '绑定时间', width: 180, sort: true,templet:function(d){return util.toDateString(d.adddt, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'optdt', title: '解绑时间', width: 180, sort: true,templet:function(d){return util.toDateString(d.optdt, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'lastoperator', title: '最后操作者', width: 120, sort: true}
      , { field: 'lastoperationtime', title: '最后操作时间',templet:function(d){return d.lastoperationtime ? util.toDateString(d.lastoperationtime, "yyyy-MM-dd HH:mm:ss") :''}}
    ]
    return arr
  },
  editIdArr:[],
  tableData:[],
  editAlert(title,data,form){
    var isAdd = title == '新增' ? 1 : 0;
    var _this = this;
    layer.open({
      title:title,
      type: 1,
      skin: 'layui-layer-test',
      area: ['600px', '400px'],
      content: htmlTpl.addHtml,
      success:function(){
        var obj={
          "username": isAdd ? '' :data.username,
          "bankObj": isAdd ? '' :data.bankId+'-'+data.bankname,
          "branchname":isAdd ? '' :data.branchname,
          "accountname":isAdd ? '' :data.accountname,
          "accountno":isAdd ? '' :data.accountno
        }
        if(isAdd){
          $('.layui-username').blur(function(){
            var name = $(this).val();
            parent.ajaxService.doGet('/systemDepositAndWithdraw/findUser.mvc',{userName:name},function(res){
              if(res.resultCode ==0){
                _this.getBankList(name,form,obj)
              }else{
                layer.msg('没有这个用户!')
                return;
              }
            })
          })
        }else{
          $('.layui-username').attr("disabled",true)
          _this.getBankList(data.username,form,obj)
        }
        
        form.render('select');
        form.on('submit(formAdd)',function(submitData){
          var reqUrl = isAdd ? '/userBank/addUserBank.mvc' : '/userBank/updateUserBank.mvc';
          var fieldData = submitData.field;
          var bankArr = fieldData.bankObj.split('-');
          var obj = {
            bankId:bankArr[0],
            bankname:bankArr[1]
          }
          delete fieldData.bankObj;
          var reqData = isAdd ? Object.assign(fieldData,obj) : Object.assign(fieldData,{id:data.id,userid:data.userid,...obj});
          parent.ajaxService.doPost(reqUrl,reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              userBank.layerCallback(msg);
              userBank.editIdArr=[];
            }else{
              layer.msg(msg)
            }
          })
          return false;
        })
      }
    })
  }
}

userBank.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  userBank.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  
  var topHeight = ~~($(".layui-row").height()+40);
  var userName = userBank.getUrlParam('userName');
  // globalAdmin.renderIntDate(laydate,util)
  if(userName)$(".layui-input[name='username']").val(userName);
  var startDate = `${new Date().getFullYear()}-01-01`;
  var endDate = util.toDateString(new Date().getTime()+1000*60*60*24,'yyyy-MM-dd'); 
  userBank.table.render({
    elem: '#demo'
    , height: `full-${topHeight}`
    , url: '/userBank/queryList.mvc'
    , toolbar: userBank.toolbarHtml
    , defaultToolbar:[]
    , page: true
    , method: 'get'
    , cols: [ userBank.getOptions(util)],
    where: {
      username:$(".layui-input[name='username']").val(),
      add_time_begin:startDate,
      add_time_end: endDate
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results
      };
      userBank.tableData=res.results;
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      userBank.pageNumber = cur;
    }
  });
  
  // 工具栏操作
  userBank.table.on("toolbar(demo)",function(res){
    var checkStatus = userBank.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    switch (res.event) {
      case '新增':
        userBank.editAlert(res.event,data,form)
      break;
      default:
        // layer.msg("接口文档未完善，需要相应人员支持!")
        break;
    }
  })
  //监听行工具事件
  userBank.table.on('tool(demo)', function(obj){
    var data = obj.data;
    var event = obj.event;
    if(event === 'lock'){
      var text = data.locked==0 ? '锁定' : '解锁'; 
      layer.confirm(`是否${text}该银行卡信息?`, function(index){
        var reqData={
          userid:data.userid,
          locked:data.locked
        }
        parent.ajaxService.doPost("/userBank/updateUserBankState.mvc",reqData,function(res){
          if(res.resultCode ==0){
            userBank.layerCallback(res.resultMessage);
          }else{
            layer.msg(res.resultMessage);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(event ==='set'){
      userBank.editAlert('修改',data,form)
    }else if(event ==='del'){
      layer.confirm("是否删除选中的银行?",{
          btn:['确定','取消']
        },function(){
        var reqData = {
          id:data.id
        }
        parent.ajaxService.doPost("/userBank/deleteUserBank.mvc",reqData,function(res){
          var msg = res.resultMessage;
          if(res.resultCode ==0){
            userBank.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    userBank.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
  laydate.render({
    elem: '#start',
    value:startDate
    ,btns: ['clear', 'confirm']
    ,max:0
  });
  laydate.render({
    elem: '#end',
    value:endDate 
    ,btns: ['clear', 'confirm']
    ,max:1
  });
});



