
var cashcardM = {
  table:null,
  toolbarHtml:'<div><button class="layui-btn" lay-event="新增">新增</button></div>',
  hasSwitch:true,
  hasSet:true,
  hasDel:true,
  hasTransferIn:true,
  hasTransferOut:true,
  pageNumber:1,
  renderPlaceholder:function(){
    $(".search-case input[name='bankname']").attr("placeholder",this.initObj.bankname);
    $(".search-case input[name='accountname']").attr("placeholder",this.initObj.accountname);
    $(".search-case input[name='accountnumber']").attr("placeholder",this.initObj.accountnumber);
  },
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ //可操作菜单选项
    var action =window.name ||  globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    this.renderPlaceholder();
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      var obj= {
        '启用禁用':'hasSwitch',
        '修改':'hasSet',
        '转入':'hasTransferIn',
        '转出':'hasTransferOut',
        '删除':'hasDel'
      }
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i !='新增'){
          this[obj[i]]=true;
        }else{
          editHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>';
        }
      })
    }
    this.toolbarHtml =`<div>${editHtml}</div>`;
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var arr=[
      { field: 'bankname', title: this.initObj.bankname, width: 140,sort: true}
      , { field: 'accountname', title: this.initObj.accountname, width: 120, sort: true}
      , { field: 'accountnumber', title: this.initObj.accountnumber, width: 210, sort: true}
      , { field: 'balance', title: '余额', sort: true,width:180,templet:function(d){return d.balance.toFixed(3)}}
      , { title: '操作', toolbar: '#barDemo'}
    ]
    return arr
  },
  editIdArr:[],
  initObj:{
    bankname:window.name =='iframe_16' ? '出款银行' : '收款银行',
    accountname:window.name =='iframe_16' ? '出款户名' : '收款户名',
    accountnumber:window.name =='iframe_16' ? '出款卡号' : '收款卡号',
    tableUrl:window.name =='iframe_16' ? '/chuKuanBank/search.mvc' : '/ruKuanBank/search.mvc'
  },
  renderTotal(res){
    if (res.data && res.data.length > 0 && res.total){
      var tr = '<tr class="table-total"><td colspan="50">总量合计：<span>总余额： '+res.total.sumBalance+'</span></td></tr>'
      $('.layui-table-body table').append(tr)
    }
  },
  editAlert(title,form,data){
    var isAdd = title == '新增' ? !0 : 0;
    layer.open({
      title:title,
      type: 1,
      skin: 'layui-layer-test',
      area: ['600px', '280px'],
      content: htmlTpl.addHtml,
      success:function(){
        $(".bankname").text(cashcardM.initObj.bankname);
        $(".accountname").text(cashcardM.initObj.accountname);
        $(".accountnumber").text(cashcardM.initObj.accountnumber);
        var obj={
          "bankname": isAdd ? '' :data.bankname,
          "accountname":isAdd ? '' :data.accountname,
          "accountnumber":isAdd ? '' :data.accountnumber,
          "balance":isAdd ? 0 :data.balance
        }
        form.val('add', obj);
        var reqUrl='';
        if(window.name=='iframe_16'){
          reqUrl = isAdd ? '/chuKuanBank/add.mvc' : '/chuKuanBank/edit.mvc';
        }else{
          reqUrl = isAdd ? '/ruKuanBank/add.mvc' : '/ruKuanBank/edit.mvc';
        }
        form.on('submit(formAdd)',function(submitData){
          var reqData = isAdd ? submitData.field : Object.assign(submitData.field,{id:data.id});
          parent.ajaxService.doPost(reqUrl,reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              cashcardM.layerCallback(msg);
              // cashcardM.editIdArr=[];
            }else{
              layer.msg(msg)
            }
          })
          return false;
        })
      }
    })
  }
}

cashcardM.renderPlaceholder();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  cashcardM.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  cashcardM.table.render({
    elem: '#demo'
    , height: 'full-70'
    , url: cashcardM.initObj.tableUrl
    ,toolbar: cashcardM.toolbarHtml
    , page: true
    , defaultToolbar:[]
    , method: 'post'
    , cols: [ cashcardM.getOptions(util)],
    where: {
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results[0],
        "total":res.results[0] && res.results[0].length > 0 && res.results[1]
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      cashcardM.pageNumber=cur;
      cashcardM.renderTotal(res);
    }
  });
  
  cashcardM.table.on("toolbar(demo)",function(res){
    var checkStatus = cashcardM.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    switch (res.event) {
      case '新增':
        cashcardM.editAlert(res.event,form);
      break;
      default:
        break;
    }
  })

  cashcardM.table.on('tool(demo)', function(obj){
    var data = obj.data;
    var event = obj.event;
    if(event === 'lock'){
      var text = data.state==0 ? '启用' : '禁用'; 
      layer.confirm(`是否${text}${data.bankname}?`, function(index){
        var reqData={
          id:data.id
        }
        var reqUrl = window.name =='iframe_16' ? '/chuKuanBank/editState.mvc' : '/ruKuanBank/editState.mvc';
        parent.ajaxService.doPost(reqUrl,reqData,function(res){
          if(res.resultCode ==0){
            cashcardM.layerCallback(res.resultMessage);
          }else{
            layer.msg(res.resultMessage);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(event==='del'){
      layer.confirm("是否删除选中的银行?",{
          btn:['确定','取消']
        },function(){
        var reqData = {
          ids:data.id
        }
        var reqUrl = window.name =='iframe_16' ? '/chuKuanBank/delete.mvc' : '/ruKuanBank/delete.mvc';
        parent.ajaxService.doPost(reqUrl,reqData,function(res){
          if(res.resultCode ==0){
            cashcardM.layerCallback(res.resultMessage);
            cashcardM.editIdArr=[];
          }else{
            layer.msg(res.resultMessage);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(event ==='in' || event ==='out'){
      var isIn = event === 'in' ? 1 : 0;
      layer.open({
        title:isIn ? '转入' : '转出',
        type: 1,
        skin: 'layui-layer-test',
        area: ['600px', '340px'],
        content: htmlTpl.transferHtml,
        success:function(){
          $(".transfer-box label").text(isIn ? '转入金额' : '转出金额');
          $(".transfer-box input").attr("name",isIn ? 'rukuan' : 'chukuan');
          form.val('add', {"handlingcharge" : 0})
          var reqUrl = window.name =='iframe_16' ? '/chuKuan/addRuKuan.mvc' : '/ruKuan/addChuKuan.mvc';
          var key =  window.name =='iframe_16' ? 'chuKuanBankId' : 'rukuanBankId';
          form.on('submit(formTransfer)',function(submitData){
            var reqData = Object.assign(submitData.field,{[key]:data.id});
            parent.ajaxService.doPost(reqUrl,reqData,function(res){
              var msg = res.resultMessage;  
              if(res.resultCode==0){
                cashcardM.layerCallback(msg);
                // cashcardM.editIdArr=[];
              }else{
                layer.msg(msg)
              }
            })
            return false;
          })
        }
      })
    }else if(event === 'set'){
      cashcardM.editAlert('修改',form,data);
    }
  })
  
  form.on('submit(formDemo)', function (data) {
    cashcardM.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        },
        done: function (res, cur, count) {
          cashcardM.renderTotal(res);
        }
    })
    return false;
  });
});



