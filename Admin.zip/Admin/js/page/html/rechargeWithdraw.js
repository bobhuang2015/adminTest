
var rechargeWithdraw = {
  table:null,
  toolbarHtml:'',
  index:9999,
  hasReview:false,
  hasThrough:false,
  hasRefuse:false,
  hasJicha:false,
  hasAccount:false,
  thirdPlatObj:{},
  chukuanBank:[],
  pageNumber:1,
  token:'',
  renderUserlevel:function(data,form){
    var html='';
    data.forEach(function(v,k){
      html+=`<option value="${v.id}">${v.name}</option>`
    })
    $(".userLevel").append(html);
    form.render('select');
    // this.getThirdplat();
  },
  getThirdplat(){
    var _this = this;
    parent.ajaxService.doGet('/thirdPartyBetRecordsWeb/getThirdPartyPlatform.mvc',null,function(res){
      if(res.resultCode == 0){
        _this.thirdPlatObj = res.results[0]
      }
    })
  },
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){
    var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    var permissionObj={
      '审核':'hasReview',
      '通过':'hasThrough',
      '拒绝':'hasRefuse',
      '稽查':'hasJicha',
      '账变':'hasAccount'
    }
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        this[permissionObj[i]]=true;
      })
    }
    this.toolbarHtml =`<div>${editHtml}</div>`;
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  formatType(type){
    var obj={
      "1":'用户提现',
      "2":'人工扣款',
      "3":'其他类型'
    }
    return obj[type]
  },
  formatStatus(status){
    var obj={
      "0":'处理中',
      "1":'审核中',
      "2":'已通过',
      "3":'已拒绝',
      "4":'提现申请',
      "5":'提现失败'
    }
    return obj[status]
  },
  getUrlParam(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); //构造一个含有目标参数的正则表达式对象
    var r = window.location.search.substr(1).match(reg);  //匹配目标参数
    if (r != null) return unescape(r[2]); return null; //返回参数值
  },
  getChukuanBank(form,util,data){
    var _this = this;
    parent.ajaxService.doGet("/chuKuanBank/chubanklist.mvc",{userid:data.userid,accountno:data.accountno},function(res){
      if(res.resultCode==0){
        var bankList = res.results[0];
        var info = res.results[1];
        _this.chukuanBank=bankList;
        var html = `
        <p>该笔提现正由${data.operator}处理</p>
        <p>最近修改:${info.withdrawstatusremark ? info.withdrawstatusremark : '--'} -- 修改时间:${info.withdrawfreezedt ? util.toDateString(info.withdrawfreezedt,"yyyy-MM-dd HH:mm:ss") : '--'}</p>
        <p>${info.fundpassword}</p>`
        $('.info').html(html)
        _this.renderData('chukuanBank',bankList);
        form.render("select",'through');
      }
    })
  },
  renderData(id,data){
    var html='';
    data.forEach((v,k)=>{
      html+=`<option value="${v.id}">${v.withdrawType}-${v.accountname}-${v.bankname}-${v.accountnumber}-(余额:${v.balance})</option>`
    })
    $(`.${id}`).append(html);
  },
  getOptions:function(util){
    var arr=[
      { title: '操作', width: 210,toolbar:'#barDemo'}
      , { field: 'userRemark', title: '会员备注', width: 110,sort: true,templet:function(d){return d.userRemark ? `<div style="color:#FF5722;font-weight:bold;">${d.userRemark}</div>` : ''}}
      , { field: 'status', title: '状态', width: 70,templet:function(d){return rechargeWithdraw.formatStatus(d.status)}}
      , { field: 'ordernumber', title: '订单号', width: 140, sort: true}
      , { field: 'changetype', title: '提现类型', width: 110,sort: true,templet:function(d){return rechargeWithdraw.formatType(d.changeType)}}
      , { field: 'username', title: '用户账号', width: 110,sort: true}
      , { field: 'floor', title: '层级', width: 100,sort: true,templet:function(d){return rechargeWithdraw.globalAdmin.userLevelObj[d.userlevel]}}
      , { field: 'moneyoutcount', title: '提现总次数', width: 120,sort: true}
      , { field: 'accountname', title: '提现银行账户', width: 140,sort: true}
      , { field: 'accountno', title: '卡号', width: 170,sort: true}
      , { field: 'balance', title: '提现前余额', width: 120,sort: true,templet:function(d){return globalAdmin.formatNum(d.balance.toFixed(3))}}
      , { field: 'amount', title: '提现金额', width: 100,sort: true,templet:function(d){return globalAdmin.formatNum(d.amount.toFixed(3))}}
      , { field: 'applydt', title: '申请时间', width: 150, sort: true,templet:function(d){return util.toDateString(d.applydt, "yyyy-MM-dd HH:mm:ss")}}
      , { title: '耗时', width: 130,sort: true,templet:function(d){return parent.globalAdmin.diffTime(d.processTime,d.applydt)}}
      , { title: '处理时间', width: 150,sort: true,templet:function(d){return d.processTime ? util.toDateString(d.processTime, "yyyy-MM-dd HH:mm:ss") : '--'}}
      , { field: 'operator', title: '操作者', width: 100}
      , { field: 'remark', title: '备注', width: 160}
    ]
    return arr
  },
  editIdArr:[],
  tableData:[],
  renderTotal(res){
    if (res.data && res.data.length > 0 && res.total){
      var str='<tr class="table-total"><td colspan="50">总量合计:';
      res.total.forEach((v,k)=>{
          str+= `<span>${v.statusName}：${globalAdmin.formatNum(v.sumAmount)}</span>`
      })
      str +='</td></tr>';
      $('.layui-table-body table').append(str)
    }
  },
  renderRechargeDate(laydate, util, id) {
    var today = new Date().getTime();
    laydate.render({
      elem: id ? `#start${id}` : "#start",
      btns: ["clear", "confirm"],
      type: "datetime",
      max: 1
    });
    laydate.render({
      elem: id ? `#end${id}` : "#end",
      btns: ["clear", "confirm"],
      type: "datetime",
      max: 1
    });
  },
}

rechargeWithdraw.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  rechargeWithdraw.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  rechargeWithdraw.renderUserlevel(parent.globalAdmin.userLevelArr,form);
  rechargeWithdraw.renderRechargeDate(laydate,util);
  rechargeWithdraw.renderRechargeDate(laydate,util,'Deal')

  var userName = rechargeWithdraw.getUrlParam('userName',window.location.search);
  if(userName)$(".layui-input[name='username']").val(userName);

  rechargeWithdraw.table.render({
    elem: '#demo'
    , height: 'full-120'
    , url: '/moneyOutRecord/search.mvc'
    // , toolbar: rechargeWithdraw.toolbarHtml
    , page: true
    , method: 'get'
    , cols: [ rechargeWithdraw.getOptions(util)],
    where: {
      username:$(".layui-input[name='username']").val()
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode,
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results[0],
        "total": res.results[0].length > 0 && res.results[1]
      };
      // rechargeWithdraw.tableData=res.results;
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      rechargeWithdraw.pageNumber = cur;
      rechargeWithdraw.renderTotal(res);
    }
  });

  // 工具栏操作
  rechargeWithdraw.table.on("tool(demo)",function(res){
    var data = res.data;
    var dataRespone = []
    switch (res.event) {
      case 'jicha':
        layer.open({
          title:'稽查',
          type: 1,
          skin: 'layui-layer-test',
          area: ['780px', '760px'],
          content: htmlTpl.checkHtml,
          success:function(){
            var index=layer.load(2);
            parent.ajaxService.doGet('/moneyOutRecord/checkAccountCapital.mvc',{moneyOutRecordId:data.id},function(res){
              if(res.resultCode == 0){
                dataRespone = res.results[0];
                var capital = dataRespone.capitalCenter;
                var thirdPlat = dataRespone.thirdGameReports;
                var transferInTotal = 0;
                var transferOutTotal = 0;
                transferInTotal = dataRespone.platformMoney.transferIn ? dataRespone.platformMoney.transferIn.reduce(function(prev,cur){return cur.money + prev},0) : 0;
                transferOutTotal = dataRespone.platformMoney.transferOut ? dataRespone.platformMoney.transferOut.reduce(function(prev,cur){return cur.money + prev},0) : 0;
                var html = '';
                var obj={
                  "accountbalance": capital.accountbalance.toFixed(3),
                  "systemmoneyin": capital.systemmoneyin.toFixed(3),
                  "moneyinamount":capital.moneyinamount.toFixed(3),
                  "moneyincount":capital.moneyincount,
                  "transfermoneyintotal":capital.transfermoneyintotal.toFixed(3),
                  "transfermoneyouttotal":capital.transfermoneyouttotal.toFixed(3),
                  "moneyoutcount":capital.moneyoutcount,
                  "withdrawdayamount":capital.withdrawdayamount.toFixed(3),
                  'transferInTotal':transferInTotal.toFixed(3),
                  'transferOutTotal':transferOutTotal.toFixed(3)
                }
                if(thirdPlat.length > 0){
                  if(thirdPlat.length >3)$('.layui-widthdraw').parent('.layui-layer-content').addClass("test");
                  thirdPlat.forEach((v,k)=>{
                    html+=`<div class="layui-form-item">
                            <div class="layui-inline" style="font-size:18px;">
                              <label class="layui-form-label">平台名称 :</label>
                              <div class="layui-input-block">
                                <input type="text" value=${top.globalAdmin.thirdPlatform[v.platform]} class="layui-input" disabled/>
                              </div>
                            </div>
                          </div>
                          <div class="layui-form-item">
                            <div class="layui-inline">
                              <label class="layui-form-label">投注总额 :</label>
                              <div class="layui-input-block">
                                <input type="text" value=${v.orderMoneyTotal.toFixed(3)} class="layui-input" disabled/>
                              </div>
                            </div>
                            <div class="layui-inline">
                              <label class="layui-form-label">自身返点 :</label>
                              <div class="layui-input-block">
                                <input type="text" value=${v.selfBonusMoney.toFixed(3)} class="layui-input" disabled/>
                              </div>
                            </div>
                          </div>
                          <div class="layui-form-item">
                            <div class="layui-inline">
                              <label class="layui-form-label">转入总额 :</label>
                              <div class="layui-input-block">
                                <input type="text" value=${v.transferInTotal.toFixed(3)} class="layui-input" disabled/>
                              </div>
                            </div>
                            <div class="layui-inline">
                              <label class="layui-form-label">转出总额 :</label>
                              <div class="layui-input-block">
                                <input type="text" value=${v.transferOutTotal.toFixed(3)} class="layui-input" disabled/>
                              </div>
                            </div>
                          </div>
                          <div class="layui-form-item">
                            <div class="layui-inline">
                              <label class="layui-form-label">投注盈亏 :</label>
                              <div class="layui-input-block">
                                <input type="text" value=${v.profitlossMoneyTotal.toFixed(3)} class="layui-input" disabled/>
                              </div>
                            </div>
                            <div class="layui-inline">
                              <label class="layui-form-label">中奖总额 :</label>
                              <div class="layui-input-block">
                                <input type="text" value=${(v.profitlossMoneyTotal + v.orderMoneyTotal).toFixed(3)} class="layui-input" disabled/>
                              </div>
                            </div>
                          </div>
                        </div>`
                  })
                  $('.layui-third').append(html);
                }
                form.val('check', obj)
              }
              layer.close(index);
            })
          }
        })
      break;
      case 'account':
        var url = "html/team-accountchange.html?userName="+data.username+"";
        var action = parent.globalAdmin.menuObj['iframe_38'].action;
        parent.tab.tabAdd('账变明细', url, rechargeWithdraw.index,action);
        parent.tab.tabChange( rechargeWithdraw.index);
        rechargeWithdraw.index++;
      break;
      case 'refuse':
        layer.open({
          title:'拒绝',
          type: 1,
          skin: 'layui-layer-test',
          area: ['550px', '400px'],
          content: htmlTpl.refuseHtml,
          success:function(){
            var obj={
              "username": data.username,
              "balance": data.balance,
              "amount": data.amount,
              "applydt": util.toDateString(data.applydt, "yyyy-MM-dd HH:mm:ss"),
              "remark": ''
            }
            form.val('refuse', obj)
            form.on('submit(formRefuse)',function(submitData){
              var reqUrl = '/moneyOutRecord/refuseApply.mvc';
              var reqData={
                'remark':submitData.field.remark,
                'moneyOutRecordId':data.id
              };
              parent.ajaxService.doPost(reqUrl,reqData,function(res){
                var msg = res.resultMessage;
                if(res.resultCode==0){
                  rechargeWithdraw.layerCallback(msg);
                }else{
                  layer.msg(msg)
                }
              })
              return false;
            })
          }
        })
      break;
      case 'through':
        layer.open({
          title:'通过',
          type: 1,
          skin: 'layui-layer-test',
          area: ['720px', '640px'],
          content: htmlTpl.throughHtml,
          success:function(){
            rechargeWithdraw.getChukuanBank(form,util,data);
            var obj={
              "username": data.username,
              "bankname": data.bankname,
              "branchname": data.branchname,
              "accountno": data.accountno,
              "accountname": data.accountname,
              "amount": data.amount,
              "handlingcharge": 0,
              "chuKuanBankId": ''
            }
            form.val('through', obj)
            var clipboard = new ClipboardJS('.layui-btn-copy');
              clipboard.on('success', function(e) {
              e.clearSelection();
              layer.msg('复制成功!')
            });
            parent.ajaxService.doGet('/systemDepositAndWithdraw/getToken.mvc',{userId:data.userid},function(res){
              if(res.resultCode == 0 ){
                rechargeWithdraw.token = res.results[0];
              }
            })
            form.on('submit(formThrough)',function(submitData){
              $('button[lay-filter="formThrough"]').addClass('layui-btn-disabled').html('提交中');
              // 根据bankType不同使用不同的接口（正常支付与代付）
              var bankType = 1
              for (let i = 0; i < rechargeWithdraw.chukuanBank.length; i++) {
                if (submitData.field.chuKuanBankId == rechargeWithdraw.chukuanBank[i].id) {
                  bankType = rechargeWithdraw.chukuanBank[i].bankType
                }
              }
              if (bankType === 1) {
                var reqUrl = '/moneyOutRecord/promiseApply.mvc';
                var reqData={
                  'handlingcharge':submitData.field.handlingcharge,
                  'chuKuanBankId':submitData.field.chuKuanBankId,
                  'moneyOutRecordId':data.id,
                  'token':rechargeWithdraw.token,
                  'userId':data.userid
                };
              } else if (bankType === 2) {
                var reqUrl = '/moneyOutRecord/agentPayApply.mvc';
                var reqData= {
                  recordId: data.id,
                  bankId: submitData.field.chuKuanBankId,
                  userId: data.userid
                }
              }
              rechargeWithdraw.token && parent.ajaxService.doPost(reqUrl,reqData,function(res){
                var msg = res.resultMessage;
                if(res.resultCode==0){
                  rechargeWithdraw.token='';
                  rechargeWithdraw.layerCallback(msg);
                }else{
                  layer.msg(msg)
                  if(res.msg == '出款卡余额不足!'){
                    setTimeout(()=>{
                      $('button[lay-filter="formThrough"]').removeClass('layui-btn-disabled').html('提交')
                    },500)
                  }
                }
              })
              return false;
            })
          }
        })
      break;
      case 'review':
        layer.confirm(`标记进行审核操作？`,function(index){
          var reqData={
            id:data.id,
            userid:data.userid
          }
          parent.ajaxService.doPost("/moneyOutRecord/verifyWithdraw.mvc",reqData,function(res){
            var msg = res.resultMessage
            if(res.resultCode == 0){
              rechargeWithdraw.layerCallback(msg);
            }else{
              layer.msg(msg);
            }
          })
          },function(index){
            layer.close(index)
          }
        )
      break;
      default:
        break;
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    rechargeWithdraw.table.reload('demo',{
        where:data.field,
        page:{
            curr:1
        },
        done: function (res, cur, count) {
          rechargeWithdraw.renderTotal(res)
        }
    })
    return false;
  });
});



