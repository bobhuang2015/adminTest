
var usercenterPicture = {
  table:null,
  upload:null,
  toolbarHtml:'',
  hasDel:false,
  hasSet:false,
  previewUrl:'',
  pageNumber:1,
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        var obj = {
          '修改':'hasSet',
          '删除':'hasDel'
        }
        if(i !='新增'){
          this[obj[i]]=true;
        }else{
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${otherHtml}</div>`;
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },  
  formatPictype(str){
    var obj={
      "1":'PC首页轮播图',
      "2":'支付二维码',
      "3":'app下载二维码',
      "4":'移动端首页轮播图',
      "5":'其它图片',
      "6":'PC购彩大厅轮播图',
    }
    return obj[str];
  },
  getOptions:function(util){
    var arr=[
      { field: 'name', title: '图片名称', width: 180,sort: true}
      , { field: 'type', title: '图片类型', width: 130, sort: true,templet:function(d){return usercenterPicture.formatPictype(d.type)}}
      , { field: 'imgurl', title: '图片路径', width: 480, sort: true}
      , { field:'timebegin',title: '开启时间', width: 180, sort: true,templet:function(d){return util.toDateString(d.timebegin,'yyyy-MM-dd HH:mm:ss')}}
      , { field:'timeend',title: '关闭时间', width: 180, sort: true,templet:function(d){return util.toDateString(d.timeend,'yyyy-MM-dd HH:mm:ss')}}
      , { field: 'sort', title: '排序', width: 120, sort: true}
      , { field: 'remarks', title: '备注', width: 180, sort: true}
      , { title: '操作', toolbar:'#barDemo'}
    ]
    return arr
  },
  editImgUpload(title,form,laydate,util,data){
    var isAdd = title=='新增' ? !0 : 0;
    layer.open({
      title:title,
      type: 1,
      skin: 'layui-layer-test',
      area: ['600px', '500px'],
      content: htmlTpl.addHtml,
      success:function(){
        lay('.layui-date').each(function(){
          laydate.render({
            elem: this
            ,trigger: 'click'
            ,type: 'datetime'
          });
        }); 
        var selectVal = isAdd ? '1' : data.type;
        var obj={
          "name": isAdd ? '' : data.name,
          // "type": usercenterPicture.formatPictype(selectVal),
          "type": selectVal,
          "imgurl":isAdd ? '' : data.imgurl,
          "timebegin":isAdd ? '' : util.toDateString(data.timebegin,'yyyy-MM-dd HH:mm:ss'),
          "timeend":isAdd ? '' : util.toDateString(data.timeend,'yyyy-MM-dd HH:mm:ss'),
          "sort":isAdd ? '' : data.sort,
          "remarks":isAdd ? '' : data.remarks
        }
        form.val('add', obj);
        usercenterPicture.previewUrl = isAdd ? '' : data.imgurl;
        var uploadUrl = usercenterPicture.globalAdmin.uploadInfo.uploadImgUrl+'/file-upload/upload-image';
        
        form.on('select(type)',function(data){
          selectVal = data.value
        })
        usercenterPicture.upload.render({
          elem: '#layui-upload' //绑定元素
          ,url: uploadUrl //上传接口
          ,choose:function(obj){
            obj.preview(function(index,file,result){//预览图片
            })
          }
          ,before:function(obj){//文件上传前的回调
            layer.load(2)
          }
          ,data:{
            tenantCode:usercenterPicture.globalAdmin.uploadInfo.tenantCode,
            category:selectVal
          }
          ,done: function(res,index){//上传完毕回调
            layer.closeAll('loading');
            var data = res.data;
            $('.layui-imgurl').val(data);
            usercenterPicture.previewUrl = data;
          }
          ,error: function(data){//请求异常回调
            layer.closeAll('loading')
          }
          ,size:1024*5
          ,acceptMime:'.jpg,.png,.svg,.jpeg,.webp'
        })
        $('#layui-preview').on('click',function(){
          if(usercenterPicture.previewUrl){
            var img = `<img src="${usercenterPicture.globalAdmin.uploadInfo.viewImgUrl+'/'+usercenterPicture.previewUrl}" style='width:300px;height:200px;'/>`
            layer.open({  
                type: 1,  
                title: '图片预览',  
                area: ['300px','250px'],  
                content: img, 
                cancel: function () {  
                }
            })  
          }else{
            layer.alert('请先上传图片!')
          }
          return false;
        })
        form.on('submit(formAdd)',function(submitData){
          var reqData = submitData.field;
          reqData.type = selectVal;
          if(!isAdd)reqData.id=data.id;
          delete reqData.file;
          var reqUrl = isAdd ? '/uploadimg/add.mvc' : '/uploadimg/update.mvc'
          parent.ajaxService.doPost(reqUrl,reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              usercenterPicture.layerCallback(msg);
            }else{
              layer.msg(msg)
            }
          })
          return false;
        })
      }
    })
  }
}

usercenterPicture.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util','upload'], function () {
  var laydate = layui.laydate;
  usercenterPicture.table = layui.table;
  usercenterPicture.upload = layui.upload;
  
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  usercenterPicture.table.render({
    elem: '#demo'
    , height: 'full-80'
    , url: '/uploadimg/list.mvc'
    , toolbar: usercenterPicture.toolbarHtml
    , defaultToolbar:[]
    , page: true
    , method: 'get'
    , cols: [ usercenterPicture.getOptions(util)],
    where: {}
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      usercenterPicture.pageNumber=cur;
    }
  });
  
  // 工具栏操作
  usercenterPicture.table.on("toolbar(demo)",function(res){
    var checkStatus = usercenterPicture.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    switch (res.event) {
      case '新增':
      usercenterPicture.editImgUpload(res.event,form,laydate)
      break;
      default:
        break;
    }
  })
  //监听行工具事件
  usercenterPicture.table.on('tool(demo)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
      layer.confirm("是否删除?",{
          btn:['确定','取消']
        },function(){
        var reqData = {
          uploadimgId:data.id
        }
        parent.ajaxService.doPost("/uploadimg/delete.mvc",reqData,function(res){
          if(res.resultCode ==0){
            usercenterPicture.layerCallback(res.resultMessage);
            usercenterPicture.editIdArr=[];
          }else{
            layer.msg(res.resultMessage);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(obj.event ==='set'){
      usercenterPicture.editImgUpload('修改',form,laydate,util,data)
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    usercenterPicture.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



