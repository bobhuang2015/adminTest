var cashcardD = {
  table:null,
  pageNumber:1,
  renderPlaceholder:function(){
    $(".search-case input[name='bankname']").attr("placeholder",this.initObj.bankname);
    $(".search-case input[name='accountname']").attr("placeholder",this.initObj.accountname);
    $(".search-case input[name='accountnumber']").attr("placeholder",this.initObj.accountnumber);
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  getOptions:function(util){
    var arr=[
        { field: 'bankname', title: this.initObj.bankname, width: 140,sort: true}
      , { field: 'accountname', title: this.initObj.accountname, width: 120, sort: true}
      , { field: 'accountnumber', title: this.initObj.accountnumber, width: 200, sort: true}
      , { field: 'rukuan', title: '入款', width: 120, sort: true,templet:function(d){return d.rukuan ? d.rukuan.toFixed(3) : '0.000'}}
      , { field: 'chukuan', title: '出款', width: 120, sort: true,templet:function(d){return d.chukuan ? d.chukuan.toFixed(3) : '0.000'}}
      , { field: 'handlingcharge', title: '手续费', width: 120, sort: true}
      , { field: 'balance', title: '当前余额', width: 120, sort: true,templet:function(d){return d.balance.toFixed(3)}}
      , { field: 'tradingbank', title: '交易银行', width: 120, sort: true}
      , { field: 'tradingname', title: '交易户名', width: 120, sort: true}
      , { field: 'tradingnumber', title: '交易卡号', width: 200, sort: true}
      , { field: 'username', title: '用户名', width: 100, sort: true}
      , { field: 'cdate', title: '操作时间', sort: true,templet:function(d){return util.toDateString(d.cdate, "yyyy-MM-dd HH:mm:ss")}}
    ]
    return arr
  },
  text:parent.$('#profitLoss .layui-this').text(),
  initObj:{
    bankname:parent.$('#profitLoss .layui-this').text()=='出款卡明细' ? '出款银行' : '收款银行',
    accountname:parent.$('#profitLoss .layui-this').text()=='出款卡明细' ? '出款户名' : '收款户名',
    accountnumber:parent.$('#profitLoss .layui-this').text()=='出款卡明细' ? '出款卡号' : '收款卡号',
    tableUrl:parent.$('#profitLoss .layui-this').text()=='出款卡明细' ? '/chuKuan/search.mvc' : '/ruKuan/search.mvc'
  },
  renderTotal(res){
    if (res.data && res.data.length > 0 && res.total){
      var tr = '<tr class="table-total"><td colspan="50">总量合计：<span>总余额： '+res.total.sumBalance+'</span>'+
            '<span>总出款： '+res.total.sumChukuan +'</span>'+'<span>总入款： '+res.total.sumRukuan+'</span>'+
            '<span>总手续费： '+res.total.sumHandlingCharge +'</span></td></tr>'
      $('.layui-table-body table').append(tr)
    }
  },
}

cashcardD.renderPlaceholder()
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  cashcardD.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  globalAdmin.renderIntDate(laydate,util);
  var topHeight = ~~($(".layui-row").height()+40);
  cashcardD.table.render({
    elem: '#demo'
    , height: `full-${topHeight}`
    , url: cashcardD.initObj.tableUrl
    , page: true
    , method: 'post'
    , cols: [ cashcardD.getOptions(util)],
    where: {
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results[0],
        "total":res.results[0].length > 0 && res.results[1]
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      cashcardD.pageNumber=cur;
      cashcardD.renderTotal(res);
    }
  });
  
  form.on('submit(formDemo)', function (data) {
    cashcardD.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        },
        done: function (res, cur, count) {
          cashcardD.renderTotal(res);
        }
    })
    return false;
  });
});



