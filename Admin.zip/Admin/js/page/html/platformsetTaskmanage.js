
var platformsetTaskmanage = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  currentPlatform:'',
  previewType:{},
  stateObj:{},
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1  
      }
	  })
  },
  renderRebateHtml(){
    var html ='';
    var platHtml ='';
    var obj={
      'ag':'AG返点',
      'bbin':'BBIN返点',
      'lk':'好利(LK)返点',
      'pt':'PT返点',
      'mg':'MG返点',
      'sb':'沙巴(SB)返点',
      'xj':'WBG(XJ)返点',
      'kx':'KX返点',
      'bg':'BG返点',
      'ky':'KY返点',
      'cp':'经典(CP)返点',
      'kg':'传统(KG)返点',
      'third':'第三方返点',
      'consumerRebate':'消费与亏损返佣'
    }
    for(var i in obj){
      html += `<div class="layui-btn layui-btn-normal" data-platform="${i}">${obj[i]}</div>`
    }
    for(let val of Object.entries(parent.globalAdmin.thirdPlatform)){
      platHtml +=`<option value="${val[0]}">${val[1]}</option>`
    }
    $('.layui-bounds-box').append('<p>系统定时任务执行失败时,可通过以下手动执行任务(该操作不会重复派发)</p>').append(html);
    $('.layui-playform').append(platHtml);
    this.getPreviewType();
  },
  gameTypeObj:{},
  getPreviewType(){
    var _this = this;
    parent.ajaxService.doGet('/getEnumByNames.mvc',{enumName:'ProfitLossSubType,ProfitLossType'},function (res){
      if(res.resultCode == 0){
        var data = res.results[0];
        _this.previewType = data.ProfitLossSubType;
        _this.stateObj = data.ProfitLossType;
      }
    } )
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var _this = this;
    var arr=[
      { field: 'orderNumber', title: '订单号', width: 180,sort: true}
      , { field: 'username', title: '用户账号', width: 140,sort: true}
      , { field: 'userFloor', title: '用户级数', width: 140,sort: true}
      , { field: 'rebateType', title: '返点类型', width: 180,sort: true,templet:function(d){return _this.stateObj[d.rebateType]}}
      , { field: 'rebateAmount', title: '收入', width: 140,sort: true,templet:function(d){return d.rebateAmount.toFixed(3)}}
      // , { field: 'rebateAmount', title: '支出', width: 140,sort: true,templet:function(d){return d.changeType==5 ? d.rebateAmount.toFixed(3) : '' }}
      , { field: 'accountBalance', title: '当前余额', width: 140,sort: true,templet:function(d){return d.accountBalance.toFixed(3)}}
      , { field: 'statisticsTime', title: '理应返点日期', width: 180,templet:function(d){return util.toDateString(d.statisticsTime, "yyyy-MM-dd")}}
      , { field: 'rebateTime', title: '返点时间',width: 180, templet:function(d){return util.toDateString(d.rebateTime, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'remark', title: '备注'}
    ]
    return arr
  },
  showLayer: function(title, url, w, h) {
    var _this = this;
    var index=layer.open({
      type: 2,
      area: [w + "px", h + "px"],
      fix: false, 
      shadeClose: true,
      shade: 0.4,
      title: title,
      content: url,
      btn:['保存','取消'],
      yes: function(index, layero){
        var reqUrl=''
        if(_this.currentPlatform !='consumerRebate' && _this.currentPlatform !='sportsconsumerRebate' && _this.currentPlatform !='divdendAndWage'){
          reqUrl = `/quzrtz/${_this.currentPlatform}Bouns.mvc`
        }else{
          reqUrl = `/quzrtz/${_this.currentPlatform}.mvc`
        }
        layer.close(index);
        var w = $(layero).find("iframe")[0].contentWindow;
        parent.ajaxService.doPost(reqUrl,w.platformPreview.dateObj,function(res){
          let index2=layer.alert('任务执行中,请勿重复点击!',function(){
            layer.close(index2)
          })
        })
      }
    });
  },
}

platformsetTaskmanage.renderRebateHtml()
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  platformsetTaskmanage.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  globalAdmin.renderIntDate(laydate,util)
  platformsetTaskmanage.table.render({
    elem: '#demo'
    , height: 'full-194'
    // , url: '/bdbProfitLoss/search.mvc'
    , url: '/rebateRecord/search.mvc'
    ,toolbar: platformsetTaskmanage.toolbarHtml
    , page: true
    , method: 'get'
    , cols: [ platformsetTaskmanage.getOptions(util)],
    where: {}
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results[0]
      };
      platformsetTaskmanage.tableData=res.results;
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
    }
  });
  
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    platformsetTaskmanage.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
  $('.layui-btn-normal').on('click',function(){
    var type = $(this).attr('data-platform');
    var txt = $(this).text();
    platformsetTaskmanage.currentPlatform = type;
    platformsetTaskmanage.showLayer(`预览返点明细-${txt}`,'./platformSet-preview.html?time='+new Date().getTime(),'1200','760')
  })
});



