
var usercenterAutored = {
  table:null,
  toolbarHtml:'',
  hasDel:false,
  hasSet:false,
  pageNumber:1,
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        var obj = {
          '修改':'hasSet',
          '删除':'hasDel'
        }
        if(i !='新增'){
          this[obj[i]]=true;
        }else{
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${otherHtml}</div>`;
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },  
  getOptions:function(util){
    var arr=[
      { title: '操作', width: 120,toolbar:"#barDemo"}
      , { field: 'totalmoney', title: '总金额', width: 120,sort: true,templet:function(d){return d.totalmoney.toFixed(3)}}
      , { field: 'betmoney', title: '投注金额', width: 120,sort: true,templet:function(d){return d.betmoney.toFixed(3)}}
      , { field: 'quantity', title: '数量', width: 120,sort: true}
      , { field: 'avgmaxratio', title: '平均值最大百分比', width: 160,sort: true}
      , { field: 'avgmixratio', title: '平均值最小百分比', width: 160,sort: true}
      , { title: '开始时间', width: 140,sort: true,templet:function(d){return util.toDateString(d.begintime,'HH:mm:ss')}}
      , { title: '结束时间', width: 140,sort: true,templet:function(d){return util.toDateString(d.endtime,'HH:mm:ss')}}
      , { field: 'limitnum', title: '限制领取次数', width: 120, sort: true}
      , { field: 'notlimitnumamount', title: '达标充值金额', width: 160, sort: true,templet:function(d){return d.notlimitnumamount.toFixed(3)}}
      , { field: 'intervaltime', title: '间隔时间(分钟)', width: 160, sort: true}
      , { field: 'allowtime', title: '红包领取的允许时间(分钟)', width: 220, sort: true}
      , { field: 'demandorderamount', title: '打码额', width: 120, sort: true}
      , { title: '启用状态', width: 120, sort: true,templet:function(d){return d.enabled ? '是' : '否'}}
      , { title: '创建时间', width: 180, sort: true,templet:function(d){return util.toDateString(d.createtime,'yyyy-MM-dd HH:mm:ss')}}
      , { field: 'lastoperator', title: '最后操作者', width: 160, sort: true}
      , { title: '最后操作时间', width: 180, sort: true,templet:function(d){return util.toDateString(d.lastoperationtime,'yyyy-MM-dd HH:mm:ss')}}
      , { field: 'remark', title: '备注', width: 120, sort: true}
    ]
    return arr
  },
  timeToSec(time){
    var s = '';
    var hour = time.split(':')[0];
    var min = time.split(':')[1];
    var sec = time.split(':')[2];
    s = Number(hour*3600) + Number(min*60) + Number(sec);
    return s;
  },
  editAlert(title,form,laydate,data,util){
    var isAdd = title=='新增' ? !0 : 0;
    var _this = this;
    layer.open({
      title:title,
      type: 1,
      skin: 'layui-layer-test',
      area: ['760px', '760px'],
      content: htmlTpl.addHtml,
      success:function(){
        lay('.layui-date').each(function(){
          laydate.render({
            elem: this
            ,trigger: 'click'
            ,type:'time'
          });
        }); 
        var obj={
          "totalmoney": isAdd ? '' : data.totalmoney,
          "betmoney": isAdd ? '' : data.betmoney,
          "quantity": isAdd ? '' : data.quantity,
          "limitnum": isAdd ? '' : data.limitnum,
          "notlimitnumamount": isAdd ? '' : data.notlimitnumamount,
          "avgmaxratio": isAdd ? 80 : data.avgmaxratio,
          "avgmixratio": isAdd ? 20 : data.avgmixratio,
          "begintime":isAdd ? '' : util.toDateString(data.begintime,'HH:mm:ss'),
          "endtime": isAdd ? '' : util.toDateString(data.endtime,'HH:mm:ss'),
          "intervaltime": isAdd ? '' : data.intervaltime,
          "allowtime": isAdd ? '' : data.allowtime,
          "demandorderamount": isAdd ? '' : data.demandorderamount,
          "enabled": isAdd ? 1 : data.enabled ? 1 : 0,
          "remark": isAdd ? '' :data.remark
        }
        form.val('add', obj);
        var reqUrl = isAdd ? '/dividendManager/addDividendConf.mvc' : '/dividendManager/updateDiviendConf.mvc'
        form.on('submit(formAdd)',function(submitData){
          var reqData = submitData.field;
          if(_this.timeToSec(reqData.endtime) < _this.timeToSec(reqData.begintime)){
            layer.msg('结束时间不能小于开始时间!');
            return false;
          }
          if(+reqData.quantity > +reqData.totalmoney){
            layer.msg('数量不能大于总金额!')
            return false;
          }
          if((+reqData.avgmaxratio + +reqData.avgmixratio) >100){
            layer.msg('平均值(最大百分比+最小百分比)不能大于100!')
            $('input[name="avgmaxratio"]').focus();
            return false;
          }
          !isAdd && Object.assign(reqData,{id:data.id});
          parent.ajaxService.doPost(reqUrl,reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              usercenterAutored.layerCallback(msg);
            }else{
              layer.msg(msg)
            }
          })
          return false;
        })
      }
    })
  }
}

usercenterAutored.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  usercenterAutored.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  usercenterAutored.table.render({
    elem: '#demo'
    , height: 'full-40'
    , url: '/dividendManager/getDivdendConfs.mvc'
    , toolbar: usercenterAutored.toolbarHtml
    , defaultToolbar:[]
    , page: true
    , method: 'get'
    , cols: [ usercenterAutored.getOptions(util)],
    where: {
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results[0]
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      usercenterAutored.pageNumber=cur;
    }
  });
  
  // 工具栏操作
  usercenterAutored.table.on("toolbar(demo)",function(res){
    var checkStatus = usercenterAutored.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    var event = res.event;
    switch (event) {
      case '新增':
        usercenterAutored.editAlert(event,form,laydate,{},util)
      break;
      default:
        break;
    }
  })
  //监听行工具事件
  usercenterAutored.table.on('tool(demo)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
      layer.confirm(`是否确认删除?`, function(index){
        var reqData={
          id:data.id
        }
        parent.ajaxService.doPost("/dividendManager/delDividendConf.mvc",reqData,function(res){
          var msg = res.resultMessage
          if(res.resultCode ==0){
            usercenterAutored.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(obj.event === 'set'){
      usercenterAutored.editAlert('修改',form,laydate,data,util);
    }
  })
});



