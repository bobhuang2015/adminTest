var profitLossTeamProxyRecharge = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  playTypeArr:[],
  thirdData:[],
  thirdTotal:[],
  upFloor:'',
  index:999999,
  reqUrl:'/profitLoss/listLevelUserProfitLoss.mvc',
  platform:{},
  lotteryTotal:{},
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    // var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    // var permision = this.globalAdmin.menuObj[action].permision;
    var permision = ['报表修复','第三方修复'];
    var editHtml = "";
    permision.forEach((v,k)=>{
      editHtml +='<button class="layui-btn" lay-event="'+v+'">'+v+'</button>'
    })
    this.toolbarHtml =`<div>${editHtml}</div>`;//toolbar 跟表格联动
  },
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1  
      }
	  })
  },
  showLayer: function(title, url, w, h) {
    layer.open({
      type: 2,
      area: [w + "px", h + "px"],
      fix: false, 
      shadeClose: true,
      shade: 0.4,
      title: title,
      content: url
    });
  },
  getUrlParam(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); //构造一个含有目标参数的正则表达式对象
    var r = parent.location.search.substr(1).match(reg);  //匹配目标参数
    if (r != null) return unescape(r[2]); return null; //返回参数值
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  reloadByClick(name){
    $('.layui-username').val(name);
    $('#layui-form-btn').click();
  },
  getOptions:function(){
    var arr=[
      { field: 'username',  title:'用户账号',width:120}
      , { field: 'username',  title:'账变时间',width:12}
      , { field: 'username',  title:'账变类型',width:12}
      , { field: 'username',  title:'账变金额',width:12}
      , { field: 'username', title:'当前余额',width:120}
      , { field: 'username', title:'操作',width:120}
    ]
    return arr
  },
  editIdArr:[],
  tableData:[]
}

layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  profitLossTeamProxyRecharge.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;

  var util = layui.util;
  var arr1 = profitLossTeamProxyRecharge.getOptions();
  var name = parent.$(".layui-this").attr("data-name");

  var startTime = util.toDateString(new Date(new Date()-1000*60*60*24), "yyyy-MM-dd");
  var endTime = util.toDateString(new Date().getTime(), "yyyy-MM-dd");
  
return;
  var renderObj = {
    elem: '#demo'
    , height: 675
    , url: `${profitLossTeamProxyRecharge.reqUrl}`
    , method: 'get'
    , cols: [arr1],
    where: {
      // userid: 14823,
      // floor: 3,
      // profitlossdt_begin: 2018-07-01,
      // profitlossdt_end: 2019-07-10,
      // profitlosssubtypeid: 0
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results[0]
      };
      profitLossTeamProxyRecharge.lotteryTotal = res.results[1];
      profitLossTeamProxyRecharge.thirdTotal = res.results[2];
      profitLossTeamProxyRecharge.upFloor = res.results[3];
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
    }
  }
  profitLossTeamProxyRecharge.table.render(renderObj);
  
  //监听工具条
  profitLossTeamProxyRecharge.table.on('toolbar(demo)', function(obj){
    var data = obj.data;
    var event = obj.event;
    var isAdd = event == '报表修复' ? !0 : 0;
    if(event === '报表修复' || event === '第三方修复'){
      layer.open({
        title:event,
        type: 1,
        skin: 'layui-layer-test',
        area: ['600px', '240px'],
        content: htmlTpl.addHtml,
        success:function(){
          if(isAdd){
            $('.layui-enddate').remove();
          }else{
            $('.layui-startdate  label').text('结束日期');
            $('#layui-addDate').attr('name','statisticsTime_end');
            $('.layui-username').remove();
            laydate.render({
              elem: '#layui-endDate' //指定元素
              ,type:'date'
              ,value: new Date(new Date() - 1000*24*60*60)
            });
          }
          
          laydate.render({
            elem: '#layui-addDate' //指定元素
            ,type:'date'
            ,value: new Date()
          });
          form.on('submit(formAdd)',function(submitData){
            var reqUrl = isAdd ? '/termsProfitStatistics/updateUserReport.mvc' : '/termsProfitStatistics/updateUserReport2.mvc';
            var reqData = submitData.field;
            parent.ajaxService.doPost(reqUrl,reqData,function(res){
              var msg = res.resultMessage;
              if(res.resultCode==0){
                profitLossTeamProxyRecharge.layerCallback(msg);
              }else{
                layer.msg(msg)
              }
            })
            return false;
          })
        }
      })
    } 
  });
  //监听行工具条
  profitLossTeamProxyRecharge.table.on('tool(demo)', function(obj){
    var data = obj.data;
    profitLossTeamProxyRecharge.thirdData = data.thirdGameReportList;
    if(obj.event === 'detail'){
      profitLossTeamProxyRecharge.showLayer(`第三方数据-${data.username}`,'./profitloss-third-user.html','800','400')
    } 
  });
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    profitLossTeamProxyRecharge.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
  laydate.render({
    elem: '#start' //指定元素
    ,type:'date'
    ,value: new Date(new Date()-1000*60*60*24)
  });
  laydate.render({
    elem: '#end' //指定元素
    ,type:'date'
    ,value: new Date()
  });
});



