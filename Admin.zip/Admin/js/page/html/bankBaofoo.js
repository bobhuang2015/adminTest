
var bankBaofoo = {
  table:null,
  index:9999999,
  toolbarHtml:'',
  isFirstRender:true,
  hasLock:false,
  hasDel:false,
  hasTransfer:false,
  rechargeList:[],
  selfBankList:[],
  merchantTypeList:[],
  merchantTypeObj:{},
  pageNumber:1,
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){
    var action = window.name || globalAdmin.getUrlParam('code');;
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    var obj={
      '修改':'hasSet',
      '禁用/启用':'hasLock',
      // '转移':'hasTransfer',
      '删除':'hasDel'
    }
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i !=='新增' && i !=='支付类别'){
          this[obj[i]]=true;
        }else{
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>';
          if(i=='支付类别'){
            parent.globalAdmin.rechargeMethod = v.childrens;
          }
        }
      })
    }
    this.toolbarHtml =`<div>${otherHtml}</div>`;
    this.getRechargeList();
  },
  getRechargeList(){
    var _this = this;
    parent.ajaxService.doGet("/rechargType/list.mvc",{enabled:1},function(res){
      if(res.resultCode==0){
        _this.rechargeList = res.results[0];
      }
    })
  },
  getMerchantType(util,layer){
    var _this = this;
    parent.ajaxService.doGet("/bank/getMerchantType.mvc",{type:1},function(res){
      if(res.resultCode==0){
        _this.merchantTypeList = res.results[0];
        res.results[0].forEach((v,k)=>{
          Object.assign(_this.merchantTypeObj,{[v.code]:{type:v.type,name:v.name}})
        })

        _this.table.render({
          elem: '#demo'
          , height: 800
          , url: '/baoFooMerchant/list.mvc'
          ,toolbar: _this.toolbarHtml
          , defaultToolbar:[]
          , page: true
          , method: 'get'
          , cols: [_this.getOptions(util)],
          where: {}
          , parseData: function (res) {
            if(_this.isFirstRender){
              _this.selfBankList = res.results[1];
              _this.isFirstRender = !_this.isFirstRender;
            }
            var result = {
              "code": res.resultCode,
              "msg": res.resultMessage,
              "count": res.meta.totalRecord,
              "data": res.results[0]
            };
            return result
          },
          response: {
            statusCode: '0'
          },
          done: function (res, cur, count) {
            _this.pageNumber=cur;
          }
        });
      }else{
        layer.alert(res.resultMessage)
      }
    })
  },
  renderData(id,data){
    var html='';
    data.forEach(function(v,k){
      html+=`<option value="${v.code ? v.code : v.id}" type="${v.type}">${v.name}</option>`
    })
    $(`.${id}`).append(html);
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  formatType(type){
    var obj={
      "0":'全部',
      "1":'网页端',
      "2":'APP'
    }
    return obj[type]
  },
  getOptions:function(util){
    var _this = this;
    var arr=[
      { field: 'sort', title: '排序', sort: true,width:100}
      , { field: 'descript', title: '支付名称', width: 120, sort: true}
      , { field: 'rechargtypename', title: '支付类别', width: 140, sort: true}
      , { field: 'merchantType', title: '商户类型', width: 140, sort: true,templet:function(d){return _this.merchantTypeObj[d.merchantType] ?  _this.merchantTypeObj[d.merchantType].name : d.merchantType}}
      , { field: 'enabled',title: '状态', width: 80,sort: true,templet:function(d){return d.enabled ? '已启用' : '已禁用'}}
      , { field: 'viewtype',title: '显示终端', width: 120, sort: true,templet:function(d){return bankBaofoo.formatType(d.viewtype)}}
      , { field: 'currentmoney', title: '累积充值', width: 120, sort: true}
      , { field: 'merchantid', title: '收款卡号', width: 180, templet:function(d){return d.merchantid ? d.merchantid : '--'}}
      , { field: 'fee', title: '手续费', width: 100, sort: true,templet:function(d){return d.fee.toFixed(3)}}
      , { field: 'rechargeremark', title: '充值备注', width: 360, sort: true}
      , { title: '操作', toolbar: '#barDemo'}
    ]
    return arr
  },
  editAlert(isAdd,title,form,data){
    var _this = this;
    layer.open({
      title:title,
      type: 1,
      skin: 'layui-layer-test',
      area: ['700px', '820px'],
      content: htmlTpl.addHtml,
      success:function(){
        isAdd || !data.bank ? $('.bank-list-box').hide() :  ($('.bank-list-box').show(),$('.layui-layer-content').css('overflow-y','scroll'));
        bankBaofoo.renderData('merchantType',bankBaofoo.merchantTypeList);
        bankBaofoo.renderData('rechargtype',bankBaofoo.rechargeList);
        var templateHtml='';
        var targetBank = isAdd || !data.bank ? _this.selfBankList : data.bank;
        targetBank.forEach((v,k)=>{
          templateHtml +=`<input type="checkbox" name="${isAdd || !data.bank ? v.id : v.bankId}" title="${v.name}" value="${isAdd || !data.bank ? v.id : v.bankId}" lay-skin="primary">`
        })
        $(".bank-list").html(templateHtml);
        form.render("select",'add');
        var obj={
          "merchantType": isAdd ? '' : data.merchantType,
          "rechargtype": isAdd ? '' : data.rechargtype,
          "viewtype": isAdd ? '' : data.viewtype,
          "ispoint": isAdd ? '' : data.ispoint ? 1 : 0,
          "sort": isAdd ? '' : data.sort,
          "descript": isAdd ? '' : data.descript,
          "rechargeremark": isAdd ? '' : data.rechargeremark,
          "merchantid": isAdd ? '' : data.merchantid,
          "thirdMerchantID": isAdd ? '' : data.thirdMerchantID,
          "publicKey": isAdd ? '' : data.publicKey,
          "md5key": isAdd ? '' : data.md5key,
          "url": isAdd ? '' : data.url,
          "payUrl": isAdd ? '' : data.payUrl,
          "maxmoney": isAdd ? '' : data.maxmoney,
          "fee": isAdd ? '' : data.fee,
          "minlimit": isAdd ? '' : data.minlimit,
          "amountConfig": isAdd ? '' : data.amountConfig,
          "maxlimit": isAdd ? '' : data.maxlimit
        }
        if(!isAdd && data.bank && data.bank.length > 0){
          data.bank.forEach((v,k)=>{
            if(v.ischeck){
              Object.assign(obj,{[v.bankId]:true});
            }
          })
        }
        form.val('add', obj);
        form.render('checkbox','add');

        isAdd ? $('.layui-edit-merchantBox').remove() : ($('.layui-edit-merchantBox input').attr('disabled',true),$('.layui-add-merchantBox').remove())
        form.on('select(merchantType)',function(data){
          var type = _this.merchantTypeObj[data.value].type;
          type == 'wy' ? ($('.bank-list-box').show(), $('.layui-layer-content').css('overflow-y','scroll')) : ($('.bank-list-box').hide(), $('.layui-layer-content').css('overflow-y','unset'))
        })
        form.on('submit(formAdd)',function(submitData){
          var reqUrl = isAdd ? '/baoFooMerchant/add.mvc' : '/baoFooMerchant/update.mvc';
          var submitType = submitData.field.merchantType;
          var reqData = Object.assign(submitData.field,{type:_this.merchantTypeObj[submitType].type});
          if(_this.merchantTypeObj[submitType].type == 'wy'){
            var checkedData = $('.bank-list-box').find('.layui-form-checkbox');
            var list = [];
            checkedData.each(function(){
              if($(this).hasClass('layui-form-checked')){
                list.push($(this).prev().val())
              }
            })
            if(list.length==0){
              layer.msg('至少选择一项网银银行!');
              return false;
            }
            var reqArr = [];
            targetBank.forEach((v,k)=>{
              var obj={};
              obj.bankId = isAdd ? v.id : v.id ? v.id : v.bankId;
              obj.ischeck= false;
              obj.merchantType = submitType;
              obj.merchantId = submitData.field.merchantid;
              for(var i=0;i<list.length;i++){
                if(isAdd && list[i] == v.id){
                    obj.ischeck=true;
                }else{
                  if(data && !data.bank){
                    if(list[i] == v.id){
                      obj.ischeck=true;
                    }
                  }
                  if(list[i] == v.bankId){
                    obj.ischeck=true;
                  }
                }
              }
              if(!isAdd)obj.id=v.id;
              reqArr.push(obj)
            })
            reqData = Object.assign(reqData,{bank:reqArr});
          }
          for(var i in reqData){
            var ikey = +i;
            if(typeof ikey == 'number' && !isNaN(ikey)){
              delete reqData[i]
            }
          }
          reqData.ispoint == '1' ? reqData.ispoint = true : reqData.ispoint = false;
          reqData.maxlimit = +reqData.maxlimit;
          reqData.minlimit = +reqData.minlimit;

          var reqData = isAdd ? JSON.stringify(reqData) : Object.assign(reqData,{id:data.id}) && JSON.stringify(reqData);
          parent.ajaxService.doPost(reqUrl,reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              bankBaofoo.layerCallback(msg);
            }else{
              layer.msg(msg)
            }
          },'baofoo')
          return false;
        })
      }
    })
  }
}

bankBaofoo.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  bankBaofoo.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  bankBaofoo.getMerchantType(util,layer);
  // 工具栏操作
  bankBaofoo.table.on("toolbar(demo)",function(res){
    var checkStatus = bankBaofoo.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    switch (res.event) {
      case '新增':
        bankBaofoo.editAlert(!0,res.event,form)
      break;
      case '支付类别':
        var url = "html/bank-recharge.html";
        parent.tab.tabAdd(res.event, url, bankBaofoo.index,'');
        parent.tab.tabChange(bankBaofoo.index);
        bankBaofoo.index++;
      break;
      default:
        // layer.msg("接口文档未完善，需要相应人员支持!")
        break;
    }
  })
  //监听行工具事件
  bankBaofoo.table.on('tool(demo)', function(obj){
    var data = obj.data;
    if(obj.event === 'lock'){
      var text = data.enabled ? '禁用' : '启用';
      layer.confirm(`是否${text}?`, function(index){
        var reqData={
          id:data.id,
          enabled:!data.enabled
        }
        parent.ajaxService.doPost("/baoFooMerchant/changestate.mvc",reqData,function(res){
          var msg = res.resultMessage
          if(res.resultCode == 0){
            bankBaofoo.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(obj.event === 'del'){
      layer.confirm(`是否删除?`, function(index){
        var reqData={
          baoFooId:data.id,
          type:bankBaofoo.merchantTypeObj[data.merchantType].type
        }
        parent.ajaxService.doPost("/baoFooMerchant/delete.mvc",reqData,function(res){
          var msg = res.resultMessage
          if(res.resultCode == 0){
            bankBaofoo.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(obj.event === 'transfer'){
      layer.open({
        title:'转移',
        type: 1,
        skin: 'layui-layer-test',
        area: ['620px', '550px'],
        content: htmlTpl.transferHtml,
        success:function(){
          var obj={
            "sourcemerchantid": data.merchantid,
            "targetbankname":'',
            "targetbranchname":'',
            "targetaccountname":'',
            "targetaccountno":'',
            "money":'',
            "fee":0,
          }
          form.val('transfer', obj)
          form.on('submit(formTrsansfer)',function(submitData){
            var reqData =  submitData.field;
            parent.ajaxService.doPost('/baoFooTransfer/add.mvc',reqData,function(res){
              var msg = res.resultMessage;
              if(res.resultCode==0){
                bankBaofoo.layerCallback(msg);
              }else{
                layer.msg(msg)
              }
            })
            return false;
          })
        }
      })
    }else if(obj.event === 'set'){
      bankBaofoo.editAlert(0,'修改',form,data);
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    bankBaofoo.table.reload('demo',{
        where:data.field,
        page:{
            curr:1
        }
    })
    return false;
  });
});



