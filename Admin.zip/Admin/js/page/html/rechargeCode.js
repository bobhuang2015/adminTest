
var rechargeCode = {
  table:null,
  toolbarHtml:'',
  hasMark:false,
  hasSet:false,
  pageNumber:1,
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var obj = {
      '标记完成':'hasMark',
      '修改':'hasSet'
    }
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        this[obj[i]]=true
      })
    }
  },
  reloadTable:function(){
    var _this=this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  formatType(type){
    var obj={
      "0":'正在打码',
      "1":'打码完成',
      "2":'被继承',
      "3":'余额不足'
    }
    return obj[type]
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getUrlParam(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); //构造一个含有目标参数的正则表达式对象
    var r = window.location.search.substr(1).match(reg);  //匹配目标参数
    if (r != null) return unescape(r[2]); return null; //返回参数值
  },
  getOptions:function(util){
    var arr=[
      { title: '操作', width: 140, toolbar: '#barDemo'}
      , { field: 'username', title: '用户账号', width: 120,sort: true}
      , { field: 'rechargeordernum', title: '充值订单号', width: 140, sort: true}
      , { field: 'rechargetime', title: '充值时间', width: 150, sort: true,templet:function(d){return util.toDateString(d.rechargetime, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'rechargemoney', title: '充值金额', width: 100,sort: true,templet:function(d){return d.rechargemoney.toFixed(3)}}
      , { field: 'mainaccountamount', title: '充值前余额', width: 110,sort: true,templet:function(d){return d.mainaccountamount.toFixed(3)}}
      , { field: 'demandordersamount', title: '要求打码额', width: 120,sort: true}
      , { field: 'currentordersamount', title: '已完成打码额', width: 130,sort: true}
      , { title: '未完成打码额', width: 130,sort: true,templet:function(d){return  (d.currentordersamount - d.demandordersamount) > 0 ? '' : (d.demandordersamount - d.currentordersamount) }}
      , { field: 'orderstate', title: '状态', width: 100,templet:function(d){return rechargeCode.formatType(d.orderstate)}} 
      , { field: 'finishedtime', title: '打码满额时间', width: 140,sort: true,templet:function(d){return util.toDateString(d.finishedtime, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'lastoperator', title: '操作人', width: 100}
      , { field: 'remark', title: '备注'}
    ]
    return arr
  },
}

rechargeCode.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  rechargeCode.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  var userName = rechargeCode.getUrlParam('userName');
  globalAdmin.renderRechargeDate(laydate,util)
  if(userName)$("#userName").val(userName);
  rechargeCode.table.render({
    elem: '#demo'
    , height: 'full-80'
    , url: '/withdrawOrdersAmount/search.mvc'
    , page: true
    , method: 'get'
    , cols: [rechargeCode.getOptions(util)]
    , where: {
      username:$("#userName").val(),
      orderstate:-1
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      rechargeCode.pageNumber=cur;
    }
  });
  
  // 工具栏操作
  rechargeCode.table.on("tool(demo)",function(obj){
    var data = obj.data;
    var event = obj.event;
    switch (event) {
      case 'mark':
        layer.confirm(`标记完成后不可修改,请确认!`,function(index){
          var reqData={
            id:data.id,
            userid:data.userid,
            rechargeordernum:data.rechargeordernum,
            demandordersamount:0
          }
          parent.ajaxService.doPost("/withdrawOrdersAmount/editdemand.mvc",reqData,function(res){
            var msg = res.resultMessage
            if(res.resultCode == 0){
              rechargeCode.layerCallback(msg);
            }else{
              layer.msg(msg);
            }
          })
          },function(index){
            layer.close(index)
          }
        )
      break;
      case 'set':
        layer.open({
          title:'修改',
          type: 1,
          skin: 'layui-layer-test',
          area: ['600px', '300px'],
          content: htmlTpl.addHtml,
          success:function(){
            var currentordersamount2 = data.demandordersamount - data.currentordersamount;//未完成打码额
            var obj={
              "currentordersamount": data.currentordersamount,
              "currentordersamount2": currentordersamount2,
              "demandordersamount":data.demandordersamount
            }
            form.val('add', obj)
            var dataObj = {
              id:data.id,
              rechargeordernum:data.rechargeordernum,
              userid:data.userid
            }
            form.on('submit(formAdd)',function(submitData){
              var reqUrl = '/withdrawOrdersAmount/editdemand.mvc';
              var reqData = Object.assign(submitData.field,dataObj);
              parent.ajaxService.doPost(reqUrl,reqData,function(res){
                var msg = res.resultMessage;
                if(res.resultCode==0){
                  rechargeCode.layerCallback(msg);
                }else{
                  layer.msg(msg)
                }
              })
              return false;
            })
          }
        })
      break
      default:
        break;
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    rechargeCode.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
  laydate.render({
    elem: '#start' //指定元素
  });
  laydate.render({
    elem: '#end' //指定元素
  });
});



