
var userCenterRedList = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  getToolbarHtml(){ 
  },
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var arr=[
      { field: 'title', title: '红包标题', width: 120, sort: true}
      , { field: 'account', title: '领取者', width: 100, sort: true}
      , { field: 'userName', title: '昵称', width: 100, sort: true}
      , { field: 'amount', title: '领取金额', width: 110, sort: true}
      , { field: 'total', title: '领取个数', width: 110, sort: true}
      , { field: 'multiple', title: '流水要求', width: 110, sort: true}
      , { field:'time',title: '领取时间', width: 160, sort: true,templet:function(d){return util.toDateString(d.time, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'ip', title: '领取IP', width: 110, sort: true}
      , { field: 'sendUser', title: '发放人', width: 110, sort: true}
      , { field:'sendTime',title: '发放时间', width: 160, sort: true,templet:function(d){return util.toDateString(d.sendTime, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'note', title: '备注'}
    ]
    return arr
  },
  renderTotal(res){
    if (res.data && res.data.length > 0 && res.total){
      var tr = '<tr class="table-total"><td colspan="50">总量合计：<span>总计金额 :'+res.total.amount+',</span><span>总计领取数 :'+res.total.total+'</span> </td></tr>'
      $('.layui-table-body table').append(tr)
    }
  }  
}

layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  userCenterRedList.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  
  var topHeight = ~~($(".layui-row").height()+40);
  parent.globalAdmin.renderIntDate(laydate,util)
  userCenterRedList.table.render({
    elem: '#demo'
    , height: `full-${topHeight}`
    , url: '/redPacket/detailList.mvc'
    , page: true
    , method: 'get'
    , cols: [ userCenterRedList.getOptions(util)],
    where: {
      "sendTimeBegin":$('#start').val(),
      "sendTimeEnd":$("#end").val()
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.results[0].total,
        "data": res.results[0].list,
        'total':res.results[1]
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      userCenterRedList.renderTotal(res)
    }
  });
  
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    userCenterRedList.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        },
        done:function(res, cur, count){
          userCenterRedList.renderTotal(res)
        }
    })
    return false;
  });
});



