
var permissionThirdPlat = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  hasSet:false,
  hasDel:false,
  platform:{},
  pageNumber:1,
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    var obj={
      '禁用/启用':'hasLock',
      '修改':'hasSet',
      '删除':'hasDel'
    }
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i!='新增'){
          this[obj[i]]=true;
        }else{
          otherHtml ='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${otherHtml}</div>`;
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  renderPlatform:function(data){
    var html='';
    for(var i in data){
      html+=`<option value="${i}">${data[i]}</option>`
    }
    $(".platform").append(html);
  },
  getPlatform(){
    var _this = this;
    parent.ajaxService.doGet("/getEnumByName.mvc",{enumName:'ThirdParty_Platform'},function(res){
      if(res.resultCode == 0){
        var data = res.results[0];
        _this.renderPlatform(data);
        _this.platform = data;
      }
    })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var arr=[
      { title: '平台类型', width: 140, sort: true,templet:function(d){return permissionThirdPlat.platform[d.thridtype]}}
      , { title: '状态', width: 140, sort: true,templet:function(d){return d.start==1 ? '启用' : '禁用'}}
      , { title: '维护开始时间', width: 180, sort: true,templet:function(d){return util.toDateString(d.whdtbegin, "yyyy-MM-dd HH:mm:ss")}}
      , { title: '维护结束时间', width: 180, sort: true,templet:function(d){return util.toDateString(d.whdtend, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'remark', title: '备注', sort: true}
      , { field: 'operator', title: '操作人', width: 140, sort: true}
      , { title: '操作时间', width: 180, sort: true,templet:function(d){return util.toDateString(d.optdt, "yyyy-MM-dd HH:mm:ss")}}
      , {title:'操作',toolbar:'#barDemo'}
    ]
    return arr
  },
  editIdArr:[],
  tableData:[]
}

permissionThirdPlat.getToolbarHtml();
permissionThirdPlat.getPlatform();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  permissionThirdPlat.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  
  parent.globalAdmin.renderIntDate(laydate,util,'third')


  permissionThirdPlat.table.render({
    elem: '#demo'
    , height: 'full-80'
    , url: '/thridMaintenanceConf/search.mvc'
    , toolbar: permissionThirdPlat.toolbarHtml
    , defaultToolbar:[]
    , page: true
    , method: 'get'
    , cols: [ permissionThirdPlat.getOptions(util)],
    where: {
     "ser_whdtbegin":$("#start").val(),
     "ser_whdtend":$("#end").val(),
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results
      };
      permissionThirdPlat.tableData=res.results;
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      permissionThirdPlat.pageNumber=cur;
      form.render('select', 'test')
    }
  });
  
  // 工具栏操作
  permissionThirdPlat.table.on("toolbar(demo)",function(res){
    var checkStatus = permissionThirdPlat.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    switch (res.event) {
      case '新增':
        layer.open({
          title:res.event,
          type: 1,
          skin: 'layui-layer-test',
          area: ['600px', '560px'],
          content: htmlTpl.addHtml,
          success:function(){
            permissionThirdPlat.renderPlatform(permissionThirdPlat.platform)
            laydate.render({
              elem: '#layui-start',
              type:'datetime'
            });
            laydate.render({
              elem: '#layui-end',
              type:'datetime' 
            });
            var obj={
              "thridtype": -1,
              "ser_whdtbegin":'',
              "start": -1,
              "ser_whdtend":'',
              "remark":'',
              'dayTransferOutTotal':'',
              'monTransferOutTotal':''
            }
            form.val('add', obj);
            form.on('submit(formAdd)',function(submitData){
              parent.ajaxService.doPost('/thridMaintenanceConf/add.mvc',submitData.field,function(res){
                var msg = res.resultMessage;
                if(res.resultCode==0){
                  permissionThirdPlat.layerCallback(msg);
                }else{
                  layer.msg(msg)
                }
              })
              return false;
            })
          }
        })
      break;
      default:
        break;
    }
  })
  //监听行工具事件
  permissionThirdPlat.table.on('tool(demo)', function(obj){
    var data = obj.data;
    var event = obj.event;
    if(event === 'lock'){
      var text = data.start==1 ? '禁用' : '启用'; 
      layer.confirm(`是否${text} ${permissionThirdPlat.platform[data.thridtype]}?`, function(index){
        var reqData={
          id:data.id
        }
        parent.ajaxService.doPost("/thridMaintenanceConf/updateLock.mvc",reqData,function(res){
          var msg = res.resultMessage;
          if(res.resultCode ==0){
            permissionThirdPlat.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(event === 'del'){
      layer.confirm(`是否删除${permissionThirdPlat.platform[data.thridtype]}?`, function(index){
        var reqData={
          id:data.id
        }
        parent.ajaxService.doPost("/thridMaintenanceConf/delete.mvc",reqData,function(res){
          var msg = res.resultMessage;
          if(res.resultCode ==0){
            permissionThirdPlat.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(event === 'set'){
      layer.open({
        title:'修改',
        type: 1,
        skin: 'layui-layer-test',
        area: ['600px', '560px'],
        content: htmlTpl.addHtml,
        success:function(){
          permissionThirdPlat.renderPlatform(permissionThirdPlat.platform)
          laydate.render({
            elem: '#layui-start',
            type:'datetime'
          });
          laydate.render({
            elem: '#layui-end',
            type:'datetime' 
          });
          var obj={
            "id":data.id,
            "thridtype": data.thridtype,
            "ser_whdtbegin": util.toDateString(data.whdtbegin, "yyyy-MM-dd HH:mm:ss"),
            "start": data.start,
            "ser_whdtend":util.toDateString(data.whdtend, "yyyy-MM-dd HH:mm:ss"),
            "remark":data.remark,
            'dayTransferOutTotal':data.dayTransferOutTotal,
            'monTransferOutTotal':data.monTransferOutTotal
          }
          form.val('add', obj);
          form.on('submit(formAdd)',function(submitData){
            var reqData = Object.assign(submitData.field,{id:data.id});
            parent.ajaxService.doPost('/thridMaintenanceConf/update.mvc',reqData,function(res){
              var msg = res.resultMessage;
              if(res.resultCode==0){
                permissionThirdPlat.layerCallback(msg);
              }else{
                layer.msg(msg)
              }
            })
            return false;
          })
        }
      })
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    permissionThirdPlat.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



