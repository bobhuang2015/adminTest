
var usercenterNotice = {
  table:null,
  toolbarHtml:'',
  hasDel:false,
  hasSet:false,
  pageNumber:1,
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){
    var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        var obj = {
          '修改':'hasSet',
          '删除':'hasDel'
        }
        if(i !='新增'){
          this[obj[i]]=true;
        }else{
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${otherHtml}</div>`;
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  formatMsgtype(str){
    var arr=[];
    var temp = str.split(",");
    var obj={
      "0":'首页',
      "1":'滚动',
      "2":'弹框',
      "6":'推送'
    }
    temp.forEach(function(v,k){
      arr.push(obj[v])
    })
    return arr.join()
  },
  getOptions:function(util){
    var arr=[
      { field: 'type', title: '公告类型', width: 130, sort: true,templet:function(d){return usercenterNotice.formatMsgtype(d.type)}}
      , { field: 'title', title: '公告标题', width: 300,sort: true}
      , { field: 'content', title: '公告内容', width: 560, sort: true}
      , { field: 'noticeTime',title: '公告时间', width: 320, sort: true}
      , { field: 'operator', title: '操作者', width: 120, sort: true}
      , { field: 'sort', title: '序号', width: 80, sort: true}
      , { title: '操作', toolbar:'#barDemo'}
    ]
    return arr
  },
}

usercenterNotice.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  usercenterNotice.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;

  var topHeight = ~~($(".layui-row").height()+40);
  usercenterNotice.table.render({
    elem: '#demo'
    , height: `full-${topHeight}`
    , url: '/notice/list.mvc'
    ,toolbar: usercenterNotice.toolbarHtml
    , page: true
    , defaultToolbar:[]
    , method: 'get'
    , cols: [ usercenterNotice.getOptions(util)],
    where: {
    }
    , parseData: function (res) {
      res.results.forEach((v,k)=>{
        v.noticeTime = util.toDateString(v.timebegin, "yyyy-MM-dd HH:mm:ss")+'--'+util.toDateString(v.timeend, "yyyy-MM-dd HH:mm:ss")
      })
      var result = {
        "code": res.resultCode,
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      usercenterNotice.pageNumber=cur;
    }
  });
var addSwicth = false
  // 工具栏操作
  usercenterNotice.table.on("toolbar(demo)",function(res){
    switch (res.event) {
      case '新增':
        layer.open({
          title:res.event,
          type: 1,
          skin: 'layui-layer-test',
          area: ['600px', '500px'],
          content: htmlTpl.addHtml,
          success:function(){
            lay('.layui-date').each(function(){
              laydate.render({
                elem: this
                ,trigger: 'click'
                ,type:'datetime'
              });
            });
            var obj={
              "title": '',
              "content": '',
              "timebegin":'',
              "timeend":'',
              'sort':'',
              "type[0]":true
            }
            form.val('add', obj)
            form.on('submit(formAdd)',function(submitData){
              var data = submitData.field;
              var arr=[]
              for(var i in data){
                if(i !='title' && i !='content' && i!='timebegin' && i!='timeend' && i!='sort'){
                  arr.push(submitData.field[i])
                }
              }
              var reqData = {
                "title": data.title,
                "content": data.content,
                "timebegin":data.timebegin,
                "timeend":data.timeend,
                'sort':data.sort,
                "type":arr.join()
              }
              if(arr.length==0){
                layer.msg("请勾选公告类型")
                return false;
              }
              if(data.content.length > 500){
                layer.msg("字数控制在500个以内!")
                return false;
              }
              if (addSwicth) { return false }
              addSwicth = true
              parent.ajaxService.doPost('/notice/add.mvc',reqData,function(res){
                addSwicth = false
                var msg = res.resultMessage;
                if(res.resultCode==0){
                  usercenterNotice.layerCallback(msg);
                }else{
                  layer.msg(msg)
                }
              })
              return false;
            })
          }
        })
      break;
      default:
        break;
    }
  })
  //监听行工具事件
  var setSwitch = false
  usercenterNotice.table.on('tool(demo)', function(obj){
    var data = obj.data;
    var event = obj.event;
    if(event === 'del'){
      layer.confirm(`是否删除?`, function(index){
        var reqData={
          noticeId:data.id
        }
        parent.ajaxService.doPost("/notice/delete.mvc",reqData,function(res){
          var msg = res.resultMessage
          if(res.resultCode ==0){
            usercenterNotice.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(event === 'set'){
      layer.open({
        title:'修改',
        type: 1,
        skin: 'layui-layer-test',
        area: ['600px', '500px'],
        content: htmlTpl.addHtml,
        success:function(){
          lay('.layui-date').each(function(){
            laydate.render({
              elem: this
              ,trigger: 'click'
              ,type:'datetime'
            });
          });
          var obj={
            "title": data.title,
            "content": data.content,
            'sort':data.sort,
            "timebegin":util.toDateString(data.timebegin, "yyyy-MM-dd HH:mm:ss"),
            "timeend":util.toDateString(data.timeend, "yyyy-MM-dd HH:mm:ss")
          }
          data.type.split(',').forEach(function(v,k){
            Object.assign(obj,{['type['+v+']']:true})
          })
          form.val('add',obj)
          form.render('checkbox','add')

          form.on('submit(formAdd)',function(submitData){
            var formData = submitData.field;
            var arr=[]
            for(var i in formData){
              if(i !='title' && i !='content' && i!='timebegin' && i!='timeend' && i!='sort'){
                arr.push(submitData.field[i])
              }
            }
            var reqData = {
              "id":data.id,
              "title": formData.title,
              "content": formData.content,
              "timebegin":formData.timebegin,
              "timeend":formData.timeend,
              'sort':formData.sort,
              "type":arr.join()
            }
            if(arr.length==0){
              layer.msg("请勾选公告类型")
              return false;
            }
            if(data.content.length > 500){
              layer.msg("字数控制在500个以内!")
              return false;
            }
            if (setSwitch) { return false}
            setSwitch = true
            parent.ajaxService.doPost('/notice/update.mvc',reqData,function(res){
              setSwitch = false
              var msg = res.resultMessage;
              if(res.resultCode==0){
                usercenterNotice.layerCallback(msg);
              }else{
                layer.msg(msg)
              }
            })
            return false;
          })
        }
      })
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    usercenterNotice.table.reload('demo',{
        where:data.field,
        page:{
            curr:1
        }
    })
    return false;
  });
});



