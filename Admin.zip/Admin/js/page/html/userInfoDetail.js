
var userInfoDetail = {
  renderData(d){
    var html = '';
    html +=`<tr>
        <td>${d.nickname}</td>
        <td>${d.floor}</td>
        <td>${parent.userInfo.getUserLevel(d.userlevel)}</td>
        <td>${d.vipLevel}</td>
        <td>${d.regsource == 1 ? '手工开户' :'注册链接'}</td>
        <td>${d.regLink ? d.regLink : '--'}</td>
        <td>${parent.userInfo.formatUsertype(d.usertype)}</td>
        <td>${d.remark ? d.remark : ''}</td>
        <td>${parent.userInfo.getTransferpower(d.transferpower)}</td>
        <td>${d.capitalCenter.state !=0  ? d.capitalCenter.withdrawstatusremark :""}</td>
      </tr>`
    $(".tbody").append(html);
  }
}
userInfoDetail.renderData(parent.userInfo.detailData)


