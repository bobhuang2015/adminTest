
var rechargeManual = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  hasDaochu:false,
  is:!0,
  token:'',
  name:'manual',
  tableIns:null,
  tableData:[],
  pageNumber:1,
  rechargeTypeObj:{},//表格充值方式
  activeTypeObj:{},//活动类型
  alertRechargeType:{},//弹窗充值方式
  bankList:{},//平台银行
  baofooList:{},//宝付账户
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i =='导出数据'){
          this.hasDaochu=!0;
          $('button[lay-filter="formDaochu"]').show();
        }else{
          editHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${editHtml}</div>`;
  },
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1  
      }
	  })
  },
  getRechargeType(form){
    var _this = this;
    parent.ajaxService.doGet("/getEnumByName.mvc",{enumName:'Recharge_Way'},function(res){
      if(res.resultCode==0){
        var data = res.results[0];
        _this.rechargeTypeObj=data;
        _this.renderData('rechargeMethod',data);
      }
    })
    // _this.getGameType(form);
    // _this.getAlertRechargeType();
  },
  getGameType(form){
    var _this = this;
    parent.ajaxService.doGet("/getEnumByName.mvc",{enumName:'Activity_GameType'},function(res){
      if(res.resultCode==0){
        var data = res.results[0];
        _this.activeTypeObj=data;
        _this.renderData('activeType',data);
        setTimeout(function(){
          _this.getAlertRechargeType(form);
        },300)
      }
    })
  },
  getAlertRechargeType(form){
    var _this = this;
    parent.ajaxService.doGet("/getEnumByName.mvc",{enumName:'Recharge_Type'},function(res){
      if(res.resultCode==0){
        var data = res.results[0];
        _this.alertRechargeType=data;
        _this.renderData('rechargeType',data);
        form.render("select",'add');
      }
    })
  },
  getPlatformBank(form){
    var _this = this;
    parent.ajaxService.doGet("/cache/getPlatformBankMap.mvc",function(res){
      if(res.resultCode==0){
        _this.bankList=res.results[0];
        _this.renderData('platform',res.results[0]);
        _this.getBaofooList(form)
      }
    })
  },
  getBaofooList(form){
    var _this = this;
    parent.ajaxService.doGet("/cache/getBaoFooMerchantMap.mvc",function(res){
      if(res.resultCode==0){
        _this.baofooList=res.results[0];
        _this.renderData('baofoo',res.results[0]);
        form.render('select','makeup')
      }
    })
  },
  formatRechargeType(type){
    var obj={
      "1":'处理中',
      "2":'成功',
      "3":'失败'
    }
    return obj[type]
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  renderData(id,data){
    var html='';
    for(var i in data){
      html+=`<option value="${i}">${data[i]}</option>`
    }
    $(`.${id}`).append(html);
  },
  getOptions:function(util){
    var arr=[
        { field: 'ordernumber', title: '订单号', width: 180, sort: true}
      , { field: 'username', title: '用户账号', width: 180,sort: true}
      , { field: 'changeitem', title: '充值方式', width: 120, sort: true,templet:function(d){return rechargeManual.rechargeTypeObj[d.changeitem]}}
      , { field: 'changemoney', title: '充提金额', width: 140, sort: true,templet:function(d){return d.changemoney.toFixed(3)}}
      , { field: 'changetime', title: '充提时间', width: 180, sort: true,templet:function(d){return util.toDateString(d.changetime, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'state', title: '状态', width: 120, sort: true,templet:function(d){return rechargeManual.formatRechargeType(d.state)}}
      , { field: 'demandorderamount', title: '打码', width: 120,templet:function(d){return d.demandorderamount > 0 ? d.demandorderamount + '%' : d.demandorderamount}}
      , { field: 'operator', title: '操作者', width: 120}
      , { field: 'remark', title: '备注'}
    ]
    return arr
  },
  getUserId(name){
    parent.ajaxService.doGet("/systemDepositAndWithdraw/findUser.mvc",{userName:name},function(res){
      if(res.resultCode==0){
        var data = res.results[0].capitalCenter;
        $(".layui-balance").val(data.accountbalance);
        $(".layui-userid").val(data.userid);
        parent.ajaxService.doGet('/systemDepositAndWithdraw/getToken.mvc',{userId:data.userid},function(res){
          if(res.resultCode == 0 ){
            rechargeManual.token = res.results[0];
          }
        })
      }else{
        layer.msg('没有该用户请重新输入!')
      }
    })
  },
  renderTotal(res){
    if (res.data && res.data.length > 0 && res.total){
      var str='<tr class="table-total"><td colspan="50">总量合计:';
      res.total.forEach((v,k)=>{
          str+= `<span>${v.changename}：${v.sumChangemoney}</span>`
      })
      str +='</td></tr>';
      $('.layui-table-body table').append(str)
    }
  },
  manualAlert(title,form){
    var _this = this;
    layer.open({
      title:title,
      type: 1,
      skin: 'layui-layer-test',
      area: ['620px', '500px'],
      content: htmlTpl.addHtml,
      success:function(){
        if(JSON.stringify(_this.alertRechargeType) =='{}' && JSON.stringify(_this.activeTypeObj) == '{}'){
          _this.getGameType(form)
        }else{
          rechargeManual.renderData('rechargeType',rechargeManual.alertRechargeType);
          rechargeManual.renderData('activeType',rechargeManual.activeTypeObj);
          form.render("select",'add');
        }
        var obj={
          "username": '',
          "userid": '',
          "accountbalance":'',
          "ispoint":'',
          "changeitem":'',
          "gametype":'0',
          "changemoney":'',
          "demandorderamount":'',
          "remark":''
        }
        form.val('add', obj);
        form.render('select','add');
        $(".layui-username").on('change',function(){
          var name = $(this).val();
          rechargeManual.getUserId(name);
        })
        form.on('submit(formAdd)',function(submitData){
          var reqUrl = '/systemDepositAndWithdraw/deposit.mvc';
          var reqData = Object.assign(submitData.field,{changetype:1,token:_this.token});
          if(+reqData.changemoney <= 0){
            layer.msg('请输入比0大的数值！');
            return false;
          }
          $('button[lay-filter="formAdd"]').addClass('layui-btn-disabled').html('提交中');
          if(rechargeManual.is){
            rechargeManual.is=0;
            parent.ajaxService.doPost(reqUrl,reqData,function(res){
              var msg = res.resultMessage;
              rechargeManual.is=!0;
              rechargeManual.token = '';
              if(res.resultCode==0){
                rechargeManual.layerCallback(msg);
              }else{
                layer.msg(msg)
              }
            })
          }
          return false;
        })
      }
    })
  },
  makeupAlert(title,form){
    var _this = this;
    return;
    this.getPlatformBank(form);
  }
}

rechargeManual.getToolbarHtml();
rechargeManual.getRechargeType();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  rechargeManual.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  var is = true;
  globalAdmin.renderRechargeDate(laydate,util);
  var topHeight = ~~($(".layui-row").height()+46);
  rechargeManual.tableIns=rechargeManual.table.render({
    elem: '#demo'
    , height: `full-${topHeight}`
    , url: '/systemDepositAndWithdraw/search.mvc'
    , toolbar: rechargeManual.toolbarHtml
    , defaultToolbar:[]
    , page: true
    , method: 'get'
    , cols: [rechargeManual.getOptions(util)]
    , where: {
      'changetype':1
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results[0],
        "total":res.results[0].length > 0 && res.results[1]
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      if(is)(is=!is,form.render('select'))
        rechargeManual.pageNumber = cur;
      rechargeManual.tableData = res.data;
      rechargeManual.renderTotal(res);
    }
  });
  
  // 工具栏操作
  rechargeManual.table.on("toolbar(demo)",function(res){
    var checkStatus = rechargeManual.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    var event = res.event;
    switch (event) {
      case '人工充值':
        rechargeManual.manualAlert(event,form)
      break;
      case '人工补单':
        rechargeManual.makeupAlert(event,form)
      break;
      default:
        break;
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    delete data.field.isAll;
    rechargeManual.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        },
        done: function (res, cur, count) {
          rechargeManual.renderTotal(res);
          rechargeManual.pageNumber = cur;
          rechargeManual.tableData = res.data;
        }
    })
    return false;
  });
  
  // 导出数据
  form.on('submit(formDaochu)', function (data) {
    rechargeManual.hasDaochu && parent.globalAdmin.exportData(form,data,rechargeManual)
    return false;
  });
});



