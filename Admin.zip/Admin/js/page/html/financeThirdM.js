
var financeThirdM = {
  table:null,
  toolbarHtml:'',
  hasSwitch:true,
  hasSet:true,
  hasDel:true,
  hasTransferIn:true,
  hasTransferOut:true,
  pageNumber:1,
  renderPlaceholder:function(){
    $(".search-case input[name='merchantName']").attr("placeholder",this.initObj.merchantName);
    $(".search-case input[name='merchantNo']").attr("placeholder",this.initObj.merchantNo);
    $(".search-case input[name='orderNo']").attr("placeholder",this.initObj.orderNo);
    $(".search-case input[name='userBankNo']").attr("placeholder",this.initObj.userBankNo);
    $(".search-case input[name='userName']").attr("placeholder",this.initObj.userName);
  },
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber
      }
    })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var arr=[
      { field: 'merchantName', title: '商户名', width: 140}
      , { field: 'merchantNo', title: '商户号', width: 120}
      , { field: 'orderNo', title: '订单号', width: 180}
      , { field: 'withdraw', title: '出款金额', sort: true,width:130,templet:function(d){return d.withdraw.toFixed(3)}}
      , { field: 'fee', title: '手续费', sort: true,width:130,templet:function(d){return d.fee.toFixed(3)}}
      , { field: 'userBank', title: '用户银行', width: 180}
      , { field: 'accountName', title: '开户名', width: 120}
      , { field: 'userBankNo', title: '用户银行卡号', width: 180}
      , { field: 'userName', title: '用户名', width: 120}
      , { field: 'checkName', title: '审核人', width: 120}
      , { field: 'checkTime', title: '审核时间',sort: true,templet:function(d){return util.toDateString(d.checkTime, "yyyy-MM-dd")}}
    ]
    return arr
  },
  editIdArr:[],
  initObj:{
    merchantName:'商户名',
    merchantNo:'商户号',
    orderNo:'订单号',
    userBankNo:'用户银行卡号',
    userName:'用户名',
    tableUrl:'/agentPayRecord/select.mvc'
  },
  renderTotal(res){
    if (res.data && res.data.length > 0 && res.total){
      var tr = '<tr class="table-total"><td colspan="50">总量合计：<span>总余额： '+res.total.sumBalance+'</span></td></tr>'
      $('.layui-table-body table').append(tr)
    }
  },
  editAlert(title,form,data){
    var isAdd = title == '新增' ? !0 : 0;
    layer.open({
      title:title,
      type: 1,
      skin: 'layui-layer-test',
      area: ['600px', '280px'],
      content: htmlTpl.addHtml,
      success:function(){
        $(".merchantName").text(financeThirdM.initObj.merchantName);
        $(".merchantNo").text(financeThirdM.initObj.merchantNo);
        $(".orderNo").text(financeThirdM.initObj.orderNo);
        $(".userBankNo").text(financeThirdM.initObj.userBankNo);
        $(".userName").text(financeThirdM.initObj.userName);
        var obj={
          "merchantName": isAdd ? '' :data.merchantName,
          "merchantNo":isAdd ? '' :data.merchantNo,
          "orderNo":isAdd ? '' :data.orderNo,
          "userBankNo":isAdd ? 0 :data.userBankNo,
          "userName":isAdd ? 0 :data.userName
        }
        form.val('add', obj);
        var reqUrl='';
        if(window.name=='iframe_16'){
          reqUrl = isAdd ? '/chuKuanBank/add.mvc' : '/chuKuanBank/edit.mvc';
        }else{
          reqUrl = isAdd ? '/ruKuanBank/add.mvc' : '/ruKuanBank/edit.mvc';
        }
        form.on('submit(formAdd)',function(submitData){
          var reqData = isAdd ? submitData.field : Object.assign(submitData.field,{id:data.id});
          parent.ajaxService.doPost(reqUrl,reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              financeThirdM.layerCallback(msg);
              // financeThirdM.editIdArr=[];
            }else{
              layer.msg(msg)
            }
          })
          return false;
        })
      }
    })
  }
}

financeThirdM.renderPlaceholder();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  financeThirdM.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  financeThirdM.table.render({
    elem: '#demo'
    , height: 'full-70'
    , url: financeThirdM.initObj.tableUrl
    ,toolbar: financeThirdM.toolbarHtml
    , page: true
    , defaultToolbar:[]
    , method: 'post'
    , cols: [ financeThirdM.getOptions(util)],
    where: {
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode,
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results[0],
        "total":res.results[0] && res.results[0].length > 0 && res.results[1]
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      financeThirdM.pageNumber=cur;
      financeThirdM.renderTotal(res);
    }
  });
  form.on('submit(formDemo)', function (data) {
    financeThirdM.table.reload('demo',{
      where:data.field,
      page:{
        curr:1
      },
      done: function (res, cur, count) {
        financeThirdM.renderTotal(res);
      }
    })
    return false;
  });
});



