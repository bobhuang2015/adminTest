
var platformLimitUser = {
  table:null,
  hasLock:false,
  reloadTable:function(index){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1  
      },
      done:function(){
        layer.close(index)
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var arr=[
      { field: 'username', title: '用户账号', width: 140,sort: true}
      , { title: '操作', toolbar:'#barDemo'}
    ]
    return arr
  }
}

layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  platformLimitUser.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  platformLimitUser.table.render({
    elem: '#demo'
    , height: 420
    , url: '/consumerRebated/listRebateUser.mvc'
    , toolbar: platformLimitUser.toolbarHtml
    , page: true
    , method: 'get'
    , cols: [ platformLimitUser.getOptions(util)],
    where: {
      type:parent.platformsetConsumerebate.currentType
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results[0]
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
    }
  });
  
  //监听行工具事件
  platformLimitUser.table.on('tool(demo)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
      layer.confirm(`是否删除选中行?`, function(index){
        var reqData={
          id:data.id
        }
        parent.ajaxService.doPost("/consumerRebated/deleteRebateUser.mvc",reqData,function(res){
          var msg = res.resultMessage;
          if(res.resultCode ==0){
            platformLimitUser.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }
  })
  $(document).on('click','.layui-icon',function(){
    parent.globalAdmin.showLayer('选择用户','./user-info.html?limitUser=true&permision=iframe_12',1700,760,'limitUser')
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    var username = data.field.username
    if(!username){
      layer.msg('请选择用户');
      return false
    }
    layer.confirm(`确认添加限制用户${username}`,{btn:['确定','取消']},function(){
      parent.ajaxService.doPost('/consumerRebated/addRebateUser.mvc',{username:username,type:parent.platformsetConsumerebate.currentType},function(res){
        var msg = res.resultMessage;
        if(res.resultCode ==0){
          $('#layui-user').val('');
          top.globalAdmin.limitUserArr=[];
          layer.alert(msg,function(index){
            platformLimitUser.reloadTable(index)
          })
        }else{
          layer.msg(msg)
        }
      })
    })
    return false;
  });
});



