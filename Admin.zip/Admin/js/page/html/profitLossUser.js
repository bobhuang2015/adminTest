var profitLossUser = {
  index:0,
  legendData:['登录会员','投注会员','新增会员','充值会员','首充会员', '领取优惠会员', '提款会员'],
  // legendData:['登录会员','投注会员','新增会员','充值会员','首充会员'],
  renderPie(xAxisData,seriesData) {
    var myChart = echarts.init(document.getElementById("demo"));
    var option = {
        title: {
            text: '用户活跃统计图'
        },
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data:profitLossUser.legendData
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        xAxis: {
            type: 'category',
            boundaryGap: false,
            data: xAxisData
        },
        yAxis: {
            type: 'value'
        },
        series: seriesData
    };
    myChart.setOption(option);
    layer.close(profitLossUser.index);
  },
  getData() {
    var _this = this;
    parent.ajaxService.doGet("/userActiveDailyReport/statisByDays.mvc",null,function(res) {
        if (res.resultCode == 0) {
          var data = res.results[0].reverse();
          var xAxisData = [];
          var seriesDataArr = [];
          var staticData = {};
          _this.legendData.forEach((v,k)=>{
            staticData[v]=[]
          })
          data.forEach((v,k)=>{
            xAxisData.push(v.reportDate.substr(5).replace(/-/g,'\/'));
            staticData['登录会员'].push(+v.loginUserNum);
            staticData['投注会员'].push(+v.betUserNum);
            staticData['新增会员'].push(+v.newUserNum);
            staticData['充值会员'].push(+v.rechargeUserNum);
            staticData['首充会员'].push(+v.conversionUserNum);
            staticData['领取优惠会员'].push(+v.receiveDiscountUserNum);
            staticData['提款会员'].push(+v.withdrawUserNum);
          })
          _this.legendData.forEach((v,k)=>{
            var obj={};
            obj.name=v;
            obj.type='line';
            // obj.smooth=true;
            obj.data=staticData[v];
            seriesDataArr.push(obj);
          })
         _this.renderPie(xAxisData,seriesDataArr)
        }
      }
    );
  }
};

layui.use(["layer"], function() {
  var layer = layui.layer;
  profitLossUser.index=layer.load(2);
  profitLossUser.getData();
});
