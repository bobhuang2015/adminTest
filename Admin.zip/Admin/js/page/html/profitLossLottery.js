// BB、AG可以合并到一起，以后合；5-30
var profitLossLottery = {
  table:null,
  toolbarHtml:'',
  detailData:{},
  platformTotal:[],
  inTotal:{},
  gameTypeDetail:{},
  isAll:'0',
  tableData:['lottery'],
  yinKuiTotal:0,
  name:'profitLossLottery',
  hasDaochu:false,
  globalAdmin:JSON.parse(parent.localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action = parent.window.name || parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i =='导出数据'){
          this.hasDaochu=!0;
          $('button[lay-filter="formDaochu"]').show();
        }
      })
    }
  },
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1  
      }
	  })
  },
  showLayer: function(title, url, w, h) {
    layer.open({
      type: 2,
      area: [w + "px", h + "px"],
      fix: false,
      shadeClose: false,
      shade: 0.4,
      title: title,
      content: url
    });
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(){
    var arr=[
      {width:52,templet:function(d){return `<i class="iconfont icon-jiahao" data-id="${d.gameType}"></i>`}}
      ,{ field: 'gameTypeName', width: 140, title:'彩种名称'}
      , { field: 'betNum', width: 140, title:'注单总数',sort:true}
      , { field: 'betAmount', width: 140, title:'投注总额',templet:function(d){return globalAdmin.commafy(d.betAmount.toFixed(3))},sort:true}
      , { field: 'winAmount', width: 140, title:'中奖总额',templet:function(d){return globalAdmin.commafy(d.winAmount.toFixed(3))},sort:true}
      , { field: 'profitAmount', width: 160, title:'注单盈亏',sort:true,templet:function(d){return `<span class="${parent.globalAdmin.getColor(d.profitAmount)}">${globalAdmin.commafy(d.profitAmount.toFixed(3))}</span>`}}
      , { width: 160, title:'杀率',templet:function(d){return d.betNum ? `<span>${globalAdmin.commafy(((d.profitAmount / d.betAmount) * 100).toFixed(3) + '%')}</span>` :'0.000%'}}
      , { field: 'selfBonusAmount', width: 160, title:'自身返点总额',sort:true,templet:function(d){return globalAdmin.commafy(d.selfBonusAmount.toFixed(3))}}
      , { field: 'agentBonusAmount', title:'代理返点总额',sort:true,templet:function(d){return globalAdmin.commafy(d.agentBonusAmount.toFixed(3))},width:160}
      , { field:'shijiProfit',title:'实际盈亏',sort:true,templet:function(d){return `<span class="${parent.globalAdmin.getColor(d.shijiProfit)}">${globalAdmin.commafy(d.shijiProfit.toFixed(3))}</span>`},width:140}
      , { title:'盈亏率',templet:function(d){return d.betNum ? globalAdmin.commafy((d.shijiProfit / d.betAmount * 100).toFixed(3))+ '%' : '0.000%'}}
      // , { title:'操作',toolbar:'#barDemo'}
    ]
    return arr
  }
}

profitLossLottery.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  profitLossLottery.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  top.globalAdmin.isYesterday = !0;
  top.globalAdmin.renderIntDate(laydate,util);
  profitLossLottery.table.render({
    elem: '#demo'
    , height: 700
    , url: '/platformPOL/lotteryPOLStatis.mvc'
    , method: 'get'
    , cols: [ profitLossLottery.getOptions()],
    where: {
      "reportdate_begin":$("#start").val(),
      "reportdate_end":$("#end").val(),
    }
    , parseData: function (res) {
      var data = res.results[0].gameTypeList;
      data.forEach(v=>{
        v.shijiProfit = v.profitAmount + v.selfBonusAmount + v.agentBonusAmount;
      })
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results[0].gameTypeList
      };
      profitLossLottery.platformTotal=res.results[0].platformTotal;
      profitLossLottery.inTotal = res.results[0].inTotal;
      profitLossLottery.gameTypeDetail = res.results[0].gameTypeDetail;
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      $('.layui-table-page').hide();
      $('.layui-table-body.layui-table-main').css('height','660px')
      if(res.data.length>1){
        var platformHtml=``;
        profitLossLottery.platformTotal.forEach((v,k)=>{
          platformHtml +=`<div class="layui-page-total"><b>${v.platformName}</b>: 注单数:${v.betNum}；投注总额:${globalAdmin.commafy(v.betAmount.toFixed(3))}；中奖总额:${globalAdmin.commafy(v.winAmount.toFixed(3))}；投注盈亏:<span class="${parent.globalAdmin.getColor(v.profitAmount)}">${globalAdmin.commafy(v.profitAmount.toFixed(3))}</span>；自身返点总额:${globalAdmin.commafy(v.selfBonusAmount.toFixed(3))}；代理返点总额:${globalAdmin.commafy(v.agentBonusAmount.toFixed(3))}；汇总盈亏:<span class="${parent.globalAdmin.getColor(v.profitAmount + v.selfBonusAmount + v.agentBonusAmount)}">${globalAdmin.commafy((v.profitAmount + v.selfBonusAmount + v.agentBonusAmount).toFixed(3))}</span>;</div>`
        })
        var totalHtml=`<div class="layui-page-total"><b>总合计</b>: 注单数:${profitLossLottery.inTotal.betNum}；投注总额:${globalAdmin.commafy(profitLossLottery.inTotal.betAmount.toFixed(3))}；中奖总额:${globalAdmin.commafy(profitLossLottery.inTotal.winAmount.toFixed(3))}；投注盈亏:<span class="${parent.globalAdmin.getColor(profitLossLottery.inTotal.profitAmount)}">${globalAdmin.commafy(profitLossLottery.inTotal.profitAmount.toFixed(3))}</span>；自身返点总额:${globalAdmin.commafy(profitLossLottery.inTotal.selfBonusAmount.toFixed(3))}；代理返点总额:${globalAdmin.commafy(profitLossLottery.inTotal.agentBonusAmount.toFixed(3))}；汇总盈亏:<span class="${parent.globalAdmin.getColor(profitLossLottery.inTotal.profitAmount + profitLossLottery.inTotal.selfBonusAmount + profitLossLottery.inTotal.agentBonusAmount)}">${globalAdmin.commafy((profitLossLottery.inTotal.profitAmount + profitLossLottery.inTotal.selfBonusAmount + profitLossLottery.inTotal.agentBonusAmount).toFixed(3))}</span>;</div>`
        $('.layui-table-main table').after(totalHtml).after(platformHtml);
      }
    }
  });
  
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    profitLossLottery.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
  // 导出数据
  form.on('submit(formDaochu)', function (data) {
    profitLossLottery.hasDaochu && parent.globalAdmin.exportData(form,data,profitLossLottery)
    return false;
  });

  profitLossLottery.table.on('tool(demo)',function(obj){
    var event = obj.event;
    var data = obj.data;
    profitLossLottery.detailData = profitLossLottery.gameTypeDetail[data.gameType];
    profitLossLottery.yinKuiTotal = (data.profitAmount + data.selfBonusAmount + data.agentBonusAmount).toFixed(3);
    if(event === 'detail'){
      profitLossLottery.showLayer(`彩种盈亏详情-${data.gameTypeName}`,'./profitloss-lottery-detail.html','1000','500')
    }
  })

  
  $(document).on('click','.layui-table-main table tr .iconfont',function(){
    var lotteryId = $(this).attr('data-id');
    var iconJia = 'icon-jiahao',iconJian = 'icon-jianhao'
    if($(this).hasClass(iconJia)){
      $(this).addClass(iconJian).removeClass('icon-jiahao');
      profitLossLottery.detailData = profitLossLottery.gameTypeDetail[lotteryId];
      profitLossLottery.detailData.forEach(v=>{
        v.shijiProfit = v.profitAmount + v.selfBonusAmount + v.agentBonusAmount
      })
      $(this).parents('tr').after('<tr class="detail'+lotteryId+'"><td colspan="12"><iframe src="./profitloss-lottery-detail.html" frameborder="0" style="width:100%;height:140px;padding-left:52px;"></iframe></td></tr>')
    }else{
      $(this).addClass('icon-jiahao').removeClass(iconJian);
      $(`tr.detail${lotteryId}`).remove();
    }
  })
});



