
var bankRecharge = {
  table:null,
  upload:null,
  toolbarHtml:'',
  hasLock:false,
  hasDel:false,
  xxList:[],
  rechargeList:[],
  bankList:[],
  uploadObj:{},
  getToolbarHtml(){ 
    var permision = parent.globalAdmin.rechargeMethod;
    var otherHtml = "";
    var editHtml = "";
    var obj={
      '修改':'hasSet',
      '禁用/启用':'hasLock',
      '删除':'hasDel'
    }
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i !=='新增'){
          this[obj[i]]=true
        }else{
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${otherHtml}</div>`;//toolbar 跟表格联
    // this.getRechargeList();
    // this.getBankList();
    // this.getXXList();
  },
  getXXList(){
    var _this = this;
    parent.ajaxService.doGet("/bank/listXX.mvc",null,function(res){
      if(res.resultCode==0){
        _this.xxList = res.results;
        _this.xxList.forEach((v,k)=>{
          _this.bankObj[v.id]=v.name;
        })
      }
    })
  },
  getBankList(){
    var _this = this;
    parent.ajaxService.doGet("/bank/list.mvc",null,function(res){
      if(res.resultCode==0){
        _this.bankList = res.results[0];
      }
    })
  },
  getRechargeList(){
    var _this = this;
    parent.ajaxService.doGet("/rechargType/list.mvc",null,function(res){
      if(res.resultCode==0){
        _this.rechargeList = res.results[0];
      }
    })
  },
  renderData(id,data,is){
    var html='';
    data.forEach(function(v,k){
      html+=`<option value="${is ? v.name : v.id}">${v.name}</option>`
    })
    $(`.${id}`).append(html);
  },
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{ 
        curr:1  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var arr=[
      { field: 'name', title: '名称', width: 160, sort: true}
      , { field: 'imgurl', title: '图片地址', width: 280, sort: true}
      , { field: 'sort', title: '排序', width: 120,sort: true}
      , { title: '操作时间', width: 180, sort: true, templet:function(d){return util.toDateString(d.operatordt, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'operator', title: '操作者', sort: true,width:140}
      , { title: '状态', width: 80,templet:function(d){return d.enabled ? '启用' : '禁用'}}
      , { title: '操作',toolbar: '#barDemo'}
    ]
    return arr
  },
  editAlert(isAdd,title,form,data,upload){
    var _this = this;
    layer.open({
      title:title,
      type: 1,
      skin: 'layui-layer-test',
      area: ['620px', '740px'],
      content: htmlTpl.addHtml,
      success:function(){
        //普通图片上传
      var uploadInst = upload.render({
        elem: '#test1'
        ,url: bankRecharge.uploadObj.imgurl
        ,before: function(obj){
          //预读本地文件示例，不支持ie8
          obj.preview(function(index, file, result){
            $('#demo1').attr('src', result); //图片链接（base64）
          });
        }
        ,done: function(res){
          //如果上传失败
          if(res.code > 0){
            return layer.msg('上传失败');
          }
          //上传成功
        }
        ,error: function(){
          //演示失败状态，并实现重传
          var demoText = $('#demoText');
          demoText.html('<span style="color: #FF5722;">上传失败</span> <a class="layui-btn layui-btn-xs demo-reload">重试</a>');
          demoText.find('.demo-reload').on('click', function(){
            uploadInst.upload();
          });
        }
      })
        form.render("select",'add');
        var obj={
          "name": isAdd ? '' :data.name,
          "imgurl": isAdd ? '' :data.imgurl,
          "sort":isAdd ? '' :data.sort,
        }
        form.val('add', obj)
        form.on('submit(formAdd)',function(submitData){
          var reqUrl = isAdd ? '/platformBank/add.mvc' : '/platformBank/update.mvc';
          var dataObj = submitData.field;
          var reqData = Object.assign(submitData.field,{bankname:bankRecharge.bankObj[dataObj.bankId]});
          var reqData = isAdd ? reqData : Object.assign(reqData,{id:data.id});
          parent.ajaxService.doPost(reqUrl,reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              bankRecharge.layerCallback(msg);
            }else{
              layer.msg(msg)
            }
          })
          return false;
        })
      }
    })
  },
  editImgUpload(title,form,data){
    var isAdd = title=='新增' ? !0 : 0;
    layer.open({
      title:title,
      type: 1,
      skin: 'layui-layer-test',
      area: ['600px', '360px'],
      content: htmlTpl.addHtml,
      success:function(){
        var obj={
          "name": isAdd ? '' : data.name,
          "imgurl":isAdd ? '' : data.imgurl,
          "sort":isAdd ? '' : data.sort,
        }
        form.val('add', obj);
        bankRecharge.previewUrl = isAdd ? '' : data.imgurl;
        var uploadUrl = parent.globalAdmin.uploadInfo.uploadImgUrl+'/file-upload/upload-image';
        bankRecharge.upload.render({
          elem: '#layui-upload'
          ,url: uploadUrl
          ,choose:function(obj){
            obj.preview(function(index,file,result){
            })
          }
          ,before:function(obj){
            layer.load(2)
          }
          ,data:{
            tenantCode:parent.globalAdmin.uploadInfo.tenantCode,
            category:'bankRecharge'
          }
          ,done: function(res,index){
            layer.closeAll('loading');
            var data = res.data;
            $('.layui-imgurl').val(data);
            bankRecharge.previewUrl = data;
          }
          ,error: function(data){
            layer.closeAll('loading')
          }
          ,size:1024*5
          ,acceptMime:'.jpg,.png,.svg,.jpeg,.webp'
        })
        $('#layui-preview').on('click',function(){
          if(bankRecharge.previewUrl){
            var img = `<img src="${parent.globalAdmin.uploadInfo.viewImgUrl+'/'+bankRecharge.previewUrl}" style='width:300px;height:200px;'/>`
            layer.open({  
                type: 1,  
                title: '图片预览',  
                area: ['300px','250px'],  
                content: img, 
                cancel: function () {  
                }
            })  
          }else{
            layer.alert('请先上传图片!')
          }
          return false;
        })
        form.on('submit(formAdd)',function(submitData){
          var reqData = submitData.field;
          if(!isAdd)reqData.id=data.id;
          delete reqData.file;
          var reqUrl = isAdd ? '/rechargType/add.mvc' : '/rechargType/update.mvc'
          parent.ajaxService.doPost(reqUrl,reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              bankRecharge.layerCallback(msg);
            }else{
              layer.msg(msg)
            }
          })
          return false;
        })
      }
    })
  }
}

bankRecharge.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util','upload'], function () {
  var laydate = layui.laydate;
  bankRecharge.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  bankRecharge.upload = layui.upload;
  bankRecharge.table.render({
    elem: '#demo'
    , height: 'full-80'
    , url: '/rechargType/list.mvc'
    , toolbar: bankRecharge.toolbarHtml
    , defaultToolbar:[]
    , page: true
    , method: 'get'
    , cols: [ bankRecharge.getOptions(util)],
    where: {
      // startDate: ''
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results[0]
      };
      bankRecharge.tableData=res.results[0];
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
    }
  });
  

  
  // 工具栏操作
  bankRecharge.table.on("toolbar(demo)",function(res){
    var checkStatus = bankRecharge.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    switch (res.event) {
      case '新增':
        bankRecharge.editImgUpload(res.event,form)
      break;
      default:
        // layer.msg("接口文档未完善，需要相应人员支持!")
        break;
    }
  })
  //监听行工具事件
  bankRecharge.table.on('tool(demo)', function(obj){
    var data = obj.data;
    if(obj.event === 'lock'){
      var text = data.enabled ? '禁用' : '启用'; 
      layer.confirm(`是否${text}?`, function(index){
        var reqData={
          id:data.id,
          enabled:!data.enabled
        }
        parent.ajaxService.doPost("/rechargType/update.mvc",reqData,function(res){
          var msg = res.resultMessage
          if(res.resultCode == 0){
            bankRecharge.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(obj.event === 'del'){
      layer.confirm(`是否删除?`, function(index){
        var reqData={
          id:data.id
        }
        parent.ajaxService.doPost("/rechargType/delete.mvc",reqData,function(res){
          var msg = res.resultMessage
          if(res.resultCode == 0){
            bankRecharge.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(obj.event === 'set'){
      bankRecharge.editImgUpload('修改',form,data)
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    bankRecharge.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
  laydate.render({
    elem: '#start' //指定元素
  });
  laydate.render({
    elem: '#end' //指定元素
  });
});



