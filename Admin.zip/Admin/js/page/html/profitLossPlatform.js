
var profitLossPlatform = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  getToolbarHtml(){ 
    var action = window.name;
    var permision = parent.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i !='解锁' && i!='增加'){
          editHtml +='<button id="'+i+'" class="layui-btn layui-btn-disabled" lay-event="'+i+'">'+i+'</button>'
        }
        if(i=='解锁'){
          this.hasLock=true;
        }
        if(i=='增加'){
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${editHtml}<div style="display:inline-block;margin-left:10px;">${otherHtml}</div></div>`;
  },
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1  
      }
	  })
  },
  getStatus:function(status){
    var obj={
      '0':'未处理',
      '1':'已通过',
      '2':'已拒绝',
      '3':'充值成功',
      '4':'充值失败',
    }
    return obj[status]
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  renderGametype(data){
    var html='';
    data.forEach((v,k)=>{
      html+=`<option value="${v.id}">${v.name}</option>`
    })
    $(".gameType").append(html);
  },
  getOptions:function(util,type){
    var arr=[];
    if(type=='game'){
      arr=[
        { field: 'agselfbonusmoney', title: '平台', width: 160,sort: true}
        , { field: 'agselfbonusmoney', title: '注单数', width: 160,sort: true}
        , { field: 'agselfbonusmoney', title: '投注总额', width: 160,sort: true}
        , { field: 'agselfbonusmoney', title: '中奖总额', width: 160,sort: true}
        , { field: 'agselfbonusmoney', title: '投注盈亏', width: 160,sort: true}
        , { field: 'agselfbonusmoney', title: '自身返点总额', width: 160,sort: true}
        , { field: 'agselfbonusmoney', title: '实际盈亏', width: 160,sort: true}
      ]
    }else if(type=='lottery'){
      arr=[
        { title: 'gametypename', width: 140, title:'彩种名称',sort: true}
        , { title: 'betcount', width: 140, title:'彩票注单数',sort: true}
        , { title: 'winmoneytotal', width: 140, title:'彩种中奖',sort: true}
        , { title: 'gameLossMoney',width: 140, title:'彩票盈亏',sort: true}
        , { title: 'bonusmoneytotal', width: 160, title:'彩种自身返点',sort: true}
        , { title: 'agentbonusmoneytotal', width: 160, title:'彩票代理返点',sort: true}
        , { title: 'kjbetcount', width: 140, title:'传统彩票注单数',sort: true}
        , { title: 'kjbetmoneytotal', width: 140, title:'传统彩票投注总额',sort: true}
        , { title: 'kjwinmoneytotal', width: 140, title:'传统彩票中奖总额',sort: true}
        , { title: 'kjgameLossMoney',title: 'winmoneytotal', width: 140,sort: true}
        , { title: 'kjbonusmoneytotal', width: 140, title:'传统彩票自身返点',sort: true}
        , { title: 'kjagentbonusmoneytotal', width: 140, title:'传统彩票代理返点',sort: true}
        , { title: 'kjbonusmoneytotal', width: 140, title:'传统彩票自身返点',sort: true}
        , { title: 'platformLossMoneyTotal', width: 140, title:'实际盈亏',sort: true}
      ]
    }else if(type=='betType'){
      arr=[
        , { field: 'playtypename', title: '玩法名称', width: 160, sort: true}
        , { field: 'betcount', title: '投注数量',sort: true}
      ]
    }
    
    return arr
  },
  editIdArr:[],
  tableData:[]
}

layui.use('element', function(){
  element = layui.element;
  var content = '';
  tab = {
    tabAdd: function(title, url, id,is) {
      content = '<iframe tab-id="' +id +'" frameborder="0" src="' +url +'" scrolling="no" class="x-iframe" style="width:100%;height:'+(is ? '1220' : '760')+'px;"></iframe>'
      element.tabAdd("xbs_tab", {
        title: title,
        content:content,
        id: id
      });
    },
    tabChange: function(id) {
      //切换到指定Tab项
      element.tabChange("xbs_tab", id); 
    }
  };
});
$("#profitLoss li").click(function(){
  var is = 0;
  $('#profitLoss').attr('data-from')=='data' && (is = !0);
  var targetPage = is ? 'data' : 'profitloss';
  var pageUrl = "./"+targetPage +"-platform-"+$(this).attr("data-page")+'.html?loadTime='+ +new Date()+'';
  var name = $(this).text();
  var index = $(this).index();
  $(this).addClass("layui-this").siblings().removeClass("layui-this");
   //触发事件
  //  debugger;
  for (var i = 0; i < $(".x-iframe").length; i++) {
    if ($(".x-iframe").eq(i).attr("tab-id") ==index+1) {
      tab.tabChange(index+1);
      event.stopPropagation();
      return;
    }
  }
  tab.tabAdd(name,pageUrl,index+1,is);
  tab.tabChange(index+1);
})



