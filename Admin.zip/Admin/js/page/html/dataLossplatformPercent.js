var dataLossplatformPercent = {
  getTable(data,id){
    var html = '';
    var tempArr=[];
    data.forEach(v=>{
      if(Object.keys(v).length !=0){
        tempArr.push(v)
      }
    })
    tempArr.forEach(v=>{
      html +=`<tr><td>${v.name}</td><td>${v.value}</td></tr>`;
    })
    return `<table class="layui-table" lay-size="sm" style="width:100%;"><thead><tr><th><div class="table_th">平台名称</div></th><th><div class="table_th">${id =='layui-bet-rate' ? '平台人数' : '注单数'}</div></th></tr></thead><tbody class="tbody">${html}</tbody></table>`
  },
  getTable2(data){
    var html = '';
    data.forEach((v,k)=>{
      html +=`<tr><td>${v.date}</td><td>${v.betNum}</td><td>${v.renjun}</td><td>${v.betUser}</td></tr>`;
    })
    var headHtml=``;
    var headArr=['日期','注单数','人均注单','投注人数'];
    for(var i=0;i<headArr.length;i++){
      headHtml +=`<th><div class="table_th2">${headArr[i]}</div></th>`
    }
    return `<table class="layui-table" lay-size="sm" style="width:100%;"><thead><tr>${headHtml}</tr></thead><tbody class="tbody">${html}</tbody></table>`
  },
  renderPie(legendData,seriesData,id) {
    if(seriesData.length ==0){
      $(`#${id}`).html('<div class="layui-nodata">暂无数据!</div>')
      return
    }
    var _this = this;
    var option = {
        title : {},
        tooltip : {
          trigger: 'item',
          formatter: "{b} : {c} [{d}%]"
        },
        legend: {
          orient: 'horizontal',
          left: 'center',
          top:'10%',
          data: legendData
        },
        toolbox: {
          show: true,
          feature:{
            dataView: {
              lang:['','关闭'],
              show: true, 
              title:'表格',
              readOnly: true,
              optionToContent:function(opt){
                var table = _this.getTable(seriesData,id);
                return table;
              },
            },
          }
        },
        series : [
            {
                name: '数据统计',
                type: 'pie',
                radius : '55%',
                center: ['50%', '60%'],
                data:seriesData,
                itemStyle: {
                    emphasis: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                }
            }
        ]
    };
    var myChart = echarts.init(document.getElementById(id));
    myChart.setOption(option,true);
  },
  renderCircle(legendData,seriesData,id){
    if(seriesData.length ==0){
      $(`#${id}`).html('<div class="layui-nodata">暂无数据!</div>')
      return
    }
    var _this = this;
    var option = {
      tooltip: {
          trigger: 'item',
          formatter: "{a} <br/>{b}: {c} ({d}%)"
      },
      legend: {
          orient: 'horizontal',
          x: 'center',
          top:'10%',
          data:legendData
      },
      toolbox: {
        show: true,
        feature:{
          dataView: {
            lang:['','关闭'],
            show: true, 
            title:'表格',
            readOnly: true,
            optionToContent:function(opt){
              var table = _this.getTable(seriesData,id);
              return table;
            },
          },
        }
      },
      series: [
          {
              name:'注单数',
              type:'pie',
              radius: ['40%', '55%'],
              center: ['50%', '60%'],
              avoidLabelOverlap: false,
              label: {
                  normal: {
                      show: false,
                      position: 'center'
                  },
                  emphasis: {
                      show: true,
                      textStyle: {
                          fontSize: '30',
                          fontWeight: 'bold'
                      }
                  }
              },
              labelLine: {
                  normal: {
                      show: false
                  }
              },
              data:seriesData
          }
      ]
    };
    var myChart = echarts.init(document.getElementById(id));
    myChart.setOption(option,true);
  },
  renderLine(date,data1,data2,data3){
    if(data1.length ==0){
      $(`#layui-bet-trend`).html('<div class="layui-nodata">暂无数据!</div>')
      return
    }
    var _this = this;
    var tempArr = [];
    date.forEach((v,k)=>{
        var obj = {}
        obj.date = v;
        obj.betNum = data1[k];
        obj.renjun = data2[k];
        obj.betUser = data3[k];
        tempArr.push(obj)
    })
    var option = {
        tooltip: {
            trigger: 'axis'
        },
        color:['#5FB878','#1E9FFF','#FFB800'],
        legend: {
            data:['注单数','人均注单','投注人数']
        },
        xAxis: [
            {
                type: 'category',
                data: date,
                axisPointer: {
                    type: 'shadow'
                }
            }
        ],
        yAxis: [
            {
                type: 'value',
                min: 0,
                axisLabel: {
                    formatter: '{value}'
                }
            },
            {
                type: 'value',
                min: 0,
                axisLabel: {
                    formatter: '{value}'
                }
            }
        ],
        toolbox: {
          show: true,
          feature:{
            dataView: {
              lang:['','关闭'],
              show: true, 
              title:'表格',
              readOnly: true,
              optionToContent:function(opt){
                var table = _this.getTable2(tempArr);
                return table;
              },
            },
          }
        },
        series: [
            {
                name:'注单数',
                type:'bar',
                barWidth:30,
                data:data1
            },
            {
                name:'人均注单',
                type:'line',
                yAxisIndex: 1,
                data:data2
            },
            {
                name:'投注人数',
                type:'line',
                yAxisIndex: 1,
                data:data3
            }
        ]
    };
    var ele = document.getElementById('layui-bet-trend')
    var myChart = echarts.init(ele);
    myChart.setOption(option,true);
  },
  getData(reqData) {
    var _this = this;
    top.ajaxService.doGet("/gameGatherDaily/findStatisByThrid.mvc",reqData,function(res) {
        if (res.resultCode == 0) {
          if($('.layui-nodata'))$('.layui-nodata').remove();
          var data = res.results[0];
          var betUserData = data.platformBetUserNumList; //平台人数占比图
          var betData = data.betNumList;//注单总览
          var trendData = data.betNumTrendList; //注单量走势
          var staticTotal = 0;
          var seriesDataArr = [];
          var legendDataArr = [];
          var betPlatNameArr = [];
          var betPlatformSeriesArr = [];
          // 投注走势数据
          var dateArr=[];
          var betNumArr =[];
          var renjunArr=[];
          var betUserArr=[];
          var totalBetNum =0;

          betUserData.forEach((v,k)=>{
            legendDataArr.push(v.platformName);
            var tempObj = {};
            tempObj.value = v.betUserNum;
            tempObj.name = v.platformName;
            seriesDataArr.push(tempObj);
          })
          betData.forEach((v,k)=>{
            var tempObj = {};
            tempObj.value = v.betNum;
            tempObj.name = v.subTypeName;
            betPlatformSeriesArr.push(tempObj);
            betPlatNameArr.push(v.subTypeName)
          })
          trendData.length > 0 && trendData.forEach((v,k)=>{
            dateArr.push(v.reportDate.substr(5).replace(/-/g,'\/'));
            betNumArr.push(v.betNum);
            totalBetNum +=v.betNum;
            renjunArr.push(v.perCapitaUserBetNum.toFixed(2))
            betUserArr.push(v.betUserNum)
          })
          _this.renderPie(legendDataArr,seriesDataArr,'layui-bet-rate');
          _this.renderCircle(betPlatNameArr,betPlatformSeriesArr,'layui-bet-moshi');
          _this.renderLine(dateArr,betNumArr,renjunArr,betUserArr);
          $('.bet-money b').text(totalBetNum);
          var isUp = data.betNumSevenDaysScale > 0 ? !0 :0;
          $('.rate').html(trendData.length > 0 && (`近7日环比 <b>${((data.betNumSevenDaysScale)*100).toFixed(2)}%&nbsp;<i class="layui-icon layui-icon-return"></i></b>`)).addClass(`${isUp ? 'up' : 'down'}`)
        }else{
          layer.msg(res.resultMessage)
        }
      }
    );
  }
};

layui.use(["laydate", "form","util"], function() {
  var laydate = layui.laydate;
  var form = layui.form;
  var util = layui.util;
  parent.globalAdmin.isYesterday = !0;
  parent.globalAdmin.renderIntDate(laydate,util);
  var reqData = {
    reportdate_begin:$('#start').val(),
    reportdate_end:$('#end').val(),
  }
  dataLossplatformPercent.getData(reqData);

  // 表单提交demo
  form.on("submit(formDemo)", function(data) {
    var reqData = {
      reportdate_begin:data.field.reportdate_begin,
      reportdate_end:data.field.reportdate_end
    }
    dataLossplatformPercent.getData(reqData);
    return false;
  });
});
