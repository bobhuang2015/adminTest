
var bankWithdraw = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  hasDel:false,
  hasSet:false,
  pageNumber:1,
  merchantTypeArr:[],
  getToolbarHtml(){ 
    var action = window.name;
    var permision = parent.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    var obj={
      // '修改':'hasSet',
      '启用/禁用':'hasLock',
      '删除':'hasDel',
    }
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i !=='新增'){
          this[obj[i]]=true
        }else{
          // otherHtml +='<button class="layui-btn" lay-event="'+i+'" style="height:30px;line-height: unset;">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${otherHtml}</div>`;//toolbar 跟表格联动
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{ 
        curr:_this.pageNumber  
      }
	  })
  },
  renderMerchantType(data){
    var html='';
    data.forEach(function(v,k){
      html+=`<option value="${v.id}">${v.name}</option>`
    })
    $(".merchantType").append(html);
  },
  getMerchantType(){
    var _this = this;
    // parent.ajaxService.doGet("/bank/list.mvc",null,function(res){
    //   if(res.resultCode==0){
    //     _this.merchantTypeArr = res.results[0];
    //   }
    // })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  formatType(type){
    var obj={
      "0":'全部',
      "1":'网页端',
      "2":'APP'
    }
    return obj[type]
  },
  getOptions:function(util){
    var arr=[
      {field: 'name', title: '银行名称', width: 180, sort: true}
      , { field:'enabled',title: '启用状态', width: 120,templet:function(d){return d.enabled ? '启用' : '禁用'},sort:true}
      , { title: '操作' ,toolbar: '#barDemo'}
    ]
    return arr
  },
  editAlert(isAdd,title,form,data){
    var _this = this;
    layer.open({
      title:title,
      type: 1,
      skin: 'layui-layer-test',
      area: ['620px', '550px'],
      content: htmlTpl.addHtml,
      success:function(){
        bankWithdraw.renderMerchantType(bankWithdraw.merchantTypeArr);
        form.render("select",'add');
        var obj={
          "bankId": isAdd ? '' :data.bankId,
          "branchname": isAdd ? '' :data.branchname,
          "accountname":isAdd ? '' :data.accountname,
          "accountno":isAdd ? '' :data.accountno,
          "accountnoname":isAdd ? '' :data.accountnoname,
          "maxmoney":isAdd ? '' :data.maxmoney
        }
        form.val('add', obj)
        form.on('submit(formAdd)',function(submitData){
          var reqUrl = isAdd ? '/withdrawalsBank/add.mvc' : '/withdrawalsBank/update.mvc';
          var reqData = isAdd ? submitData.field : Object.assign(submitData.field,{id:data.id});
          parent.ajaxService.doPost(reqUrl,reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              bankWithdraw.layerCallback(msg);
            }else{
              layer.msg(msg)
            }
          })
          return false;
        })
      }
    })
  }
}

bankWithdraw.getToolbarHtml();
bankWithdraw.getMerchantType();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  bankWithdraw.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  bankWithdraw.table.render({
    elem: '#demo'
    , height: 'full-40'
    , url: '/bank/list.mvc'
    // , toolbar: bankWithdraw.toolbarHtml
    , defaultToolbar:[]
    , page: true
    , method: 'get'
    , cols: [ bankWithdraw.getOptions(util)],
    where: {
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results[0]
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      bankWithdraw.pageNumber=cur;
    }
  });
  
  // 工具栏操作
  bankWithdraw.table.on("toolbar(demo)",function(res){
    var checkStatus = bankWithdraw.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    switch (res.event) {
      case '新增':
        bankWithdraw.editAlert(!0,'新增',form);
      break;
    }
  })
  //监听行工具事件
  bankWithdraw.table.on('tool(demo)', function(obj){
    var data = obj.data;
    if(obj.event === 'lock'){
      var text = data.enabled ? '禁用' : '启用  '; 
      layer.confirm(`是否${text}银行 ${data.name}?`, function(index){
        var reqData={
          id:data.id,
          enabled:!data.enabled
        }
        parent.ajaxService.doPost("/bank/changestate.mvc",reqData,function(res){
          if(res.resultCode ==0){
            bankWithdraw.layerCallback(res.resultMessage);
          }else{
            layer.msg(res.resultMessage);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(obj.event==='set'){
      bankWithdraw.editAlert(0,'修改',form,data);
    }else if(obj.event === 'del'){
      layer.confirm("是否删除选中的银行?",{
        btn:['确定','取消']
      },function(){
      var reqData = {
        withdrawalsBankId:data.id
      }
      parent.ajaxService.doPost("/bank/delete.mvc",reqData,function(res){
        if(res.resultCode ==0){
          bankWithdraw.layerCallback(res.resultMessage);
        }else{
          layer.msg(res.resultMessage);
        }
      })
      },function(index){
        layer.close(index)
      }
    )
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    bankWithdraw.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



