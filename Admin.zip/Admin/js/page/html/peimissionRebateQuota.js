
var peimissionRebateQuota = {
  table:null,
  getToolbarHtml(){ 
  },
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var arr=[
      { field: 'operator', title: '操作者', width: 140, sort: true}
      , { field: 'updateobject', title: '被操作对象', width: 140, sort: true}
      , { field: 'remark', title: '执行操作', width: 140, sort: true}
      , { field: 'beforevalue', title: '修改前数值', width: 140, sort: true}
      , { field: 'updatevalue', title: '修改数值', width: 140, sort: true}
      , { field: 'aftervalue', title: '修改后数值', width: 140, sort: true}
      , { field: 'createdate',title: '操作时间',sort: true,templet:function(d){return util.toDateString(d.createdate, "yyyy-MM-dd HH:mm:ss")}}
    ]
    return arr
  },
}

layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  peimissionRebateQuota.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  
  var topHeight = ~~($(".layui-row").height()+40);
  parent.globalAdmin.renderIntDate(laydate,util)
  peimissionRebateQuota.table.render({
    elem: '#demo'
    , height: `full-${topHeight}`
    , url: '/rqrecord/search.mvc'
    , page: true
    , method: 'get'
    , cols: [ peimissionRebateQuota.getOptions(util)],
    where: {
      // startDate: ''
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results
      };
      peimissionRebateQuota.tableData=res.results;
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
    }
  });
  
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    peimissionRebateQuota.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



