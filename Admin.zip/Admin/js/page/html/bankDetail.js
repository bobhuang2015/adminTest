
var bankDetail = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  getToolbarHtml(){
    var action = window.name;
    var permision = parent.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i !='解锁' && i!='增加'){
          editHtml +='<button id="'+i+'" class="layui-btn layui-btn-disabled" lay-event="'+i+'">'+i+'</button>'
        }
        if(i=='解锁'){
          this.hasLock=true;
        }
        if(i=='增加'){
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${editHtml}<div style="display:inline-block;margin-left:10px;">${otherHtml}</div></div>`;
  },
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1
      }
	  })
  },
  getStatus:function(status){
    var obj={
      '0':'未处理',
      '1':'已通过',
      '2':'已拒绝',
      '3':'充值成功',
      '4':'充值失败',
    }
    return obj[status]
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  renderGametype(data){
    var html='';
    data.forEach((v,k)=>{
      html+=`<option value="${v.id}">${v.name}</option>`
    })
    $(".gameType").append(html);
  },
}

layui.use('element', function(){
  element = layui.element;
  tab = {
    tabAdd: function(title, url, id) {
      //新增一个Tab项
      element.tabAdd("xbs_tab", {
        title: title,
        content:'<iframe tab-id="' +id +'" frameborder="0" src="' +url +'" scrolling="no" class="x-iframe" style="width:100%;height:760px;"></iframe>',
        id: id
      });
    },
    tabChange: function(id) {
      //切换到指定Tab项
      element.tabChange("xbs_tab", id);
    }
  };
});
$("#profitLoss li").click(function(){
  var pageUrl = ["./finance-cashcardD.html", "./finance-thirdM.html"];
  var name = $(this).text();
  var index = $(this).index();
  $(this).addClass("layui-this").siblings().removeClass("layui-this");
   //触发事件;
  for (var i = 0; i < $(".x-iframe").length; i++) {
    if ($(".x-iframe").eq(i).attr("tab-id") ==index+1) {
      tab.tabChange(index+1);
      event.stopPropagation();
      return;
    }
  }
  tab.tabAdd(name,pageUrl[index-1],index+1);
  tab.tabChange(index+1);
})



