
var userCenterHelp = {
  table:null,
  index:9999999,
  layeditIndex:0,
  toolbarHtml:'',
  hasSet:false,
  hasDel:false,
  pageNumber:1,
  smallTypeArr:[],
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action = window.name || globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    var obj={
      '修改':'hasSet',
      '删除':'hasDel'
    }
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i !=='新增' && i !=='管理大类' && i !=='管理中类' && i !=='管理小类'){
          this[obj[i]]=true
        }else{
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>';
        }
      })
    }
    this.toolbarHtml =`<div>${otherHtml}<a class="layui-btn layui-btn-primary layui-btn-small"  href="javascript:location.replace(location.href);" title="刷新">刷新</a></div>`;//toolbar 跟表格联
    this.getSmallType();
  },
  renderSelect(data,ele){
    var html = '';
    data.forEach((v,k)=>{
      html+=`<option value="${v.id}">${v.title}</option>`
    })
    $(ele).append(html);
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{ 
        curr:_this.pageNumber  
      }
	  })
  },
  getSmallType(){
    var _this = this;
    parent.ajaxService.doGet('/questionCenter/searchType.mvc',{floor:2},function(res){
      if(res.resultCode == 0){
        _this.smallTypeArr = res.results[0];
      }
    })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var arr=[
      { field: 'question', title: '标题', width: 240, sort: true}
      , { field: 'answer', title: '基本内容', width: 840,sort: true}
      , { field: 'ranking', title: '排序', width: 80,sort: true}
      , { field: 'smallTypeName', title: '所属小类', width: 120,sort: true}
      , { field: 'bigTypeName', title: '所属大类', width: 120,sort: true}
      , { title: '操作', toolbar: '#barDemo'}
    ]
    return arr
  },
  editAlert(isAdd,title,form,data,layedit){
    var _this = this;
    layer.open({
      title:title,
      type: 1,
      skin: 'layui-layer-test',
      area: ['760px', '640px'],
      content: htmlTpl.addListHtml,
      success:function(){
        _this.renderSelect(_this.smallTypeArr,'.layui-parent');
        var obj={
          "title": isAdd ? '' :data.title,
          "question": isAdd ? '' :data.question,
          "answer": isAdd ? '' :data.answer,
          "ranking": isAdd ? '' :data.ranking,
          "parentId":isAdd ? '' :data.parentId
        }
        form.val('add', obj);
        form.render("select",'add');

        form.on('submit(formAdd)',function(submitData){
          var reqUrl = isAdd ? '/questionCenter/add.mvc' : '/questionCenter/edit.mvc';
          var reqData = isAdd ? submitData.field : Object.assign(submitData.field,{id:data.id});
          reqData.answer=layedit.getContent(userCenterHelp.layeditIndex);
          reqData.floor=3;
          parent.ajaxService.doPost(reqUrl,reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              userCenterHelp.layerCallback(msg);
            }else{
              layer.msg(msg)
            }
          })
          return false;
        })
      }
    })
    setTimeout(()=>{
      userCenterHelp.layeditIndex = layedit.build('LAY_demo2',{tool: ['fontSize','colorpicker','strong', 'italic','underline','del','|','left','center','right','|','link','unlink','face']});
      layedit.setContent(userCenterHelp.layeditIndex, isAdd ? "" : data.answer);
    },200)
  }
}

userCenterHelp.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util','layedit'], function () {
  var laydate = layui.laydate;
  userCenterHelp.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  var layedit = layui.layedit;
  userCenterHelp.table.render({
    elem: '#demo'
    , height: 800
    , url: '/questionCenter/list.mvc'
    , toolbar: userCenterHelp.toolbarHtml
    , defaultToolbar:[]
    , page: true
    , method: 'get'
    , cols: [userCenterHelp.getOptions(util)],
    where: {}
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      userCenterHelp.pageNumber=cur;
    }
  });
  
  // 工具栏操作
  userCenterHelp.table.on("toolbar(demo)",function(res){
    var checkStatus = userCenterHelp.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    var event = res.event;
    if(event === '新增'){
      userCenterHelp.editAlert(!0,res.event,form,'',layedit)
    }else{
      var obj ={
        '管理大类':'1',
        '管理小类':'2',
      }
      var url = `html/userCenter-helpClass.html?floor=${obj[res.event]}`;
      parent.tab.tabAdd(res.event, url, userCenterHelp.index,'');
      parent.tab.tabChange(userCenterHelp.index);
      userCenterHelp.index++;
    }
  })
  //监听行工具事件
  userCenterHelp.table.on('tool(demo)', function(obj){
    var data = obj.data;
     if(obj.event === 'set'){
      userCenterHelp.editAlert(0,'修改',form,data,layedit);
    }else if(obj.event =='del'){
      layer.confirm(`是否删除?`, function(index){
        parent.ajaxService.doPost("/questionCenter/del.mvc",{id:data.id,floor:4},function(res){
          var msg = res.resultMessage
          if(res.resultCode == 0){
            userCenterHelp.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }
  })
  // 表单提交demo 
  form.on('submit(formDemo)', function (data) {
    userCenterHelp.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



