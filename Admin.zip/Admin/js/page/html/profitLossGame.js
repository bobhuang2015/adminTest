var profitLossGame = {
  table: null,
  toolbarHtml: "",
  tableData: [],
  subTypeDetail:{},
  gameType:{
    "1":'视讯',
    "2":'电子',
    "3":'体育',
    "4":'棋牌',
    "5":'彩票',
    "6":'真人',
    "7":'捕鱼',
  },
  getToolbarHtml() {
    var action = window.name;
    var permision = parent.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      permision.forEach((v, k) => {
        var i = v.menuName;
      });
    }
  },
  reloadTable: function() {
    this.table.reload("demo", {
      where:{statsTimeBegin:$('#start').val(),statsTimeEnd:$('#end').val()},
      page: {
        curr: 1
      }
    });
  },
  renderHtml(id,data){
    var html = ``;
    for(var i in data){
      html +=`<option value="${i}">${data[i]}</option>`
    }
    $(id).append(html);
  },
  tableHtml(data){
    var html=`<table class="layui-table" lay-size="sm" style="width:95%;">
          <colgroup>
            <col width="150">
            <col width="200">
            <col>
          </colgroup>
          <thead>
            <tr>
              <th style="width:10%">平台</th>
              <th style="width:12%">平台子玩法</th>
              <th>注单数</th>
              <th>投注总额</th>
              <th>自身返点总额</th>
              <th>代理返点总额</th>
              <th>盈亏金额</th>
            </tr> 
          </thead>
          <tbody class="tbody">
          </tbody>
        </table>`
    return html;
  },
  layerCallback(msg) {
    var _this = this;
    layer.alert(msg, function() {
      layer.closeAll();
      _this.reloadTable();
    });
  },
  getOptions: function() {
    var arr = [
      {width:140,templet:function(d){return `<i class="iconfont icon-jiahao" data-id="${d.platformCode}-${d.subType}"></i>`}},
      { field: "platformName", width: 140, title: "游戏平台",sort:true},
      { field: "subTypeName", width: 100, title: "类型",sort:true},
      { field: "betNum", width: 110, title: "注单数" ,sort:true},
      { field: "betUserNum", width: 110, title: "投注人数" ,sort:true},
      { width: 110, title: "人均注单" ,templet:function(d){return (d.betNum / d.betUserNum).toFixed(1)}},
      { field: "betAmount",width: 140,title: "投注额",templet: function(d) {return globalAdmin.commafy(d.betAmount.toFixed(3))},sort:true},
      { field: "winAmount",width: 140,title: "中奖",templet: function(d) {return globalAdmin.commafy(d.winAmount.toFixed(3))}},
      { field: 'profitAmount',width: 140,title: "注单盈亏",templet: function(d) {return `<span class="${parent.globalAdmin.getColor(d.profitAmount)}">${globalAdmin.commafy(d.profitAmount.toFixed(3))}</span>`}},
      { field: "bonusAmount",width: 140,title: "杀率",templet: function(d) {return ((d.profitAmount/d.betAmount)*100).toFixed(3)+'%'}},
      { field: "bonusAmount",width: 140,title: "自身返点",templet: function(d) {return globalAdmin.commafy(d.bonusAmount.toFixed(3))},sort:true},
      { field: "totalProfitLoss", title: "实际盈亏",width:140,templet: function(d) {return `<span class="${parent.globalAdmin.getColor(d.totalProfitLoss)}">${globalAdmin.commafy((d.totalProfitLoss).toFixed(3))}</span>`}},
      { title: "盈亏率",templet: function(d) {return d.betNum ?  `<span >${globalAdmin.commafy((d.totalProfitLoss / d.betAmount *100).toFixed(3))}%</span>` : '0.000%'}}
    ];
    return arr;
  }
}

profitLossGame.renderHtml("#platformCode",top.globalAdmin.thirdPlatform);
profitLossGame.renderHtml("#subType",profitLossGame.gameType);
layui.use(["laydate", "table", "form", "layer", "util"], function() {
  var laydate = layui.laydate;
  profitLossGame.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  // top.globalAdmin.isYesterday = !0;
  top.globalAdmin.renderIntDate(laydate,util);
  profitLossGame.table.render({
    elem: "#demo",
    height: 'full-50',
    url: " /platformPOL/gamePOLStatis.mvc",
    page:false,
    // totalRow:true,
    method: "get",
    cols: [profitLossGame.getOptions()],
    where: {
      "statsTimeBegin":$("#start").val(),
      "statsTimeEnd":$("#end").val(),
    },
    parseData: function(res) {
      var resData = res.results[0];
     resData && resData.gameProfitList.forEach(v=>{
        v.totalProfitLoss = v.profitAmount + v.bonusAmount
      })
      var result = {
        code: res.resultCode,
        msg: res.resultMessage,
        count: res.meta.totalRecord,
        data:resData && resData.gameProfitList.length > 0 && resData.gameProfitList
      };
      profitLossGame.subTypeDetail = resData && resData.gameProfitList.length > 0 && resData.gameProfitDetail;
      profitLossGame.tableData =resData && resData.gameProfitList.length > 0 && resData.gameProfitList;
      return result;
    },
    response: {
      statusCode: "0"
    },
    done: function(res, cur, count) {
        var obj = {betNum:0,betUser:0,betAmount:0,winAmount:0,profitAmount:0,bonusAmount:0,totalProfitLoss:0}
        res.data && res.data.forEach(v=>{
          obj.betNum+=v.betNum;
          obj.betUser+=v.betUserNum;
          obj.betAmount+=v.betAmount;
          obj.winAmount+=v.winAmount;
          obj.profitAmount+=v.profitAmount;
          obj.bonusAmount+=v.bonusAmount;
          obj.totalProfitLoss+=v.totalProfitLoss;
        })
        var html = `<div class="layui-page-total">总计:  注单数: ${obj.betNum}；投注总额: ${globalAdmin.commafy(obj.betAmount.toFixed(3))}； 中奖总额: ${globalAdmin.commafy(obj.winAmount.toFixed(3))}； 投注盈亏:<span class='${parent.globalAdmin.getColor(obj.profitAmount)}'>${globalAdmin.commafy(obj.profitAmount.toFixed(3)) }</span>； 自身返点总额:${globalAdmin.commafy((obj.bonusAmount).toFixed(3))}； 实际盈亏:<span class='${parent.globalAdmin.getColor(obj.totalProfitLoss)}'>${globalAdmin.commafy((obj.totalProfitLoss).toFixed(3))}</span></div>`
        $('.layui-table-main table').after(html);
    }
  });

  form.on("submit(formDemo)", function(data) {
    profitLossGame.table.reload("demo", {
      where: data.field,
      page: {
        curr: 1
      }
    });
    return false;
  });

  function getDate(day){  
    var today = new Date();  
    var targetday_milliseconds=today.getTime() + 1000*60*60*24*day;          
    today.setTime(targetday_milliseconds);
    var tYear = today.getFullYear();  
    var tMonth = today.getMonth();  
    var tDate = today.getDate();  
    tMonth = doHandleMonth(tMonth + 1);  
    tDate = doHandleMonth(tDate);  
    return tYear+"-"+tMonth+"-"+tDate;  
  }  
  function doHandleMonth(month){  
      var m = month;  
      if(month.toString().length == 1){  
        m = "0" + month;  
      }  
      return m;  
  }

  function getStartEndTime(numberDate) {
    if (typeof numberDate == "string") numberDate = parseInt(numberDate);
    var day = "-" +numberDate; 
    var endDate = numberDate == 1 ? 0 : 1;
    $("#start").val(getDate(day));
    $("#end").val(getDate(endDate));
  }
  $('.layui-btn-normal').on("click",function(){
    var time = $(this).attr('data-time');
    getStartEndTime(time);
    profitLossGame.reloadTable();
  })

  $(document).on('click','.layui-table-main table tr .iconfont',function(){
    var targetId = $(this).attr('data-id');
    var iconJia = 'icon-jiahao',iconJian = 'icon-jianhao';
    var tempArr = profitLossGame.subTypeDetail[targetId];
    profitLossGame.detailData = tempArr.reverse();
    if($(this).hasClass(iconJia)){
      $(this).addClass(iconJian).removeClass('icon-jiahao');
      var len = profitLossGame.detailData.length > 0 && profitLossGame.detailData.length || 2;
      $(this).parents('tr').after('<tr class="detail'+targetId+'"><td colspan="18"><iframe src="./profitloss-game-detail.html?time='+new Date().getTime()+'" frameborder="0" style="width:100%;height:'+(len * 31 + 46)+'px;"></iframe></td></tr>')
    }else{
      $(this).addClass('icon-jiahao').removeClass(iconJian);
      $(`tr.detail${targetId}`).remove();
    }
  })
});
