
var userCenterPromotionReview = {
  table:null,
  toolbarHtml:'',
  hasReview:false,
  hasReject:false,
  pageNumber:1,
  activeList:JSON.parse(localStorage.getItem('activeList')) || null,
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action ='userCenter-promotion-review';
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    var obj={
      '审核':'hasReview',
      '拒绝':'hasReject'
    }
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        this[obj[i]]=true;
      })
    }
    this.toolbarHtml =`<div>${otherHtml}</div>`;//toolbar 跟表格联动
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  getActiveType(){
    var _this = this;
    !this.activeList && parent.ajaxService.doGet('/getEnumByName.mvc',{enumName:'Promotions_Type'},function (res) {
      if(res.resultCode == 0){
        _this.activeList = res.results[0];
        _this.renderHtml(_this.activeList,'layui-type',false)
        localStorage.setItem('activeList',JSON.stringify(_this.activeList));
      }
    })
    this.activeList && this.renderHtml(this.activeList,'layui-type',false)
  },
  renderHtml(data,ele,is){
    var html='';
    if(is){
      data.forEach((v,k)=>{
        html+=`<option value="${v.id}">${v.name}</option>`
      })
    }else{
      for(var i  in  data){
        html+=`<option value="${i}">${data[i]}</option>`
      }
    }
    $(`.${ele}`).append(html);
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  formatStatus(type){
    var obj={
      '1':'未处理',
      '2':'已通过',
      '3':'已拒绝',
      '4':'审核失败'
    }
    return obj[type]
  },
  getOptions:function(util){
    var _this = this;
    var arr=[
      { field: 'orderNumber', title: '订单号', width: 220, sort: true}
      , { field: 'username', title: '用户名', width: 120,sort: true}
      , { field: 'amount', title: '派发金额', width: 120, sort: true}
      , { field: 'balance', title: '当前余额', width: 120, sort: true}
      , { field: 'type', title: '活动类型', width: 120, sort: true,templet:function(d){return _this.activeList[d.type]}}
      , { field: 'applyTime', title: '申请时间', width: 180, sort: true,templet:function(d){return util.toDateString(d.applyTime, "yyyy-MM-dd HH:mm:ss")}}
      , { title: '耗时', width: 140, sort: true,templet:function(d){return parent.globalAdmin.diffTime(d.passTime,d.applyTime)}}
      , { field: 'operator', title: '操作员', width: 120, sort: true}
      , { field: 'status', title: '状态', width: 100, sort: true,templet:function(d){return _this.formatStatus(d.status)}}
      , { title: '操作', width: 130,toolbar: '#barDemo'}
      , { field: 'remark', title: '备注'}
    ]
    return arr
  },
  editIdArr:[],
  tableData:[],
  editAlert(title,data,form,util){
    var isAdd = title == '审核' ? 1 : 0;
    layer.open({
      title:title,
      type: 1,
      skin: 'layui-layer-test',
      area: ['600px', '400px'],
      content: htmlTpl.reviewHtml,
      success:function(){
        !isAdd && $('.layui-money').remove(); 
        var obj={
          "username": data.username,
          "amount": data.amount,
          "applyTime":util.toDateString(data.applyTime, "yyyy-MM-dd HH:mm:ss"),
          "balance":data.balance,
          "remark":data.remark
        }
        form.val('add', obj)
        form.on('submit(formAdd)',function(submitData){
          var reqUrl = '/promotionsCheck/updateStatus.mvc';
          var reqData = {
            id:data.id,
            status:isAdd ? 2 : 3,
            remark:submitData.field.remark
          }
          $('button[lay-filter="formAdd"]').addClass('layui-btn-disabled').html('提交中');
          parent.ajaxService.doPost(reqUrl,reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              userCenterPromotionReview.layerCallback(msg);
            }else{
              layer.msg(msg)
            }
          })
          return false;
        })
      }
    })
  },
  renderTotal(res){
    if (res.data && res.data.length > 0 && res.total){
      var tr = '<tr class="table-total"><td colspan="50">合计共派发：<span>'+res.total.sumReceiveAmount+'元</span></td></tr>'
      $('.layui-table-body table').append(tr)
    }
  }
}

userCenterPromotionReview.getToolbarHtml();
new Promise((resolve,reject)=>{
  resolve(userCenterPromotionReview.getActiveType());
})
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  userCenterPromotionReview.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  
  var topHeight = ~~($(".layui-row").height()+40);
  globalAdmin.renderIntDate(laydate,util);
  userCenterPromotionReview.table.render({
    elem: '#demo'
    , height: `full-${topHeight}`
    , url: '/promotionsCheck/list.mvc'
    , page: true
    , method: 'get'
    , cols: [ userCenterPromotionReview.getOptions(util)],
    where: {}
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results[0],
        'total':res.results[0].length > 0 && res.results[1]
      };
      userCenterPromotionReview.tableData=res.results;
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      userCenterPromotionReview.pageNumber = cur;
      userCenterPromotionReview.renderTotal(res);
    }
  });
  
  //监听行工具事件
  userCenterPromotionReview.table.on('tool(demo)', function(obj){
    var data = obj.data;
    var event = obj.event;
    if(event ==='review' || event ==='reject'){
      var title = {
        'review':'审核',
        'reject':'拒绝'
      }
      userCenterPromotionReview.editAlert(title[event],data,form,util)
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    userCenterPromotionReview.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        },
        done:function(res){
          userCenterPromotionReview.renderTotal(res);
        }
    })
    return false;
  });
});



