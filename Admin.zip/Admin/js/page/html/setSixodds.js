
var setSixodds = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        editHtml +='<div class="layui-btn" lay-event="'+i+'">'+i+'</div>'
      })
    }
    this.toolbarHtml =`<div>${editHtml}</div>`;//toolbar 跟表格联动
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      where:{
        gametype:_this.currentGame.gametype,
        playtype:_this.currentGame.playtype,
        sixplaytype:_this.currentGame.sixplaytype
      }
	  })
  },
  currentGame:{},
  getGametype(util,form){
    var _this = this;
    parent.ajaxService.doGet("/lotteryOdds/getSixOddsGamePlay.mvc",null,function(res){
      if(res.resultCode == 0){
        var html='';
        var data = res.results[0];
        data.forEach(function(v,k){
          html+=`<option value="${v.gametype}">${v.gamename}</option>`
        })
        $(".layui-game-type").append(html);
        _this.getTabs(data[0].gametype,util,form);
      }
    })
  },
  getTabs(gametype,util,form){
    var _this = this;
    parent.ajaxService.doGet("/lotteryOdds/getSixOddsGamePlayChild.mvc",{gametype:gametype},function(res){
      if(res.resultCode == 0){
        var html='';
        var data = res.results[0];
        _this.currentGame = data[0];
        data.forEach(function(v,k){
          html+=`<li class="${k==0 ? 'layui-this' :''}" data-playType='${v.playtype}' data-gameType='${v.gametype}' data-sixplaytype='${v.sixplaytype}'>${v.playname}</option>`
        })
        $(".layui-tab-title").html(html);
        // if(is)_this.reloadTable();
        setSixodds.table.render({
          elem: '#demo'
          , height: 'full-140'
          , url: '/lotteryOdds/getLotteryOdds.mvc'
          , toolbar: setSixodds.toolbarHtml  
          , defaultToolbar:[]
          , method: 'get'
          , cols: [ setSixodds.getOptions(util)],
          where: {
            gametype:66,
            playtype:setSixodds.currentGame.playtype,
            sixplaytype:setSixodds.currentGame.sixplaytype
          }
          , parseData: function (res) {
            var result = {
              "code": res.resultCode, 
              "msg": res.resultMessage,
              "count": res.meta.totalRecord,
              "data": res.results[0]
            };
            return result
          },
          response: {
            statusCode: '0'
          },
          done: function (res, cur, count) {
            $('.layui-enabled-select').parents('td').addClass('test');
            layui.each($(".layui-enabled-select"), function (index, item) {
              var elem = $(item);
              elem.val(elem.data('value'));
            });
            form.render('select');
          }
        });
      }
    })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var arr=[
      {type:'checkbox',width:80}
      , { field: 'name', title: '号码', width: 180,sort: true}
      , { field: 'odds', title: '赔率', width: 140,sort: true,edit:'text'}
      , { field: 'water', title: '返水%', width: 140,sort: true,edit:'text'}
      , { field: 'maxbet', title: '最大投注', width: 180,sort: true,edit:'text'}
      , { field: 'minbet', title: '最小投注', width: 140,sort: true,edit:'text'}
      , { field: 'enabled', title: '是否启用', width: 180,templet: '#selectDictName'}
      , { field: 'updateoperator', title: '操作人', width: 120,sort: true}
      , { field:'updatetime',title: '操作时间', sort: true,templet:function(d){return util.toDateString(d.updatetime, "yyyy-MM-dd HH:mm:ss")}}
    ]
    return arr
  },
  editAlert(form,is,data){
    layer.open({
      title:'修改',
      type: 1,
      skin: 'layui-layer-test',
      area: ['600px', '400px'],
      content: htmlTpl.addHtml,
      success:function(){
        form.render('select');
        var idArr = [];
        if(is){
          data.forEach((v,k)=>{
            idArr.push(v.id);
          })
        }
        form.on('submit(formSet)',function(submitData){
          layer.load(2);
          var reqData = submitData.field;
          if(submitData.field.minbet =="") reqData.minbet=-1;
          if(submitData.field.maxbet =="") reqData.maxbet=-1;
          if(submitData.field.odds =="") reqData.odds=-1;
          if(submitData.field.water =="") reqData.water=-1;
          var obj = {
            gametype:setSixodds.currentGame.gametype,
            playtype:setSixodds.currentGame.playtype,
            sixplaytype:setSixodds.currentGame.sixplaytype || 0
          }
          if(is)obj.ids=idArr.join()
          reqData = Object.assign(reqData,obj);
          var reqUrl = is ? '/lotteryOdds/batchStringUpdateLotteryOdds.mvc' : '/lotteryOdds/batchUpdateLotteryOdds.mvc'
          parent.ajaxService.doPost(reqUrl,reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              setSixodds.layerCallback(msg);
            }else{
              layer.msg(msg)
            }
          })
          return false;
        })
      }
    })
  },
  updateViewDate(reqData){
    layer.load(2);
    parent.ajaxService.doPost('/lotteryOdds/updateLotteryOdds.mvc',reqData,function(res){
      if(res.resultCode==0){
        var msg = res.resultMessage;
        setSixodds.layerCallback(msg);
      }else{
        layer.msg(msg);
      }
    })
  }
}

setSixodds.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util','element'], function () {
  var laydate = layui.laydate;
  setSixodds.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  var element = layui.element;
  
  setSixodds.getGametype(util,form);

  element.render('tab','tab_box');

  element.on('tab(tab_box)', function (data) {
    $(document).resize();
    setSixodds.currentGame.gametype = $(this).attr("data-gametype");
    setSixodds.currentGame.playtype = $(this).attr("data-playtype");
    setSixodds.currentGame.sixplaytype = $(this).attr("data-sixplaytype");
    setSixodds.reloadTable();
  })
  
  // 工具栏操作
  setSixodds.table.on("toolbar(demo)",function(res){
    var checkStatus = setSixodds.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    var event = res.event;
    switch (event) {
      case '选择修改':
        if(data.length==0){
          layer.alert('至少选择一项进行修改!')
          return;
        }
        setSixodds.editAlert(form,!0,data)
      break;
      case '批量修改':
        setSixodds.editAlert(form,0)
      break;
      default:
        break;
    }
  })

  // 监听select选择
  form.on('select(shop)', function(data){
    setSixodds.getTabs(data.value,util,form);
  });

  //监听select;
  form.on('select(enabled)',function(data){
    var reqData = {
      id:$(data.elem).attr('data-id'),
      enabled:data.value,
      odds:$(data.elem).attr('data-odds'),
      water:$(data.elem).attr('data-water'),
      maxbet:$(data.elem).attr('data-maxbet'),
      minbet:$(data.elem).attr('data-minbet')
    }
    if(data.value == $(data.elem).attr('data-value'))return;
    setSixodds.updateViewDate(reqData);
  })
   //监听单元格编辑
   setSixodds.table.on('edit(demo)', function(obj){
    var value = obj.value //得到修改后的值
    ,data = obj.data //得到所在行所有键值
    ,field = obj.field; //得到字段
    if(field == 'odds'){
      var re = /^\d+(?=\.{0,1}\d+$|$)/;
      if(!re.test(value)){
        layer.alert('只能输入数字和小数点')
        return;
      }
      if(value.length>5)value = value.substr(0,5);
    }else{
      var re = /^[1-9]\d*$/;
      if(!re.test(value)){
        layer.alert('只能输入数字,且首个不能为0!')
        return;
      }
    }
    var reqData = {
      id:data.id,
      wateramount:field=='wateramount' ? value : data.wateramount,
      odds: data.odds,
      water:field=='water' ? value : data.water,
      maxbet:field=='maxbet' ? value : data.maxbet,
      minbet:field=='minbet' ? value : data.minbet
    }
    
    if(field =='odds'){//修改赔率特殊处理
      function getData(is){
        var reqData = {
          id:data.id,
          playtype:setSixodds.currentGame.playtype,
          name:data.name,
          odds:value,
          state:is
        }
        return reqData;
      }
      function doPost(data){
        var postData = getData(data);
        layer.load(2);
        parent.ajaxService.doPost("/lotteryOdds/updateOddsOrSync.mvc",postData,function(res){
          var msg = res.resultMessage;
          if(res.resultCode ==0){
            setSixodds.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
      }
      layer.confirm("是否同步赔率到同类型的玩法中?",{
          btn:['是','否']
        },function(){
          doPost(1)
        },function(index){
          doPost(0)
        }
      )
    }else{
      setSixodds.updateViewDate(reqData)
    }
  });
});



