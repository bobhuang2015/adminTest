
var bankOpen = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  hasDel:false,
  hasSet:false,
  merchantTypeArr:[],
  renderMerchantType(data){
    var html='';
    data.forEach(function(v,k){
      html+=`<option value="${v.code}">${v.name}</option>`
    })
    $(".merchantType").append(html);
  },
  getToolbarHtml(){ 
    this.getMerchantType();
    var action = window.name;
    var permision = parent.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      var obj = {
        '修改':'hasSet',
        '删除':'hasDel',
        '禁用/启用':'hasLock'
      }
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i =='新增'){
          editHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }else{
          this[obj[i]]=true;
        }
      })

    }
    this.toolbarHtml =`<div>${editHtml}</div>`;//toolbar 跟表格联动
  },
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{ 
        curr:1  
      }
	  })
  },
  getMerchantType(){
    var _this = this;
    parent.ajaxService.doGet("/bank/getMerchantType.mvc",null,function(res){
      if(res.resultCode==0){
        _this.merchantTypeArr = res.results[0];
        _this.renderMerchantType(_this.merchantTypeArr);
      }
    })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(){
    var arr=[
      { field: 'name', title: '银行名称', width: 180, sort: true}
      , { field: 'url', title: '银行登录地址', width: 140, sort: true}
      , { title: '图标', width: 220,sort: true,templet:function(d){return `<div><img src='/resources${d.icon}'/></div>`}}
      , { field: 'minlimit', title: '最低限额', width: 120, sort: true}
      , { field: 'maxlimit', title: '最高限额', width: 120, sort: true}
      , { title: '操作',toolbar: '#barDemo'}
    ]
    return arr
  },
  editAlert(title,form,data){
    var isAdd = title == '新增' ? !0 : 0;
    layer.open({
      title:title,
      type: 1,
      skin: 'layui-layer-test',
      area: ['620px', '550px'],
      content: htmlTpl.addHtml,
      success:function(){
        bankOpen.renderMerchantType(bankOpen.merchantTypeArr);
        form.render("select",'add');
        var obj={
          "merchantType": isAdd ? '' : data.merchantType,
          "name": isAdd ? '' : data.name,
          "icon": isAdd ? '' : data.icon,
          "code": isAdd ? '' : data.code,
          "url": isAdd ? '' : data.url,
          "minlimit": isAdd ? '' : data.minlimit,
          "maxlimit": isAdd ? '' : data.maxlimit
        }
        form.val('add', obj)
        form.on('submit(formAdd)',function(submitData){
          var reqUrl = isAdd ? '/bank/add.mvc' : '/bank/update.mvc';
          var reqData = isAdd ? submitData.field : Object.assign(submitData.field,{id:data.id});
          parent.ajaxService.doPost(reqUrl,reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              bankOpen.layerCallback(msg);
            }else{
              layer.msg(msg)
            }
          })
          return false;
        })
      }
    })
  }
}

bankOpen.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  bankOpen.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  bankOpen.table.render({
    elem: '#demo'
    , height: 'full-80'
    , url: '/bank/list.mvc'
    ,toolbar: bankOpen.toolbarHtml
    ,defaultToolbar:[]
    , page: true
    , method: 'get'
    , cols: [ bankOpen.getOptions()],
    where: {
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results[0]
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      form.render("select",'test');
    }
  });
  
  // 工具栏操作
  bankOpen.table.on("toolbar(demo)",function(res){
    var checkStatus = bankOpen.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    switch (res.event) {
      case '新增':
        bankOpen.editAlert(res.event,form,data)
      break;
      default:
        break;
    }
  })
  //监听行工具事件
  bankOpen.table.on('tool(demo)', function(obj){
    var data = obj.data;
    var event = obj.event;
    if(event === 'lock'){
      var text = data.enabled ? '禁用' : '启用'; 
      layer.confirm(`是否${text}银行 ${data.name}?`, function(index){
        var reqData={
          id:data.id,
          enabled:!data.enabled
        }
        parent.ajaxService.doPost("/bank/changestate.mvc",reqData,function(res){
          if(res.resultCode ==0){
            bankOpen.layerCallback(res.resultMessage);
            bankOpen.editIdArr=[];
          }else{
            layer.msg(res.resultMessage);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(event === 'set'){
      bankOpen.editAlert('修改',form,data)
    }else{
      layer.confirm("是否删除选中的银行?",{
          btn:['确定','取消']
        },function(){
        var reqData = {
          bankId:data.id
        }
        parent.ajaxService.doPost("/bank/delete.mvc",reqData,function(res){
          if(res.resultCode ==0){
            bankOpen.layerCallback(res.resultMessage);
          }else{
            layer.msg(res.resultMessage);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    bankOpen.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



