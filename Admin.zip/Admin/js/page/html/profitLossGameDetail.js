
var profitLossGameDetail = {
  renderData(data){
    var html = '';
    if(data && data.length>0){
      data.forEach((v,k)=>{
        html +=`<tr>
          <td>${v.reportDate}</td>
          <td>${v.platformName}</td>
          <td>${v.subTypeName}</td>
          <td>${v.betNum}</td>
          <td>${v.betUserNum}</td>
          <td>${(v.betNum / v.betUserNum).toFixed(1)}</td>
          <td>${top.globalAdmin.commafy(v.betAmount.toFixed(3))}</td>
          <td>${top.globalAdmin.commafy(v.winAmount.toFixed(3))}</td>
          <td class='${top.globalAdmin.getColor(v.profitAmount)}'>${top.globalAdmin.commafy(v.profitAmount.toFixed(3))}</td>
          <td>${((v.profitAmount/v.betAmount)*100).toFixed(3)+'%'}</td>
          <td>${top.globalAdmin.commafy(v.bonusAmount.toFixed(3))}</td>
          <td class='${top.globalAdmin.getColor(v.profitAmount + v.bonusAmount)}'>${top.globalAdmin.commafy((v.profitAmount + v.bonusAmount).toFixed(3))}</td>
          <td>${v.betAmount ?((v.profitAmount + v.bonusAmount)/v.betAmount * 100).toFixed(3) : '0.000'}%</td>
        </tr>`
      })
      $(".tbody").append(html);
    }else{
      $('table').after('<div class="layui-none">无数据</div>')
    }
  }
}
profitLossGameDetail.renderData(parent.profitLossGame.detailData)


