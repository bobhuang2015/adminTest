
var rechargeAmount = {
  table:null,
  toolbarHtml:'',
  hasMakeup:false,
  pageNumber:1,
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i=='接口补单')this.hasMakeup=true;
      })
    }
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  formatType(type){
    var obj={
      "0":'失败',
      "1":'成功',
      "2":'接口失败',
      "3":'API失败',
      "4":'补单成功',
    }
    return obj[type]
  },
  platformObj:{},
  getPlatform(form){
    var _this = this;
    var p = new Promise(function(resovle,reject){
      parent.ajaxService.doGet("/platformTransferRecords/getTransferPlatform.mvc",null,function(res){
        if(res.resultCode==0){
          var html='';
          var data = res.results[0]
          _this.platformObj = data;
          for(var i in data){
            html+=`<option value='${i}'>${data[i]}</option>`
          }
          $(".platform").append(html);
          form.render('select');
          resovle(data);
        }
      })
    })
    return p;
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util,data){
    var arr=[
      { title: '操作', width: 90 , toolbar: '#barDemo'}
      ,{ field: 'ordernumber', title: '订单号', width: 180, sort: true}
      , { field: 'userName', title: '用户账号', width: 140,sort: true}
      , { field: 'transferout', title: '转出方', width: 140,sort: true,templet:function(d){return data[d.transferout]}}
      , { field: 'transferin', title: '转入方', width: 120,sort: true,templet:function(d){return data[d.transferin]}}
      , { field: 'money', title: '转账金额', width: 120,sort: true,templet:function(d){return d.money.toFixed(3)}}
      , { field: 'datetime', title: '转账时间', width: 180, sort: true,templet:function(d){return util.toDateString(d.datetime, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'status', title: '状态', width: 120,templet:function(d){return rechargeAmount.formatType(d.status)}}
      , { field: 'operator', title: '操作者', width: 120}
      , { field: 'remark', title: '备注'}
    ]
    return arr
  },
}

rechargeAmount.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  rechargeAmount.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  globalAdmin.renderIntDate(laydate,util);
  rechargeAmount.getPlatform(form).then(function(data){
    rechargeAmount.table.render({
      elem: '#demo'
      , height: 'full-80'
      , url: '/platformTransferRecords/search.mvc'
      , page: true
      , method: 'get'
      , cols: [rechargeAmount.getOptions(util,data)]
      , where: {
      }
      , parseData: function (res) {
        var result = {
          "code": res.resultCode, 
          "msg": res.resultMessage,
          "count": res.meta.totalRecord,
          "data": res.results
        };
        return result
      },
      response: {
        statusCode: '0'
      },
      done: function (res, cur, count) {
        rechargeAmount.pageNumber = cur;
      }
    });
  })
  
  // 工具栏操作
  rechargeAmount.table.on("tool(demo)",function(obj){
    var data = obj.data;
    var event = obj.event;
    switch (event) {
        case 'makeup':
        case 'wallet':
        var txt = {
          'makeup':'接口',
          'wallet':'钱包'
        }
        layer.confirm(`确认要进行${txt[event]}补单操作吗?`,function(index){
          var reqData={
            id:data.id
          }
          parent.ajaxService.doPost("/platformTransferRecords/retransfer.mvc",reqData,function(res){
            var msg = res.resultMessage
            if(res.resultCode == 0){
              rechargeAmount.layerCallback(msg);
            }else{
              layer.msg(msg);
            }
          })
          },function(index){
            layer.close(index)
          }
        )
      break;
      default:
        break;
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    rechargeAmount.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



