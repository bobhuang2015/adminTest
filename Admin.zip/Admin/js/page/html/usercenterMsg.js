
var usercenterMsg = {
  table:null,
  toolbarHtml:'',
  hasDel:false,
  pageNumber:1,
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i =='删除'){
         this.hasDel=true;
        }else if(i == '发信'){
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${otherHtml}</div>`;
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  formatMsgtype(type){
    return type==1 ? '用户消息' : '系统消息'
  },
  getOptions:function(util){
    var arr=[
      { field: 'messagetype', title: '信息类型', width: 120, sort: true,templet:function(d){return usercenterMsg.formatMsgtype(d.messagetype)}}
      , { field: 'sendername', title: '发送者', width: 120,sort: true}
      , { field: 'receivername', title: '接收者', width: 120, sort: true}
      , { field: 'messagetitle', title: '消息标题', width: 220, sort: true}
      , { field: 'messagecontent', title: '消息内容', width: 300, sort: true}
      , { field: 'sendtime', title: '发送时间', width: 180, sort: true,templet:function(d){return util.toDateString(d.sendtime, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'isread', title: '状态', width: 120, sort: true,templet:function(d){return d.isread==1 ? '已阅读' : '未阅读'}}
      , { title: '操作', toolbar:'#barDemo'}
    ]
    return arr
  }
}

usercenterMsg.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  usercenterMsg.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  globalAdmin.renderRechargeDate(laydate,util);
  var topHeight = ~~($(".layui-row").height()+40);

  usercenterMsg.table.render({
    elem: '#demo'
    , height: `full-${topHeight}`
    , url: '/messages/search.mvc'
    , toolbar: usercenterMsg.toolbarHtml
    , page: true
    , defaultToolbar:[]
    , method: 'get'
    , cols: [ usercenterMsg.getOptions(util)],
    where: {
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      usercenterMsg.pageNumber=cur;
    }
  });
  parent.globalAdmin.checkboxEdit(usercenterMsg,window.name)
  
  // 工具栏操作
  usercenterMsg.table.on("toolbar(demo)",function(res){
    var checkStatus = usercenterMsg.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    switch (res.event) {
      case '发信':
        layer.open({
          title:res.event,
          type: 1,
          skin: 'layui-layer-test',
          area: ['600px', '500px'],
          content: htmlTpl.addHtml,
          success:function(){
            var obj={
              "messagetype": 1,
              "messagetitle": '',
              "messagecontent":'',
              "receivername":''
            }
            form.val('add', obj)
            form.render()
            form.on('submit(formAdd)',function(submitData){
              var reqData = submitData.field;
              if(reqData.receivernames)reqData.receivernames='y'
              parent.ajaxService.doPost('/messages/send.mvc',reqData,function(res){
                var msg = res.resultMessage;
                if(res.resultCode==0){
                  usercenterMsg.layerCallback(msg);
                }else{
                  layer.msg(msg)
                }
              })
              return false;
            })
          }
        })
      break;
      default:
        // layer.msg("接口文档未完善，需要相应人员支持!")
        break;
    }
  })
  //监听行工具事件
  usercenterMsg.table.on('tool(demo)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
      layer.confirm(`确认要删除所选记录?`, function(index){
        var reqData={
          messagesId:data.id
        }
        parent.ajaxService.doPost("/messages/deleteMessage.mvc",reqData,function(res){
          var msg = res.resultMessage
          if(res.resultCode ==0){
            usercenterMsg.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    usercenterMsg.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



