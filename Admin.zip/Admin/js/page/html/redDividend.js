
var redDividend = {
  table:null,
}

layui.use([ 'table', 'layer','util','form'], function () {
  var laydate = layui.laydate;
  redDividend.table = layui.table;
  var layer = layui.layer;
  var util = layui.util;
  var form = layui.form;
  redDividend.table.render({
    elem: '#demo'
    , height: 440
    , url: '/dividendManager/getDividendDetailss.mvc'
    , page: true
    , method: 'get'
    , where:{
      infoid:location.search.split("=")[1]
    }
    , cols: [[
       { field: 'username', title: '用户名称', width: 100 }
      , { field:'dividendmoney',title: '领取金额', width: 120, sort: true}
      , { field:'receiveip',title: '领取IP', width: 120, sort: true}
      , { title: '领取时间', width: 180, sort: true ,templet:function(d){return util.toDateString(d.receivetime, "yyyy-MM-dd HH:mm:ss")}}
      , { field:'remark',title: '备注',  sort: true}
    ]]
    , parseData: function (res) {
      var result = {
        "code": res.resultCode,
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
    }
  });

  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    redDividend.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});
