
var betKGzhuihao = {
  table:null,
  toolbarHtml:'',
  hasStop:false,
  stateObj:{},
  getToolbarHtml(){ 
    var action = window.name;
    var permision = parent.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      permision.forEach((v,k)=>{
        var i  = v.menuName;
        if(i=='停止')this.hasStop=true;
      })
    }
    // $(".btn-area").append(editHtml).append(`<div style="display:inline-block;margin-left:10px;">${otherHtml}</div>`);
  },
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1  
      }
	  })
  },
  renderGametype(data){
    var html='';
    data.forEach((v,k)=>{
      html+=`<option value="${v.id}">${v.name}</option>`
    })
    $(".gameType").append(html);
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var arr=[
      // { title: '操作',fixed: 'left', width: 140,toolbar:'#barDemo'}
      { title: '操作',fixed: 'left', width: 140}
      , { fixed: 'left',field: 'ordernumber', title: '追号单号', width: 180, sort: true}
      , { fixed: 'left',field: 'username', title: '用户账号', width: 140, sort: true}
      , { field: 'gametypename', title: '游戏类型', width: 140, sort: true}
      , { field: 'betmoneytotal', title: '投注总额', width: 140,sort: true}
      , { field:'optdt',title: '下单时间', width:180, sort: true,templet:function(d){return util.toDateString(d.optdt, "yyyy-MM-dd HH:mm:ss")}}
      , { field:'iswinstop',title: '中奖停止', width: 100, sort: true,templet:function(d){return d.iswinstop ? '是' : '否'}}
      , { title: '剩余/总期数', width: 140,templet:function(d){return d.issuelave + '/' + d.issuecount}}
      , { field:'stopped',title: '状态', width: 100, sort: true,templet:function(d){return d.stopped == 1 ? '追号中' : '已停止'}}
      , { field: 'uniqueness', title: '最后追号期号', width: 140, sort: true}
      , { field:'stopdt',title: '停止时间', width: 180 ,sort: true,templet:function(d){return util.toDateString(d.stopdt, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'remarks', title: '备注', width: 120, sort: true}
    ]
    return arr
  },
  editIdArr:[],
  tableData:[]
}

betKGzhuihao.getToolbarHtml();
betKGzhuihao.renderGametype(parent.globalAdmin.gameListArr);
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  betKGzhuihao.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  globalAdmin.renderRechargeDate(laydate,util);
  betKGzhuihao.table.render({
    elem: '#demo'
    , height: 600
    , url: '/kjzhuihao/search.mvc'
    , page: true
    , method: 'get'
    , cols: [ betKGzhuihao.getOptions(util)],
    where: {}
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results
      };
      betKGzhuihao.tableData=res.results;
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
    }
  });
  
  //监听行工具事件
  betKGzhuihao.table.on('tool(demo)', function(obj){
    var data = obj.data;
    if(obj.event === 'stop'){
      layer.confirm(`是否停止该记录?`, function(index){
        var reqData={
          userid:data.userid,
          id:data.id
        }
        parent.ajaxService.doPost("/kjzhuihao/stop.mvc",reqData,function(res){
          var msg = res.resultMessage
          if(res.resultCode ==0){
            betKGzhuihao.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    betKGzhuihao.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



