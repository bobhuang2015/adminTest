
var platformsetLoginip = {
  table:null,
  toolbarHtml:'',
  hasDel:false,
  pageNumber:1,
  isFront:window.name=='iframe_1761' || parent.globalAdmin.getUrlParam('code')=='iframe_1761' ? !0 :0,
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  isValidIp(ip){
    var reg =  /^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$/   
    return reg.test(ip);  
  },
  getToolbarHtml(){ 
    var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = '';
    var editHtml = "";
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        var obj = {
          '删除':'hasDel',
        }
        if(i !='新增'){
          this[obj[i]]=true;
        }else{
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${otherHtml}</div>`;
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var arr=[
      { field: 'address', title: 'IP地址', width: 180,sort: true}
      , { field: 'operator', title: '操作者', width: 140,sort: true}
      , { title: '时间', width: 200,sort: true,templet:function(d){return util.toDateString(d.operatordt, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'remarks', title: '备注', width: 180,sort: true}
      , { title: '操作', toolbar:'#barDemo'} 
    ]
    return arr
  },
  editIdArr:[],
  tableData:[]
}

platformsetLoginip.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  platformsetLoginip.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  var requestUrl = platformsetLoginip.isFront ? '/ipaddress/list.mvc' : '/ipaddress/listHt.mvc';
  var topHeight = $('.layui-row').height()+40;
  platformsetLoginip.table.render({
    elem: '#demo'
    , height: `full-${topHeight}`
    , url: requestUrl
    , toolbar: platformsetLoginip.toolbarHtml
    , defaultToolbar:[]
    , page: true
    , method: 'get'
    , cols: [ platformsetLoginip.getOptions(util)],
    where: {
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      platformsetLoginip.pageNumber=cur;
    }
  });
  
  // 工具栏操作
  platformsetLoginip.table.on("toolbar(demo)",function(res){
    var checkStatus = platformsetLoginip.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    switch (res.event) {
      case '新增':
        layer.open({
          title:res.event,
          type: 1,
          skin: 'layui-layer-test',
          area: ['600px', '400px'],
          content: htmlTpl.addHtml,
          success:function(){
            var html = platformsetLoginip.isFront ? '<option value="0">前端</option>' : '<option value="1">后端</option>';
            var type = platformsetLoginip.isFront ? 0 : 1;
            $('#layui-type').html(html);
            var obj={
              "type": type,
              "address": '',
              "remarks":''
            }
            form.render('select','add')
            form.val('add', obj);

            form.verify({
              ip: function(value, item){ //value：表单的值、item：表单的DOM对象
                var isIp = platformsetLoginip.isValidIp(value);
                if(!isIp){
                  return '请输入正确的IP地址';
                }
              }
            }); 
            form.on('submit(formAdd)',function(submitData){
              var reqData =submitData.field ;
              parent.ajaxService.doPost('/ipaddress/add.mvc',reqData,function(res){
                var msg = res.resultMessage;
                if(res.resultCode==0){
                  platformsetLoginip.layerCallback(msg);
                }else{
                  layer.msg(msg)
                }
              })
              return false;
            })
          }
        })
      break;
      default:
        break;
    }
  })
  //监听行工具事件
  platformsetLoginip.table.on('tool(demo)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
      layer.confirm(`是否删除?`, function(index){
        var reqData={
          id:data.id,
        }
        parent.ajaxService.doPost("/ipaddress/delete.mvc",reqData,function(res){
          var msg = res.resultMessage;
          if(res.resultCode ==0){
            platformsetLoginip.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    platformsetLoginip.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



