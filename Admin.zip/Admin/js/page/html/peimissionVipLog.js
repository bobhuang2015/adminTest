
var peimissionVipLog = {
  table:null,
  toolbarHtml:'',
  getToolbarHtml(){ 
  },
  reloadTable:function(){
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:1  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var arr=[
      { field: 'username', title: '会员名称', width: 140, sort: true}
      , { field: 'operationfunction', title: '操作菜单名称', width: 140, sort: true}
      , { field: 'ip', title: '操作IP',sort: true,width:220}
      , { field:'operationtime',title: '操作时间',sort: true,templet:function(d){return util.toDateString(d.operationtime, "yyyy-MM-dd HH:mm:ss")}}
    ]
    return arr
  },
}

layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  peimissionVipLog.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  parent.globalAdmin.renderIntDate(laydate,util)
  
  var topHeight = ~~($(".layui-row").height()+40);
  peimissionVipLog.table.render({
    elem: '#demo'
    , height: `full-${topHeight}`
    , url: '/userOperateLog/search.mvc'
    // ,toolbar: peimissionVipLog.toolbarHtml
    , page: true
    , method: 'get'
    , cols: [ peimissionVipLog.getOptions(util)],
    where: {
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results
      };
      peimissionVipLog.tableData=res.results;
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
    }
  });
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    peimissionVipLog.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
});



