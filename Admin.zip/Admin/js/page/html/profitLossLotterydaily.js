var profitLossLotterydaily = {
  legendData:['投注总额','中奖总额','返点总额','传统投注总额','传统中奖总额','传统返点总额','微投投注总额','微投中奖总额','微投返点总额'],
  getTable2(data){
    var _this = this;
    var html = '';
    data.forEach(v=>{
      html +=`<tr><td>${v.reportDate}</td><td>${v.betAmount}</td><td>${v.winAmount}</td><td>${v.bonusAmount}</td><td>${v.kjBetAmount}</td><td>${v.kjWinAmount}</td><td>${v.kjBonusAmount}</td><td>${v.wtBetAmount}</td><td>${v.wtWinAmount}</td><td>${v.wtBonusAmount}</td></tr>`;
    })
    var headHtml=``;
    var tempArr = [..._this.legendData];
    tempArr.unshift('日期');
    for(var i=0;i<tempArr.length;i++){
      headHtml +=`<th><div class="table_th2">${tempArr[i]}</div></th>`
    }
    return `<table class="layui-table" lay-size="sm" style="width:100%;"><thead><tr>${headHtml}</tr></thead><tbody class="tbody">${html}</tbody></table>`
  },
  renderPie(xAxisData,seriesData,resData) {
    var _this = this;
    var myChart = echarts.init(document.getElementById("demo"));
    var option = {
        title: {
            y:'10px',
            text: '彩票日结统计图'
        },
        toolbox: {
          show: true,
          feature:{
            dataView: {
              lang:['','关闭'],
              show: true, 
              title:'表格',
              readOnly: true,
              optionToContent:function(opt){
                // var dataview = opt.toolbox[0].feature.dataView;
                var table = _this.getTable2(resData);
                return table;
              },
            },
          }
        },
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            y:'10px',
            data:_this.legendData
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        xAxis: {
            type: 'category',
            boundaryGap: false,
            data: xAxisData
        },
        yAxis: {
            type: 'value'
        },
        series: seriesData
    };
    myChart.setOption(option);
  },
  getData(data) {
    var _this = this;
    parent.parent.ajaxService.doGet("/gameGatherDaily/statisByDay.mvc",data,function(res) {
        if (res.resultCode == 0) {
          var resData = res.results[0];
          var xAxisData = [];
          var seriesDataArr = [];
          var staticData = {};
          _this.legendData.forEach((v,k)=>{
            staticData[v]=[]
          })
          resData.forEach((v,k)=>{
            xAxisData.push(v.reportDate.substr(5).replace(/-/g,'\/'));
            staticData['投注总额'].push((+v.betAmount).toFixed(3));
            staticData['中奖总额'].push((+v.winAmount).toFixed(3));
            staticData['返点总额'].push((+v.bonusAmount).toFixed(3));
            staticData['传统投注总额'].push((+v.kjBetAmount).toFixed(3));
            staticData['传统中奖总额'].push((+v.kjWinAmount).toFixed(3));
            staticData['传统返点总额'].push((+v.kjBonusAmount).toFixed(3));
            staticData['微投投注总额'].push((+v.wtBetAmount).toFixed(3));
            staticData['微投中奖总额'].push((+v.wtWinAmount).toFixed(3));
            staticData['微投返点总额'].push((+v.wtBonusAmount).toFixed(3));
          })
          _this.legendData.forEach((v,k)=>{
            var obj={};
            obj.name=v;
            obj.type='line';
            obj.stack='总量'+k;
            obj.smooth=true;
            obj.data=staticData[v];
            seriesDataArr.push(obj);
          })
         _this.renderPie(xAxisData,seriesDataArr,resData)
        }
      }
    );
  }
};

layui.use(["laydate", "form","util"], function() {
  var laydate = layui.laydate;
  var form = layui.form;
  var util = layui.util;
  parent.globalAdmin.isYesterday = !0;
  parent.globalAdmin.renderIntDate(laydate,util);
  var start = $('#start').val();
  var end = $('#end').val();
  var initData={
    reportDateBegin:start,
    reportDateEnd:end
  }
  profitLossLotterydaily.getData(initData);

  // 表单提交demo
  form.on("submit(formDemo)", function(data) {
    var reqData = {
      reportDateBegin:data.field.reportDateBegin,
      reportDateEnd:data.field.reportDateEnd
    }
    profitLossLotterydaily.getData(reqData);
    return false;
  });
});
