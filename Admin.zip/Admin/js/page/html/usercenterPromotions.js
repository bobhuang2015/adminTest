
var usercenterPromotios = {
  table:null,
  toolbarHtml:'',
  hasLock:false,
  hasDel:false,
  hasSet:false,
  isFirstRecharge:true,
  currentActiveType:'',
  activeList:JSON.parse(localStorage.getItem('activeList')) || null,
  layeditIndex1:0,
  layeditIndex2:100,
  openList:[],
  type:1,
  client:'PC',
  pageNumber:1,
  editToolObj:{tool: ['fontSize','colorpicker','strong', 'italic','underline','del','|','left','center','right','|','link','unlink','face'],height: 140},
  pcHtml:`<div class="layui-form-item pic">
          <label class="layui-form-label">PC详情图片路径</label>
          <div class="layui-input-block">
            <input type="text" name="detailImgUrlPc" class="layui-input layui-imgurl" readonly autocomplete='off' style="width:482px;display:inline-block;" lay-verify="required"/>
            <button class='layui-btn layui-btn-operator layui-btn-normal' id="layui-upload-web-detail" type="button">&nbsp;&nbsp;选择&nbsp;&nbsp;</button>
            <button class='layui-btn layui-btn-operator layui-btn-normal layui-preview'>预览图片</button>
          </div>
        </div>`,
  appHtml:`<div class="layui-form-item pic">
        <label class="layui-form-label">app详情图片路径</label>
        <div class="layui-input-block">
          <input type="text" name="detailImgUrlApp" class="layui-input layui-imgurl" readonly autocomplete='off' style="width:482px;display:inline-block;margin-left:-2px;" lay-verify="required"/>
          <button class='layui-btn layui-btn-operator layui-btn-normal' id="layui-upload-app-detail" type="button">&nbsp;&nbsp;选择&nbsp;&nbsp;</button>
          <button class='layui-btn layui-btn-operator layui-btn-normal layui-preview'>预览图片</button>
        </div>
      </div>`,
  getToolbarHtml(){
    var action = globalAdmin.getUrlParam('permision') || window.name;
    var permision = parent.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        var obj = {
          '修改':'hasSet',
          '删除':'hasDel',
          '启用/禁用':'hasLock'
        }
        if(i !='新增'){
          this[obj[i]]=true;
        }else{
          otherHtml +='<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${otherHtml}</div>`;
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber
      }
	  })
  },
  renderHtml(data,ele,is){
    var html='';
    var host = location.host;
    if(is){
      data.forEach((v,k)=>{
        html+=`<option value="${v.id}">${v.name}</option>`
      })
    }else{
      for(var i  in  data){
        // if(host != '211.21.23.194:89'){ //非测试环境只有通用类型
          // i == 6 && (html+=`<option value="${i}">${data[i]}</option>`)
        // }else{
          html+=`<option value="${i}">${data[i]}</option>`
        // }
      }
    }
    $(`.${ele}`).append(html);
  },
  getActiveType(){
    var _this = this;
    !this.activeList && parent.ajaxService.doGet('/getEnumByName.mvc',{enumName:'Promotions_Type'},function (res) {
      if(res.resultCode == 0){
        _this.activeList = res.results[0];
        _this.renderHtml(_this.activeList,'layui-type',false)
        localStorage.setItem('activeList',JSON.stringify(_this.activeList));
      }
    })
    this.activeList && this.renderHtml(this.activeList,'layui-type',false)
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOpenHtml(data){
    var html = '<option value="0">不限</option>'
    data.forEach((v,k)=>{
      html +=`<option value="${v.id}">${v.name}</option>`
    })
    return html;
  },
  getOpen(){
    var _this = this;
    parent.ajaxService.doGet('/rechargType/getListOpen.mvc',null,function(res){
      if(res.resultCode == 0){
        _this.openList  = res.results[0];
      }
    })
  },
  getShowType(d){
    var tempStr = (d.isDisplayPc ? 'PC&' :'') + (d.isDisplayH5 ? 'H5&' :'') + (d.isDisplayIos ? 'iOS&' :'') + (d.isDisplayAndroid ? 'Android&' :'');
    var tempArr = tempStr.split('&');
    tempArr.pop();
    return tempArr.join('&');
  },
  getOptions:function(util){
    var _this = this;
    var arr=[
      { field: 'type', title: '活动类型', width: 120, sort: true,templet:function(d){return _this.activeList[d.type]}}
      , { field: 'template', title: '活动模板', width: 120, sort: true}
      , { field: 'title', title: '活动标题', width: 120, sort: true}
      , { field: 'introductionPc', title: '活动介绍', width: 260, sort: true}
      , { field:'displayBegin', title: '展示时间', width: 200, sort: true,templet:function(d){return util.toDateString(d.displayBegin, "yyyy/MM/dd")+'-'+util.toDateString(d.displayEnd, "yyyy/MM/dd")}}
      , { field:'doingBegin',title: '活动时间', width: 200, sort: true,templet:function(d){return util.toDateString(d.doingBegin, "yyyy/MM/dd")+'-'+util.toDateString(d.doingEnd, "yyyy/MM/dd")}}
      , { field:'isDisplayPc',title: '展示端', width: 200, sort: true,templet:function(d){return _this.getShowType(d)}}
      , { field: 'operatorDate', title: '最后编辑时间', width: 140, sort: true,templet:function(d){return util.toDateString(d.operatorDate, "yyyy-MM-dd")}}
      , { field: 'sort', title: '排序', width: 80, sort: true,edit:'text'}
      , { title: '操作',toolbar:'#barDemo'}
    ]
    return arr
  },
  editIdArr:[],
  tableData:[],
  uploadImg(title,upload,data){
    var isAdd = title=='新增' ? !0 : 0;
    var _this  =this;
    var uploadUrl = parent.globalAdmin.uploadInfo.uploadImgUrl+'/file-upload/upload-image';
    var obj = {
      "#layui-upload-web":'headImgUrlPc',
      "#layui-upload-web-detail":'detailImgUrlPc',
      "#layui-upload-h5":'headImgUrlH5',
      "#layui-upload-h5-detail":'detailImgUrlH5',
      "#layui-upload-app":'headImgUrlApp',
      "#layui-upload-app-detail":'detailImgUrlApp'
    };
    for(var i in obj){
      if(!isAdd)$(i).siblings('.layui-preview').attr('data-src',data[obj[i]]);
      picUpload(i)
    }
    function picUpload(ele){
      upload.render({
        elem: ele//绑定元素
        ,url: uploadUrl //上传接口
        ,choose:function(obj){
          obj.preview(function(index,file,result){//预览图片
          })
        }
        ,before:function(obj){//文件上传前的回调
          layer.load(2);
        }
        ,data:{
          tenantCode:parent.globalAdmin.uploadInfo.tenantCode,
          category:'promotion'
        }
        ,done: function(res,index){//上传完毕回调
          layer.closeAll('loading');
          var data = res.data;
          $(ele).siblings('.layui-imgurl').val(data);
          $(ele).siblings('.layui-preview').attr('data-src',data);
        }
        ,error: function(data){//请求异常回调
          layer.closeAll('loading')
        }
        ,size:1024*2
      })
    }

    $('.layui-preview').on('click',function(){
      var src = $(this).attr('data-src');
      if(src){
        var imgHtml = `<img src="${parent.globalAdmin.uploadInfo.viewImgUrl+'/'+src}" style='width:300px;height:200px;'/>`
        layer.open({
            type: 1,
            title: '图片预览',
            area: ['300px','250px'],
            content: imgHtml,
            cancel: function () {
            }
        })
      }else{
        layer.alert('请先上传图片!')
      }
      return false;
    })
  },
  renderFirstStep(form){
    this.client="PC";
    this.renderHtml(usercenterPromotios.activeList,'layui-type',false);
    var _this = this;
    getPreviewImg(this.type,1,this.client);
    function getPreviewImg(type,template,client){
      var index=layer.load(2)
      parent.ajaxService.doPost('/promotions/getTemplateUrl.mvc',{type:type,template:template,client:client},function(res){
        if(res.responseCode ==0){
          var img = `<img src="${parent.globalAdmin.uploadInfo.viewImgUrl+'/'+res.responseData.templateUrl}" style="margin-left:86px;width:${client=='APP' ? '50%' : '70%'}" id="previewImg"/>`;
          $('.layui-preview-box').html(img)
          $('.layui-btn[lay-filter="formFirst"]').show()
        }else{
          layer.alert(res.responseMessage+',请先上传活动模板图片!')
          $('.layui-btn[lay-filter="formFirst"]').hide()
        }
        setTimeout(()=>{
          layer.close(index);
        },5e2)
      })
    }
    form.render();
    form.on('radio(preview)', function(data){
      _this.client=data.value;
      getPreviewImg(_this.type,1,_this.client);
    });
    form.on('select(type)',function(data){
      _this.type=data.value;
      getPreviewImg(_this.type,1,_this.client);

    })
    $(".layui-preview-box").on('click',"#previewImg",function(){
      var src = $(this).attr('src')
      var imgHtml = `<img src="${src}" style='width:80%;height:auto;margin-left:10%;' class="layui-scale-img"/>`
      layer.open({
          type: 1,
          title: '图片预览',
          area: ['1000px','800px'],
          content: imgHtml,
          cancel: function () {
          },
          success:function(){
            $('.layui-scale-img').parent().css('overflow-y',"scroll")
          }
      })
    })
  },
  addHtml(form,selectHtml){
    var _this = this;
    $('.layui-add').on('click',function(){
      var len =$(this).siblings('table').children('.layui-tbody').children('tr').length;
      var index = $(this).attr('data-id');
      var str = ''
      if(_this.currentActiveType ==1){//累计充值
        if(Number($(`.layui-tbody tr:eq(${len-1}) .layui-amounts`).val()) > (1000000000 / 2))return;
        str=`<tr>
          <td>第${len+1}档</td>
          <td>
            <select class="layui-rechargeMethodId">${selectHtml}</select>
          </td>
          <td>
            <input type="text" class="layui-input layui-amounts layui-control" value="${len>0 ? +$(`.layui-tbody tr:eq(${len-1}) .layui-amounts`).val()*2 : 1000}"/> 
          </td>
          <td>
            <input type="text" class="layui-input layui-number layui-control" value="100"/> 
          </td>
          <td>
            <input type="number" class="layui-input layui-fixedReward" value="18"/> 
          </td>
          <td>
            <div class="layui-btn layui-btn-sm layui-btn-danger layui-del">删除</div>
          </td>
        </tr>`
      }else if(_this.currentActiveType ==2){//单笔充值
        if(Number($(`.layui-tbody tr:eq(${len-1}) .layui-amounts2`).val()) > (1000000000 / 10))return;
        str=`<tr>
          <td>
            <select class="layui-rechargeMethodId">${selectHtml}</select>
          </td>
          <td>
            <input type="text" class="layui-input layui-amounts1 layui-control" value="${len>0 ? +$(`.layui-tbody tr:eq(${len-1}) .layui-amounts2`).val()+1 : 1}" style="width:60px;display:inline-block"/> ~ <input type="text" class="layui-input layui-amounts2 layui-control" value="${len>0 ? +$(`.layui-tbody tr:eq(${len-1}) .layui-amounts2`).val() * 10 : 100}" style="width:60px;display:inline-block"/>
          </td>
          <td>
            <input type="text" class="layui-input layui-number layui-control" value="100"/> 
          </td>
          <td>
            <input type="number" class="layui-input layui-fixedReward" value="18"/> 
          </td>
          <td>
            <input type="number" class="layui-input layui-ratio" value="0" ${_this.isFirstRecharge ? '' : 'disabled'}/> 
          </td>
          <td>
            <div class="layui-btn layui-btn-sm layui-btn-danger layui-del">删除</div>
          </td>
        </tr>`
      } else if ( _this.currentActiveType ==8) { // 提现送
        if(Number($(`.layui-tbody tr:eq(${len-1}) .layui-amounts2`).val()) > (1000000000 / 10))return;
        str=`<tr>
          <td>
            <input type="text" class="layui-input layui-amounts1 layui-control" value="${len>0 ? +$(`.layui-tbody tr:eq(${len-1}) .layui-amounts2`).val()+1 : 1}" style="width:60px;display:inline-block"/> ~ <input type="text" class="layui-input layui-amounts2 layui-control" value="${len>0 ? +$(`.layui-tbody tr:eq(${len-1}) .layui-amounts2`).val() * 10 : 100}" style="width:60px;display:inline-block"/>
          </td>
          <td>
            <input type="text" class="layui-input layui-number layui-control" value="100"/> 
          </td>
          <td>
            <input type="number" class="layui-input layui-fixedReward" value="18"/> 
          </td>
          <td>
            <div class="layui-btn layui-btn-sm layui-btn-danger layui-del">删除</div>
          </td>
        </tr>`
      }else if(_this.currentActiveType == 3){//打码送
        if(Number($(`.layui-tbody tr:eq(${len-1}) .layui-amounts`).val()) > (1000000000 / 10))return;
        str=`<tr>
          <td>
            <input type="text" class="layui-input layui-amounts layui-control" value="${len>0 ? +$(`.layui-tbody tr:eq(${len-1}) .layui-amounts`).val() * 10 : 100}" />
          </td>
          <td>
            <input type="text" class="layui-input layui-number layui-control" value="10"/> 
          </td>
          <td>
            <input type="number" class="layui-input layui-fixedReward" value="10"/> 
          </td>
          <td>
            <input type="number" class="layui-input layui-ratio" value="0" ${_this.isFirstRecharge ? '' : 'disabled'}/> 
          </td>
          <td>
            <div class="layui-btn layui-btn-sm layui-btn-danger layui-del">删除</div>
          </td>
        </tr>`
      }else if(_this.currentActiveType == 4){//盈亏送
        if(Number($(`.layui-tbody tr:eq(${len-1}) .layui-amounts`).val()) > (1000000000 / 10))return;
        str=`<tr data-type="${index}">
          <td>
            <input type="text" class="layui-input layui-amounts layui-control" value="${len>0 ? +$(`.layui-tbody[data-content='${index}'] tr:eq(${len-1}) .layui-amounts`).val() * 10 : 100}" />
          </td>
          <td>
            <input type="number" class="layui-input layui-fixedReward" value="${len > 1 ? 5 * len * len * 100 : len == 1 ? 25 : 1}"/> 
          </td>
          <td>
            <input type="text" class="layui-input layui-number layui-control" value="1"/> 
          </td>
          <td>
            <div class="layui-btn layui-btn-sm layui-btn-danger layui-del">删除</div>
          </td>
        </tr>`
      }

      $(this).siblings('table').children('.layui-tbody').append(str);
      // form.val('second',{
      //   'receiveType':'1',
      //   'isMemberType':'1'
      // })
      form.render();

      // 输入数字控制;
      $(".layui-tbody .layui-control").keyup(function(){
        var tmptxt=$(this).val();
        $(this).val(tmptxt.replace(/\D|^0/g,''));
      }).bind("paste",function(){
        var tmptxt=$(this).val();
        $(this).val(tmptxt.replace(/\D|^0/g,''));
      }).css("ime-mode", "disabled");
    })

    // 流水复选框操作;
    form.on('checkbox(benjin)', function(data){
      $(data.elem).siblings('input').attr('disabled',data.elem.checked ? false : true).val(data.elem.checked ? '100' : '0');
    });
    form.on('checkbox(jiangli)', function(data){
      $(data.elem).siblings('input').attr('disabled',data.elem.checked ? false : true).val(data.elem.checked ? '100' : '0');
    });
    // PC展示端控制
    form.on('checkbox(PC)', function(data){
      if(data.elem.checked){
        $('input[name=headImgUrlPc]').attr('lay-verify','required')
      }else{
        $('input[name=headImgUrlPc]').removeAttr('lay-verify')
      }
    });

  },
  savePromotion(secondData,layer,txt,layedit,firstObj,data){
    var _this = this;
    let data2 = secondData.field;
    let promotionsSubs=[];
    let reqData={};
    let isSubmit  = true;
    let introduceActive = layedit.getContent(_this.layeditIndex1);
    let introduceNotice = layedit.getContent(_this.layeditIndex2);
    if(data2.isDisplayH5 || data2.isDisplayIos || data2.isDisplayAndroid){
      if(!data2.headImgUrlApp){
        layer.alert('请先上传app图片路径');
        return false;
      }
    }
    $('.layui-tbody tr').each(function(index,value){
      var obj = {}
      obj.rechargeMethodId = $(value).find('.layui-rechargeMethodId').val() ? $(value).find('.layui-rechargeMethodId').val() : 0;
      if(_this.currentActiveType ==2 || _this.currentActiveType ==8){
        obj.amonuts = $(value).find('.layui-amounts1').val() + '-'+$(value).find('.layui-amounts2').val()
      }else{
        obj.amonuts = $(value).find('.layui-amounts').val();
      }
      if(txt =='set' && $(value).attr('data-id')){
        obj.id=$(value).attr('data-id');
        obj.promotionId = $(value).attr('data-promotionId');
      }
      obj.number = $(value).find('.layui-number').val();
      obj.fixedReward = $(value).find('.layui-fixedReward').val();
      obj.ratio = $(value).find('.layui-ratio').val() ? $(value).find('.layui-ratio').val() : 0;
      obj.specialType = $(value).attr('data-type') ? $(value).attr('data-type') : '';
      promotionsSubs.push(obj);
    })
    // if(firstObj.type !=6 && !introduceActive){
    //   layer.alert('活动内容不能为空!');
    //   return false;
    // }
    // if(firstObj.type !=6 && !introduceNotice){
    //   layer.alert('注意事项不能为空!');
    //   return false;
    // }
    if(firstObj.type !=6 && promotionsSubs.length ==0){
      layer.alert('请添加条件设置!');
      return false;
    }
    if(_this.currentActiveType == 3 || _this.currentActiveType==4){//打码送&盈亏送
      var checkedData = $('.fanwei-list').find('.layui-form-checkbox');
      var checkList = [];
      checkedData.each(function(){
        if($(this).hasClass('layui-form-checked')){
          checkList.push($(this).prev().val())
        }
      })
      if(checkList.length==0){
        layer.msg('至少选择一项活动范围!');
        return false;
      }
    }
    // 递增处理;
    if(promotionsSubs.length > 0 && firstObj.type !=4){
      for(var i=0;i<promotionsSubs.length;i++){
        if(i > 0 && +promotionsSubs[i].amonuts <= +promotionsSubs[i-1].amonuts){
          layer.msg('额度只能递增');
          isSubmit = false;
          return false;
        }
      }
    }
    reqData={
      title:data2.title,
      sort:data2.sort,
      isDisplayPc:data2.isDisplayPc ? true : false,
      isDisplayH5:data2.isDisplayH5 ? true : false,
      isDisplayIos:data2.isDisplayIos ? true : false,
      isDisplayAndroid:data2.isDisplayAndroid ? true : false,
      displayBegin:new Date(data2.showTime.split(' - ')[0]).getTime(),
      displayEnd:new Date(data2.showTime.split(' - ')[1]).getTime(),
      doingBegin:new Date(data2.activeTime.split(' - ')[0]).getTime(),
      doingEnd:new Date(data2.activeTime.split(' - ')[1]).getTime(),
      isDoingDate:data2.isDoingDate ? true : false,
      memberType:data2.memberType,
      lable:(data2.label1 ? data2.label1+'&'+data2.labelSelect1 : '')+'-'+(data2.label2 ? data2.label2+'&'+data2.labelSelect2 :'')+"-"+(data2.label3 ? data2.label3+'&'+data2.labelSelect3 :''),
      isMemberType:data2.isMemberType ? true : false,
      introductionPc:introduceActive,
      introductionApp:introduceActive,
      isDailyReset:data2.isDailyReset ? true : false,
      isIpCheck:data2.isIpCheck ? true : false,
      isFirstRecharge:data2.isFirstRecharge ? true : false,
      principalRate:data2.principalRate,
      receiveType:data2.receiveType,
      rewardRate:data2.rewardRate,
      precautionsPc:introduceNotice,
      precautionsApp:introduceNotice,
      promotionsSubs:promotionsSubs,
      status:txt =='set' ? data.status : 6,
      activityRange:checkList &&  checkList.length > 0 ? checkList.join() : '',
      headImgUrlPc:data2.headImgUrlPc,
      headImgUrlApp:data2.headImgUrlApp,
      bateTotal:data2.bateTotal,
      deposit:data2.deposit,
      ...firstObj
    }
    txt =='set' && Object.assign(reqData,{id:data.id});
    firstObj.type==6 && Object.assign(reqData,{"detailImgUrlPc":data2.detailImgUrlPc,"detailImgUrlApp":data2.detailImgUrlApp})
    var reqStr = JSON.stringify(reqData);
    var reqUrl = txt =='set' ? '/promotions/update.mvc' : '/promotions/add.mvc';
    isSubmit && parent.ajaxService.doPost(reqUrl,reqStr,function(res){
      var msg = res.resultMessage;
      if(res.resultCode == 0){
        usercenterPromotios.layerCallback(msg);
      }else{
        layer.msg(msg);
      }
    },'baofoo')
  }
}

usercenterPromotios.getToolbarHtml();
new Promise((resolve,reject)=>{
  resolve(usercenterPromotios.getActiveType());
}).then((res)=>{
  usercenterPromotios.getOpen();
})
layui.use(['laydate', 'table', 'form', 'layer','util','layedit','upload'], function () {
  var laydate = layui.laydate;
  usercenterPromotios.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  var layedit = layui.layedit;
  var upload = layui.upload;
  var options = usercenterPromotios.getOptions(util);
  var isContentWindow = globalAdmin.getUrlParam('blackList');
  if(isContentWindow){
    options.pop();
    options.unshift({type:'radio'});
  }
  usercenterPromotios.table.render({
    elem: '#demo'
    , height: 'full-80'
    , url: '/promotions/list.mvc'
    , toolbar: usercenterPromotios.toolbarHtml
    , defaultToolbar:[]
    , page: true
    , method: 'get'
    , cols: [ options],
    where: {
      // startDate: ''
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode,
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results
      };
      usercenterPromotios.tableData=res.results;
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      usercenterPromotios.tableData=res.data
      usercenterPromotios.pageNumber=cur;
    }
  });


  // 工具栏操作
  usercenterPromotios.table.on("toolbar(demo)",function(res){
    var checkStatus = usercenterPromotios.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    switch (res.event) {
      case '新增':
        layer.open({
          title:'选择您想添加的活动类型及展示模板',
          type: 1,
          skin: 'layui-layer-test',
          area: ['800px', '600px'],
          content: htmlTpl.stepFirstHtml,
          success:function(){
           usercenterPromotios.renderFirstStep(form);
            form.on('submit(formFirst)',function(firstData){
              let data1 = firstData.field;
              var firstObj = {};
              usercenterPromotios.currentActiveType = data1.type;
              firstObj.type = data1.type;
              firstObj.template = data1.template;
              if(data1.type !=1 && data1.type !=2 && data1.type !=3 && data1.type !=4 && data1.type !=6 && data1.type !=8){
                layer.alert('该活动类型目前没有参数设置!');
                return false;
              }
              layer.open({
                title:'设置活动参数',
                type:1,
                skin: 'layui-layer-test',
                area: ['800px', '720px'],
                content: htmlTpl.stepSecondHtml,
                success:function(){
                  firstObj.type ==6 && ($('#special-box,.layui-ip').remove(),$('.layui-pc').after(usercenterPromotios.pcHtml),$('.layui-app').after(usercenterPromotios.appHtml));
                  $(".mask-box").parent().css('overflow-y',"scroll");
                  var selectHtml = usercenterPromotios.getOpenHtml(usercenterPromotios.openList);
                  $('.layui-open-list').append(selectHtml);
                  // 日期控件
                  lay('.layui-date').each(function(){
                    laydate.render({
                      elem: this
                      ,trigger: 'click'
                      ,type: 'datetime'
                      ,range: true
                      ,min:0
                    });
                  });
                  setTimeout(()=>{
                    usercenterPromotios.layeditIndex1 = layedit.build('LAY_demo2',usercenterPromotios.editToolObj);
                    layedit.setContent(usercenterPromotios.layeditIndex1,"");
                  },200)
                  setTimeout(()=>{
                    usercenterPromotios.layeditIndex2 = layedit.build('LAY_demo1',usercenterPromotios.editToolObj);
                    layedit.setContent(usercenterPromotios.layeditIndex2,"");
                  },300)

                  // 首次充值显示与否;
                  if(usercenterPromotios.currentActiveType == 1){
                    $('.layui-first,.layui-thead .layui-th-ratio,.layui-fanwei,.layui-yinkui-box,.layui-yinkui-set,.layui-withdrawal-amount').remove();
                  }else if(usercenterPromotios.currentActiveType ==2 || usercenterPromotios.currentActiveType ==8){
                    $('.layui-pos,.layui-fanwei,.layui-yinkui-box,.layui-yinkui-set').remove();
                    if (usercenterPromotios.currentActiveType ==2) {
                      $('.layui-withdrawal-amount').remove();
                      $('.layui-th-amount').html('当笔充值').css('width',"140px")
                    } else {
                      $(".layui-first-condition,.layui-th-recharge,.layui-th-ratio").remove();
                      $('.layui-th-amount').html('提现次数').css('width',"140px")
                      $(".layui-first input[name='isFirstRecharge']").attr('title', '不限时间')
                    }
                  }else if(usercenterPromotios.currentActiveType ==3 || usercenterPromotios.currentActiveType==4){
                    $('.layui-withdrawal-amount').remove();
                    if(usercenterPromotios.currentActiveType==3){
                      $('.layui-pos,.layui-th-recharge,.layui-yinkui-box,.layui-yinkui-set,.layui-first,.layui-first-condition').remove();
                      $('.layui-th-amount').html('打码额度');
                      $('.layui-thead .layui-th-ratio').html('打码比例');
                    }else{
                      $('.layui-other-box,.layui-other-set,.layui-first,.layui-withdrawal-amount').remove()
                    }
                    let html=``;
                    for(var i in parent.globalAdmin.thirdPlatform){
                      html +=`<input type="checkbox"  title="${parent.globalAdmin.thirdPlatform[i]}" value="${i}" lay-skin="primary" class="fanwei-input" checked>`
                    }
                    $('.fanwei-list').html(html);
                  }
                  // 后期完善
                  // form.val('second',{
                  //   'introductionPc':true,
                  //   'introductionApp':true,
                  //   'precautionsPc':true,
                  //   'precautionsApp':true
                  // })
                  form.render();
                  usercenterPromotios.uploadImg(res.event,upload);
                  // 页面交互操作;
                  form.on('checkbox(firstRecharge)', function(data){
                    usercenterPromotios.isFirstRecharge = data.elem.checked;
                    if(!data.elem.checked){
                      $('.layui-tbody .layui-ratio').attr('disabled',true);
                    }else{
                      $('.layui-tbody .layui-ratio').removeAttr('disabled');
                    }
                  });

                  usercenterPromotios.addHtml(form,selectHtml)

                  // 保存活动
                  form.on('submit(formSecond)',function(secondData){
                    usercenterPromotios.savePromotion(secondData,layer,'新增',layedit,firstObj)
                    return false;
                  })
                }
              })
              return false;
            })
          },
          cancel:function(){
            usercenterPromotios.reloadTable()
          }
        })
      break;
      default:
      break;
    }
  })
  //监听行工具事件
  usercenterPromotios.table.on('tool(demo)', function(obj){
    var data = obj.data;
    if(obj.event === 'lock'){
      var text = data.status== 6 ? '启用' : '禁用';
      layer.confirm(`是否${text}${data.title}?`, function(index){
        var reqData={
          id:data.id,
          status:data.status == 6 ? 5 : 6
        }
        parent.ajaxService.doPost("promotions/updateStatus.mvc",reqData,function(res){
          var msg = res.resultMessage
          if(res.resultCode ==0){
            usercenterPromotios.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(obj.event === 'del'){
      let tips = data.status == 4 ? '恢复' : '删除';
      layer.confirm(`是否${tips}选中?`, function(index){
        parent.ajaxService.doPost("promotions/deleteOrRecovery.mvc",{id:data.id},function(res){
          var msg = res.resultMessage
          if(res.resultCode ==0){
            usercenterPromotios.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(obj.event === 'set' || obj.event =='look'){
      layer.open({
        title:'选择您想修改的展示模板',
        type: 1,
        skin: 'layui-layer-test',
        area: ['800px', '600px'],
        content: htmlTpl.stepFirstHtml,
        success:function(){
          $('.layui-type-box select').attr('disabled', 'disabled');
          usercenterPromotios.type=data.type;
          usercenterPromotios.renderFirstStep(form);
          form.val('first',{
            type:data.type,
            template:data.template
          })
          form.on('submit(formFirst)',function(firstData){
            let data1 = firstData.field;
            var firstObj = {};
            usercenterPromotios.currentActiveType = data1.type;
            firstObj.type = data1.type;
            firstObj.template = data1.template;
            layer.open({
              title:'修改活动参数',
              type:1,
              skin: 'layui-layer-test',
              area: ['800px', '720px'],
              content: htmlTpl.stepSecondHtml,
              success:function(){
                firstObj.type ==6 && ($('#special-box,.layui-ip').remove(),$('.layui-pc').after(usercenterPromotios.pcHtml),$('.layui-app').after(usercenterPromotios.appHtml));
                $(".mask-box").parent().css('overflow-y',"scroll");
                var selectHtml = usercenterPromotios.getOpenHtml(usercenterPromotios.openList);
                usercenterPromotios.isFirstRecharge = data.isFirstRecharge;
                $('.layui-open-list').append(selectHtml);
                lay('.layui-date').each(function(){
                  laydate.render({
                    elem: this
                    ,trigger: 'click'
                    ,type: 'datetime'
                    ,range: true
                    ,min:0
                  });
                });

                setTimeout(()=>{
                  usercenterPromotios.layeditIndex1 = layedit.build('LAY_demo2',usercenterPromotios.editToolObj);
                  layedit.setContent(usercenterPromotios.layeditIndex1,data.introductionPc);
                },200)
                setTimeout(()=>{
                  usercenterPromotios.layeditIndex2 = layedit.build('LAY_demo1',usercenterPromotios.editToolObj);
                  layedit.setContent(usercenterPromotios.layeditIndex2,data.precautionsPc);
                },300)

                // 首次充值显示与否;
                var htmlTpl = ''
                if(usercenterPromotios.currentActiveType == 1){
                  $('.layui-first,.layui-thead .layui-th-ratio,.layui-fanwei,.layui-yinkui-box,.layui-yinkui-set,.layui-withdrawal-amount').remove();
                  data.promotionsSubs.forEach((v,k)=>{
                    htmlTpl+=`<tr data-id="${v.id}" data-promotionId="${v.promotionId}">
                      <td>第${k+1}档</td>
                      <td>
                        <select class="layui-rechargeMethodId" lay-filter="enabled" data-value="${v.rechargeMethodId}">${selectHtml}</select>
                      </td>
                      <td>
                        <input type="text" class="layui-input layui-amounts layui-control" value="${v.amonuts}"/> 
                      </td>
                      <td>
                        <input type="text" class="layui-input layui-number layui-control" value="${v.number}"/> 
                      </td>
                      <td>
                        <input type="number" class="layui-input layui-fixedReward" value="${v.fixedReward}"/> 
                      </td>
                      <td>
                        <div class="layui-btn layui-btn-sm layui-btn-danger layui-del">删除</div>
                      </td>
                    </tr>`
                  })
                  $('.layui-tbody').html(htmlTpl)
                }else if(usercenterPromotios.currentActiveType ==2 || usercenterPromotios.currentActiveType ==8){
                  $('.layui-pos,.layui-fanwei,.layui-yinkui-box,.layui-yinkui-set').remove();
                  if (usercenterPromotios.currentActiveType ==2) {
                    $('.layui-withdrawal-amount').remove();
                    $('.layui-th-amount').html('当笔充值').css('width',"140px")
                  } else {
                    $(".layui-first-condition,.layui-th-recharge,.layui-th-ratio").remove();
                    $('.layui-th-amount').html('提现次数').css('width',"140px")
                    $(".layui-first input[name='isFirstRecharge']").attr('title', '不限时间')
                  }
                  data.promotionsSubs.forEach((v,k)=>{
                    if (usercenterPromotios.currentActiveType ==2) {
                      htmlTpl+=`<tr  data-id="${v.id}" data-promotionId="${v.promotionId}">
                      <td>
                        <select class="layui-rechargeMethodId" lay-filter="enabled" data-value="${v.rechargeMethodId}">${selectHtml}</select>
                      </td>
                      <td>
                        <input type="text" class="layui-input layui-amounts1 layui-control" value="${v.amonuts.split('-')[0]}" style="width:60px;display:inline-block"/> ~ <input type="text" class="layui-input layui-amounts2 layui-control" value="${v.amonuts.split('-')[1]}" style="width:60px;display:inline-block"/>
                      </td>
                      <td>
                        <input type="text" class="layui-input layui-number layui-control" value="${v.number}"/> 
                      </td>
                      <td>
                        <input type="number" class="layui-input layui-fixedReward" value="${v.fixedReward}"/> 
                      </td>
                      <td>
                        <input type="number" class="layui-input layui-ratio" value="${v.ratio}" ${usercenterPromotios.isFirstRecharge ? '' : 'disabled'}/> 
                      </td>
                      <td>
                        <div class="layui-btn layui-btn-sm layui-btn-danger layui-del">删除</div>
                      </td>
                    </tr>`
                    } else {
                      htmlTpl+=`<tr  data-id="${v.id}" data-promotionId="${v.promotionId}">
                      <td>
                        <input type="text" class="layui-input layui-amounts1 layui-control" value="${v.amonuts.split('-')[0]}" style="width:60px;display:inline-block"/> ~ <input type="text" class="layui-input layui-amounts2 layui-control" value="${v.amonuts.split('-')[1]}" style="width:60px;display:inline-block"/>
                      </td>
                      <td>
                        <input type="text" class="layui-input layui-number layui-control" value="${v.number}"/> 
                      </td>
                      <td>
                        <input type="number" class="layui-input layui-fixedReward" value="${v.fixedReward}"/> 
                      </td>
                      <td>
                        <div class="layui-btn layui-btn-sm layui-btn-danger layui-del">删除</div>
                      </td>
                    </tr>`
                    }
                  })
                  $('.layui-tbody').html(htmlTpl)
                }else if(usercenterPromotios.currentActiveType ==3 || usercenterPromotios.currentActiveType ==4){
                  $('.layui-withdrawal-amount').remove();
                  if(usercenterPromotios.currentActiveType==3){
                    $('.layui-pos,.layui-th-recharge,.layui-yinkui-box,.layui-yinkui-set,.layui-first,.layui-first-condition').remove();
                    $('.layui-th-amount').html('打码额度');
                    $('.layui-thead .layui-th-ratio').html('打码比例');
                    data.promotionsSubs.forEach((v,k)=>{
                      htmlTpl+=`<tr  data-id="${v.id}" data-promotionId="${v.promotionId}">
                        <td>
                          <input type="text" class="layui-input layui-amounts layui-control" value="${v.amonuts}" />
                        </td>
                        <td>
                          <input type="text" class="layui-input layui-number layui-control" value="${v.number}"/> 
                        </td>
                        <td>
                          <input type="number" class="layui-input layui-fixedReward" value="${v.fixedReward}"/> 
                        </td>
                        <td>
                          <input type="number" class="layui-input layui-ratio" value="${v.ratio}" ${usercenterPromotios.isFirstRecharge ? '' : 'disabled'}/> 
                        </td>
                        <td>
                          <div class="layui-btn layui-btn-sm layui-btn-danger layui-del">删除</div>
                        </td>
                      </tr>`
                    })
                    $('.layui-tbody').html(htmlTpl)
                  }else{
                    $('.layui-other-box,.layui-other-set,.layui-first,.layui-withdrawal-amount').remove();
                    var tempObj={
                      '1':{'html':''},
                      '2':{'html':''}
                    }
                    var htmlTplYinli='';
                    var htmlTplKuisun='';
                    data.promotionsSubs.forEach((v,k)=>{
                      tempObj[v.specialType].html+=`<tr data-type="${v.specialType}" data-id="${v.id}" data-promotionId="${v.promotionId}">
                        <td>
                          <input type="text" class="layui-input layui-amounts layui-control" value="${v.amonuts}" />
                        </td>
                        <td>
                          <input type="number" class="layui-input layui-fixedReward" value="${v.fixedReward}"/> 
                        </td>
                        <td>
                          <input type="text" class="layui-input layui-number layui-control" value="${v.number}"/> 
                        </td>
                        <td>
                          <div class="layui-btn layui-btn-sm layui-btn-danger layui-del">删除</div>
                        </td>
                      </tr>`
                    })
                    $(`.layui-tbody[data-content='1']`).html(tempObj['1'].html);
                    $(`.layui-tbody[data-content='2']`).html(tempObj['2'].html);
                  }
                  let html=``;
                  let promotionThird = parent.globalAdmin.thirdPlatform;

                  for(var i in parent.globalAdmin.thirdPlatform){
                    html +=`<input type="checkbox"  title="${parent.globalAdmin.thirdPlatform[i]}" value="${i}" lay-skin="primary" class="fanwei-input" name="${i}">`
                  }
                  $('.fanwei-list').html(html);
                }

                // 渲染初始数据;
                var objInit={
                  "title": data.title,
                  "sort":data.sort,
                  "isDisplayPc":data.isDisplayPc ? true : false,
                  "isDisplayH5":data.isDisplayH5 ? true : false,
                  "isDisplayIos":data.isDisplayIos ? true : false,
                  "isDisplayAndroid":data.isDisplayAndroid ? true : false,
                  "isDoingDate":data.isDoingDate ? true : false,
                  "showTime": util.toDateString(data.displayBegin,'yyyy-MM-dd HH:mm:ss')+' - '+ util.toDateString(data.displayEnd,'yyyy-MM-dd HH:mm:ss'),
                  "activeTime": util.toDateString(data.doingBegin,'yyyy-MM-dd HH:mm:ss')+' - '+ util.toDateString(data.doingEnd,'yyyy-MM-dd HH:mm:ss'),
                  "memberType":data.memberType,
                  "isMemberType":data.isMemberType ? true : false,
                  "principalRate":data.principalRate,
                  "rewardRate":data.rewardRate,
                  "receiveType":data.receiveType,
                  "isDailyReset": data.isDailyReset ? true : false,
                  "isFirstRecharge": data.isFirstRecharge ? true : false,
                  "isIpCheck": data.isIpCheck ? true : false,
                  "headImgUrlPc":data.headImgUrlPc,
                  "detailImgUrlPc":data.detailImgUrlPc,
                  "headImgUrlApp":data.headImgUrlApp,
                  "detailImgUrlApp":data.detailImgUrlApp,
                  "headImgUrlH5":data.headImgUrlH5,
                  "detailImgUrlH5":data.detailImgUrlH5,
                  "bateTotal":data.bateTotal,
                  "deposit":data.deposit,
                }
                // 标签
                data.lable && data.lable.split('-').forEach(function(v,k){
                  if(v)Object.assign(objInit,{['label'+(k+1)+'']:v.split('&')[0],['labelSelect'+(k+1)+'']:v.split('&')[1]})
                })

                //活动范围
                data.activityRange && data.activityRange.split(',').forEach(function(v,k){
                  if(v)Object.assign(objInit,{[v]:true})
                })

                form.val('second',objInit)
                layui.each($(".layui-rechargeMethodId"), function (index, item) {
                  var elem = $(item);
                  elem.val(elem.data('value'));
                });
                form.render()

                obj.event =='look' && ($('.layui-promotion-box .layui-btn').addClass('layui-btn-disabled'),$('.layui-save-box').remove());
                usercenterPromotios.uploadImg('修改',upload,data);

                // 输入数字控制;
                $(".layui-tbody .layui-control").keyup(function(){
                  var tmptxt=$(this).val();
                  $(this).val(tmptxt.replace(/\D|^0/g,''));
                }).bind("paste",function(){
                  var tmptxt=$(this).val();
                  $(this).val(tmptxt.replace(/\D|^0/g,''));
                }).css("ime-mode", "disabled");

                // 页面交互操作;
                form.on('checkbox(firstRecharge)', function(data){
                  usercenterPromotios.isFirstRecharge = data.elem.checked;
                  if(!data.elem.checked){
                    $('.layui-tbody .layui-ratio').attr('disabled',true);
                  }else{
                    $('.layui-tbody .layui-ratio').removeAttr('disabled');
                  }
                });
                //添加html操作
                usercenterPromotios.addHtml(form,selectHtml)

                // 保存活动
                form.on('submit(formSecond)',function(secondData){
                  usercenterPromotios.savePromotion(secondData,layer,'set',layedit,firstObj,data)
                  return false;
                })
              }
            })
            return false;
          })
        },
        cancel:function(){
          usercenterPromotios.reloadTable()
        }
      })
    }
  })

  usercenterPromotios.table.on('radio(demo)', function(obj){
    if(usercenterPromotios.editIdArr.length !=0){
      usercenterPromotios.editIdArr.pop();
    }
    var data=obj.data;
    usercenterPromotios.editIdArr.push(data);
  });

  // 删除行操作;
  $(document).on('click',".layui-del",function(){
    $(this).parents('tr').remove();
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    var submitData = data.field;
    var status = [];
    for(var i in submitData){
      if(i !='type' && i != 'template'){
        status.push(submitData[i])
      }
    }
    var reqData = {
      type:submitData.type,
      template:submitData.template,
      queryStatus:status.join()
    }
    usercenterPromotios.table.reload('demo',{
        where:reqData,
        page:{
            curr:1
        }
    })
    return false;
  });
  //监听单元格编辑
  usercenterPromotios.table.on('edit(demo)', function(obj){
    var value = obj.value
    ,data = obj.data
    ,field = obj.field;
    var reqData={
      id:data.id,
      sort:value,
      title:data.title
    }
    if(!/^[0-9]*$/.test(value)){
      layer.alert('请填写正确的数字');
      return
    }
    parent.ajaxService.doPost('/promotions/updateSort.mvc',reqData,function(res){
      var msg = res.resultMessage;
      if(res.resultCode==0){
        usercenterPromotios.layerCallback(msg);
      }else{
        layer.msg(msg)
      }
    })
  });
});



