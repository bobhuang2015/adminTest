
var rechargeOnline = {
  table:null,
  toolbarHtml:'',
  hasManual:false,
  pageNumber:1,
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if(i=='手动补单')this.hasManual=true;
      })
    }
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('order',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  shopObj:{},
  getShopList:function(){
    var _this = this;
    parent.ajaxService.doGet("/userLevel/getEnableBaofoo.mvc",null,function(res){
      if(res.resultCode==0){
        var data = res.results[0];
        var html='';
        data.forEach(function(v,k){
          html+=`<option value="${v.code}">${v.name}</option>`;
          Object.assign(_this.shopObj,{[v.code]:v.name});
        })
        $("#account").append(html);
      }
    })
  },
  getStatus:function(status){
    var obj={
      '1':'充值中',
      '2':'支付成功',
      '3':'支付失败',
      '4':'充值成功',
      '5':'充值失败'
    }
    return obj[status]
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  formatDate(util,date){
    return util.toDateString(date,"yyyy-MM-dd HH:mm:ss")
  },
  getBankType(form){
    parent.ajaxService.doGet('/platformBank/platformBankList.mvc',null,function(res){
      if(res.resultCode == 0){
        var data = res.results;
        var html='';
        data.forEach(function(v,k){
          html+=`<option value="${v.id}">${v.payName}</option>`
        })
        $("#bankType").append(html);
        form.render('select')
      }
    })
  },
  getOptions:function(util,type){
    var arr=[];
    if(type=='order'){
      arr=[
        { title: '操作', width: 100,toolbar: '#barDemo'}
        , { field: 'orderNumber', title: '订单号', width: 200, sort: true}
        , { field: 'username', title: '用户账号', width: 120,sort: true}
        , { field: 'merchantType', title: '商户类型', width: 150, sort: true,templet:function(d){return rechargeOnline.shopObj[d.merchantType] ? rechargeOnline.shopObj[d.merchantType] : d.merchantType}}
        , { field: 'merchantid', title: '收款商户ID', width: 140, sort: true}
        , { field: 'ordermoney', title: '订单金额', width: 120, sort: true,templet:function(d){return d.ordermoney.toFixed(3)}}
        , { field: 'factmoney', title: '实际充值金额', width: 140, sort: true,templet:function(d){return d.factmoney.toFixed(3)}}
        , { title: '订单状态', width: 140, sort: true,templet:function(d){return rechargeOnline.getStatus(d.result)}}
        , { field: 'tradedate', title: '交易时间', width: 180, sort: true,templet:function(d){return rechargeOnline.formatDate(util,d.tradedate)}}
        , { field: 'operatordt', title: '操作时间', width: 180, sort: true,templet:function(d){return d.operatordt ? rechargeOnline.formatDate(util,d.operatordt) : '' }}
        , { field: 'operator', title: '操作者', sort: true}
      ]
    }else if(type=='transfer'){
      arr=[
        { field: 'sourcemerchantid', title: '源商户ID', width: 120, sort: true}
        , { field: 'targetbankname', title:'目标银行名称', width: 180, sort: true}
        , { field:'targetaccountno',title: '目标银行卡号', width: 240, sort: true}
        , { field: 'money', title: '金额', width: 210, sort: true,templet:function(d){return d.money.toFixed(3)}}
        , { field: 'fee', title: '手续费', width: 100, sort: true,templet:function(d){return d.fee.toFixed(3)}}
        , { field: 'optdt', title: '操作时间', width: 180, sort: true,templet:function(d){return rechargeOnline.formatDate(util,d.optdt)}}
        , { field: 'operator', title: '操作者', sort: true}
      ]
    }else{
      arr=[
        { field: 'bankid',title: '商户ID', width: 240, sort: true}
        , { field: 'rechargetimes', title: '充值次数', width: 100, sort: true}
        , { field: 'rechargemoney', title: '充值总额', width: 120, sort: true,templet:function(d){return d.rechargemoney.toFixed(3)}}
        , { field: 'rechargefee', title: '充值手续费', width: 160, sort: true,templet:function(d){return d.rechargefee.toFixed(3)}}
        , { field: 'transfertimes', title: '转移次数', width: 100, sort: true}
        , { field: 'transfermoney', title: '转移金额', width: 120, sort: true,templet:function(d){return d.transfermoney.toFixed(3)}}
        , { field: 'transferfee', title: '转移手续费', sort: true,templet:function(d){return d.transferfee.toFixed(3)}}
      ]
    }
    return arr
  },
  renderTotal(res){
    if (res.data && res.data.length > 0 && res.total){
      var id=$('.layui-this').attr('data-id');
      var totalData = res.total;
      var tr = '<tr class="table-total"><td colspan="50">总量合计：<span>订单总额： '+(id==1 ? totalData.ordermoney : totalData.rechargeMoneySum)+'</span>'+
            '<span>实际充值金额： '+(id==1 ? totalData.factmoney :totalData.rechargeFeeSum)+'</span></td></tr>'
      $('.layui-table-body table').append(tr);
    }
  }
}

rechargeOnline.getToolbarHtml();
rechargeOnline.getShopList();
layui.use(['laydate', 'table', 'form', 'layer','util','element'], function () {
  var laydate = layui.laydate;
  rechargeOnline.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;

  var element = layui.element;
  var isTransfer=0;
  var isReport = 0;
  rechargeOnline.table.render(getOptions('order','/baoFooPay/search.mvc'))

  element.on('tab(table_box)', function (data) {
    $(document).resize()
    if(data.index==1 && !isReport){
      isReport=!0;
      rechargeOnline.table.render(getOptions('report','/platformBankDailyStatistics/statistics.mvc'));
      rechargeOnline.getBankType(form);
      submitTable('report');
    }
  });

  function getOptions(id,reqUrl){
    var obj={
      elem: `#${id}`
      , height: 'full-160'
      , url: `${reqUrl}` 
      , page: true
      , method: 'get'
      , cols: [rechargeOnline.getOptions(util,id)],
      where: {
        t:(new Date()).valueOf()
      }
      , parseData: function (res) {
        var result = {
          "code": res.resultCode, 
          "msg": res.resultMessage,
          "count": res.meta.totalRecord,
          "data": Array.isArray(res.results[0]) ? res.results[0] : res.results,
          "total": res.results.length==2 && res.results[1]
        };
        return result
      },
      response: {
        statusCode: '0'
      },
      done: function (res, cur, count) {
        if(id=='order')rechargeOnline.pageNumber=cur;
        rechargeOnline.renderTotal(res);
      }
    }
    if(id=='report'){
      Object.assign(obj.where,{'bankType':2});
    }
    return obj
  }
  
  setTimeout(()=>{
    form.render("select",'orderForm');
  },500)
  //监听行工具事件
  rechargeOnline.table.on('tool(order)', function(obj){
    var data = obj.data;
    if(obj.event === 'manual'){
      layer.confirm(`是否补单?`, function(index){
        var reqData={
          baoFooPayId:data.id
        }
        parent.ajaxService.doPost("/moneyInRecord/recharge.mvc",reqData,function(res){
          if(res.resultCode == 0){
            rechargeOnline.layerCallback(res.resultMessage);
          }else{
            layer.msg(res.resultMessage);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }
  })

  submitTable('order');

  function submitTable(id){
    globalAdmin.renderRechargeDate(laydate,util,id);
    form.on('submit(form'+id+')', function (data) {
      rechargeOnline.table.reload(`${id}`,{
          where:data.field,
          page:{
              curr:1  
          },
          done:function(res, cur, count){
             rechargeOnline.renderTotal(res);
          }
      })
      return false;
    });
  }
});



