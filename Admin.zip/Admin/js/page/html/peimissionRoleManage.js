var peimissionRoleManage = {
    table: null,
    toolbarHtml: '',
    toolbarHtml: '',
    editHtml: '',
    pageNumber:1,
    globalAdmin: JSON.parse(localStorage.getItem('globalAdmin')),
    getToolbarHtml() {
        var action = window.name || parent.globalAdmin.getUrlParam('code');
        var permision = this.globalAdmin.menuObj[action].permision;
        var otherHtml = "";
        var editHtml = "";
        if (permision) {
            permision.forEach((v, k) => {
                var i = v.menuName;
                if (i != '新增') {
                    editHtml += '<a class="layui-btn layui-btn-operator layui-btn-normal ' + (i == '删除' ? 'layui-btn-danger' : '') + '" lay-event="' + i + '">' + i + '</a>'
                } else {
                    otherHtml = '<button class="layui-btn" lay-event="' + i + '">' + i + '</button>'
                }
            })
        }
        this.toolbarHtml = `<div>${otherHtml}</div>`;
        this.editHtml = `<div>${editHtml}</div>`;
    },
    reloadTable: function () {
        var _this =this;
        this.table.reload('demo', {
            // where:data.field,
            page: {
                curr: _this.pageNumber
            }
        })
    },
    getRoleType(type) {
        var obj = {
            '1': '用户角色',
            '2': '管理员角色',
        }
        return obj[type]
    },
    layerCallback(msg) {
        var _this = this;
        layer.alert(msg, function () {
            layer.closeAll();
            _this.reloadTable();
        })
    },
    getOptions: function (util) {
        var _this = this;
        var arr = [
            {
                field: 'roletype', title: '角色类型', width: 140, sort: true, templet: function (d) {
                    return _this.getRoleType(d.roletype)
                }
            }
            , {field: 'rolename', title: '角色名称', width: 180, sort: true}
            , {field: 'operator', title: '创建者', width: 180, sort: true}
            , {
                title: '创建时间', sort: true, width: 220, templet: function (d) {
                    return util.toDateString(d.createtime, "yyyy-MM-dd HH:mm:ss")
                }
            }
            , {
                title: '操作', templet: function (d) {
                    return peimissionRoleManage.editHtml
                }
            }
        ]
        return arr
    },
    editIdArr: [],
    tableData: []
}

peimissionRoleManage.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer', 'util'], function () {
    var laydate = layui.laydate;
    peimissionRoleManage.table = layui.table;
    var form = layui.form;
    var layer = layui.layer;
    var util = layui.util;

    peimissionRoleManage.table.render({
        elem: '#demo'
        , height: `full-60`
        , url: '/role/list.mvc'
        , toolbar: peimissionRoleManage.toolbarHtml
        , defaultToolbar: []
        , page: true
        , method: 'get'
        , cols: [peimissionRoleManage.getOptions(util)],
        where: {
            // startDate: ''
        }
        , parseData: function (res) {
            var result = {
                "code": res.resultCode,
                "msg": res.resultMessage,
                "count": res.meta.totalRecord,
                "data": res.results
            };
            peimissionRoleManage.tableData = res.results;
            return result
        },
        response: {
            statusCode: '0'
        },
        done: function (res, cur, count) {
            peimissionRoleManage.pageNumber=cur;
        }
    });
    parent.globalAdmin.checkboxEdit(peimissionRoleManage, window.name)

    // 工具栏操作
    peimissionRoleManage.table.on("toolbar(demo)", function (res) {
        var checkStatus = peimissionRoleManage.table.checkStatus(res.config.id);
        var data = checkStatus.data;
        switch (res.event) {
            case '新增':
                layer.open({
                    title: res.event,
                    type: 1,
                    skin: 'layui-layer-test',
                    area: ['600px', '300px'],
                    content: htmlTpl.addHtml,
                    success: function () {
                        var obj = {
                            "roletype": '1',
                            "rolename": ''
                        }
                        form.val('add', obj);
                        form.on('submit(formAdd)', function (submitData) {
                            var reqData = submitData.field;
                            parent.ajaxService.doPost('/role/add.mvc', reqData, function (res) {
                                var msg = res.resultMessage;
                                if (res.resultCode == 0) {
                                    peimissionRoleManage.layerCallback(msg);
                                } else {
                                    layer.msg(msg)
                                }
                            })
                            return false;
                        })
                    }
                })
                break;
            default:
                break;
        }
    })
    //监听行工具事件
    peimissionRoleManage.table.on('tool(demo)', function (obj) {
        var data = obj.data;
        var event = obj.event;
        if (event === '修改') {
            layer.open({
                title: `修改-<span class='red'>${data.rolename}</span>`,
                type: 1,
                skin: 'layui-layer-test',
                area: ['600px', '240px'],
                content: htmlTpl.setHtml,
                success: function () {
                    var obj = {
                        "id": data.id,
                        "rolename": data.rolename,
                        "roletype": data.roletype
                    }
                    form.val('set', obj)
                    form.on('submit(formSet)', function (submitData) {
                        var reqData = submitData.field;
                        parent.ajaxService.doPost('/role/update.mvc', reqData, function (res) {
                            var msg = res.resultMessage;
                            if (res.resultCode == 0) {
                                peimissionRoleManage.layerCallback(msg);
                            } else {
                                layer.msg(msg)
                            }
                        })
                        return false;
                    })
                }
            })
        } else if (event === '菜单权限') {
            var index = layer.load(2);
            parent.ajaxService.doPost('/menu/getRoleRootMenu.mvc', {
                roleId: data.id,
                roleType: data.roletype
            }, function (res) {
                var html = roleMenu(res.data)

                layer.open({
                    type: 1,
                    title: '菜单权限',
                    shadeClose: true,
                    shade: 0.8,
                    area: ['600px', '700px'],
                    content: html,
                    btn: ['保存', '取消'],
                    success: function () {
                        layer.close(index);
                        $('.role-floor dt span').click(function () {
                            $(this).parent().siblings().toggle()
                            var display = $(this).parent().siblings('dl').css('display')
                            if (display === 'none') {
                                $(this).siblings('b').removeClass().addClass("menu-folder-close")
                            } else {
                                $(this).siblings('b').removeClass().addClass("menu-folder-open")
                            }
                        })
                        $('.role-floor dt b').click(function () {
                            $(this).parent().siblings().toggle()
                            var display = $(this).parent().siblings('dl').css('display')
                            if (display === 'none') {
                                $(this).removeClass().addClass("menu-folder-close")
                            } else {
                                $(this).removeClass().addClass("menu-folder-open")
                            }
                        })

                        $('.role-pm-main i').click(function () {
                            var floor = Number($(this).attr('floor')) || 1
                            var iClassName = this.className
                            if (!iClassName) {
                                $(this).addClass('menu-checkbox')
                                $(this).parent().siblings('dl').find('i').addClass('menu-checkbox')
                                for (var i = (floor-1); i >= 1; i--) {
                                    $(this).parents('.role-floor-'+i).children('dt').children('i').addClass('menu-checkbox')
                                }
                            } else {
                                $(this).removeClass()
                                $(this).parent().siblings('dl').find('i').removeClass()
                                for (var i = (floor-1); i >= 1; i--) {
                                   var iLen = $(this).parents('.role-floor-'+i).children('dl').find('.menu-checkbox')
                                    if (iLen.length > 0){
                                        break
                                    }
                                    $(this).parents('.role-floor-'+i).children('dt').children('i').removeClass('menu-checkbox')
                                }
                            }
                        })
                    },
                    btn1: function (btn1) {
                        var arr = []
                        $('.menu-checkbox').each(function (key,val) {
                            var id = val.id
                            arr.push(id)
                        })
                        var ids = arr.join(',')
                        parent.ajaxService.doPost('/roleMenu/saveRoleMenu.mvc',{menuIds:ids,roleId:data.id},function (res) {
                            layer.msg(res.resultMessage);
                        })
                        layer.close(btn1);
                    },
                    btn2: function (btn2) {
                        layer.close(btn2);
                    }
                });

            })

        } else if (event === '删除') {
            layer.confirm('是否删除该角色?', function (index) {
                    var reqData = {
                        roleId: data.id
                    }
                    parent.ajaxService.doPost('/role/delete.mvc', reqData, function (res) {
                        var msg = res.resultMessage;
                        if (res.resultCode == 0) {
                            peimissionRoleManage.layerCallback(msg);
                        } else {
                            layer.msg(msg);
                        }
                    })
                }, function (index) {
                    layer.close(index)
                }
            )
        }
    })
});


function roleMenu(data) {
    return '<div class="role-pm-main">' + roleMenuHtml(data, 'remove') + '</div>'
}

function roleMenuHtml(data, type) {
    var ul = ''
    data.forEach(function (item) {
        var li = '<dl  class="role-floor role-floor-' + item.floor + '"><dt>'

        if (item.childrens && item.childrens.length > 0) {
            li += '<b class="'+(String(item.floor) === '1'?'menu-folder-open':'menu-folder-close')+'"></b>'
        } else {
            // li += '<b class="menu-folder-close">-</b>'
        }
        li += '<i id="' + item.id + '" class="' + (String(item.isShow) === '1' ? 'menu-checkbox' : '') + '" floor="' + item.floor + '"></i>'
        li += '<span>' + item.menuName + '</span>'
        li += '</dt>'
        if (item.childrens) {
            li += roleMenuHtml(item.childrens, type)
        }
        li += '</dl>'
        ul += li
    })
    return ul
}




