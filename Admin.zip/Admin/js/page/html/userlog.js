
var userLog = {
  table:null,
  pageNumber:1,
  getOptions:function(util){
    var arr=[
      { field: 'username', title: '用户账号', width: 160, sort: true}
      , { field: 'loginip', title: '登录IP', width: 180,sort: true}
      , { field: 'address', title: '所在地区', width: 120,sort: true}
      , { field: 'loginadds', title: '登录网址', width: 220, sort: true}
      , { field: 'logintime', title: '登录时间', width: 180, sort: true,templet:function(d){return util.toDateString(d.logintime, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'machinecode', title: '终端', width: 120, sort: true}
      , { field: 'browsername', title: '设备ID', sort: true,width:260}
      , { field:'browserversion',title:'app/浏览器版本'}
    ]
    return arr
  }
}

layui.use(['laydate', 'table', 'form', 'layer','util','element'], function () {
  var laydate = layui.laydate;
  userLog.table = layui.table;
  var form = layui.form;
  var util = layui.util;
  var element = layui.element;
  var topHeight = ~~($(".layui-row").height()+40);
  
  var isCheck=0;
  userLog.table.render(getOptions('login'))
  
  element.on('tab(tab_box)', function (data) {
    $(document).resize()
    
    if( data.index == 1 && !isCheck){
      isCheck=!0;
      userLog.table.render(getOptions('check'));
      submitTable('check');
    }
  });

  function getOptions(id){
    var obj={
      elem: `#${id}`
      , height: `full-140`
      , url: `/userLoginLog/queryList.mvc` 
      , page: true
      , method: 'get'
      , cols: [userLog.getOptions(util)],
      where: {
        isCheck:id=='login' ? 0 : 1
      }
      , parseData: function (res) {
        var result = {
          "code": res.resultCode, 
          "msg": res.resultMessage,
          "count": res.meta.totalRecord,
          "data": res.results
        };
        return result
      },
      response: {
        statusCode: '0'
      },
      done: function (res, cur, count) {
        userLog.pageNumber = cur;
      }
    }
    return obj
  }

  submitTable('login');
  
  
  function submitTable(id){
    laydate.render({
      elem: `#start${id}`
      ,value:  util.toDateString(new Date(),'yyyy-MM-dd')
      ,btns: ['clear', 'confirm']  
    });
    laydate.render({
      elem: `#end${id}`
      ,value:  util.toDateString(new Date().getTime()+1000*60*60*24,'yyyy-MM-dd')
      ,btns: ['clear', 'confirm'] 
    });
    form.on('submit(form'+id+')', function (data) {
      userLog.table.reload(`${id}`,{
          where:data.field,
          page:{
              curr:1  
          }
      })
      return false;
    });
  }
});



