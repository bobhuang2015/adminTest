
var platformsetTransferuser = {
  checkUser(name){
    parent.ajaxService.doPost("/systemDepositAndWithdraw/findUser.mvc",{userName:name},function(res){
      if(res.resultCode!=0){
        layer.msg('没有该操作用户!')
      }
    })
  }
}

layui.use(['form', 'layer'], function () {
  var form = layui.form;
  var layer = layui.layer;

  $("#subUser").change(function(){
    var value = $(this).val();
    platformsetTransferuser.checkUser(value);
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    var reqData = data.field;
    parent.ajaxService.doPost("/systemDepositAndWithdraw/findUser.mvc",{userName:reqData.parentUsername},function(res){
      if(res.resultCode == 0){
        parent.ajaxService.doPost("/userInfo/userMoveLevel.mvc",reqData,function(res){
          if(res.resultCode!=0){
            layer.msg(res.resultMessage)
          }else{
            layer.alert('转移成功',function(){
              location.reload(true);
            })
          }
        })
      }else{
        layer.msg('没有该转移方用户!')
        $("#parentUser").focus();
      }
    })
    return false;
  });
})



