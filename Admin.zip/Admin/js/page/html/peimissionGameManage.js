
var peimissionGameManage = {
  table:null,
  toolbarHtml:'',
  hasCT:false,
  hasKG:false,
  hasRedlimit:false,
  hasSort:false,
  hasWt:false,
  hasDes:false,
  hasSource:false,
  editRowObj:{},
  notWTList:['上海时时乐','福彩3D','排列三'],
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  pageNumber:1,
  getToolbarHtml(){ 
    var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var obj={
      '关闭/开启彩种':'hasCT',
      '关闭/开启传统彩种':'hasKG',
      '修改限红':'hasRedlimit',
      '设置排序':'hasSort',
      '关闭/开启微投':'hasWt',
      '关闭/开启官方说明':'hasDes',
      '关闭/开启号源校验':'hasSource'
    }
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        if( i!= '添加彩票限制' && i !='添加传统彩票限制'){
          this[obj[i]]=true;
        }else{
         otherHtml += '<button class="layui-btn" lay-event="'+i+'">'+i+'</button>'
        }
      })
    }
    this.toolbarHtml =`<div>${otherHtml}</div>`;
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var arr=[
      {title:'选择',type:'radio'}
      , { field: 'name', title: '游戏类型', width: 100, sort: true}
      , { field: 'maxwinmoney', title: '限红金额', width: 100, sort: true}
      , { field: 'kjmaxwinmoney', title: 'KG限红金额', width: 120, sort: true}
      , { title: '状态', width: 80, sort: true,templet:function(d){return d.enabled ? '开启' : '关闭'}}
      , { title: 'KG状态', width: 100, sort: true,templet:function(d){return d.startKj ? '开启' : '关闭'}}
      , { title: 'wt状态', width: 100, sort: true,templet:function(d){return d.startWt ? '开启' : '关闭'}}
      , { title: '说明状态', width: 110, sort: true,templet:function(d){return d.startExplain ? '开启' : '关闭'}}
      , { title: '号源状态', width: 110, sort: true,templet:function(d){return d.startSign ? '开启' : '关闭'}}
      , { field: 'hotSort', title: '热门排序', width: 110, sort: true}
      , { field: 'recommendType', title: '彩种推荐', width: 110, sort: true}
      , { title: '操作', toolbar:'#barDemo',minWidth:290}
    ]
    return arr
  }
}

peimissionGameManage.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  peimissionGameManage.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  peimissionGameManage.table.render({
    elem: '#demo'
    , height: `full-40`
    , url: '/gameType/list.mvc'
    , toolbar: peimissionGameManage.toolbarHtml
    , defaultToolbar:[]
    , page: true
    , method: 'get'
    , cols: [peimissionGameManage.getOptions(util)],
    where: {
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      peimissionGameManage.pageNumber = cur;

    }
  });
  
  function editLimit(res,data,type){
    var inputObj={
      "limitlist":0,
      "limitnum":0
    }
    var playtypes=[];//玩法类型;
    var bettypes = [];//子玩法类型;
    var limitList = [];//接口返回的限制数据;
    var reqLimitsArr = [];//用户输入的限制数据;
    
    var inputSubmitObj={};//保存在内存中的输入数据(包含接口返回的原始数据);
    var currentInputStr=''//当前编辑的属性，用于inputObj,格式值data-playtype,data-id;

    var index=0;
    playtypes = res.results[0].playtypes;
    bettypes = res.results[0].bettypes;
    limitList = res.results[0].limits;
    var selectHtml = '';
    playtypes.forEach((v,k)=>{
      selectHtml+=`<option value="${v.id}">${v.name}</option>`
    })
    $(".limit-list").html(selectHtml);
    form.render('select','limit');
    renderSubPlayHtml(playtypes[0].id);
    
    if(limitList.length >0){
      let typeArr =limitList[0].type.split(',');
      let targetStr = `${bettypes[0].playtype},${bettypes[0].id}`
      limitList.forEach((v,k)=>{
        //获得原始的返回限制数据
        inputSubmitObj[v.type]={limitlist:v.limitlist,limitnum:v.limitnum};

        if(v.type == targetStr){
          inputObj.limitlist = limitList[k].limitlist;
          inputObj.limitnum = limitList[k].limitnum;
        }
      })
    }
    form.val("limit",inputObj);
    inputChange(bettypes[0].playtype,bettypes[0].id);
    currentInputStr = `${bettypes[0].playtype},${bettypes[0].id}`;
    
    if(!inputSubmitObj[currentInputStr])inputSubmitObj[currentInputStr]={};

    function renderSubPlayHtml(id,is){
      var playHtml = '';
      bettypes.forEach((v,k)=>{
        if(v.playtype == id){
          playHtml +='<div data-id="'+v.id+'" data-play="'+v.playtype+'" class="layui-play layui-btn layui-btn-normal layui-btn-operator" style="margin:0 10px 10px 0;line-height:38px;">'+v.name+'</div>'
        }
      })
      $("#layui-subType").html(playHtml);
      $("#layui-subType .layui-play:eq(0)").addClass('layui-btn-warm')
      
      var play = $('.layui-play:eq(0)').attr('data-play');
      var id= $('.layui-play:eq(0)').attr('data-id');
      var clickStr = `${play},${id}`
      currentInputStr = clickStr
      // 有重复的地方，后期优化
      if(!inputSubmitObj[clickStr])inputSubmitObj[clickStr]={};
      if(is){
        inputObj={
          "limitlist":0,
          "limitnum":0
        }
        for(var i in inputSubmitObj){
          if(i == clickStr){
            inputObj.limitlist=inputSubmitObj[i].limitlist;
            inputObj.limitnum=inputSubmitObj[i].limitnum;
          }
        }
        form.val('limit',inputObj)
        inputChange();
      }

      $("#layui-subType").find('.layui-play').on("click",function(){
        $(this).addClass('layui-btn-warm').siblings().removeClass('layui-btn-warm');
        var play = $(this).attr('data-play');
        var id= $(this).attr('data-id');
        var clickStr = `${play},${id}`
        currentInputStr = clickStr;
        if(!inputSubmitObj[clickStr])inputSubmitObj[clickStr]={};
        inputObj={
          "limitlist":0,
          "limitnum":0
        }
        for(var i in inputSubmitObj){
          if(i == clickStr){
            inputObj.limitlist=inputSubmitObj[i].limitlist;
            inputObj.limitnum=inputSubmitObj[i].limitnum;
          }
        }
        form.val('limit',inputObj)
        inputChange();
      })
    }
    
    function inputChange(){
      $(".money-min").on('blur',function(){
        Object.assign(inputSubmitObj[currentInputStr],{limitlist:+$(".money-min").val()})
      })
      $(".money-max").on('blur',function(){
        Object.assign(inputSubmitObj[currentInputStr],{limitnum:+$(".money-max").val()})

      })
    }
    // 下拉框选择事件
    form.on('select(limit)', function(selectData){
      renderSubPlayHtml(selectData.value,!0)
    })
    //提交数据处理
    form.on('submit(limit)',function(submitData){
      var inputArr = [];//输入的限制数据数组;
      for(let i in inputSubmitObj){
        var obj={};
        obj.iskg=type;
        obj.gametype = data[0].id;
        obj.limitamount = 0;
        obj.type=i;
        obj.limitnum = inputSubmitObj[i].limitnum;
        obj.limitlist = inputSubmitObj[i].limitlist;
        inputArr.push(obj);
      }
      var reqStr = JSON.stringify(inputArr)
      var reqData = {
        id:data[0].id,
        showtype:type,
        limits:reqStr
      }
      parent.ajaxService.doPost("/gameType/updateLimit.mvc",reqData,function(res){
        var msg = res.resultMessage;
        if(res.resultCode==0){
          if(res.resultCode==0){
            peimissionGameManage.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        }
      })
      return false;
    })
  }

  // 工具栏操作
  peimissionGameManage.table.on("toolbar(demo)",function(res){
    var checkStatus = peimissionGameManage.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    if(data.length==0){
      layer.msg('请选择一项进行修改');
      return
    };
    switch (res.event) {
      case '添加彩票限制':
        if(!data[0].enabled)return;
        parent.ajaxService.doGet("/gameType/getLotterylimit.mvc",{id:data[0].id,showtype:0},function(res){
          if(res.resultCode==0 && res.results[0].playtypes.length > 0 && res.results[0].bettypes.length > 0){
            layer.open({
              title:res.event,
              type: 1,
              skin: 'layui-layer-test',
              area: ['700px', '400px'],
              content: htmlTpl.limitHtml,
              success:function(){
                editLimit(res,data,0)
              }
            })
          }else{
            layer.alert('该彩种没有经典彩票限制!')
          }
        })
      break;
      case '添加传统彩票限制':
        if(!data[0].startKj)return;
        parent.ajaxService.doGet("/gameType/getLotterylimit.mvc",{id:data[0].id,showtype:1},function(res){
          if(res.resultCode==0 && res.results[0].playtypes.length > 0){
            layer.open({
              title:res.event,
              type: 1,
              skin: 'layui-layer-test',
              area: ['700px', '400px'],
              content: htmlTpl.limitHtml,
              success:function(){
                if(!res.results[0].bettypes){
                  var inputObj={
                    "limitlist":0,
                    "limitnum":0
                  }
                  var playtypes=[];
                  var limitList = [];

                  var reqLimitsArr = [];
                  var index=0;

                  var typeObj = {};//类型对象包括limitlist,limitnum属性;
                  var type = 0;//当前选择类型;
                  $('.layui-subType').remove();

                  playtypes = res.results[0].playtypes;
                  limitList = res.results[0].limits;

                  var selectHtml = '';
                  playtypes.forEach((v,k)=>{
                    selectHtml+=`<option value="${v.id}">${v.name}</option>`
                  })
                  $(".limit-list").html(selectHtml);
                  type = playtypes[0].id;

                  if(limitList.length > 0 && limitList[0].type == playtypes[0].id){
                    inputObj.limitlist = limitList[0].limitlist;
                    inputObj.limitnum = limitList[0].limitnum;
                    typeObj[type] = {limitlist:limitList[0].limitlist,limitnum:limitList[0].limitnum};
                  }else{
                    typeObj[type]={}
                  }

                  form.render('select','limit');
                  form.val("limit",inputObj);
  
                  inputChange();
                  function inputChange(){
                    $(".money-min").on('blur',function(){
                      Object.assign(typeObj[type],{limitlist:+$(".money-min").val()})
                    })
                    $(".money-max").on('blur',function(){
                      Object.assign(typeObj[type],{limitnum:+$(".money-max").val()});
                    })
                  }
                  form.on('select(limit)', function(selectData){
                    type = selectData.value;
                    var hasLimitIndex = limitList.findIndex((v)=> v.type == selectData.value)
                    inputObj.limitlist = typeObj[type] && JSON.stringify(typeObj[type]) !='{}' ? typeObj[type].limitlist || '' : hasLimitIndex !=-1 ? limitList[hasLimitIndex].limitlist : '';
                    inputObj.limitnum = typeObj[type] && JSON.stringify(typeObj[type]) !='{}' ? typeObj[type].limitnum || '' : hasLimitIndex !=-1 ? limitList[hasLimitIndex].limitnum :  '';
                    form.val("limit",inputObj);
                    if(!typeObj[type])typeObj[type]={};
                    if( hasLimitIndex !=-1)(typeObj[type].limitlist =limitList[hasLimitIndex].limitlist,typeObj[type].limitnum =limitList[hasLimitIndex].limitnum) 
                    inputChange();
                  })
  
                  form.on('submit(limit)',function(submitData){
                    var reqArr = [];
                    var inputArr = [];//输入的限制数据数组;
                    for(let i in typeObj){
                      var obj={};
                      obj.iskg=1;
                      obj.gametype = data[0].id;
                      obj.limitamount = 0;
                      obj.type=i;
                      obj.limitnum = typeObj[i].limitnum;
                      obj.limitlist = typeObj[i].limitlist;
                      inputArr.push(obj);
                    }
                    // 比较一些相同的，并将输入的覆盖原始的数据;
                    if(limitList.length > 0){
                      limitList.forEach((v,k,arr)=>{
                        inputArr.forEach((iv,ik)=>{
                          if(v.type == iv.type){
                            arr[k]='';
                          }
                        })
                      })
                    }
                    
                    var concatArr = inputArr.concat(limitList);
                    reqArr = concatArr.filter(function(v,k){return v !=''});
                    
                    if(inputArr.length==0)reqArr = limitList;
                    var reqStr = JSON.stringify(reqArr);
                    var reqData = {
                      id:data[0].id,
                      showtype:1,
                      limits:reqStr
                    }
                    parent.ajaxService.doPost("/gameType/updateLimit.mvc",reqData,function(res){
                      if(res.resultCode==0){
                        peimissionGameManage.layerCallback(res.resultMessage);
                      }else{
                        layer.msg(res.resultMessage);
                      }
                    })
                    return false;
                  })
                }else{
                  editLimit(res,data,1)
                }
              }
                
            })
          }else{
            layer.alert('该彩种没有传统彩票限制!')
          }
        })
      break;
      default:
        break;
    }
  })
  //单选按钮事件;
  peimissionGameManage.table.on('row(demo)',function(obj){
    peimissionGameManage.editRowObj = obj.data;
  })

  //监听行工具事件
  peimissionGameManage.table.on('tool(demo)', function(obj){
    var data = obj.data;
    var event = obj.event;
    var txt = '';
    var desTxt ='官方说明';
    var sourceTxt = '号源校验'
    function getTxt(event){
      if(event =='CT'){
        txt = data.enabled ? '关闭' :'开启'
      }else if(event == 'KG'){
        txt = data.startKj ? '关闭' :'开启'
      }else if(event =='WT'){
        txt = data.startWt ? '关闭' :'开启'
      }else if(event =='Des'){
        txt = data.startExplain ? '关闭'+desTxt : '开启'+desTxt
      }else if(event =='Source'){
        txt = data.startSign ? '关闭'+sourceTxt : '开启'+sourceTxt
      }
    }
    if(event === 'CT' || event === 'KG' || event === 'WT' || event === 'Des' || event === 'Source'){
      getTxt(event);
      var tempObj={
        'CT':'/gameType/updateGameType.mvc',
        'KG':'/gameType/updateKjGameType.mvc',
        'WT':'/gameType/updateStartWt.mvc',
        'Des':'/gameType/updateStartExplain.mvc', 
        'Source':'/gameType/updateNumSign.mvc'
      }
      if(event =='WT' && peimissionGameManage.notWTList.includes(data.name)){
        layer.msg('该彩种没有微投模式');
        return;
      }
      layer.confirm(`是否 ${txt} 彩种 <span class="red">${data.name}</span>?`, function(index){
        var reqData={
          id:data.id
        }
        parent.ajaxService.doPost(tempObj[event],reqData,function(res){
          var msg = res.resultMessage
          if(res.resultCode ==0){
            peimissionGameManage.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(event =='redLimit'){
      layer.open({
        title:'修改限红- <span class="red">'+data.name+'</span>',
        type: 1,
        skin: 'layui-layer-test',
        area: ['600px', '300px'],
        content: htmlTpl.redHtml,
        success:function(){
          var obj={
            "maxwinmoney": data.maxwinmoney,
            "kjmaxwinmoney": data.kjmaxwinmoney,
            "id":data.id
          }
          form.val('red', obj);
          form.on('submit(formRed)',function(submitData){
            var reqData = submitData.field;
            parent.ajaxService.doPost('/gameType/updateMaxWinMoney.mvc',reqData,function(res){
              var msg = res.resultMessage;
              if(res.resultCode==0){
                peimissionGameManage.layerCallback(msg);
              }else{
                layer.msg(msg)
              }
            })
            return false;
          })
        }
      })
    }else if(event =='sort'){
      layer.open({
        title:'设置首页推荐顺序- <span class="red">'+data.name+'</span>',
        type: 1,
        skin: 'layui-layer-test',
        area: ['400px', '320px'],
        content: htmlTpl.sortHtml,
        success:function(){
          var obj={
            "recommendSort": data.recommendSort,
            "hotSort": data.hotSort,
            "recommendType": data.recommendType,
            "id":data.id
          }
          form.val('sort', obj);
          form.on('submit(formSort)',function(submitData){
            var reqData = submitData.field;
            reqData.recommendType = reqData.recommendType ? reqData.recommendType : '';
            parent.ajaxService.doPost('/gameType/updateRecommendSort.mvc',reqData,function(res){
              var msg = res.resultMessage;
              if(res.resultCode==0){
                peimissionGameManage.layerCallback(msg);
              }else{
                layer.msg(msg)
              }
            })
            return false;
          })
        }
      })
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    peimissionGameManage.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
  //监听单元格编辑
  peimissionGameManage.table.on('edit(demo)', function(obj){
    var value = obj.value //得到修改后的值
    ,data = obj.data //得到所在行所有键值
    ,field = obj.field; //得到字段
    var reqData={
      id:data.id,
      deep:value
    }
    parent.ajaxService.doPost('/gameType/update.mvc',reqData,function(res){
      var msg = res.resultMessage;
      if(res.resultCode==0){
        peimissionGameManage.layerCallback(msg);
      }else{
        layer.msg(msg)
      }
    })
  });
});



