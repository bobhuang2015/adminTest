
var rechargeProxy = {
  table:null,
  toolbarHtml:'',
  hasThrough:false,
  hasRefuse:false,
  pageNumber:1,
  tableIns:null,
  name:'proxy',
  tableData:[],
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action =window.name ||  parent.globalAdmin.getUrlParam('code');
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var obj={
      '通过':'hasThrough',
      '拒绝':'hasRefuse'
    }
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        this[obj[i]]=true;
      })
    }
  },
  reloadTable:function(){
    var _this=this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  formatStatus(status){
    var obj={
      "0":'未处理',
      "1":'已通过',
      "2":'已拒绝'
    }
    return obj[status]
  },
  formatType(type){
    var obj={
      '1':'其他',
      '2':'充值',
      '3':'分红',
      '4':'日工资'
    }
    return obj[type]
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getOptions:function(util){
    var arr=[
      { title: '操作', width: 110, toolbar: '#barDemo'}
      ,{ field: 'ordernumber', title: '订单号', width: 140, sort: true}
      , { field: 'outusername', title: '转出代理', width: 110,sort: true}
      , { field: 'outuserbalance', title: '转出前余额', width: 120,sort: true,templet:function(d){return d.outuserbalance.toFixed(3)}}
      , { field: 'inusername', title: '转入用户', width: 110,sort: true}
      , { field: 'inuserbalance', title: '转入前余额', width: 120,sort: true,templet:function(d){return d.inuserbalance.toFixed(3)}}
      , { field: 'transfertype', title: '转账类型', width: 110,sort: true,templet:function(d){return rechargeProxy.formatType(d.transfertype)}}
      , { field: 'amount', title: '金额', width: 100,sort: true,templet:function(d){return d.amount.toFixed(3)}}
      , { field: 'dme', title: '打码额', width: 100,sort: true,templet:function(d){return d.dme+'%'}}
      , { field: 'applydt', title: '申请时间', width: 150, sort: true,templet:function(d){return util.toDateString(d.applydt, "yyyy-MM-dd HH:mm:ss")}}
      , { field: 'status', title: '状态', width: 100,templet:function(d){return d.status ==2 ? `<div class='red'> ${rechargeProxy.formatStatus(d.status)}</div>` : rechargeProxy.formatStatus(d.status)}}
      , { title: '耗时', width: 140, sort: true,templet:function(d){return parent.globalAdmin.diffTime(d.processtime,d.applydt)}}
      , { field: 'operator', title: '操作者', width: 100}
      , { field: 'remark', title: '备注'}
    ]
    return arr
  },
  renderTotal(res){
    if (res.data && res.data.length > 0 && res.total){
      var str='<tr class="table-total"><td colspan="50">总量合计:';
      var obj={
        'fh':'分红',
        'qt':'其他',
        'cz':'充值',
        'rgz':'日工资'
      }
      for(var i in res.total){
        str+= `<span>${obj[i]}：${res.total[i]}</span>`
      }
      str +='</td></tr>';
      $('.layui-table-body table').append(str)
    }
  }
}

rechargeProxy.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  rechargeProxy.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  globalAdmin.renderRechargeDate(laydate,util)
  rechargeProxy.tableIns=rechargeProxy.table.render({
    elem: '#demo'
    , height: 'full-80'
    , url: ' /transferRecord/search.mvc'
    , page: true
    , method: 'get'
    , cols: [rechargeProxy.getOptions(util)],
    where: {
    }
    , parseData: function (res) {
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": res.results[0],
        "total":res.results[0].length > 0 && res.results[1]
      };
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      rechargeProxy.pageNumber=cur;
      rechargeProxy.tableData = res.data;
      rechargeProxy.renderTotal(res);
    }
  });
  
  // 金额验证;
  form.verify({
    money:function(value,item){
      if(+value >= 1000){
        return '打码额必须小于1000大于0'
      }
    }
  })

  // 工具栏操作
  rechargeProxy.table.on("tool(demo)",function(obj){
    var data = obj.data;
    var event = obj.event;
    switch (event) {
      case 'through':
        layer.open({
          title:'通过',
          type: 1,
          skin: 'layui-layer-test',
          area: ['600px', '240px'],
          content: htmlTpl.throughHtml,
          success:function(){
            form.on('submit(formThrough)',function(submitData){
              var reqUrl = '/transferRecord/promiseTransfer.mvc';
              var reqData =submitData.field 
              if(!reqData.dme)reqData.dme=-1;
              var reqData1 = Object.assign(reqData,{transferRecordId:data.id});
              parent.ajaxService.doPost(reqUrl,reqData1,function(res){
                var msg = res.resultMessage;
                if(res.resultCode==0){
                  rechargeProxy.layerCallback(msg);
                }else{
                  layer.msg(msg)
                }
              })
              return false;
            })
          }
        })
      break;
      case 'refuse':
        layer.open({
          title:'拒绝',
          type: 1,
          skin: 'layui-layer-test',
          area: ['600px', '160px'],
          content: htmlTpl.refuseHtml,
          success:function(){
            form.on('submit(formAdd)',function(submitData){
              var reqUrl = '/transferRecord/refuseTransfer.mvc';
              var reqData = submitData.field; 
              var reqData1 = Object.assign(reqData,{transferRecordId:data.id});
              parent.ajaxService.doPost(reqUrl,reqData1,function(res){
                var msg = res.resultMessage;
                if(res.resultCode==0){
                  rechargeProxy.layerCallback(msg);
                }else{
                  layer.msg(msg)
                }
              })
              return false;
            })
          }
        })
      break;
      default:
        break;
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    delete data.field.isAll;
    rechargeProxy.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        },
        done: function (res, cur, count) {
          rechargeProxy.renderTotal(res);
          rechargeProxy.tableData = res.data;
          rechargeProxy.pageNumber=cur;
        }
    })
    return false;
  });
  
  // 导出数据
  form.on('submit(formDaochu)', function (data) {
    parent.globalAdmin.exportData(form,data,rechargeProxy)
    return false;
  });
});



