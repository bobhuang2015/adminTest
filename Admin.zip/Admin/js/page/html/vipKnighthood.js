
var vipKnighthood = {
  table:null,
  hasSet:false,
  pageNumber:1,
  bankList:[],
  subPlatObj:{},
  globalAdmin:JSON.parse(localStorage.getItem('globalAdmin')),
  getToolbarHtml(){ 
    var action ='vip-set';
    var permision = this.globalAdmin.menuObj[action].permision;
    var otherHtml = "";
    var editHtml = "";
    var obj={
      '修改':'hasSet'
    }
    if(permision){
      permision.forEach((v,k)=>{
        var i = v.menuName;
        this[obj[i]]=true;
      })
    }
    this.getSub();
  },
  reloadTable:function(){
    var _this = this;
    this.table.reload('demo',{
      // where:data.field,
      page:{
        curr:_this.pageNumber  
      }
	  })
  },
  layerCallback(msg){
    var _this = this;
    layer.alert(msg,function(){
      layer.closeAll();
      _this.reloadTable();
    })
  },
  getSub(){
    var _this = this;
    parent.ajaxService.doGet('/getEnumByName.mvc',{enumName:'Game_SubType'},function(res){
      if(res.resultCode ==0 ){
        _this.subPlatObj = res.results[0]
      }
    })
  },
  getOptions:function(util){
    var arr=[
      { field: 'name', title: '爵位称号', width: 120, sort: true}
      , { field: 'minLevel', title: '等级范围', width: 120,templet:function(d){return d.minLevel +'~'+d.maxLevel+'级'}}
      , { field: 'userNum', title: '会员数量', width: 120, sort: true}
      , { field: 'cashGift', title: '爵位礼金', width: 120, sort: true}
      , { field: 'salary', title: '爵位俸禄', width: 120, sort: true}
      , { field: 'withdrawalsNum', title: '提现次数', width: 120, sort: true}
      , { field: 'withdrawalsLimit', title: '提现额度', width: 120, sort: true}
      , { field: 'subExperience', title: '衰减经验', width: 120, sort: true}
      , { title: '操作',toolbar: '#barDemo'}
    ]
    return arr
  },
  editIdArr:[],
  tableData:[],
  editAlert(title,data,form){
    var _this = this;
    layer.open({
      title:title,
      type: 1,
      skin: 'layui-layer-test',
      area: ['660px', '520px'],
      content: htmlTpl.knighthoodHtml,
      success:function(){
        $('.checkbox-list').append(html);
        var obj={
          "cashGift":data.cashGift,
          "salary":data.salary,
          "withdrawalsNum":data.withdrawalsNum,
          "withdrawalsLimit":data.withdrawalsLimit,
          "subExperience":data.subExperience,
          "bouns":data.bouns
        }
        
        var html='';
        var tempSubArr = [];
        var targetSubArr =[];
        for(var i in _this.subPlatObj){
          html +=`<input type="checkbox" name="subType[${i}]" title="${_this.subPlatObj[i]}" value="${i}" lay-skin="primary">`
          tempSubArr.push(i);
        }
        $('.fanwei-list').html(html);

        targetSubArr = data.subType ? data.subType.split(',') : tempSubArr;
        targetSubArr.forEach(function(v,k){
          Object.assign(obj,{['subType['+v+']']:true})
        })

        form.val('add',obj);
        form.render('checkbox');
        data.levelNo ==1 && $('.layui-special').attr('disabled',true).addClass('layui-disabled');
        form.on('submit(formAdd)',function(submitData){
          var reqUrl ='/vipNobilitySetup/edit.mvc';
          var fieldData = submitData.field;
          var tempArr=[];
          var subTypeArr=[];
          for(var i in fieldData){
            if(i.indexOf("subType")>-1){
              subTypeArr.push(fieldData[i])
            }
          }
          if(subTypeArr.length ==0){
            layer.msg('请至少勾选一个返点类型')
            return false;
          }
          var targetData = {
            cashGift:fieldData.cashGift,
            salary:fieldData.salary,
            withdrawalsNum:fieldData.withdrawalsNum,
            withdrawalsLimit:fieldData.withdrawalsLimit,
            subExperience:fieldData.subExperience,
            id:data.id,
            bouns:fieldData.bouns,
            subType:subTypeArr.join()
          }
          var reqData =  tempArr.push(targetData) && 'vipNobilitySetupList='+JSON.stringify(tempArr);
          parent.ajaxService.doPost(reqUrl,reqData,function(res){
            var msg = res.resultMessage;
            if(res.resultCode==0){
              vipKnighthood.layerCallback(msg);
            }else{
              layer.msg(msg)
            }
          })
          return false;
        })
      }
    })
  }
}

vipKnighthood.getToolbarHtml();
layui.use(['laydate', 'table', 'form', 'layer','util'], function () {
  var laydate = layui.laydate;
  vipKnighthood.table = layui.table;
  var form = layui.form;
  var layer = layui.layer;
  var util = layui.util;
  
  vipKnighthood.table.render({
    elem: '#demo'
    , height: `full-20`
    , url: '/vipNobilitySetup/getList.mvc'
    , page: false
    , method: 'get'
    , cols: [ vipKnighthood.getOptions(util)],
    where: {
    }
    , parseData: function (res) {
      var data = res.results.reverse();
      var result = {
        "code": res.resultCode, 
        "msg": res.resultMessage,
        "count": res.meta.totalRecord,
        "data": data
      };
      vipKnighthood.tableData=data;
      return result
    },
    response: {
      statusCode: '0'
    },
    done: function (res, cur, count) {
      vipKnighthood.pageNumber = cur;
    }
  });
  
  // 工具栏操作
  vipKnighthood.table.on("toolbar(demo)",function(res){
    var checkStatus = vipKnighthood.table.checkStatus(res.config.id);
    var data = checkStatus.data;
    switch (res.event) {
      case '新增':
        vipKnighthood.editAlert(res.event,data,form)
      break;
      default:
        // layer.msg("接口文档未完善，需要相应人员支持!")
        break;
    }
  })
  //监听行工具事件
  vipKnighthood.table.on('tool(demo)', function(obj){
    var data = obj.data;
    var event = obj.event;
    if(event ==='del'){
      layer.confirm("是否删除选中的平台?",{
          btn:['确定','取消']
        },function(){
        var reqData = {
          ids:data.id
        }
        parent.ajaxService.doPost("/vipExpRation/delete.mvc",reqData,function(res){
          var msg = res.resultMessage;
          if(res.resultCode ==0){
            vipKnighthood.layerCallback(msg);
          }else{
            layer.msg(msg);
          }
        })
        },function(index){
          layer.close(index)
        }
      )
    }else if(event === 'set'){
      vipKnighthood.editAlert('修改',data,form)
    }
  })
  // 表单提交demo
  form.on('submit(formDemo)', function (data) {
    vipKnighthood.table.reload('demo',{
        where:data.field,
        page:{
            curr:1  
        }
    })
    return false;
  });
  // laydate.render({
  //   elem: '#start',
  //   value:startDate
  //   ,btns: ['clear', 'confirm']
  //   ,max:0
  // });
  // laydate.render({
  //   elem: '#end',
  //   value:endDate 
  //   ,btns: ['clear', 'confirm']
  //   ,max:1
  // });
});



