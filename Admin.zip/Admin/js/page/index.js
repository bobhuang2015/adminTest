$(function() {
  var wsObj = null;
  getMenuList();
  $(document).on("click",'#logoutBtn',function(){
    logout();
  })
  function getMenuList() {
    ajaxService.doGet("/menu/getManageMenuList.mvc", null, function(res) {
      if (res.resultCode == 0) {
        var data = res.results;
        globalAdmin.baseInfo = data[1];
        renderNav(data[0]);
        getCenterData();
      }
    });
  }

  function renderNav(data) {
    $(".layui-nav-item > a").text(globalAdmin.baseInfo.account);
    var html = "";
    for (var i = 0; i < data.length; i++) {
      html +='<li><a href="javascript:;"><i class="iconfont">&#xe6eb;</i><cite>' + data[i].menuName +'</cite><i class="iconfont nav_right">&#xe6a7;</i></a>';
      var liHtml = "";
      if(data[i].childrens){
        for (var j = 0; j < data[i].childrens.length; j++) {
          for(var iv in globalAdmin.menuObj){
              if(iv == "iframe_"+data[i].childrens[j].id || iv == data[i].childrens[j].url){
                  var obj = {};
                  obj.action = "iframe_"+data[i].childrens[j].id;
                  obj.permision = data[i].childrens[j].childrens;
                  Object.assign(globalAdmin.menuObj[iv],obj);
              }
          }
          var id = "iframe_"+data[i].childrens[j].id;
          // var id = data[i].childrens[j].url;
          var hasUrl =  data[i].childrens[j].url;
          var menuName = data[i].childrens[j].menuName;   
          var menuCodeObj = globalAdmin.menuObj[''+hasUrl+''] || globalAdmin.menuObj[''+id+''];
          // var pageName = menuCodeObj ? menuCodeObj.page :'welcome';
          // liHtml +='<li data-name='+ menuName +'><a href="html/'+pageName+'.html?code='+id+'"  _href="html/'+pageName+'.html'+(pageName=='welcome' ? ('?name='+encodeURI(menuName)+'') : '')+'" data-act='+id+' onclick="return false;"><i class="iconfont">&#xe6a7;</i><cite>' +menuName +"</cite></a></li>";
          if(menuCodeObj)liHtml +='<li data-name='+ menuName +'><a href="html/'+menuCodeObj.page+'.html?code='+id+'"  _href="html/'+menuCodeObj.page+'.html" data-act='+id+' onclick="return false;"><i class="iconfont">&#xe6a7;</i><cite>' +menuName +"</cite></a></li>";
        }
      }
      html += '<ul class="sub-menu">' + liHtml + "</ul>" + "</li>";
    }
    $("#nav").html(html);
    leftNavEvents();
  }
  
  function getCenterData(){
    var p = new Promise((resolve,reject)=>{
          resolve(getMainName())
        })
        .then((res)=>{
          // globalAdmin.getGametype()
        })
    return p;
  }

  // 退出系统
  function logout(){
    ajaxService.doGet('/login/logout.mvc',null,function(res){
      if(res.httpCode==200){
        globalAdmin.wsObj && globalAdmin.wsObj.close();
        localStorage.clear();
        location.href="./login.html";
      }else{
        layer.msg(res.msg);
      }
    })
  }
  function leftNavEvents() {
    //加载弹出层
    layui.config({
      base: 'lib/layui_extends/module/',
    }).use(["form", "element",'tabrightmenu'], function() {
        layer = layui.layer;
        element = layui.element;
        var rightmenu = layui.tabrightmenu;
          rightmenu.render({
            container: '#nav_xbs_tab',
            filter: 'xbs_tab',
            navArr: [
              {eventName: 'refresh', title: '刷新当前页'},
              {eventName: 'closethis', title: '关闭当前页'},
              {eventName: 'newWindow', title: '新窗口打开'},
              {eventName: 'closeothers', title: '关闭其它页'}
            ]
          });
    });

    //触发事件
   tab = {
      tabAdd: function(title, url, id,action) {
        //新增一个Tab项
        var targetParam = url.indexOf('?') > -1 ? '&' : "?";
        element.tabAdd("xbs_tab", {
          title: title,
          content:'<iframe tab-id="' +id +'" frameborder="0" src="' +url+ targetParam+'loadTime='+Date.now()+'" scrolling="yes" class="x-iframe" name="'+action+'"></iframe>',
          id: id
        });
        $('.x-iframe[tab-id='+id+']').parent('.layui-tab-item').attr('data-id',id)
      },
      tabDelete: function(othis) {
        //删除指定Tab项
        element.tabDelete("xbs_tab", "44"); 
      },
      tabChange: function(id) {
        //切换到指定Tab项
        element.tabChange("xbs_tab", id); 
      }
    };

    tableCheck = {
      init: function() {
        $(".layui-form-checkbox").click(function(event) {
          if ($(this).hasClass("layui-form-checked")) {
            $(this).removeClass("layui-form-checked");
            if ($(this).hasClass("header")) {
              $(".layui-form-checkbox").removeClass("layui-form-checked");
            }
          } else {
            $(this).addClass("layui-form-checked");
            if ($(this).hasClass("header")) {
              $(".layui-form-checkbox").addClass("layui-form-checked");
            }
          }
        });
      },
      getData: function() {
        var obj = $(".layui-form-checked").not(".header");
        var arr = [];
        obj.each(function(index, el) {
          arr.push(obj.eq(index).attr("data-id"));
        });
        return arr;
      }
    };

    //开启表格多选
    tableCheck.init();


    $(".layui-tab").on("click",function(e){
       if($(e.target).is(".layui-tab-close")){
            tab.tabDelete();
      }
    })
    $(".container .left_open i").click(function(event) {
      if ($(".left-nav").css("left") == "0px") {
        $(".left-nav").animate({ left: "-181px" }, 100);
        $(".page-content").animate({ left: "0px" }, 100);
        $(".page-content-bg").hide();
      } else {
        $(".left-nav").animate({ left: "0px" }, 100);
        $(".page-content").animate({ left: "181px" }, 100);
        if ($(window).width() < 768) {
          $(".page-content-bg").show();
        }
      }
    });

    $(".page-content-bg").click(function(event) {
      $(".left-nav").animate({ left: "-181px" }, 100);
      $(".page-content").animate({ left: "0px" }, 100);
      $(this).hide();
    });

    $(".layui-tab-close").click(function(event) {
      $(".layui-tab-title li").eq(0).find("i").remove();
    });

    $("tbody.x-cate tr[fid!='0']").hide();
    // 栏目多级显示效果
    $(".x-show").click(function() {
      if ($(this).attr("status") == "true") {
        $(this).html("&#xe625;");
        $(this).attr("status", "false");
        cateId = $(this).parents("tr").attr("cate-id");
        $("tbody tr[fid=" + cateId + "]").show();
      } else {
        cateIds = [];
        $(this).html("&#xe623;");
        $(this).attr("status", "true");
        cateId = $(this).parents("tr").attr("cate-id");
        getCateId(cateId);
        for (var i in cateIds) {
          $("tbody tr[cate-id=" + cateIds[i] + "]").hide().find(".x-show").html("&#xe623;").attr("status", "true");
        }
      }
    });

    //左侧菜单效果
    $(document).ready(function() {
      $(".left-nav #nav li .sub-menu li").click(function() {
        $(this).addClass("menu-current").siblings().removeClass("menu-current");
      });
    });

    $(".left-nav #nav li .sub-menu li").click(function() {
      $(this).addClass("menu-current").siblings().removeClass("menu-current");
    });
    $(".left-nav #nav li").click(function(event) {
      if ($(this).children(".sub-menu").length) {
        if ($(this).hasClass("open")) {
          $(this).removeClass("open");
          $(this).find(".nav_right").html("&#xe6a7;");
          $(this).children(".sub-menu").stop().slideUp();
          $(this).siblings().children(".sub-menu").slideUp();
        } else {
          $(this).addClass("open");
          $(this).children("a").find(".nav_right").html("&#xe6a6;");
          $(this).children(".sub-menu").stop().slideDown();
          $(this).siblings().children(".sub-menu").stop().slideUp();
          $(this).siblings().find(".nav_right").html("&#xe6a7;");
          $(this).siblings().removeClass("open");
        }
      } else {
        var url = $(this).children("a").attr("_href");
        var title = $(this).find("cite").html();  
        var action = $(this).children("a").attr("data-act");
        var index = $(".left-nav #nav li").index($(this));
        // debugger;
        for (var i = 0; i < $(".x-iframe").length; i++) {
          if ($(".x-iframe").eq(i).attr("tab-id") ==index + 1) {
            tab.tabChange(index + 1);
            event.stopPropagation();
            return;
          }
        }
        tab.tabAdd(title, url, index + 1,action);
        tab.tabChange(index + 1);
        
        var activeUrl = $(this).children("a").attr('href');
        Object.assign(globalAdmin.openObj,{[index + 1]:activeUrl})
      }
      event.stopPropagation();
    });
  }
});
var cateIds = [];
function getCateId(cateId) {
    $("tbody tr[fid="+cateId+"]").each(function(index, el) {
        id = $(el).attr('cate-id');
        cateIds.push(id);
        getCateId(id);
    });
}

function getMainName(){
  ajaxService.doGet('/captcha/platform.mvc',null,function(res){
    if(res.resultCode ==0 ){
      $('title').html(res.results[0]);
    }
  })
}