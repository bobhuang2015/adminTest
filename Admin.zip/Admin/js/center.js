var globalAdmin = {
  baseInfo: {},
  openObj: {},
  isYesterday:0,
  tenantCode:'',
  menuObj:{
    'user-info': { page: "user-info" }, //会员管理-会员资料
    'user-level': { page: "user-level" }, //会员管理-会员分层
    'user-bank': { page: "user-bank" }, //会员管理-用户银行
    'user-log': { page: "user-log" }, //会员管理-用户日志
    'bank-detail': { page: "bank-detail" }, //出入款明细
    'bank-manage': { page: "bank-manage" }, //银行卡管理
    'bank-agentpay': { page: "bank-agentpay" }, //第三方代付配置
    'bank-baofoo': { page: "bank-baofoo" }, //银行管理-宝付账户
    'bank-offline': { page: "bank-offline" }, //银行管理-线下银行
    'bank-withdraw': { page: "bank-withdraw" }, //银行管理-提现银行管理
    'recharge-offline': { page: "recharge-offline" }, //充值提现-线下充值审核
    'recharge-online': { page: "recharge-online" }, //充值提现-在线充值订单
    'recharge-manual': { page: "recharge-manual" }, //充值提现-人工充值
    'recharge-record': { page: "recharge-record" }, //充值提现-充值记录
    'recharge-withdraw': { page: "recharge-withdraw" }, //充值提现-用户提现处理
    'recharge-deduction': { page: "recharge-deduction" }, //充值提现-人工扣款
    'recharge-proxy': { page: "recharge-proxy" }, //充值提现-代理转账处理
    'recharge-amount': { page: "recharge-amount" }, //充值提现-额度转换记录
    'recharge-code': { page: "recharge-code" }, //充值提现-打码限额
    'usercenter-password': { page: "usercenter-password" }, //用户中心-修改密码
    'usercenter-msg': { page: "usercenter-msg" }, //用户中心-消息管理
    'usercenter-notice': { page: "usercenter-notice" }, //用户中心-新闻公告
    'usercenter-promotions': { page: "usercenter-promotions" }, //用户中心-优惠活动
    'usercenter-picture': { page: "usercenter-picture" }, //用户中心-其他图片上传
    'usercenter-feedback': { page: "usercenter-feedback" }, //用户中心-意见反馈
    'usercenter-autored': { page: "usercenter-autored" }, //用户中心-自动红包管理
    'usercenter-autodividend': { page: "usercenter-autodividend" }, //用户中心-自动分红派发查询
    'usercenter-redmanage': { page: "usercenter-redmanage" }, //用户中心-红包管理
    'platformset-paramconfig': { page: "platformset-paramconfig" }, //平台设置-平台参数配置
    // 'platformset-paramconfigPT': { page: "platformset-paramconfig" }, //平台设置-普通参数配置
    'platformset-consumerebate': { page: "platformset-consumerebate" }, //平台设置-消费与亏损返利管理
    'platformset-loginip': { page: "platformset-loginip" }, //平台设置-前台登录IP限制
    'platformset-loginipHT': { page: "platformset-loginip" }, //平台设置-后台登录白名单
    'platformset-thirdrebate': { page: "platformset-thirdrebate" }, //平台设置-第三方返点配置
    'platformset-transferuser': { page: "platformset-transferuser" }, //平台设置-转移用户
    'platformset-taskmanage': { page: "platformset-taskmanage" }, //平台设置-任务管理
    'platformset-rebatelimit': { page: "platformset-rebatelimit" }, //平台设置-返点限制
    'set-single': { page: "set-single" }, //设置-单挑设置
    'set-redis': { page: "set-redis" }, //设置-刷新redis缓存
    'set-kgodds': { page: "set-kgodds" }, //设置-KG彩票赔率
    'bet-lotterynumber': { page: "bet-lotterynumber" }, //投注开奖-彩票开奖号码
    'bet-recordlist': { page: "bet-recordlist" }, //投注开奖-彩票投注记录
    'bet-zhuihaolist': { page: "bet-zhuihaolist" }, //投注开奖-彩票追号记录
    'bet-kgrecord': { page: "bet-kgrecord" }, //投注开奖-KG投注记录
    'bet-thirdgame': { page: "bet-thirdgame" }, //投注开奖-第三方投注记录
    'team-accountchange': { page: "team-accountchange" }, //团队账变明细-账变明细
    'team-dailywagereview': { page: "team-dailywagereview" }, //团队账变明细-分红与日工资审核
    'team-dailywagemanage': { page: "team-dailywagemanage" }, //团队账变明细-分红与日工资管理
    'profitloss-platform': { page: "profitloss-platform" }, //盈亏报表-平台盈亏报表
    'profitloss-team': { page: "profitloss-team" }, //盈亏报表-团队盈亏报表
    'profitloss-daily': { page: "profitloss-daily" }, //盈亏报表-团队日结报表
    'profitloss-user': { page: "profitloss-user" }, //盈亏报表-用户活跃报表
    'permission-system-manage': { page: "permission-system-manage" }, //权限配置-系统管理员
    'permission-roles-manage': { page: "permission-roles-manage" }, //权限配置-角色管理
    'permission-admin-log': { page: "permission-admin-log" }, //权限配置-管理员操作日志
    'permission-vip-log': { page: "permission-vip-log" }, //权限配置-会员操作日志
    'permission-rebate-quota': { page: "permission-rebate-quota" }, //权限配置-返点配额变动记录
    'permission-game-manage': { page: "permission-game-manage" }, //权限配置-游戏管理
    'permission-third-plat': { page: "permission-third-plat" }, //权限配置-第三方维护配置
    'permission-register-link': { page: "permission-register-link" }, //权限配置-注册链接管理
    'permission-menu-manage': { page: "permission-menu-manage" }, //权限管理-菜单管理
    'usercenter-thirdGame': { page: "usercenter-thirdGame" }, //权限管理-第三方游戏管理
    'usercenter-helpCenter': { page: "usercenter-helpCenter" }, //内容管理-帮助中心

    iframe_12: { page: "user-info" }, //会员管理-会员资料==》以下旧版
    iframe_13: { page: "user-level" }, //会员管理-会员分层
    iframe_14: { page: "user-bank" }, //会员管理-用户银行
    iframe_17: { page: "user-log" }, //会员管理-用户日志
    iframe_15: { page: "bank-detail" }, //出入款明细
    iframe_30: { page: "bank-manage" }, //银行卡管理
    iframe_16: { page: "finance-cashcardM" }, //财务报表-出款卡管理
    iframe_63: { page: "finance-cashcardM" }, //财务报表-收款卡管理
    iframe_18: { page: "finance-cashcardD" }, //财务报表-出款卡明细
    iframe_19: { page: "finance-cashcardD" }, //财务报表-收款卡明细
    iframe_31750: { page: "bank-agentpay" }, //第三方代付配置
    iframe_67: { page: "bank-baofoo" }, //银行管理-宝付账户
    iframe_68: { page: "bank-offline" }, //银行管理-线下银行
    iframe_65: { page: "bank-withdraw" }, //银行管理-提现银行管理
    iframe_62: { page: "bank-open" }, //银行管理-开放银行
    iframe_CZDL: { page: "bank-recharge" }, //银行管理-充值大类  未做
    iframe_21: { page: "recharge-offline" }, //充值提现-线下充值审核
    iframe_22: { page: "recharge-online" }, //充值提现-在线充值订单
    iframe_23: { page: "recharge-manual" }, //充值提现-人工充值
    iframe_24: { page: "recharge-record" }, //充值提现-充值记录
    iframe_25: { page: "recharge-withdraw" }, //充值提现-用户提现处理
    iframe_26: { page: "recharge-deduction" }, //充值提现-人工扣款
    iframe_27: { page: "recharge-proxy" }, //充值提现-代理转账处理
    iframe_28: { page: "recharge-amount" }, //充值提现-额度转换记录
    iframe_29: { page: "recharge-code" }, //充值提现-打码限额
    iframe_56: { page: "usercenter-password" }, //用户中心-修改密码
    iframe_57: { page: "usercenter-msg" }, //用户中心-消息管理
    iframe_58: { page: "usercenter-notice" }, //用户中心-新闻公告
    iframe_59: { page: "usercenter-promotions" }, //用户中心-优惠活动
    iframe_2507: { page: "usercenter-picture" }, //用户中心-其他图片上传
    iframe_2625: { page: "usercenter-feedback" }, //用户中心-意见反馈
    iframe_3478: { page: "usercenter-autored" }, //用户中心-自动红包管理
    iframe_3479: { page: "usercenter-autodividend" }, //用户中心-自动分红派发查询
    iframe_5027: { page: "usercenter-redmanage" }, //用户中心-红包管理
    iframe_HMXZ: { page: "platformset-numberlimit" }, //平台设置-号码限制
    iframe_64: { page: "platformset-paramconfig" }, //平台设置-平台参数配置
    // iframe_2893: { page: "platformset-paramconfig" }, //平台设置-普通参数配置 这个地方调整一定要改相应的js
    iframe_1748: { page: "platformset-consumerebate" }, //平台设置-消费与亏损返利管理
    // "iframe_1752":   { page: "platformset-dailywage"},//平台设置-日工资返利管理
    iframe_1761: { page: "platformset-loginip" }, //平台设置-前台登录IP限制
    iframe_1765: { page: "platformset-loginip" }, //平台设置-后台登录白名单
    iframe_1774: { page: "platformset-thirdrebate" }, //平台设置-第三方返点配置
    iframe_1773: { page: "platformset-thirdrebate" }, //平台设置-第三方返点配置
    iframe_APKBBXX: { page: "platformset-apkversion" }, //平台设置-apk版本信息
    iframe_SJXLGL: { page: "platformset-phoneline" }, //平台设置-手机线路管理
    iframe_2525: { page: "platformset-transferuser" }, //平台设置-转移用户
    iframe_2336: { page: "platformset-taskmanage" }, //平台设置-任务管理
    iframe_JCPESZ: { page: "platformset-basequota" }, //平台设置-基础配额设置  取消
    iframe_QHXF: { page: "platformset-periodrepair" }, //平台设置-期号修复
    iframe_3003: { page: "platformset-rebatelimit" }, //平台设置-返点限制
    // "iframe_5098":   { page: "set-sixhandicap"},//设置-六合彩盘口设置
    iframe_2334: { page: "set-single" }, //设置-单挑设置
    // "iframe_2371":   { page: "set-userlimit"},//设置-用户限制
    // "iframe_5105":   { page: "set-sixodds"},//设置-新六合彩KG赔率
    iframe_2513: { page: "set-redis" }, //设置-刷新redis缓存
    // "iframe_5102":   { page: "set-sixnumber"},//设置-六合彩生肖号码设置
    iframe_SLSZ: { page: "set-killrate" }, //设置-杀率设置
    iframe_2502: { page: "set-kgodds" }, //设置-KG彩票赔率
    iframe_JSFS: { page: "set-settlemethod" }, //设置-结算方式
    iframe_31: { page: "bet-lotterynumber" }, //投注开奖-彩票开奖号码
    iframe_32: { page: "bet-recordlist" }, //投注开奖-彩票投注记录
    iframe_33: { page: "bet-zhuihaolist" }, //投注开奖-彩票追号记录
    iframe_2504: { page: "bet-kgrecord" }, //投注开奖-KG投注记录
    iframe_2620: { page: "bet-kgzhuihao" }, //投注开奖-KG追号记录
    iframe_3000: { page: "bet-thirdgame" }, //投注开奖-第三方投注记录
    iframe_38: { page: "team-accountchange" }, //团队账变明细-账变明细
    iframe_DLFHGL: { page: "team-proxydividend" }, //团队账变明细-代理分红管理
    iframe_39: { page: "team-dailywagereview" }, //团队账变明细-分红与日工资审核
    iframe_2505: { page: "team-dailywagemanage" }, //团队账变明细-分红与日工资管理
    iframe_43: { page: "profitloss-platform" }, //盈亏报表-平台盈亏报表
    iframe_44: { page: "profitloss-team" }, //盈亏报表-团队盈亏报表
    iframe_45: { page: "profitloss-daily" }, //盈亏报表-团队日结报表
    iframe_46: { page: "profitloss-user" }, //盈亏报表-用户活跃报表
    iframe_48: { page: "permission-system-manage" }, //权限配置-系统管理员
    iframe_49: { page: "permission-roles-manage" }, //权限配置-角色管理
    iframe_51: { page: "permission-admin-log" }, //权限配置-管理员操作日志
    iframe_52: { page: "permission-vip-log" }, //权限配置-会员操作日志
    iframe_53: { page: "permission-rebate-quota" }, //权限配置-返点配额变动记录
    iframe_54: { page: "permission-game-manage" }, //权限配置-游戏管理
    iframe_66: { page: "permission-third-plat" }, //权限配置-第三方维护配置
    iframe_1745: { page: "permission-register-link" }, //权限配置-注册链接管理
    iframe_50: { page: "permission-menu-manage" }, //权限管理-菜单管理
    iframe_5082: { page: "usercenter-thirdGame" }, //权限管理-第三方游戏管理
    iframe_5091: { page: "usercenter-helpCenter" }, //内容管理-帮助中心
    "permission-global-log": { page: "permission-global-log" }, //权限配置-全局操作日志(线上),
    "permission-user-bet-log": { page: "permission-user-bet-log" }, //权限配置-用户投注日志(线上),
    "data-vip-retain": { page: "data-vip-retain" }, //数据分析-会员留存
    "userCenter-promotion-review": { page: "userCenter-promotion-review" }, //活动管理-派奖审核
    "permision-game-classic": { page: "permision-game-classic" }, //游戏管理-经典彩票赔率
    "data-game-analyse": { page: "data-game-analyse" }, //游戏分析-数据分析
    "vip-set": { page: "vip-set" }, //vip设置
    "interest-set": { page: "interest-set" }, //利息宝设置
    "permission-sys-log": { page: "permission-sys-log" }, //更新日志
    "permission-black-list": { page: "permission-black-list" }, //黑名单设置
    "userCenter-red-list": { page: "userCenter-red-list" }, //活动管理-管理员红包列表
    "userCenter-red-set": { page: "userCenter-red-set" }, //活动管理-管理员红包设置列表
  },
  uploadInfo: {}, //上传基础信息
  roleidArr: [], //角色id
  gameListArr: [], //彩种游戏
  selfGameList: {}, //自家彩种
  gameDigits: {}, //自家彩种位数
  classicGameList:[],//经典彩票
  userLevelArr: [], //用户层级数组
  userLevelObj: {}, //用户层级对象
  thirdPlatform: {}, //第三方平台
  rechargeMethod: [], //充值大类
  limitUserArr: [], //限制用户
  limitWindowName: "",
  thirdStateObj: {}, //第三方投注状态
  wsObj: null, //消息推送相关
  showLayer: function(title, url, w, h, str) {
    //此方法为公用弹窗，适用于打开一个html弹窗进行编辑
    if (title == null || title == "") {
      title = false;
    }
    if (url == null || url == "") {
      url = "404.html";
    }
    if (w == null || w == "") {
      w = $(window).width() * 0.92;
    }
    if (h == null || h == "") {
      h = $(window).height() - 50;
    }
    var obj = {
      type: 2,
      area: [w + "px", h + "px"],
      fix: false, //不固定
      shadeClose: false,
      shade: 0.4,
      title: title,
      content: url
    };
    var limitObj = {
      btn: ["确定", "取消"],
      yes: function(index) {
        layer.close(index);
        var limitWindowName = sessionStorage.getItem("limitWindowName");
        $(window.frames[limitWindowName].document)
          .find("#layui-user")
          .val(top.globalAdmin.limitUserArr.join());
      }
    };
    if ((str = "limitUser")) Object.assign(obj, limitObj);
    layer.open(obj);
  },
  getUrlParam(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); //构造一个含有目标参数的正则表达式对象
    var r = window.location.search.substr(1).match(reg); //匹配目标参数
    if (r != null) return unescape(r[2]);
    return null; //返回参数值
  },
  commafy(num){
  	return num && num
  		.toString()
  		.replace(/(\d)(?=(\d{3})+\.)/g, function($1, $2){
  			return $2 + ',';
  		});
  },
  formatNum(str) {
    var newStr = "";
    var count = 0;
    str = ""+str;
    if (str.indexOf(".") == -1) {
      for (var i = str.length - 1; i >= 0; i--) {
        if (count % 3 == 0 && count != 0) {
          newStr = str.charAt(i) + "," + newStr;
        } else {
          newStr = str.charAt(i) + newStr;
        }
        count++;
      }
      str = newStr + ".00"; //自动补小数点后两位
    } else {
      for (var i = str.indexOf(".") - 1; i >= 0; i--) {
        if (count % 3 == 0 && count != 0) {
          newStr = str.charAt(i) + "," + newStr;
        } else {
          newStr = str.charAt(i) + newStr; //逐个字符相接起来
        }
        count++;
      }
      str = newStr + (str + "00").substr((str + "00").indexOf("."), 3);
    }
    return str
  },
  checkboxEdit(page, name) {
    /**
     * page (当前页面自定义的唯一全局变量，例如userLevel)
     * name (当前页面的window的name属性)
     */
    var _this = this;
    var $docuemt = null;
    name ? ($docuemt = $(window.frames[name].document)) : ($docuemt = $(document));
    page.table.on("checkbox(demo)", function(obj) {
      var $allBtn = $docuemt.find(".layui-table-tool-temp > button");
      var $editBtn = $docuemt.find(
        '.layui-table-tool-temp > button:not("#删除")'
      );
      var $delBtn = $docuemt.find("#删除");
      var disabledClass = "layui-btn-disabled";
      var clickClass = "layui-table-click";
      if (obj.type == "all" && obj.checked) {
        // 全选
        page.editIdArr = [];
        page.tableData.forEach((v, k) => {
          page.editIdArr.push(v.id);
        });
        $delBtn.removeClass(disabledClass);
        if ($delBtn.length > 0) {
          $editBtn.addClass(disabledClass);
        } else {
          $editBtn.removeClass(disabledClass);
        }
        $docuemt
          .find(".layui-table-body table.layui-table tbody tr")
          .addClass(clickClass);
      } else if (obj.type == "all" && !obj.checked) {
        // 全不选
        page.editIdArr = [];
        $allBtn.addClass(disabledClass);
        $docuemt
          .find(".layui-table-body table.layui-table tbody tr")
          .removeClass(clickClass);
      } else if (obj.checked && obj.type == "one") {
        // 单选
        page.editIdArr.push(obj.data.id);
        if (page.editIdArr.length > 1) {
          if ($delBtn.length > 0) {
            $editBtn.addClass(disabledClass);
          } else {
          }
        } else {
          $allBtn.removeClass(disabledClass);
        }
        if (obj.checked == true) {
          obj.tr.addClass(clickClass);
        } else {
          obj.tr.removeClass(clickClass);
        }
      } else if (!obj.checked && obj.type == "one") {
        // 单不选
        var index = page.editIdArr.findIndex(v => v == obj.data.id);
        page.editIdArr.splice(index, 1);
        if (page.editIdArr.length == 0) {
          $allBtn.addClass(disabledClass);
        } else if (page.editIdArr.length == 1) {
          $editBtn.removeClass(disabledClass);
        }
        if (obj.tr.hasClass(clickClass)) {
          obj.tr.removeClass(clickClass);
        }
      }
    });
  },
  /**
   * 共用耗时计算方法
   */
  diffTime: function(startDate, endDate) {
    if (!startDate) return "";
    var diff = startDate - endDate;
    var days = Math.floor(diff / (24 * 3600 * 1000));
    var leave1 = diff % (24 * 3600 * 1000);
    var hours = Math.floor(leave1 / (3600 * 1000));
    var leave2 = leave1 % (3600 * 1000);
    var minutes = Math.floor(leave2 / (60 * 1000));
    var leave3 = leave2 % (60 * 1000);
    var seconds = Math.round(leave3 / 1000);
    var returnStr = seconds + "秒";
    return days + "天" + hours + "小时" + minutes + "分" + returnStr;
  },
  getRoleAndLevel(params) {
    //角色与层级
    var _this = this;
    ajaxService.doPost("/userInfo/getRoleAndLevel.mvc", null, function(res) {
      if (res.resultCode == 0) {
        var level = res.results[0]["userLevelList"];
        var role = res.results[0]["roleList"];
        _this.userLevelArr = level;
        _this.roleidArr = role;
        level.forEach(function(v, k) {
          Object.assign(_this.userLevelObj, { [v.id]: v.name });
        });
        _this.getThirdPlatform();
      }
    });
  },
  getGametype() {
    //彩种游戏
    var _this = this;
    _this.getWsUrl();
    ajaxService.doGet("/gameType/list.mvc", null, function(res) {
      if (res.resultCode == 0) {
        var data = res.results;
        globalAdmin.gameListArr = data;
        data.forEach((v, k) => {
          if (v.self) {
            Object.assign(_this.selfGameList, { [v.id]: v.name });
          }
          Object.assign(_this.gameDigits, {
            [v.id]: { digits: v.digits, long: v.noGroup }
          });
        });
        _this.getRoleAndLevel();
      }else{
        layer.msg(res.resultsMessage+',出错接口是:/gameType/list.mvc')
      }
    });
  },
  getUploadInfo() {
    //上传图片基础信息
    var _this = this;
    ajaxService.doGet("/promotions/platformurl.mvc", { url: "http" }, function(res) {
      if (res.responseCode == 0) {
        _this.uploadInfo = res.responseData;
        localStorage.setItem("globalAdmin", JSON.stringify(globalAdmin));
      }else{
        layer.msg(res.resultsMessage+',出错接口是:/promotions/platformurl.mvc')
      }
    });
  },
  renderIntDate(laydate, util, plat) {
    var _this = this;
    //日期格式初始化
    function renderDate(id) {
      var today = new Date().getTime();
      var oneDay = 1000 * 60 * 60 * 24;
      var monthDay = 30 * oneDay;
      // today = !_this.isYesterday ? today  : today - oneDay;
      var tomorrow =  today + oneDay ;
      var obj = {
        elem: `#${id}`,
        value: util.toDateString(id == "start" ? today : tomorrow,"yyyy-MM-dd"),
        btns: ["clear", "confirm"],
        max: id == "start" ? 0 : !plat ? 1 : 10000
      }
      if(_this.isYesterday){
        var today1 = today - monthDay;
        var tomorrow1 = today;
        obj.value= util.toDateString(id == "start" ? today1 : tomorrow1,"yyyy-MM-dd")
      }
      laydate.render(obj);
    }
    renderDate("start");
    renderDate("end");
  },
  renderRechargeDate(laydate, util, id) {
    var today = new Date().getTime();
    var todayTimeInit = util.toDateString(today, "yyyy-MM-dd") + " 00:00:00";
    var tomorrowTimeInit =util.toDateString(today + 1000 * 60 * 60 * 24, "yyyy-MM-dd") +" 00:00:00";
    laydate.render({
      elem: id ? `#start${id}` : "#start",
      value: todayTimeInit,
      btns: ["clear", "confirm"],
      type: "datetime",
      max: 1
    });
    laydate.render({
      elem: id ? `#end${id}` : "#end",
      value: tomorrowTimeInit,
      btns: ["clear", "confirm"],
      type: "datetime",
      max: 1
    });
  },
  getThirdPlatform() {
    var _this = this;
    ajaxService.doGet(
      "/getEnumByName.mvc",
      { enumName: "ThirdParty_Platform" },
      function(res) {
        if (res.resultCode == 0) {
          _this.thirdPlatform = res.results[0];
          _this.getUploadInfo();
        }
      }
    );
  },
  goLoginHtml() {
    layer.alert("登录失效，请重新登录!", function() {
      parent.location.href = "../login.html";
    });
  },
  getWsUrl() {
    var _this = this;
    ajaxService.doGet("/kjmanager/message/push-config.mvc", null, function(res) {
      if (res.resultCode == 0) {
        var data = res.results[0];
        _this.tenantCode = data.tenant;
        if (data.tenant === 'MY') {
          $('#layui-logo').attr('src',`./images/logo/${data.tenant}.png`)
        } else {
          $('#layui-logo').attr('src',`./images/logo/${data.tenant}.svg`)
        }
        _this.wsObj = new WebSocket(
          `${data.messageWsUrl}?tenant=${data.tenant}&token=${data.messageToken}&userType=BACKEND`
        );
        layui.use(["layer"], function() {
          var layer = layui.layer;
          // 推送相关逻辑
          _this.wsObj.onmessage = function(event) {
            var data = JSON.parse(event.data);
            if (data.type == "SYS") {
              var messageBody = JSON.parse(data.body);
              layer.open({
                type: 1,
                offset: "rb",
                shade: 0,
                content: `<div style="padding: 20px;">${messageBody.message}</div>`,
                area: ["300px", "200px"],
                time: 60 * 1000
              });
              var codeObj = JSON.parse(data.body);
              // 语音播报404 提现,403 充值,401 转账
              if (
                codeObj.code == 404 ||
                codeObj.code == 403 ||
                codeObj.code == 401
              ) {
                // var _audio = $(document).find('#layui-audio').get(0);
                // if(!_audioObj.paused)_video.ended();
                var audioObj = {
                  "404": "money_out_apply",
                  "403": "money_in_verify",
                  "401": "transfer_apply"
                };
                $(document)
                  .find("#layui-audio")
                  .attr("src", `../mp3/${audioObj[codeObj.code]}.mp3`);
                document.getElementById("layui-audio").play();
              }
            }
          };
        });
      }
    });
  },
  getColor(num) {
    return +num >= 0 ? "red" : "green";
  },
  clearNoNum(obj){
    obj.value = obj.value.replace(/[^\d.]/g,"");
    obj.value = obj.value.replace(/\.{2,}/g,".");
    obj.value = obj.value.replace(".","$#$").replace(/\./g,"").replace("$#$",".");
    obj.value = obj.value.replace(/^(\-)*(\d+)\.(\d\d).*$/,'$1$2.$3');
    if(obj.value.indexOf(".")< 0 && obj.value !=""){
      obj.value= parseFloat(obj.value);
    }
  },
  showMore(ele,name){
    var $document = null;
    name ? ($document = $(window.frames[name].document)) : ($document = $(document));
    $document.on('click','.layui-btn-more',function(){
      $document.find(ele).slideToggle(200);
      $(this).toggleClass('r180')
    })
  },
  exportData(form,data,obj){
    var reqData = data.field;
    var targetUrl = '';
    var host = location.protocol+'//'+location.host;
    if(reqData.isAll !='' && obj.tableData.length > 0){
      obj.name !='profitLossLottery' && obj.name !='userInfo' && Object.assign(reqData,{page:obj.pageNumber,limit:obj.tableIns.config.limit});
      switch (obj.name) {
        case 'thirdGame':
          targetUrl = `${host}/thirdPartyBetRecordsWeb/thirdPartyBetRecordsDownload.mvc?platform=${reqData.platform}&billNo=${reqData.billNo}&userName=${reqData.userName}&betTimeBegin=${reqData.betTimeBegin}&betTimeEnd=${reqData.betTimeEnd}&page=${reqData.page}&limit=${reqData.limit}&isAll=${reqData.isAll}`
          break;
        case 'rechargeRecord':
          targetUrl = `${host}/moneyInRecord/moneyInRecordDownload.mvc?isceshi=${reqData.isceshi}&way=${reqData.way}&ordernumber=${reqData.ordernumber}&platformbankaccountname=${reqData.platformbankaccountname}&page=${reqData.page}&limit=${reqData.limit}&isAll=${reqData.isAll}&username=${reqData.username}&rechargedt_begin=${reqData.rechargedt_begin}&rechargedt_end=${reqData.rechargedt_end}&remark=${reqData.remark}`
          break;
        case 'manual':
          targetUrl = `${host}/systemDepositAndWithdraw/download.mvc?changeitem=${reqData.changeitem}&ordernumber=${reqData.ordernumber}&username=${reqData.username}&page=${reqData.page}&limit=${reqData.limit}&isAll=${reqData.isAll}&changetime_begin=${reqData.changetime_begin}&changetime_end=${reqData.changetime_end}&operator=${reqData.operator}&remark=${reqData.remark}`
          break;
        case 'teamUser':
          targetUrl = `${host}/termsProfitStatistics/usersStatisDownload.mvc?statisticsTime_begin=${reqData.statisticsTime_begin}&statisticsTime_end=${reqData.statisticsTime_end}&username=${reqData.username}&usernameQuery=${reqData.usernameQuery}&page=${reqData.page}&limit=${reqData.limit}&isAll=${reqData.isAll}`
          break;
        case 'proxy':
          targetUrl = `${host}/transferRecord/download.mvc?status=${reqData.status}&ordernumber=${reqData.ordernumber}&outusername=${reqData.outusername}&inusername=${reqData.inusername}&page=${reqData.page}&limit=${reqData.limit}&isAll=${reqData.isAll}&applydt_begin=${reqData.applydt_begin}&applydt_end=${reqData.applydt_end}`
          break;
        case 'betRecordList':
          targetUrl = `${host}/betrecord/betRecordDownload.mvc?gametype=${reqData.gametype}&playtype=${reqData.playtype}&bettype=${reqData.bettype}&iszhuihao=${reqData.iszhuihao}&state=${reqData.state}&iswin=${reqData.iswin}&username=${reqData.username}&usernameQuery=${reqData.usernameQuery}&ordernumber=${reqData.ordernumber}&issueno=${reqData.issueno}&mobileBet=${reqData.mobileBet}&isceshi=${reqData.isceshi}&betMoneyTotal_begin=${reqData.betMoneyTotal_begin}&betMoneyTotal_end=${reqData.betMoneyTotal_end}&betdt_begin=${reqData.betdt_begin}&betdt_end=${reqData.betdt_end}&page=${reqData.page}&limit=${reqData.limit}&isAll=${reqData.isAll}`
        break
        case 'betKGRecordList':
          targetUrl = `${host}/kjbetrecord/kjBetRecordDownload.mvc?gametype=${reqData.gametype}&playtype=${reqData.playtype}&state=${reqData.state}&iswin=${reqData.iswin}&username=${reqData.username}&usernameQuery=${reqData.usernameQuery}&ordernumber=${reqData.ordernumber}&issueno=${reqData.issueno}&mobileBet=${reqData.mobileBet}&isceshi=${reqData.isceshi}&betMoneyTotal_begin=${reqData.betMoneyTotal_begin}&betMoneyTotal_end=${reqData.betMoneyTotal_end}&betdt_begin=${reqData.betdt_begin}&betdt_end=${reqData.betdt_end}&page=${reqData.page}&limit=${reqData.limit}&isAll=${reqData.isAll}&cathecticType=${reqData.cathecticType}`
        break
        case 'profitLossLottery':
          targetUrl = `${host}/platformPOL/lotteryPOLStatisDownload.mvc?reportdate_begin=${reqData.reportdate_begin}&reportdate_end=${reqData.reportdate_end}`
        break;
        case 'userInfo':
          targetUrl = `${host}/userInfo/userDownload.mvc?usernameQuery=${reqData.usernameQuery}&usertype=${reqData.usertype}&onlinestatus=${reqData.onlinestatus}&userstate=${reqData.userstate}&loginlocked=${reqData.loginlocked}&regsource=${reqData.regsource}&nickname=${reqData.nickname}&username=${reqData.username}&userlevels=${reqData.userlevels}&roleids=${reqData.roleids}&bonus_begin=${reqData.bonus_begin}&bonus_end=${reqData.bonus_end}&moneyinamount_begin=${reqData.moneyinamount_begin}&moneyinamount_end=${reqData.moneyinamount_end}&outmoneytotal_begin=${reqData.outmoneytotal_begin}&outmoneytotal_end=${reqData.outmoneytotal_end}&reg_time_begin=${reqData.reg_time_begin}&reg_time_end=${reqData.reg_time_end}&lastlogindt_begin=${reqData.lastlogindt_begin}&lastlogindt_end=${reqData.lastlogindt_end}&regLink=${reqData.regLink}`
        break;
        default:
          break;
      }
      window.open(targetUrl)
    }else if(obj.name !='userInfo' && reqData.isAll ==''){
      layer.msg('请选择是否全部导出!')
    }else if(obj.tableData.length ==0 ){
      parent.layer.msg('当前无数据导出!')
    }
  },
  selectTable(name) {
    name ? ($docuemt = $(window.frames[name].document)) : ($docuemt = $(document));
    $docuemt.on( "click", ".layui-table-body table.layui-table tbody tr",function() {
        var index = $(this).attr("data-index");
        var tableBox = $(this).parents(".layui-table-box");
        //存在固定列
        if (
          tableBox.find(".layui-table-fixed.layui-table-fixed-l").length > 0
        ) {
          tableDiv = tableBox.find(".layui-table-fixed.layui-table-fixed-l");
        } else {
          tableDiv = tableBox.find(".layui-table-body.layui-table-main");
        }
        var checkCell = tableDiv
          .find("tr[data-index=" + index + "]")
          .find("td div.laytable-cell-checkbox div.layui-form-checkbox i");
        if (checkCell.length > 0) {
          checkCell.click();
        }
      }
    );
    $docuemt.on( "click","td div.laytable-cell-checkbox div.layui-form-checkbox",function(e) {
        e.stopPropagation();
      }
    );
  },
  toggleClick(name,data){ //待合并
    var _this = this;
    name ? ($docuemt = $(window.frames[name].document)) : ($docuemt = $(document));
    $docuemt.on('click','.layui-table-main table tr .iconfont',function(){
      var targetId = $(this).attr('data-id');
      var iconJia = 'icon-jiahao',iconJian = 'icon-jianhao';
      if($(this).hasClass(iconJia)){
        $(this).addClass(iconJian).removeClass(iconJia);
        var targetArr = data.tableData.filter(v=>{return v.id == targetId});
        data.detailData = targetArr[0];
        $(this).parents('tr').after('<tr class="detail'+targetId+'"><td colspan="14"><iframe src="./userInfo-detail.html?time='+new Date().getTime()+'" frameborder="0" style="width:95%;padding-left:154px;height:80px;"></iframe></td></tr>')
      }else{
        $(this).addClass(iconJia).removeClass(iconJian);
        $docuemt.find(`tr.detail${targetId}`).remove();
      }
    })
  }
};

var ajaxService = {
  t: new Date().getTime(),
  doPost: function(url, params, callback, name) {
    this.doAjax("post", url, params, callback, true, name);
  },
  doGet: function(url, params, callback) {
    this.doAjax("get", url + "?t=" + this.t, params, callback, true);
  },

  doSyncPost: function(url, params, callback) {
    this.doAjax("post", url, params, callback, false);
  },

  doAjax: function(method, url, params, callback, async, name) {
    var reqUrl = this.buildApiUrl(url);
    $.ajax({
      url: reqUrl,
      type: method,
      dataType: "json",
      async: async,
      traditional: true,
      contentType:
        name != "baofoo"
          ? "application/x-www-form-urlencoded; charset=UTF-8"
          : "application/json",
      data: params,
      success: function(data) {
        if (callback) {
          callback(data);
        }
      },
      error: function(xhr, state, errorThrown) {
        if (xhr.responseText.indexOf("login-form") > 0) {
          if (location.href.indexOf("login") > -1) {
            // url =='/login/auth-data.mvc' && layer.msg('授权码验证失败')
          } else {
            $("body").html("");
            layui.use(["layer"], function() {
              var layer = layui.layer;
              globalAdmin.goLoginHtml();
            });
          }
        } else {
          var status = xhr.status;
          switch (+status) {
            case 504:
            case 503:
            case 500:
              layer.alert("系统错误,请联系管理员!");
              break;
            case 409:
              layer.alert("操作失败(409),请联系管理员!");
              break;
            default:
              layer.alert("操作失败!");
              break;
          }
        }
        console.log("出错接口URL是:" + url);
      }
    });
  },
  buildApiUrl: function(url) {
    return url;
  }
};
